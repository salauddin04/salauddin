package com.google.android.gms.ads_base;

/* renamed from: com.google.android.gms.ads_base.R */
public final class C0337R {
    private C0337R() {
    }
}
