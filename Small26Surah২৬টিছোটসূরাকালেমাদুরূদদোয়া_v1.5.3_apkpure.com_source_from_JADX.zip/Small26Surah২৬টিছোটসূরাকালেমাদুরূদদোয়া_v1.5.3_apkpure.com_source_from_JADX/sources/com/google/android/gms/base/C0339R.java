package com.google.android.gms.base;

import com.sahell.small26surah.C0393R;

/* renamed from: com.google.android.gms.base.R */
public final class C0339R {

    /* renamed from: com.google.android.gms.base.R$attr */
    public static final class attr {
        public static final int buttonSize = 2130903117;
        public static final int circleCrop = 2130903125;
        public static final int colorScheme = 2130903142;
        public static final int imageAspectRatio = 2130903223;
        public static final int imageAspectRatioAdjust = 2130903224;
        public static final int scopeUris = 2130903348;

        private attr() {
        }
    }

    /* renamed from: com.google.android.gms.base.R$color */
    public static final class color {
        public static final int common_google_signin_btn_text_dark = 2131034154;
        public static final int common_google_signin_btn_text_dark_default = 2131034155;
        public static final int common_google_signin_btn_text_dark_disabled = 2131034156;
        public static final int common_google_signin_btn_text_dark_focused = 2131034157;
        public static final int common_google_signin_btn_text_dark_pressed = 2131034158;
        public static final int common_google_signin_btn_text_light = 2131034159;
        public static final int common_google_signin_btn_text_light_default = 2131034160;
        public static final int common_google_signin_btn_text_light_disabled = 2131034161;
        public static final int common_google_signin_btn_text_light_focused = 2131034162;
        public static final int common_google_signin_btn_text_light_pressed = 2131034163;
        public static final int common_google_signin_btn_tint = 2131034164;

        private color() {
        }
    }

    /* renamed from: com.google.android.gms.base.R$drawable */
    public static final class drawable {
        public static final int common_full_open_on_phone = 2131165285;
        public static final int common_google_signin_btn_icon_dark = 2131165286;
        public static final int common_google_signin_btn_icon_dark_focused = 2131165287;
        public static final int common_google_signin_btn_icon_dark_normal = 2131165288;
        public static final int common_google_signin_btn_icon_dark_normal_background = 2131165289;
        public static final int common_google_signin_btn_icon_disabled = 2131165290;
        public static final int common_google_signin_btn_icon_light = 2131165291;
        public static final int common_google_signin_btn_icon_light_focused = 2131165292;
        public static final int common_google_signin_btn_icon_light_normal = 2131165293;
        public static final int common_google_signin_btn_icon_light_normal_background = 2131165294;
        public static final int common_google_signin_btn_text_dark = 2131165295;
        public static final int common_google_signin_btn_text_dark_focused = 2131165296;
        public static final int common_google_signin_btn_text_dark_normal = 2131165297;
        public static final int common_google_signin_btn_text_dark_normal_background = 2131165298;
        public static final int common_google_signin_btn_text_disabled = 2131165299;
        public static final int common_google_signin_btn_text_light = 2131165300;
        public static final int common_google_signin_btn_text_light_focused = 2131165301;
        public static final int common_google_signin_btn_text_light_normal = 2131165302;
        public static final int common_google_signin_btn_text_light_normal_background = 2131165303;
        public static final int googleg_disabled_color_18 = 2131165314;
        public static final int googleg_standard_color_18 = 2131165315;

        private drawable() {
        }
    }

    /* renamed from: com.google.android.gms.base.R$id */
    public static final class id {
        public static final int adjust_height = 2131230749;
        public static final int adjust_width = 2131230750;
        public static final int auto = 2131230755;
        public static final int dark = 2131230784;
        public static final int icon_only = 2131230910;
        public static final int light = 2131230930;
        public static final int none = 2131230946;
        public static final int standard = 2131231063;
        public static final int wide = 2131231105;

        private id() {
        }
    }

    /* renamed from: com.google.android.gms.base.R$string */
    public static final class string {
        public static final int common_google_play_services_enable_button = 2131623971;
        public static final int common_google_play_services_enable_text = 2131623972;
        public static final int common_google_play_services_enable_title = 2131623973;
        public static final int common_google_play_services_install_button = 2131623974;
        public static final int common_google_play_services_install_text = 2131623975;
        public static final int common_google_play_services_install_title = 2131623976;
        public static final int common_google_play_services_notification_channel_name = 2131623977;
        public static final int common_google_play_services_notification_ticker = 2131623978;
        public static final int common_google_play_services_unsupported_text = 2131623980;
        public static final int common_google_play_services_update_button = 2131623981;
        public static final int common_google_play_services_update_text = 2131623982;
        public static final int common_google_play_services_update_title = 2131623983;
        public static final int common_google_play_services_updating_text = 2131623984;
        public static final int common_google_play_services_wear_update_text = 2131623985;
        public static final int common_open_on_phone = 2131623986;
        public static final int common_signin_button_text = 2131623987;
        public static final int common_signin_button_text_long = 2131623988;

        private string() {
        }
    }

    /* renamed from: com.google.android.gms.base.R$styleable */
    public static final class styleable {
        public static final int[] LoadingImageView = new int[]{C0393R.attr.circleCrop, C0393R.attr.imageAspectRatio, C0393R.attr.imageAspectRatioAdjust};
        public static final int LoadingImageView_circleCrop = 0;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 2;
        public static final int[] SignInButton = new int[]{C0393R.attr.buttonSize, C0393R.attr.colorScheme, C0393R.attr.scopeUris};
        public static final int SignInButton_buttonSize = 0;
        public static final int SignInButton_colorScheme = 1;
        public static final int SignInButton_scopeUris = 2;

        private styleable() {
        }
    }

    private C0339R() {
    }
}
