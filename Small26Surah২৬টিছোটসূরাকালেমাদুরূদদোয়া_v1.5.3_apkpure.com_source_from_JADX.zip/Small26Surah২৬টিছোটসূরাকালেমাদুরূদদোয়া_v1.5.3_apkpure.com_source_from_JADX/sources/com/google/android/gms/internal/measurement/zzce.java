package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzbr.zza;
import java.io.IOException;

public final class zzce extends zzip<zzce> {
    public String zzch;
    public Long zzxa;
    private Integer zzxb;
    public zza[] zzxc;
    public zzcd[] zzxd;
    public zzbx[] zzxe;
    private String zzxf;
    public Boolean zzxg;

    public zzce() {
        this.zzxa = null;
        this.zzch = null;
        this.zzxb = null;
        this.zzxc = new zza[0];
        this.zzxd = zzcd.zzje();
        this.zzxe = zzbx.zziz();
        this.zzxf = null;
        this.zzxg = null;
        this.zzand = null;
        this.zzanm = -1;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzce)) {
            return false;
        }
        zzce zzce = (zzce) obj;
        Long l = this.zzxa;
        if (l == null) {
            if (zzce.zzxa != null) {
                return false;
            }
        } else if (!l.equals(zzce.zzxa)) {
            return false;
        }
        String str = this.zzch;
        if (str == null) {
            if (zzce.zzch != null) {
                return false;
            }
        } else if (!str.equals(zzce.zzch)) {
            return false;
        }
        Integer num = this.zzxb;
        if (num == null) {
            if (zzce.zzxb != null) {
                return false;
            }
        } else if (!num.equals(zzce.zzxb)) {
            return false;
        }
        if (!zzit.equals(this.zzxc, zzce.zzxc) || !zzit.equals(this.zzxd, zzce.zzxd) || !zzit.equals(this.zzxe, zzce.zzxe)) {
            return false;
        }
        str = this.zzxf;
        if (str == null) {
            if (zzce.zzxf != null) {
                return false;
            }
        } else if (!str.equals(zzce.zzxf)) {
            return false;
        }
        Boolean bool = this.zzxg;
        if (bool == null) {
            if (zzce.zzxg != null) {
                return false;
            }
        } else if (!bool.equals(zzce.zzxg)) {
            return false;
        }
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                return this.zzand.equals(zzce.zzand);
            }
        }
        if (zzce.zzand != null) {
            if (zzce.zzand.isEmpty() == null) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int hashCode = (getClass().getName().hashCode() + 527) * 31;
        Long l = this.zzxa;
        int i = 0;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        String str = this.zzch;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        Integer num = this.zzxb;
        hashCode = (((((((hashCode + (num == null ? 0 : num.hashCode())) * 31) + zzit.hashCode(this.zzxc)) * 31) + zzit.hashCode(this.zzxd)) * 31) + zzit.hashCode(this.zzxe)) * 31;
        str = this.zzxf;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        Boolean bool = this.zzxg;
        hashCode = (hashCode + (bool == null ? 0 : bool.hashCode())) * 31;
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                i = this.zzand.hashCode();
            }
        }
        return hashCode + i;
    }

    public final void zza(zzin zzin) throws IOException {
        int i;
        Long l = this.zzxa;
        if (l != null) {
            zzin.zzi(1, l.longValue());
        }
        String str = this.zzch;
        if (str != null) {
            zzin.zzb(2, str);
        }
        Integer num = this.zzxb;
        if (num != null) {
            zzin.zzc(3, num.intValue());
        }
        zza[] zzaArr = this.zzxc;
        int i2 = 0;
        if (zzaArr != null && zzaArr.length > 0) {
            i = 0;
            while (true) {
                zza[] zzaArr2 = this.zzxc;
                if (i >= zzaArr2.length) {
                    break;
                }
                zzgh zzgh = zzaArr2[i];
                if (zzgh != null) {
                    zzin.zze(4, zzgh);
                }
                i++;
            }
        }
        zzcd[] zzcdArr = this.zzxd;
        if (zzcdArr != null && zzcdArr.length > 0) {
            i = 0;
            while (true) {
                zzcd[] zzcdArr2 = this.zzxd;
                if (i >= zzcdArr2.length) {
                    break;
                }
                zziv zziv = zzcdArr2[i];
                if (zziv != null) {
                    zzin.zza(5, zziv);
                }
                i++;
            }
        }
        zzbx[] zzbxArr = this.zzxe;
        if (zzbxArr != null && zzbxArr.length > 0) {
            while (true) {
                zzbxArr = this.zzxe;
                if (i2 >= zzbxArr.length) {
                    break;
                }
                zziv zziv2 = zzbxArr[i2];
                if (zziv2 != null) {
                    zzin.zza(6, zziv2);
                }
                i2++;
            }
        }
        str = this.zzxf;
        if (str != null) {
            zzin.zzb(7, str);
        }
        Boolean bool = this.zzxg;
        if (bool != null) {
            zzin.zzb(8, bool.booleanValue());
        }
        super.zza(zzin);
    }

    protected final int zzja() {
        int i;
        int zzja = super.zzja();
        Long l = this.zzxa;
        if (l != null) {
            zzja += zzin.zzd(1, l.longValue());
        }
        String str = this.zzch;
        if (str != null) {
            zzja += zzin.zzc(2, str);
        }
        Integer num = this.zzxb;
        if (num != null) {
            zzja += zzin.zzg(3, num.intValue());
        }
        zza[] zzaArr = this.zzxc;
        int i2 = 0;
        if (zzaArr != null && zzaArr.length > 0) {
            i = zzja;
            zzja = 0;
            while (true) {
                zza[] zzaArr2 = this.zzxc;
                if (zzja >= zzaArr2.length) {
                    break;
                }
                zzgh zzgh = zzaArr2[zzja];
                if (zzgh != null) {
                    i += zzeg.zzc(4, zzgh);
                }
                zzja++;
            }
            zzja = i;
        }
        zzcd[] zzcdArr = this.zzxd;
        if (zzcdArr != null && zzcdArr.length > 0) {
            i = zzja;
            zzja = 0;
            while (true) {
                zzcd[] zzcdArr2 = this.zzxd;
                if (zzja >= zzcdArr2.length) {
                    break;
                }
                zziv zziv = zzcdArr2[zzja];
                if (zziv != null) {
                    i += zzin.zzb(5, zziv);
                }
                zzja++;
            }
            zzja = i;
        }
        zzbx[] zzbxArr = this.zzxe;
        if (zzbxArr != null && zzbxArr.length > 0) {
            while (true) {
                zzbxArr = this.zzxe;
                if (i2 >= zzbxArr.length) {
                    break;
                }
                zziv zziv2 = zzbxArr[i2];
                if (zziv2 != null) {
                    zzja += zzin.zzb(6, zziv2);
                }
                i2++;
            }
        }
        str = this.zzxf;
        if (str != null) {
            zzja += zzin.zzc(7, str);
        }
        Boolean bool = this.zzxg;
        if (bool == null) {
            return zzja;
        }
        bool.booleanValue();
        return zzja + (zzin.zzaj(8) + 1);
    }

    public final /* synthetic */ zziv zza(zzim zzim) throws IOException {
        while (true) {
            int zzkj = zzim.zzkj();
            if (zzkj == 0) {
                return this;
            }
            if (zzkj == 8) {
                this.zzxa = Long.valueOf(zzim.zzlc());
            } else if (zzkj == 18) {
                this.zzch = zzim.readString();
            } else if (zzkj == 24) {
                this.zzxb = Integer.valueOf(zzim.zzlb());
            } else if (zzkj == 34) {
                zzkj = zziy.zzb(zzim, 34);
                zza[] zzaArr = this.zzxc;
                r1 = zzaArr == null ? 0 : zzaArr.length;
                r0 = new zza[(zzkj + r1)];
                if (r1 != 0) {
                    System.arraycopy(this.zzxc, 0, r0, 0, r1);
                }
                while (r1 < r0.length - 1) {
                    r0[r1] = (zza) zzim.zza(zza.zzgs());
                    zzim.zzkj();
                    r1++;
                }
                r0[r1] = (zza) zzim.zza(zza.zzgs());
                this.zzxc = r0;
            } else if (zzkj == 42) {
                zzkj = zziy.zzb(zzim, 42);
                zzcd[] zzcdArr = this.zzxd;
                r1 = zzcdArr == null ? 0 : zzcdArr.length;
                r0 = new zzcd[(zzkj + r1)];
                if (r1 != 0) {
                    System.arraycopy(this.zzxd, 0, r0, 0, r1);
                }
                while (r1 < r0.length - 1) {
                    r0[r1] = new zzcd();
                    zzim.zza(r0[r1]);
                    zzim.zzkj();
                    r1++;
                }
                r0[r1] = new zzcd();
                zzim.zza(r0[r1]);
                this.zzxd = r0;
            } else if (zzkj == 50) {
                zzkj = zziy.zzb(zzim, 50);
                zzbx[] zzbxArr = this.zzxe;
                r1 = zzbxArr == null ? 0 : zzbxArr.length;
                r0 = new zzbx[(zzkj + r1)];
                if (r1 != 0) {
                    System.arraycopy(this.zzxe, 0, r0, 0, r1);
                }
                while (r1 < r0.length - 1) {
                    r0[r1] = new zzbx();
                    zzim.zza(r0[r1]);
                    zzim.zzkj();
                    r1++;
                }
                r0[r1] = new zzbx();
                zzim.zza(r0[r1]);
                this.zzxe = r0;
            } else if (zzkj == 58) {
                this.zzxf = zzim.readString();
            } else if (zzkj == 64) {
                this.zzxg = Boolean.valueOf(zzim.zzkp());
            } else if (!super.zza(zzim, zzkj)) {
                return this;
            }
        }
    }
}
