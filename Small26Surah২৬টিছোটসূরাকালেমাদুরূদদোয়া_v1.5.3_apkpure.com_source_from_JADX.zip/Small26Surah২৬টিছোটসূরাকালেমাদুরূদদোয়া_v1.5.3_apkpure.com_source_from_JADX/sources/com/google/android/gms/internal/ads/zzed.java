package com.google.android.gms.internal.ads;

final class zzed {
    static zzdbp zzya;

    static boolean zzb(com.google.android.gms.internal.ads.zzdy r5) throws java.lang.IllegalAccessException, java.lang.reflect.InvocationTargetException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = zzya;
        r1 = 1;
        if (r0 == 0) goto L_0x0006;
    L_0x0005:
        return r1;
    L_0x0006:
        r0 = com.google.android.gms.internal.ads.zzact.zzcrm;
        r2 = com.google.android.gms.internal.ads.zzyr.zzpe();
        r0 = r2.zzd(r0);
        r0 = (java.lang.String) r0;
        r2 = 0;
        r3 = 0;
        if (r0 == 0) goto L_0x001c;
    L_0x0016:
        r4 = r0.length();
        if (r4 != 0) goto L_0x0037;
    L_0x001c:
        if (r5 != 0) goto L_0x0020;
    L_0x001e:
        r0 = r2;
        goto L_0x0034;
    L_0x0020:
        r0 = "zu6uZ8u7nNJHsIXbotuBCEBd9hieUh9UBKC94dMPsF422AtJb3FisPSqZI3W+06A";
        r4 = "tm6XtP5M5qvCs+TffoCZhF/AF3Fx7Ow8iqgApPbgXSw=";
        r5 = r5.zzc(r0, r4);
        if (r5 != 0) goto L_0x002b;
    L_0x002a:
        goto L_0x001e;
    L_0x002b:
        r0 = new java.lang.Object[r3];
        r5 = r5.invoke(r2, r0);
        r5 = (java.lang.String) r5;
        r0 = r5;
    L_0x0034:
        if (r0 != 0) goto L_0x0037;
    L_0x0036:
        return r3;
    L_0x0037:
        r5 = com.google.android.gms.internal.ads.zzcg.zza(r0, r1);	 Catch:{ IllegalArgumentException -> 0x005f }
        r5 = com.google.android.gms.internal.ads.zzdby.zzl(r5);	 Catch:{  }
        r0 = com.google.android.gms.internal.ads.zzddb.zzgpt;	 Catch:{  }
        com.google.android.gms.internal.ads.zzdbk.zza(r0);	 Catch:{  }
        r0 = new com.google.android.gms.internal.ads.zzddf;	 Catch:{  }
        r0.<init>();	 Catch:{  }
        com.google.android.gms.internal.ads.zzdce.zza(r0);	 Catch:{  }
        r0 = com.google.android.gms.internal.ads.zzdbp.class;	 Catch:{  }
        r5 = com.google.android.gms.internal.ads.zzdce.zza(r5, r2, r0);	 Catch:{  }
        r5 = com.google.android.gms.internal.ads.zzdce.zza(r5);	 Catch:{  }
        r5 = (com.google.android.gms.internal.ads.zzdbp) r5;	 Catch:{  }
        zzya = r5;	 Catch:{  }
        r5 = zzya;
        if (r5 == 0) goto L_0x005f;
    L_0x005e:
        return r1;
    L_0x005f:
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzed.zzb(com.google.android.gms.internal.ads.zzdy):boolean");
    }
}
