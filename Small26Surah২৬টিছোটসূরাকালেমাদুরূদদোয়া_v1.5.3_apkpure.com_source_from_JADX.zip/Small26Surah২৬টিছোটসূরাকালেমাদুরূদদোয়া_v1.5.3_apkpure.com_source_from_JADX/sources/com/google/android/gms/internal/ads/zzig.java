package com.google.android.gms.internal.ads;

import android.net.Uri;
import android.os.SystemClock;
import android.util.SparseArray;
import java.io.IOException;

public final class zzig implements zzhn, zzif, zzka {
    private final Uri uri;
    private zzho[] zzacr;
    private boolean zzacs;
    private int zzact;
    private boolean[] zzacv;
    private volatile zzhw zzadp;
    private final zzjp zzahu;
    private final zzid zzaic;
    private final zzjr zzaid;
    private final int zzaie;
    private final SparseArray<zzii> zzaif;
    private final int zzaig;
    private final boolean zzaih;
    private volatile boolean zzaii;
    private volatile zzio zzaij;
    private int zzaik;
    private long zzail;
    private boolean[] zzaim;
    private boolean[] zzain;
    private long zzaio;
    private long zzaip;
    private long zzaiq;
    private boolean zzair;
    private long zzais;
    private zzjz zzait;
    private zzih zzaiu;
    private IOException zzaiv;
    private boolean zzaiw;
    private int zzaix;
    private long zzaiy;
    private boolean zzaiz;
    private int zzaja;
    private int zzajb;

    public zzig(Uri uri, zzjp zzjp, zzid zzid, int i, int i2) {
        this(uri, zzjp, zzid, 2, i2, -1);
    }

    private zzig(Uri uri, zzjp zzjp, zzid zzid, int i, int i2, int i3) {
        this.uri = uri;
        this.zzahu = zzjp;
        this.zzaic = zzid;
        this.zzact = 2;
        this.zzaie = i2;
        this.zzaig = -1;
        this.zzaif = new SparseArray();
        this.zzaid = new zzjr(262144);
        this.zzaiq = -1;
        this.zzaih = true;
        zzid.zza(this);
    }

    public final boolean zzdg(long j) throws IOException {
        if (this.zzacs != null) {
            return true;
        }
        if (this.zzait == null) {
            this.zzait = new zzjz("Loader:ExtractorSampleSource");
        }
        zzfj();
        int i = 0;
        if (!(this.zzaij == null || this.zzaii == null)) {
            for (j = null; j < this.zzaif.size(); j++) {
                if (!((zzii) this.zzaif.valueAt(j)).zzfd()) {
                    j = null;
                    break;
                }
            }
            j = 1;
            if (j != null) {
                j = this.zzaif.size();
                this.zzain = new boolean[j];
                this.zzacv = new boolean[j];
                this.zzaim = new boolean[j];
                this.zzacr = new zzho[j];
                this.zzail = -1;
                while (i < j) {
                    zzhj zzfe = ((zzii) this.zzaif.valueAt(i)).zzfe();
                    this.zzacr[i] = new zzho(zzfe.mimeType, zzfe.zzack);
                    if (zzfe.zzack != -1 && zzfe.zzack > this.zzail) {
                        this.zzail = zzfe.zzack;
                    }
                    i++;
                }
                this.zzacs = true;
                return true;
            }
        }
        zzfl();
        return false;
    }

    public final int getTrackCount() {
        return this.zzaif.size();
    }

    public final zzho zzo(int i) {
        zzkh.checkState(this.zzacs);
        return this.zzacr[i];
    }

    public final void zza(int i, long j) {
        zzkh.checkState(this.zzacs);
        zzkh.checkState(this.zzain[i] ^ true);
        this.zzaik++;
        this.zzain[i] = true;
        this.zzaim[i] = true;
        if (this.zzaik == 1) {
            zzdi(j);
        }
    }

    public final void zzp(int i) {
        zzkh.checkState(this.zzacs);
        zzkh.checkState(this.zzain[i]);
        this.zzaik--;
        this.zzain[i] = false;
        this.zzacv[i] = false;
        if (this.zzaik == 0) {
            if (this.zzait.isLoading() != 0) {
                this.zzait.zzgb();
            } else {
                zzfn();
                this.zzaid.zzz(0);
            }
        }
    }

    public final boolean zzdh(long j) throws IOException {
        zzkh.checkState(this.zzacs);
        zzkh.checkState(this.zzaik > 0);
        this.zzaio = j;
        j = this.zzaio;
        int i = 0;
        while (true) {
            boolean[] zArr = this.zzain;
            if (i >= zArr.length) {
                break;
            }
            if (!zArr[i]) {
                ((zzii) this.zzaif.valueAt(i)).zzdr(j);
            }
            i++;
        }
        if (this.zzaiz == null) {
            if (zzfj() == null) {
                return false;
            }
        }
        return true;
    }

    public final int zza(int i, long j, zzhk zzhk, zzhm zzhm, boolean z) throws IOException {
        this.zzaio = j;
        j = this.zzacv;
        int i2 = 0;
        if (j[i]) {
            j[i] = null;
            return -5;
        }
        if (!z) {
            if (!zzfo()) {
                zzii zzii = (zzii) this.zzaif.valueAt(i);
                if (this.zzaim[i]) {
                    zzhk.zzado = zzii.zzfe();
                    zzhk.zzadp = this.zzadp;
                    this.zzaim[i] = null;
                    return -4;
                } else if (zzii.zza(zzhm) != 0) {
                    i = (this.zzaih == 0 || zzhm.zzaga >= this.zzaip) ? 0 : 1;
                    j = zzhm.flags;
                    if (i != 0) {
                        i2 = 134217728;
                    }
                    zzhm.flags = j | i2;
                    zzhm.zzaga += this.zzais;
                    return -3;
                } else if (this.zzaiz != 0) {
                    return -1;
                } else {
                    zzfl();
                    return -2;
                }
            }
        }
        zzfl();
        return -2;
    }

    public final void zzdi(long j) {
        zzkh.checkState(this.zzacs);
        int i = 0;
        zzkh.checkState(this.zzaik > 0);
        this.zzaij.zzfc();
        this.zzaip = j;
        if ((zzfo() ? this.zzaiq : this.zzaio) != j) {
            this.zzaio = j;
            int zzfo = zzfo() ^ 1;
            int i2 = 0;
            while (zzfo != 0 && i2 < this.zzaif.size()) {
                zzfo &= ((zzii) this.zzaif.valueAt(i2)).zzds(j);
                i2++;
            }
            if (zzfo == 0) {
                zzdt(j);
            }
            while (true) {
                j = this.zzacv;
                if (i < j.length) {
                    j[i] = 1;
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    public final long zzdu() {
        if (this.zzaiz) {
            return -3;
        }
        if (zzfo()) {
            return this.zzaiq;
        }
        long j = Long.MIN_VALUE;
        for (int i = 0; i < this.zzaif.size(); i++) {
            j = Math.max(j, ((zzii) this.zzaif.valueAt(i)).zzff());
        }
        return j == Long.MIN_VALUE ? this.zzaio : j;
    }

    public final void release() {
        zzkh.checkState(this.zzact > 0);
        int i = this.zzact - 1;
        this.zzact = i;
        if (i == 0) {
            zzjz zzjz = this.zzait;
            if (zzjz != null) {
                zzjz.release();
                this.zzait = null;
            }
        }
    }

    public final void zza(zzkc zzkc) {
        this.zzaiz = true;
    }

    public final void zzb(zzkc zzkc) {
        if (this.zzaik > null) {
            zzdt(this.zzaiq);
            return;
        }
        zzfn();
        this.zzaid.zzz(0);
    }

    public final void zza(zzkc zzkc, IOException iOException) {
        this.zzaiv = iOException;
        int i = 1;
        if (this.zzaja <= this.zzajb) {
            i = 1 + this.zzaix;
        }
        this.zzaix = i;
        this.zzaiy = SystemClock.elapsedRealtime();
        zzfk();
    }

    public final zzip zzs(int i) {
        zzii zzii = (zzii) this.zzaif.get(i);
        if (zzii != null) {
            return zzii;
        }
        zzip zzii2 = new zzii(this, this.zzaid);
        this.zzaif.put(i, zzii2);
        return zzii2;
    }

    public final void zzfi() {
        this.zzaii = true;
    }

    public final void zza(zzio zzio) {
        this.zzaij = zzio;
    }

    public final void zzb(zzhw zzhw) {
        this.zzadp = zzhw;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final boolean zzfj() throws java.io.IOException {
        /*
        r5 = this;
        r5.zzfk();
        r0 = r5.zzfo();
        r1 = 0;
        if (r0 == 0) goto L_0x000b;
    L_0x000a:
        return r1;
    L_0x000b:
        r0 = r5.zzacs;
        r2 = 1;
        if (r0 == 0) goto L_0x0031;
    L_0x0010:
        r0 = 0;
    L_0x0011:
        r3 = r5.zzain;
        r4 = r3.length;
        if (r0 >= r4) goto L_0x002d;
    L_0x0016:
        r3 = r3[r0];
        if (r3 == 0) goto L_0x002a;
    L_0x001a:
        r3 = r5.zzaif;
        r3 = r3.valueAt(r0);
        r3 = (com.google.android.gms.internal.ads.zzii) r3;
        r3 = r3.isEmpty();
        if (r3 != 0) goto L_0x002a;
    L_0x0028:
        r0 = 1;
        goto L_0x002e;
    L_0x002a:
        r0 = r0 + 1;
        goto L_0x0011;
    L_0x002d:
        r0 = 0;
    L_0x002e:
        if (r0 == 0) goto L_0x0031;
    L_0x0030:
        r1 = 1;
    L_0x0031:
        if (r1 != 0) goto L_0x0036;
    L_0x0033:
        r5.zzfl();
    L_0x0036:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzig.zzfj():boolean");
    }

    private final void zzdt(long j) {
        this.zzaiq = j;
        this.zzaiz = 0;
        if (this.zzait.isLoading() != null) {
            this.zzait.zzgb();
            return;
        }
        zzfn();
        zzfk();
    }

    private final void zzfk() {
        if (!this.zzaiz) {
            if (!this.zzait.isLoading()) {
                boolean z = true;
                int i = 0;
                if (this.zzaiv != null) {
                    if (this.zzaiu == null) {
                        z = false;
                    }
                    zzkh.checkState(z);
                    if (SystemClock.elapsedRealtime() - this.zzaiy >= Math.min((((long) this.zzaix) - 1) * 1000, 5000)) {
                        this.zzaiv = null;
                        if (this.zzacs) {
                            this.zzaij.zzfc();
                        } else {
                            while (i < this.zzaif.size()) {
                                ((zzii) this.zzaif.valueAt(i)).clear();
                                i++;
                            }
                            this.zzaiu = zzfm();
                        }
                        this.zzajb = this.zzaja;
                        this.zzait.zza(this.zzaiu, (zzka) this);
                    }
                    return;
                }
                this.zzais = 0;
                this.zzair = false;
                if (this.zzacs) {
                    zzkh.checkState(zzfo());
                    long j = this.zzail;
                    if (j == -1 || this.zzaiq < j) {
                        this.zzaiu = new zzih(this.uri, this.zzahu, this.zzaic, this.zzaid, this.zzaie, this.zzaij.zzdq(this.zzaiq));
                        this.zzaiq = -1;
                    } else {
                        this.zzaiz = true;
                        this.zzaiq = -1;
                        return;
                    }
                }
                this.zzaiu = zzfm();
                this.zzajb = this.zzaja;
                this.zzait.zza(this.zzaiu, (zzka) this);
            }
        }
    }

    private final void zzfl() throws IOException {
        if (this.zzaiv != null) {
            int i = this.zzaig;
            if (i == -1) {
                if (this.zzaij != null) {
                    this.zzaij.zzfc();
                }
                i = 3;
            }
            if (this.zzaix > i) {
                throw this.zzaiv;
            }
        }
    }

    private final zzih zzfm() {
        return new zzih(this.uri, this.zzahu, this.zzaic, this.zzaid, this.zzaie, 0);
    }

    private final void zzfn() {
        for (int i = 0; i < this.zzaif.size(); i++) {
            ((zzii) this.zzaif.valueAt(i)).clear();
        }
        this.zzaiu = null;
        this.zzaiv = null;
        this.zzaix = 0;
        this.zzaiw = false;
    }

    private final boolean zzfo() {
        return this.zzaiq != -1;
    }
}
