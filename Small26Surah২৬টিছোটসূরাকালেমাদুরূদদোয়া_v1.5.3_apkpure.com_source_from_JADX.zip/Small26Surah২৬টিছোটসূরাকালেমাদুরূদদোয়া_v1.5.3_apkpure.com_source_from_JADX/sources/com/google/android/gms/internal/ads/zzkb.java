package com.google.android.gms.internal.ads;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.io.IOException;

@SuppressLint({"HandlerLeak"})
final class zzkb extends Handler implements Runnable {
    private final zzkc zzaqk;
    private final zzka zzaql;
    private final int zzaqm = null;
    private volatile Thread zzaqn;
    private final /* synthetic */ zzjz zzaqo;

    public zzkb(zzjz zzjz, Looper looper, zzkc zzkc, zzka zzka, int i) {
        this.zzaqo = zzjz;
        super(looper);
        this.zzaqk = zzkc;
        this.zzaql = zzka;
    }

    public final void quit() {
        this.zzaqk.zzfp();
        if (this.zzaqn != null) {
            this.zzaqn.interrupt();
        }
    }

    public final void run() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = "LoadTask";
        r1 = 0;
        r2 = 1;
        r3 = java.lang.Thread.currentThread();	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
        r5.zzaqn = r3;	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
        r3 = r5.zzaqm;	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
        if (r3 <= 0) goto L_0x0014;	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
    L_0x000e:
        r3 = r5.zzaqm;	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
        r3 = (long) r3;	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
        java.lang.Thread.sleep(r3);	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
    L_0x0014:
        r3 = r5.zzaqk;	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
        r3 = r3.zzfq();	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
        if (r3 != 0) goto L_0x0021;	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
    L_0x001c:
        r3 = r5.zzaqk;	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
        r3.zzfr();	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
    L_0x0021:
        r5.sendEmptyMessage(r1);	 Catch:{ IOException -> 0x0054, InterruptedException -> 0x0047, Exception -> 0x0034, Error -> 0x0025 }
        return;
    L_0x0025:
        r1 = move-exception;
        r2 = "Unexpected error loading stream";
        android.util.Log.e(r0, r2, r1);
        r0 = 2;
        r0 = r5.obtainMessage(r0, r1);
        r0.sendToTarget();
        throw r1;
    L_0x0034:
        r1 = move-exception;
        r3 = "Unexpected exception loading stream";
        android.util.Log.e(r0, r3, r1);
        r0 = new com.google.android.gms.internal.ads.zzkd;
        r0.<init>(r1);
        r0 = r5.obtainMessage(r2, r0);
        r0.sendToTarget();
        return;
    L_0x0047:
        r0 = r5.zzaqk;
        r0 = r0.zzfq();
        com.google.android.gms.internal.ads.zzkh.checkState(r0);
        r5.sendEmptyMessage(r1);
        return;
    L_0x0054:
        r0 = move-exception;
        r0 = r5.obtainMessage(r2, r0);
        r0.sendToTarget();
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzkb.run():void");
    }

    public final void handleMessage(Message message) {
        if (message.what != 2) {
            this.zzaqo.zzaqj = false;
            this.zzaqo.zzaqi = null;
            if (this.zzaqk.zzfq()) {
                this.zzaql.zzb(this.zzaqk);
                return;
            }
            int i = message.what;
            if (i != 0) {
                if (i == 1) {
                    this.zzaql.zza(this.zzaqk, (IOException) message.obj);
                }
                return;
            }
            this.zzaql.zza(this.zzaqk);
            return;
        }
        throw ((Error) message.obj);
    }
}
