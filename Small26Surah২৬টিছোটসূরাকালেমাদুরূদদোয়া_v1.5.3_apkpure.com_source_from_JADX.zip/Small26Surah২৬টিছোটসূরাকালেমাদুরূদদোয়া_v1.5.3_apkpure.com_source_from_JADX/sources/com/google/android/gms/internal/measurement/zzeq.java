package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

final class zzeq<FieldDescriptorType extends zzes<FieldDescriptorType>> {
    private static final zzeq zzadt = new zzeq(true);
    private final zzhb<FieldDescriptorType, Object> zzadq = zzhb.zzbe(16);
    private boolean zzadr;
    private boolean zzads = false;

    private zzeq() {
    }

    private static void zza(com.google.android.gms.internal.measurement.zzif r2, java.lang.Object r3) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:29:0x004e in {2, 7, 11, 12, 17, 18, 19, 20, 21, 22, 23, 24, 26, 28} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        com.google.android.gms.internal.measurement.zzfb.checkNotNull(r3);
        r0 = com.google.android.gms.internal.measurement.zzer.zzadu;
        r2 = r2.zzpb();
        r2 = r2.ordinal();
        r2 = r0[r2];
        r0 = 1;
        r1 = 0;
        switch(r2) {
            case 1: goto L_0x0040;
            case 2: goto L_0x003d;
            case 3: goto L_0x003a;
            case 4: goto L_0x0037;
            case 5: goto L_0x0034;
            case 6: goto L_0x0031;
            case 7: goto L_0x0028;
            case 8: goto L_0x001e;
            case 9: goto L_0x0015;
            default: goto L_0x0014;
        };
    L_0x0014:
        goto L_0x0043;
    L_0x0015:
        r2 = r3 instanceof com.google.android.gms.internal.measurement.zzgh;
        if (r2 != 0) goto L_0x0026;
    L_0x0019:
        r2 = r3 instanceof com.google.android.gms.internal.measurement.zzfk;
        if (r2 == 0) goto L_0x0043;
    L_0x001d:
        goto L_0x0026;
    L_0x001e:
        r2 = r3 instanceof java.lang.Integer;
        if (r2 != 0) goto L_0x0026;
    L_0x0022:
        r2 = r3 instanceof com.google.android.gms.internal.measurement.zzfc;
        if (r2 == 0) goto L_0x0043;
    L_0x0026:
        r1 = 1;
        goto L_0x0043;
    L_0x0028:
        r2 = r3 instanceof com.google.android.gms.internal.measurement.zzdp;
        if (r2 != 0) goto L_0x0026;
    L_0x002c:
        r2 = r3 instanceof byte[];
        if (r2 == 0) goto L_0x0043;
    L_0x0030:
        goto L_0x0026;
    L_0x0031:
        r0 = r3 instanceof java.lang.String;
        goto L_0x0042;
    L_0x0034:
        r0 = r3 instanceof java.lang.Boolean;
        goto L_0x0042;
    L_0x0037:
        r0 = r3 instanceof java.lang.Double;
        goto L_0x0042;
    L_0x003a:
        r0 = r3 instanceof java.lang.Float;
        goto L_0x0042;
    L_0x003d:
        r0 = r3 instanceof java.lang.Long;
        goto L_0x0042;
    L_0x0040:
        r0 = r3 instanceof java.lang.Integer;
    L_0x0042:
        r1 = r0;
    L_0x0043:
        if (r1 == 0) goto L_0x0046;
    L_0x0045:
        return;
    L_0x0046:
        r2 = new java.lang.IllegalArgumentException;
        r3 = "Wrong object type used with protocol message reflection.";
        r2.<init>(r3);
        throw r2;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzeq.zza(com.google.android.gms.internal.measurement.zzif, java.lang.Object):void");
    }

    private zzeq(boolean z) {
        zzjz();
    }

    public static <T extends zzes<T>> zzeq<T> zzlx() {
        return zzadt;
    }

    final boolean isEmpty() {
        return this.zzadq.isEmpty();
    }

    public final void zzjz() {
        if (!this.zzadr) {
            this.zzadq.zzjz();
            this.zzadr = true;
        }
    }

    public final boolean isImmutable() {
        return this.zzadr;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzeq)) {
            return null;
        }
        return this.zzadq.equals(((zzeq) obj).zzadq);
    }

    public final int hashCode() {
        return this.zzadq.hashCode();
    }

    public final Iterator<Entry<FieldDescriptorType, Object>> iterator() {
        if (this.zzads) {
            return new zzfn(this.zzadq.entrySet().iterator());
        }
        return this.zzadq.entrySet().iterator();
    }

    final Iterator<Entry<FieldDescriptorType, Object>> descendingIterator() {
        if (this.zzads) {
            return new zzfn(this.zzadq.zzok().iterator());
        }
        return this.zzadq.zzok().iterator();
    }

    private final Object zza(FieldDescriptorType fieldDescriptorType) {
        fieldDescriptorType = this.zzadq.get(fieldDescriptorType);
        return fieldDescriptorType instanceof zzfk ? zzfk.zzne() : fieldDescriptorType;
    }

    private final void zza(FieldDescriptorType fieldDescriptorType, Object obj) {
        if (!fieldDescriptorType.zzmc()) {
            zza(fieldDescriptorType.zzma(), obj);
        } else if (obj instanceof List) {
            List arrayList = new ArrayList();
            arrayList.addAll((List) obj);
            ArrayList arrayList2 = (ArrayList) arrayList;
            int size = arrayList2.size();
            int i = 0;
            while (i < size) {
                Object obj2 = arrayList2.get(i);
                i++;
                zza(fieldDescriptorType.zzma(), obj2);
            }
            obj = arrayList;
        } else {
            throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
        }
        if (obj instanceof zzfk) {
            this.zzads = true;
        }
        this.zzadq.zza((Comparable) fieldDescriptorType, obj);
    }

    public final boolean isInitialized() {
        for (int i = 0; i < this.zzadq.zzoi(); i++) {
            if (!zzb(this.zzadq.zzbf(i))) {
                return false;
            }
        }
        for (Entry zzb : this.zzadq.zzoj()) {
            if (!zzb(zzb)) {
                return false;
            }
        }
        return true;
    }

    private static boolean zzb(Entry<FieldDescriptorType, Object> entry) {
        zzes zzes = (zzes) entry.getKey();
        if (zzes.zzmb() == zzik.MESSAGE) {
            if (zzes.zzmc()) {
                for (zzgh isInitialized : (List) entry.getValue()) {
                    if (!isInitialized.isInitialized()) {
                        return false;
                    }
                }
            }
            entry = entry.getValue();
            if (entry instanceof zzgh) {
                if (((zzgh) entry).isInitialized() == null) {
                    return false;
                }
            } else if ((entry instanceof zzfk) != null) {
                return true;
            } else {
                throw new IllegalArgumentException("Wrong object type used with protocol message reflection.");
            }
        }
        return true;
    }

    public final void zza(zzeq<FieldDescriptorType> zzeq) {
        for (int i = 0; i < zzeq.zzadq.zzoi(); i++) {
            zzc(zzeq.zzadq.zzbf(i));
        }
        for (FieldDescriptorType zzc : zzeq.zzadq.zzoj()) {
            zzc(zzc);
        }
    }

    private static Object zzj(Object obj) {
        if (obj instanceof zzgo) {
            return ((zzgo) obj).zznv();
        }
        if (!(obj instanceof byte[])) {
            return obj;
        }
        byte[] bArr = (byte[]) obj;
        Object obj2 = new byte[bArr.length];
        System.arraycopy(bArr, 0, obj2, 0, bArr.length);
        return obj2;
    }

    private final void zzc(Entry<FieldDescriptorType, Object> entry) {
        Comparable comparable = (zzes) entry.getKey();
        entry = entry.getValue();
        if (entry instanceof zzfk) {
            entry = zzfk.zzne();
        }
        Object zza;
        if (comparable.zzmc()) {
            zza = zza((zzes) comparable);
            if (zza == null) {
                zza = new ArrayList();
            }
            for (Object zzj : (List) entry) {
                ((List) zza).add(zzj(zzj));
            }
            this.zzadq.zza(comparable, zza);
        } else if (comparable.zzmb() == zzik.MESSAGE) {
            zza = zza((zzes) comparable);
            if (zza == null) {
                this.zzadq.zza(comparable, zzj(entry));
                return;
            }
            Object zza2;
            if (zza instanceof zzgo) {
                zza2 = comparable.zza((zzgo) zza, (zzgo) entry);
            } else {
                zza2 = comparable.zza(((zzgh) zza).zzmk(), (zzgh) entry).zzmr();
            }
            this.zzadq.zza(comparable, zza2);
        } else {
            this.zzadq.zza(comparable, zzj(entry));
        }
    }

    static void zza(zzeg zzeg, zzif zzif, int i, Object obj) throws IOException {
        if (zzif == zzif.GROUP) {
            zzgh zzgh = (zzgh) obj;
            zzfb.zzf(zzgh);
            zzeg.zzb(i, 3);
            zzgh.zzb(zzeg);
            zzeg.zzb(i, 4);
            return;
        }
        zzeg.zzb(i, zzif.zzpc());
        switch (zzer.zzacu[zzif.ordinal()]) {
            case 1:
                zzeg.zzd(((Double) obj).doubleValue());
                break;
            case 2:
                zzeg.zza(((Float) obj).floatValue());
                return;
            case 3:
                zzeg.zzaq(((Long) obj).longValue());
                return;
            case 4:
                zzeg.zzaq(((Long) obj).longValue());
                return;
            case 5:
                zzeg.zzaf(((Integer) obj).intValue());
                return;
            case 6:
                zzeg.zzas(((Long) obj).longValue());
                return;
            case 7:
                zzeg.zzai(((Integer) obj).intValue());
                return;
            case 8:
                zzeg.zzm(((Boolean) obj).booleanValue());
                return;
            case 9:
                ((zzgh) obj).zzb(zzeg);
                return;
            case 10:
                zzeg.zzb((zzgh) obj);
                return;
            case 11:
                if ((obj instanceof zzdp) != null) {
                    zzeg.zza((zzdp) obj);
                    return;
                } else {
                    zzeg.zzco((String) obj);
                    return;
                }
            case 12:
                if ((obj instanceof zzdp) != null) {
                    zzeg.zza((zzdp) obj);
                    return;
                }
                byte[] bArr = (byte[]) obj;
                zzeg.zze(bArr, null, bArr.length);
                return;
            case 13:
                zzeg.zzag(((Integer) obj).intValue());
                return;
            case 14:
                zzeg.zzai(((Integer) obj).intValue());
                return;
            case 15:
                zzeg.zzas(((Long) obj).longValue());
                return;
            case 16:
                zzeg.zzah(((Integer) obj).intValue());
                return;
            case 17:
                zzeg.zzar(((Long) obj).longValue());
                return;
            case 18:
                if ((obj instanceof zzfc) == null) {
                    zzeg.zzaf(((Integer) obj).intValue());
                    break;
                } else {
                    zzeg.zzaf(((zzfc) obj).zzgp());
                    return;
                }
            default:
                break;
        }
    }

    public final int zzly() {
        int i = 0;
        for (int i2 = 0; i2 < this.zzadq.zzoi(); i2++) {
            Entry zzbf = this.zzadq.zzbf(i2);
            i += zzb((zzes) zzbf.getKey(), zzbf.getValue());
        }
        for (Entry zzbf2 : this.zzadq.zzoj()) {
            i += zzb((zzes) zzbf2.getKey(), zzbf2.getValue());
        }
        return i;
    }

    public final int zzlz() {
        int i = 0;
        for (int i2 = 0; i2 < this.zzadq.zzoi(); i2++) {
            i += zzd(this.zzadq.zzbf(i2));
        }
        for (Entry zzd : this.zzadq.zzoj()) {
            i += zzd(zzd);
        }
        return i;
    }

    private static int zzd(Entry<FieldDescriptorType, Object> entry) {
        zzes zzes = (zzes) entry.getKey();
        Object value = entry.getValue();
        if (zzes.zzmb() != zzik.MESSAGE || zzes.zzmc() || zzes.zzmd()) {
            return zzb(zzes, value);
        }
        if (value instanceof zzfk) {
            return zzeg.zzb(((zzes) entry.getKey()).zzgp(), (zzfk) value);
        }
        return zzeg.zzd(((zzes) entry.getKey()).zzgp(), (zzgh) value);
    }

    static int zza(zzif zzif, int i, Object obj) {
        i = zzeg.zzaj(i);
        if (zzif == zzif.GROUP) {
            zzfb.zzf((zzgh) obj);
            i <<= 1;
        }
        return i + zzb(zzif, obj);
    }

    private static int zzb(zzif zzif, Object obj) {
        switch (zzer.zzacu[zzif.ordinal()]) {
            case 1:
                return zzeg.zze(((Double) obj).doubleValue());
            case 2:
                return zzeg.zzb(((Float) obj).floatValue());
            case 3:
                return zzeg.zzat(((Long) obj).longValue());
            case 4:
                return zzeg.zzau(((Long) obj).longValue());
            case 5:
                return zzeg.zzak(((Integer) obj).intValue());
            case 6:
                return zzeg.zzaw(((Long) obj).longValue());
            case 7:
                return zzeg.zzan(((Integer) obj).intValue());
            case 8:
                return zzeg.zzn(((Boolean) obj).booleanValue());
            case 9:
                return zzeg.zzd((zzgh) obj);
            case 10:
                if ((obj instanceof zzfk) != null) {
                    return zzeg.zza((zzfk) obj);
                }
                return zzeg.zzc((zzgh) obj);
            case 11:
                if ((obj instanceof zzdp) != null) {
                    return zzeg.zzb((zzdp) obj);
                }
                return zzeg.zzcp((String) obj);
            case 12:
                if ((obj instanceof zzdp) != null) {
                    return zzeg.zzb((zzdp) obj);
                }
                return zzeg.zzi((byte[]) obj);
            case 13:
                return zzeg.zzal(((Integer) obj).intValue());
            case 14:
                return zzeg.zzao(((Integer) obj).intValue());
            case 15:
                return zzeg.zzax(((Long) obj).longValue());
            case 16:
                return zzeg.zzam(((Integer) obj).intValue());
            case 17:
                return zzeg.zzav(((Long) obj).longValue());
            case 18:
                if ((obj instanceof zzfc) != null) {
                    return zzeg.zzap(((zzfc) obj).zzgp());
                }
                return zzeg.zzap(((Integer) obj).intValue());
            default:
                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
        }
    }

    private static int zzb(zzes<?> zzes, Object obj) {
        zzif zzma = zzes.zzma();
        int zzgp = zzes.zzgp();
        if (!zzes.zzmc()) {
            return zza(zzma, zzgp, obj);
        }
        int i = 0;
        if (zzes.zzmd() != null) {
            for (Object obj2 : (List) obj2) {
                i += zzb(zzma, obj2);
            }
            return (zzeg.zzaj(zzgp) + i) + zzeg.zzar(i);
        }
        for (Object obj22 : (List) obj22) {
            i += zza(zzma, zzgp, obj22);
        }
        return i;
    }

    public final /* synthetic */ Object clone() throws CloneNotSupportedException {
        zzeq zzeq = new zzeq();
        for (int i = 0; i < this.zzadq.zzoi(); i++) {
            Entry zzbf = this.zzadq.zzbf(i);
            zzeq.zza((zzes) zzbf.getKey(), zzbf.getValue());
        }
        for (Entry zzbf2 : this.zzadq.zzoj()) {
            zzeq.zza((zzes) zzbf2.getKey(), zzbf2.getValue());
        }
        zzeq.zzads = this.zzads;
        return zzeq;
    }
}
