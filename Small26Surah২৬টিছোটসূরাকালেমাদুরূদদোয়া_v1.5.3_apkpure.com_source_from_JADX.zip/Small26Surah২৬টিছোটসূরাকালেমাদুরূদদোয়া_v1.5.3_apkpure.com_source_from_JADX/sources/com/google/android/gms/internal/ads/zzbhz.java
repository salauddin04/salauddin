package com.google.android.gms.internal.ads;

public interface zzbhz {
    boolean zzaan();
}
