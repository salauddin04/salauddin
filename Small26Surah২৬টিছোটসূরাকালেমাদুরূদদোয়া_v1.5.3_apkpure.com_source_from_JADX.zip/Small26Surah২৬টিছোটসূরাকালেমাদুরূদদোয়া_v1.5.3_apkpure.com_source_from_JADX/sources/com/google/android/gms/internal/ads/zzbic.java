package com.google.android.gms.internal.ads;

import android.annotation.TargetApi;
import android.support.annotation.Nullable;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;

@TargetApi(21)
@zzare
public final class zzbic extends zzbib {
    public zzbic(zzbha zzbha, zzwh zzwh, boolean z) {
        super(zzbha, zzwh, z);
    }

    @Nullable
    public final WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
        if (webResourceRequest != null) {
            if (webResourceRequest.getUrl() != null) {
                return zza(webView, webResourceRequest.getUrl().toString(), webResourceRequest.getRequestHeaders());
            }
        }
        return null;
    }
}
