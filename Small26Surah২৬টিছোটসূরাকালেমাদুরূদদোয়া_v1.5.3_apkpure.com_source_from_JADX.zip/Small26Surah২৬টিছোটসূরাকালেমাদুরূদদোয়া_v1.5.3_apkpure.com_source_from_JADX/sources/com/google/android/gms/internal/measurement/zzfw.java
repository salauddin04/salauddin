package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzez.zze;

final class zzfw implements zzgz {
    private static final zzgg zzaiq = new zzfx();
    private final zzgg zzaip;

    public zzfw() {
        this(new zzfy(zzey.zzmf(), zznl()));
    }

    private zzfw(zzgg zzgg) {
        this.zzaip = (zzgg) zzfb.zza((Object) zzgg, "messageInfoFactory");
    }

    public final <T> zzgy<T> zze(Class<T> cls) {
        zzha.zzg(cls);
        zzgf zzc = this.zzaip.zzc(cls);
        if (zzc.zznt()) {
            if (zzez.class.isAssignableFrom(cls) != null) {
                return zzgn.zza(zzha.zzof(), zzep.zzlv(), zzc.zznu());
            }
            return zzgn.zza(zzha.zzod(), zzep.zzlw(), zzc.zznu());
        } else if (zzez.class.isAssignableFrom(cls)) {
            if (zza(zzc)) {
                return zzgl.zza((Class) cls, zzc, zzgr.zznx(), zzfr.zznj(), zzha.zzof(), zzep.zzlv(), zzge.zznq());
            }
            return zzgl.zza((Class) cls, zzc, zzgr.zznx(), zzfr.zznj(), zzha.zzof(), null, zzge.zznq());
        } else if (zza(zzc)) {
            return zzgl.zza((Class) cls, zzc, zzgr.zznw(), zzfr.zzni(), zzha.zzod(), zzep.zzlw(), zzge.zznp());
        } else {
            return zzgl.zza((Class) cls, zzc, zzgr.zznw(), zzfr.zzni(), zzha.zzoe(), null, zzge.zznp());
        }
    }

    private static boolean zza(zzgf zzgf) {
        return zzgf.zzns() == zze.zzahc ? true : null;
    }

    private static com.google.android.gms.internal.measurement.zzgg zznl() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = "com.google.protobuf.DescriptorMessageInfoFactory";	 Catch:{ Exception -> 0x0019 }
        r0 = java.lang.Class.forName(r0);	 Catch:{ Exception -> 0x0019 }
        r1 = "getInstance";	 Catch:{ Exception -> 0x0019 }
        r2 = 0;	 Catch:{ Exception -> 0x0019 }
        r3 = new java.lang.Class[r2];	 Catch:{ Exception -> 0x0019 }
        r0 = r0.getDeclaredMethod(r1, r3);	 Catch:{ Exception -> 0x0019 }
        r1 = 0;	 Catch:{ Exception -> 0x0019 }
        r2 = new java.lang.Object[r2];	 Catch:{ Exception -> 0x0019 }
        r0 = r0.invoke(r1, r2);	 Catch:{ Exception -> 0x0019 }
        r0 = (com.google.android.gms.internal.measurement.zzgg) r0;	 Catch:{ Exception -> 0x0019 }
        return r0;
    L_0x0019:
        r0 = zzaiq;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzfw.zznl():com.google.android.gms.internal.measurement.zzgg");
    }
}
