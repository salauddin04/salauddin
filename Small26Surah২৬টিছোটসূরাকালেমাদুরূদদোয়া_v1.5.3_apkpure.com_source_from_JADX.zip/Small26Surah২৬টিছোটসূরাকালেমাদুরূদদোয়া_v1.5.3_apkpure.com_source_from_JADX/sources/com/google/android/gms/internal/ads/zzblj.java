package com.google.android.gms.internal.ads;

public final class zzblj implements zzdth<zzacg> {
    private static final zzblj zzfeq = new zzblj();

    public static zzacg zzaer() {
        return (zzacg) zzdtn.zza(new zzacg(), "Cannot return null from a non-@Nullable @Provides method");
    }

    public final /* synthetic */ Object get() {
        return zzaer();
    }
}
