package com.google.android.gms.internal.ads;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.formats.NativeAd.AdChoicesInfo;
import com.google.android.gms.ads.formats.NativeAd.Image;
import com.google.android.gms.ads.formats.NativeContentAd;
import com.google.android.gms.dynamic.IObjectWrapper;
import java.util.ArrayList;
import java.util.List;

@zzare
public final class zzafc extends NativeContentAd {
    private final VideoController zzcjf = new VideoController();
    private final List<Image> zzcyt = new ArrayList();
    private final AdChoicesInfo zzcyv;
    private final zzaez zzcyw;
    private final zzaek zzcyx;

    public zzafc(zzaez zzaez) {
        zzaek zzaek;
        String str = "";
        this.zzcyw = zzaez;
        zzaez = null;
        try {
            List images = this.zzcyw.getImages();
            if (images != null) {
                for (Object next : images) {
                    zzaeh zzaej;
                    if (next instanceof IBinder) {
                        IBinder iBinder = (IBinder) next;
                        if (iBinder != null) {
                            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.INativeAdImage");
                            zzaej = queryLocalInterface instanceof zzaeh ? (zzaeh) queryLocalInterface : new zzaej(iBinder);
                            if (zzaej != null) {
                                this.zzcyt.add(new zzaek(zzaej));
                            }
                        }
                    }
                    zzaej = null;
                    if (zzaej != null) {
                        this.zzcyt.add(new zzaek(zzaej));
                    }
                }
            }
        } catch (Throwable e) {
            zzbae.zzc(str, e);
        }
        try {
            zzaeh zzrl = this.zzcyw.zzrl();
            if (zzrl != null) {
                zzaek = new zzaek(zzrl);
                this.zzcyx = zzaek;
                if (this.zzcyw.zzrj() != null) {
                    zzaez = new zzaec(this.zzcyw.zzrj());
                }
                this.zzcyv = zzaez;
            }
        } catch (Throwable e2) {
            zzbae.zzc(str, e2);
        }
        zzaek = null;
        this.zzcyx = zzaek;
        try {
            if (this.zzcyw.zzrj() != null) {
                zzaez = new zzaec(this.zzcyw.zzrj());
            }
        } catch (Throwable e22) {
            zzbae.zzc(str, e22);
        }
        this.zzcyv = zzaez;
    }

    private final IObjectWrapper zzrh() {
        try {
            return this.zzcyw.zzrh();
        } catch (Throwable e) {
            zzbae.zzc("", e);
            return null;
        }
    }

    public final void performClick(Bundle bundle) {
        try {
            this.zzcyw.performClick(bundle);
        } catch (Bundle bundle2) {
            zzbae.zzc("", bundle2);
        }
    }

    public final boolean recordImpression(Bundle bundle) {
        try {
            return this.zzcyw.recordImpression(bundle);
        } catch (Bundle bundle2) {
            zzbae.zzc("", bundle2);
            return null;
        }
    }

    public final void reportTouchEvent(Bundle bundle) {
        try {
            this.zzcyw.reportTouchEvent(bundle);
        } catch (Bundle bundle2) {
            zzbae.zzc("", bundle2);
        }
    }

    public final CharSequence getHeadline() {
        try {
            return this.zzcyw.getHeadline();
        } catch (Throwable e) {
            zzbae.zzc("", e);
            return null;
        }
    }

    public final List<Image> getImages() {
        return this.zzcyt;
    }

    public final CharSequence getBody() {
        try {
            return this.zzcyw.getBody();
        } catch (Throwable e) {
            zzbae.zzc("", e);
            return null;
        }
    }

    public final Image getLogo() {
        return this.zzcyx;
    }

    public final CharSequence getCallToAction() {
        try {
            return this.zzcyw.getCallToAction();
        } catch (Throwable e) {
            zzbae.zzc("", e);
            return null;
        }
    }

    public final CharSequence getAdvertiser() {
        try {
            return this.zzcyw.getAdvertiser();
        } catch (Throwable e) {
            zzbae.zzc("", e);
            return null;
        }
    }

    public final VideoController getVideoController() {
        try {
            if (this.zzcyw.getVideoController() != null) {
                this.zzcjf.zza(this.zzcyw.getVideoController());
            }
        } catch (Throwable e) {
            zzbae.zzc("Exception occurred while getting video controller", e);
        }
        return this.zzcjf;
    }

    public final Bundle getExtras() {
        try {
            return this.zzcyw.getExtras();
        } catch (Throwable e) {
            zzbae.zzc("", e);
            return null;
        }
    }

    public final AdChoicesInfo getAdChoicesInfo() {
        return this.zzcyv;
    }

    public final CharSequence getMediationAdapterClassName() {
        try {
            return this.zzcyw.getMediationAdapterClassName();
        } catch (Throwable e) {
            zzbae.zzc("", e);
            return null;
        }
    }

    public final void destroy() {
        try {
            this.zzcyw.destroy();
        } catch (Throwable e) {
            zzbae.zzc("", e);
        }
    }

    protected final /* synthetic */ Object zzkq() {
        return zzrh();
    }
}
