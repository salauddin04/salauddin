package com.google.android.gms.internal.measurement;

import android.content.ContentResolver;
import android.net.Uri;
import android.support.annotation.GuardedBy;
import android.support.v4.util.ArrayMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public final class zzcl implements zzcp {
    @GuardedBy("ConfigurationContentLoader.class")
    static final Map<Uri, zzcl> zzzi = new ArrayMap();
    private static final String[] zzzn = new String[]{"key", "value"};
    private final Uri uri;
    private final ContentResolver zzzj;
    private final Object zzzk = new Object();
    private volatile Map<String, String> zzzl;
    @GuardedBy("this")
    private final List<zzco> zzzm = new ArrayList();

    private zzcl(ContentResolver contentResolver, Uri uri) {
        this.zzzj = contentResolver;
        this.uri = uri;
        this.zzzj.registerContentObserver(uri, false, new zzcn(this, null));
    }

    public final void zzjk() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:21:0x0029 in {11, 13, 16, 20} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r2 = this;
        r0 = r2.zzzk;
        monitor-enter(r0);
        r1 = 0;
        r2.zzzl = r1;	 Catch:{ all -> 0x0026 }
        com.google.android.gms.internal.measurement.zzcw.zzjp();	 Catch:{ all -> 0x0026 }
        monitor-exit(r0);	 Catch:{ all -> 0x0026 }
        monitor-enter(r2);
        r0 = r2.zzzm;	 Catch:{ all -> 0x0023 }
        r0 = r0.iterator();	 Catch:{ all -> 0x0023 }
    L_0x0011:
        r1 = r0.hasNext();	 Catch:{ all -> 0x0023 }
        if (r1 == 0) goto L_0x0021;	 Catch:{ all -> 0x0023 }
    L_0x0017:
        r1 = r0.next();	 Catch:{ all -> 0x0023 }
        r1 = (com.google.android.gms.internal.measurement.zzco) r1;	 Catch:{ all -> 0x0023 }
        r1.zzjo();	 Catch:{ all -> 0x0023 }
        goto L_0x0011;	 Catch:{ all -> 0x0023 }
    L_0x0021:
        monitor-exit(r2);	 Catch:{ all -> 0x0023 }
        return;	 Catch:{ all -> 0x0023 }
    L_0x0023:
        r0 = move-exception;	 Catch:{ all -> 0x0023 }
        monitor-exit(r2);	 Catch:{ all -> 0x0023 }
        throw r0;
    L_0x0026:
        r1 = move-exception;
        monitor-exit(r0);	 Catch:{ all -> 0x0026 }
        throw r1;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzcl.zzjk():void");
    }

    final /* synthetic */ java.util.Map zzjm() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:24:0x0050 in {3, 9, 13, 14, 18, 20, 23} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r6 = this;
        r0 = r6.zzzj;
        r1 = r6.uri;
        r2 = zzzn;
        r3 = 0;
        r4 = 0;
        r5 = 0;
        r0 = r0.query(r1, r2, r3, r4, r5);
        if (r0 != 0) goto L_0x0014;
    L_0x000f:
        r0 = java.util.Collections.emptyMap();
        return r0;
    L_0x0014:
        r1 = r0.getCount();	 Catch:{ all -> 0x004b }
        if (r1 != 0) goto L_0x0022;	 Catch:{ all -> 0x004b }
    L_0x001a:
        r1 = java.util.Collections.emptyMap();	 Catch:{ all -> 0x004b }
        r0.close();
        return r1;
    L_0x0022:
        r2 = 256; // 0x100 float:3.59E-43 double:1.265E-321;
        if (r1 > r2) goto L_0x002c;
    L_0x0026:
        r2 = new android.support.v4.util.ArrayMap;	 Catch:{ all -> 0x004b }
        r2.<init>(r1);	 Catch:{ all -> 0x004b }
        goto L_0x0033;	 Catch:{ all -> 0x004b }
    L_0x002c:
        r2 = new java.util.HashMap;	 Catch:{ all -> 0x004b }
        r3 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;	 Catch:{ all -> 0x004b }
        r2.<init>(r1, r3);	 Catch:{ all -> 0x004b }
    L_0x0033:
        r1 = r0.moveToNext();	 Catch:{ all -> 0x004b }
        if (r1 == 0) goto L_0x0047;	 Catch:{ all -> 0x004b }
    L_0x0039:
        r1 = 0;	 Catch:{ all -> 0x004b }
        r1 = r0.getString(r1);	 Catch:{ all -> 0x004b }
        r3 = 1;	 Catch:{ all -> 0x004b }
        r3 = r0.getString(r3);	 Catch:{ all -> 0x004b }
        r2.put(r1, r3);	 Catch:{ all -> 0x004b }
        goto L_0x0033;
    L_0x0047:
        r0.close();
        return r2;
    L_0x004b:
        r1 = move-exception;
        r0.close();
        throw r1;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzcl.zzjm():java.util.Map");
    }

    public static com.google.android.gms.internal.measurement.zzcl zza(android.content.ContentResolver r3, android.net.Uri r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = com.google.android.gms.internal.measurement.zzcl.class;
        monitor-enter(r0);
        r1 = zzzi;	 Catch:{ all -> 0x001a }
        r1 = r1.get(r4);	 Catch:{ all -> 0x001a }
        r1 = (com.google.android.gms.internal.measurement.zzcl) r1;	 Catch:{ all -> 0x001a }
        if (r1 != 0) goto L_0x0018;
    L_0x000d:
        r2 = new com.google.android.gms.internal.measurement.zzcl;	 Catch:{ SecurityException -> 0x0018 }
        r2.<init>(r3, r4);	 Catch:{ SecurityException -> 0x0018 }
        r3 = zzzi;	 Catch:{ SecurityException -> 0x0017 }
        r3.put(r4, r2);	 Catch:{ SecurityException -> 0x0017 }
    L_0x0017:
        r1 = r2;
    L_0x0018:
        monitor-exit(r0);	 Catch:{ all -> 0x001a }
        return r1;	 Catch:{ all -> 0x001a }
    L_0x001a:
        r3 = move-exception;	 Catch:{ all -> 0x001a }
        monitor-exit(r0);	 Catch:{ all -> 0x001a }
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzcl.zza(android.content.ContentResolver, android.net.Uri):com.google.android.gms.internal.measurement.zzcl");
    }

    public final Map<String, String> zzjj() {
        Map<String, String> map = this.zzzl;
        if (map == null) {
            synchronized (this.zzzk) {
                map = this.zzzl;
                if (map == null) {
                    map = zzjl();
                    this.zzzl = map;
                }
            }
        }
        if (map != null) {
            return map;
        }
        return Collections.emptyMap();
    }

    private final java.util.Map<java.lang.String, java.lang.String> zzjl() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r2 = this;
        r0 = new com.google.android.gms.internal.measurement.zzcm;	 Catch:{ SecurityException -> 0x000c, SecurityException -> 0x000c, SecurityException -> 0x000c }
        r0.<init>(r2);	 Catch:{ SecurityException -> 0x000c, SecurityException -> 0x000c, SecurityException -> 0x000c }
        r0 = com.google.android.gms.internal.measurement.zzcq.zza(r0);	 Catch:{ SecurityException -> 0x000c, SecurityException -> 0x000c, SecurityException -> 0x000c }
        r0 = (java.util.Map) r0;	 Catch:{ SecurityException -> 0x000c, SecurityException -> 0x000c, SecurityException -> 0x000c }
        return r0;
    L_0x000c:
        r0 = "ConfigurationContentLoader";
        r1 = "PhenotypeFlag unable to load ContentProvider, using default values";
        android.util.Log.e(r0, r1);
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzcl.zzjl():java.util.Map<java.lang.String, java.lang.String>");
    }

    public final /* synthetic */ Object zzca(String str) {
        return (String) zzjj().get(str);
    }
}
