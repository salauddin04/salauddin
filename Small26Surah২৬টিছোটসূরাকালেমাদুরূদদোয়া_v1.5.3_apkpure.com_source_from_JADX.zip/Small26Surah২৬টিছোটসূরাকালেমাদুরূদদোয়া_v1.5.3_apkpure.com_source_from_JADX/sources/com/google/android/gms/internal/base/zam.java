package com.google.android.gms.internal.base;

public interface zam {
}
