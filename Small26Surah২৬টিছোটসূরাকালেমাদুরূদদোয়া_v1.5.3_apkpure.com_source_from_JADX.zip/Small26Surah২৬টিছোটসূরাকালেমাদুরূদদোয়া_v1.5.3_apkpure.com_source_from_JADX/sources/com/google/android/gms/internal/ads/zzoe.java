package com.google.android.gms.internal.ads;

final class zzoe implements zznq {
    zzoe() {
    }

    public final zznn[] zzih() {
        return new zznn[]{new zzod()};
    }
}
