package com.google.android.gms.internal.measurement;

interface zzho {
    int size();

    byte zzr(int i);
}
