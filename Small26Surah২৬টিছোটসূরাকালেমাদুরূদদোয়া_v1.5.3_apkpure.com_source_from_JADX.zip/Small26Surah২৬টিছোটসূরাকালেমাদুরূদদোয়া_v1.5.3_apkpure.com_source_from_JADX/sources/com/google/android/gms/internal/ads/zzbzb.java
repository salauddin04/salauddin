package com.google.android.gms.internal.ads;

import android.support.annotation.Nullable;
import android.support.v4.util.SimpleArrayMap;
import java.util.ArrayList;

public final class zzbzb {
    public static final zzbzb zzfpd = new zzbzd().zzaip();
    @Nullable
    private final zzafk zzfow;
    @Nullable
    private final zzafh zzfox;
    @Nullable
    private final zzafw zzfoy;
    @Nullable
    private final zzaft zzfoz;
    @Nullable
    private final zzajf zzfpa;
    private final SimpleArrayMap<String, zzafq> zzfpb;
    private final SimpleArrayMap<String, zzafn> zzfpc;

    @Nullable
    public final zzafk zzaii() {
        return this.zzfow;
    }

    @Nullable
    public final zzafh zzaij() {
        return this.zzfox;
    }

    @Nullable
    public final zzafw zzaik() {
        return this.zzfoy;
    }

    @Nullable
    public final zzaft zzail() {
        return this.zzfoz;
    }

    @Nullable
    public final zzajf zzaim() {
        return this.zzfpa;
    }

    @Nullable
    public final zzafq zzfn(String str) {
        return (zzafq) this.zzfpb.get(str);
    }

    @Nullable
    public final zzafn zzfo(String str) {
        return (zzafn) this.zzfpc.get(str);
    }

    public final ArrayList<String> zzain() {
        ArrayList<String> arrayList = new ArrayList();
        if (this.zzfoy != null) {
            arrayList.add(Integer.toString(6));
        }
        if (this.zzfow != null) {
            arrayList.add(Integer.toString(1));
        }
        if (this.zzfox != null) {
            arrayList.add(Integer.toString(2));
        }
        if (this.zzfpb.size() > 0) {
            arrayList.add(Integer.toString(3));
        }
        if (this.zzfpa != null) {
            arrayList.add(Integer.toString(7));
        }
        return arrayList;
    }

    public final ArrayList<String> zzaio() {
        ArrayList<String> arrayList = new ArrayList(this.zzfpb.size());
        for (int i = 0; i < this.zzfpb.size(); i++) {
            arrayList.add((String) this.zzfpb.keyAt(i));
        }
        return arrayList;
    }

    private zzbzb(zzbzd zzbzd) {
        this.zzfow = zzbzd.zzfow;
        this.zzfox = zzbzd.zzfox;
        this.zzfoy = zzbzd.zzfoy;
        this.zzfpb = new SimpleArrayMap(zzbzd.zzfpb);
        this.zzfpc = new SimpleArrayMap(zzbzd.zzfpc);
        this.zzfoz = zzbzd.zzfoz;
        this.zzfpa = zzbzd.zzfpa;
    }
}
