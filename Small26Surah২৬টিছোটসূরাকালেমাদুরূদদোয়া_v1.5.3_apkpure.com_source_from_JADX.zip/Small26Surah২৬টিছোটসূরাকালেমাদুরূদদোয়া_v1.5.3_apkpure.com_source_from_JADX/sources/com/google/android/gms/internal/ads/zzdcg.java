package com.google.android.gms.internal.ads;

import com.google.android.gms.internal.ads.zzdgz.zzb;
import com.google.android.gms.internal.ads.zzdoa.zza;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

final class zzdcg {
    private static final Charset UTF_8 = Charset.forName("UTF-8");

    public static zzdhb zzc(zzdgz zzdgz) {
        zza zzev = zzdhb.zzass().zzev(zzdgz.zzash());
        for (zzb zzb : zzdgz.zzasi()) {
            zzev.zzb((zzdhb.zzb) ((zzdoa) zzdhb.zzb.zzasu().zzgq(zzb.zzasn().zzart()).zzc(zzb.zzaso()).zzc(zzb.zzanw()).zzew(zzb.zzasp()).zzaya()));
        }
        return (zzdhb) ((zzdoa) zzev.zzaya());
    }

    public static void zzd(com.google.android.gms.internal.ads.zzdgz r9) throws java.security.GeneralSecurityException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:37:0x00c5 in {16, 18, 21, 23, 25, 27, 31, 33, 34, 36} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = r9.zzash();
        r9 = r9.zzasi();
        r9 = r9.iterator();
        r1 = 1;
        r2 = 0;
        r3 = 0;
        r4 = 0;
        r5 = 1;
    L_0x0011:
        r6 = r9.hasNext();
        if (r6 == 0) goto L_0x00ad;
    L_0x0017:
        r6 = r9.next();
        r6 = (com.google.android.gms.internal.ads.zzdgz.zzb) r6;
        r7 = r6.zzaso();
        r8 = com.google.android.gms.internal.ads.zzdgt.DESTROYED;
        if (r7 == r8) goto L_0x0011;
    L_0x0025:
        r3 = r3 + 1;
        r7 = r6.zzasm();
        if (r7 == 0) goto L_0x0095;
    L_0x002d:
        r7 = r6.zzanw();
        r8 = com.google.android.gms.internal.ads.zzdhl.UNKNOWN_PREFIX;
        if (r7 == r8) goto L_0x007d;
    L_0x0035:
        r7 = r6.zzaso();
        r8 = com.google.android.gms.internal.ads.zzdgt.UNKNOWN_STATUS;
        if (r7 == r8) goto L_0x0065;
    L_0x003d:
        r7 = r6.zzaso();
        r8 = com.google.android.gms.internal.ads.zzdgt.ENABLED;
        if (r7 != r8) goto L_0x0057;
    L_0x0045:
        r7 = r6.zzasp();
        if (r7 != r0) goto L_0x0057;
    L_0x004b:
        if (r4 != 0) goto L_0x004f;
    L_0x004d:
        r4 = 1;
        goto L_0x0057;
    L_0x004f:
        r9 = new java.security.GeneralSecurityException;
        r0 = "keyset contains multiple primary keys";
        r9.<init>(r0);
        throw r9;
    L_0x0057:
        r6 = r6.zzasn();
        r6 = r6.zzarv();
        r7 = com.google.android.gms.internal.ads.zzdgq.zzb.ASYMMETRIC_PUBLIC;
        if (r6 == r7) goto L_0x0011;
    L_0x0063:
        r5 = 0;
        goto L_0x0011;
    L_0x0065:
        r9 = new java.security.GeneralSecurityException;
        r0 = new java.lang.Object[r1];
        r1 = r6.zzasp();
        r1 = java.lang.Integer.valueOf(r1);
        r0[r2] = r1;
        r1 = "key %d has unknown status";
        r0 = java.lang.String.format(r1, r0);
        r9.<init>(r0);
        throw r9;
    L_0x007d:
        r9 = new java.security.GeneralSecurityException;
        r0 = new java.lang.Object[r1];
        r1 = r6.zzasp();
        r1 = java.lang.Integer.valueOf(r1);
        r0[r2] = r1;
        r1 = "key %d has unknown prefix";
        r0 = java.lang.String.format(r1, r0);
        r9.<init>(r0);
        throw r9;
    L_0x0095:
        r9 = new java.security.GeneralSecurityException;
        r0 = new java.lang.Object[r1];
        r1 = r6.zzasp();
        r1 = java.lang.Integer.valueOf(r1);
        r0[r2] = r1;
        r1 = "key %d has no key data";
        r0 = java.lang.String.format(r1, r0);
        r9.<init>(r0);
        throw r9;
    L_0x00ad:
        if (r3 == 0) goto L_0x00bd;
    L_0x00af:
        if (r4 != 0) goto L_0x00bc;
    L_0x00b1:
        if (r5 == 0) goto L_0x00b4;
    L_0x00b3:
        goto L_0x00bc;
    L_0x00b4:
        r9 = new java.security.GeneralSecurityException;
        r0 = "keyset doesn't contain a valid primary key";
        r9.<init>(r0);
        throw r9;
    L_0x00bc:
        return;
    L_0x00bd:
        r9 = new java.security.GeneralSecurityException;
        r0 = "empty keyset";
        r9.<init>(r0);
        throw r9;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzdcg.zzd(com.google.android.gms.internal.ads.zzdgz):void");
    }

    public static byte[] zzg(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[1024];
        while (true) {
            int read = inputStream.read(bArr);
            if (read == -1) {
                return byteArrayOutputStream.toByteArray();
            }
            byteArrayOutputStream.write(bArr, 0, read);
        }
    }
}
