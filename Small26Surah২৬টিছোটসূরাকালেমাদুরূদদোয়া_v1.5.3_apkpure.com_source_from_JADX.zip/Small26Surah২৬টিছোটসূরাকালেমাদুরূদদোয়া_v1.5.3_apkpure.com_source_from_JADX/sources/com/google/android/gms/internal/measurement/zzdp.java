package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.util.Comparator;
import java.util.Iterator;

public abstract class zzdp implements Serializable, Iterable<Byte> {
    public static final zzdp zzaby = new zzdz(zzfb.zzahk);
    private static final zzdv zzabz = (zzdk.zzkb() ? new zzea() : new zzdt());
    private static final Comparator<zzdp> zzacb = new zzdr();
    private int zzaca = 0;

    zzdp() {
    }

    private static int zza(byte b) {
        return b & 255;
    }

    public abstract boolean equals(Object obj);

    public abstract int size();

    protected abstract int zza(int i, int i2, int i3);

    public abstract zzdp zza(int i, int i2);

    protected abstract String zza(Charset charset);

    abstract void zza(zzdo zzdo) throws IOException;

    public abstract boolean zzke();

    public abstract byte zzr(int i);

    abstract byte zzs(int i);

    public static zzdp zzb(byte[] bArr, int i, int i2) {
        zzb(i, i + i2, bArr.length);
        return new zzdz(zzabz.zzc(bArr, i, i2));
    }

    static zzdp zzg(byte[] bArr) {
        return new zzdz(bArr);
    }

    public static zzdp zzcn(String str) {
        return new zzdz(str.getBytes(zzfb.UTF_8));
    }

    public final String zzkd() {
        return size() == 0 ? "" : zza(zzfb.UTF_8);
    }

    public final int hashCode() {
        int i = this.zzaca;
        if (i == 0) {
            i = size();
            i = zza(i, 0, i);
            if (i == 0) {
                i = 1;
            }
            this.zzaca = i;
        }
        return i;
    }

    static zzdx zzt(int i) {
        return new zzdx(i);
    }

    protected final int zzkf() {
        return this.zzaca;
    }

    static int zzb(int i, int i2, int i3) {
        int i4 = i2 - i;
        if ((((i | i2) | i4) | (i3 - i2)) >= 0) {
            return i4;
        }
        if (i < 0) {
            StringBuilder stringBuilder = new StringBuilder(32);
            stringBuilder.append("Beginning index: ");
            stringBuilder.append(i);
            stringBuilder.append(" < 0");
            throw new IndexOutOfBoundsException(stringBuilder.toString());
        } else if (i2 < i) {
            r1 = new StringBuilder(66);
            r1.append("Beginning index larger than ending index: ");
            r1.append(i);
            r1.append(", ");
            r1.append(i2);
            throw new IndexOutOfBoundsException(r1.toString());
        } else {
            r1 = new StringBuilder(37);
            r1.append("End index: ");
            r1.append(i2);
            r1.append(" >= ");
            r1.append(i3);
            throw new IndexOutOfBoundsException(r1.toString());
        }
    }

    public final String toString() {
        return String.format("<ByteString@%s size=%d>", new Object[]{Integer.toHexString(System.identityHashCode(this)), Integer.valueOf(size())});
    }

    public /* synthetic */ Iterator iterator() {
        return new zzdq(this);
    }
}
