package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzbl.zzb.zzb;

final class zzbq implements zzfe {
    static final zzfe zzty = new zzbq();

    private zzbq() {
    }

    public final boolean zzf(int i) {
        return zzb.zzg(i) != 0;
    }
}
