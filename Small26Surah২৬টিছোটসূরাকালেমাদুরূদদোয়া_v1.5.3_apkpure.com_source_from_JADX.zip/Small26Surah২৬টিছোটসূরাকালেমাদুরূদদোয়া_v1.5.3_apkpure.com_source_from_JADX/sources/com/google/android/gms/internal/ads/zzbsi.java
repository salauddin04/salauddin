package com.google.android.gms.internal.ads;

final /* synthetic */ class zzbsi implements zzbtt {
    private final String zzdbm;
    private final String zzdst;
    private final zzass zzfkd;

    zzbsi(zzass zzass, String str, String str2) {
        this.zzfkd = zzass;
        this.zzdbm = str;
        this.zzdst = str2;
    }

    public final void zzr(Object obj) {
        ((zzbrk) obj).zzb(this.zzfkd, this.zzdbm, this.zzdst);
    }
}
