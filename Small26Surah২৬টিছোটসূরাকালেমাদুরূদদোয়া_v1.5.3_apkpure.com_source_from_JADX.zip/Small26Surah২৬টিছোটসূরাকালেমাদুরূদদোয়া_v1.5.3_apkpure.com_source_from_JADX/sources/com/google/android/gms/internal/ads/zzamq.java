package com.google.android.gms.internal.ads;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzamq extends IInterface {
    zzamt zzcu(String str) throws RemoteException;

    boolean zzcv(String str) throws RemoteException;

    zzaow zzcy(String str) throws RemoteException;
}
