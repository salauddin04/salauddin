package com.google.android.gms.internal.ads;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.annotation.Nullable;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.common.internal.Objects;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Class;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Constructor;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Field;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Param;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Reserved;
import org.json.JSONArray;
import org.json.JSONException;

@Class(creator = "RewardItemParcelCreator")
@Reserved({1})
@zzare
public final class zzatp extends AbstractSafeParcelable {
    public static final Creator<zzatp> CREATOR = new zzatq();
    @Field(id = 2)
    public final String type;
    @Field(id = 3)
    public final int zzdqo;

    public zzatp(RewardItem rewardItem) {
        this(rewardItem.getType(), rewardItem.getAmount());
    }

    @Constructor
    public zzatp(@Param(id = 2) String str, @Param(id = 3) int i) {
        this.type = str;
        this.zzdqo = i;
    }

    @Nullable
    public static zzatp zza(JSONArray jSONArray) throws JSONException {
        if (jSONArray != null) {
            if (jSONArray.length() != 0) {
                return new zzatp(jSONArray.getJSONObject(0).optString("rb_type"), jSONArray.getJSONObject(0).optInt("rb_amount"));
            }
        }
        return null;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = SafeParcelWriter.beginObjectHeader(parcel);
        SafeParcelWriter.writeString(parcel, 2, this.type, false);
        SafeParcelWriter.writeInt(parcel, 3, this.zzdqo);
        SafeParcelWriter.finishObjectHeader(parcel, i);
    }

    public final boolean equals(Object obj) {
        if (obj != null) {
            if (obj instanceof zzatp) {
                zzatp zzatp = (zzatp) obj;
                if (Objects.equal(this.type, zzatp.type) && Objects.equal(Integer.valueOf(this.zzdqo), Integer.valueOf(zzatp.zzdqo)) != null) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        return Objects.hashCode(this.type, Integer.valueOf(this.zzdqo));
    }
}
