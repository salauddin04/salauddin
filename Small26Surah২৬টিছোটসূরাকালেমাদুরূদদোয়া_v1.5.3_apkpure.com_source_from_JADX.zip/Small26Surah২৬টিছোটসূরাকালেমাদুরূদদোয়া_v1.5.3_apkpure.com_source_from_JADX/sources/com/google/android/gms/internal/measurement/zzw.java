package com.google.android.gms.internal.measurement;

import android.os.IInterface;

public interface zzw extends IInterface {
}
