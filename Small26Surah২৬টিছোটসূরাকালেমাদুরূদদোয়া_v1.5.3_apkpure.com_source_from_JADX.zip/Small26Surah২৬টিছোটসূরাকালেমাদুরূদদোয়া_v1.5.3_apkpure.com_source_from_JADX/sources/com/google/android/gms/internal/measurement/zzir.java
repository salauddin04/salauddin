package com.google.android.gms.internal.measurement;

public final class zzir implements Cloneable {
    private static final zzis zzanf = new zzis();
    private int mSize;
    private boolean zzang;
    private int[] zzanh;
    private zzis[] zzani;

    zzir() {
        this(10);
    }

    private zzir(int i) {
        this.zzang = false;
        i = idealIntArraySize(i);
        this.zzanh = new int[i];
        this.zzani = new zzis[i];
        this.mSize = 0;
    }

    final zzis zzbm(int i) {
        i = zzbo(i);
        if (i >= 0) {
            zzis[] zzisArr = this.zzani;
            if (zzisArr[i] != zzanf) {
                return zzisArr[i];
            }
        }
        return 0;
    }

    final void zza(int i, zzis zzis) {
        int zzbo = zzbo(i);
        if (zzbo >= 0) {
            this.zzani[zzbo] = zzis;
            return;
        }
        zzbo ^= -1;
        if (zzbo < this.mSize) {
            zzis[] zzisArr = this.zzani;
            if (zzisArr[zzbo] == zzanf) {
                this.zzanh[zzbo] = i;
                zzisArr[zzbo] = zzis;
                return;
            }
        }
        int i2 = this.mSize;
        if (i2 >= this.zzanh.length) {
            i2 = idealIntArraySize(i2 + 1);
            Object obj = new int[i2];
            Object obj2 = new zzis[i2];
            Object obj3 = this.zzanh;
            System.arraycopy(obj3, 0, obj, 0, obj3.length);
            obj3 = this.zzani;
            System.arraycopy(obj3, 0, obj2, 0, obj3.length);
            this.zzanh = obj;
            this.zzani = obj2;
        }
        i2 = this.mSize;
        if (i2 - zzbo != 0) {
            obj = this.zzanh;
            int i3 = zzbo + 1;
            System.arraycopy(obj, zzbo, obj, i3, i2 - zzbo);
            obj2 = this.zzani;
            System.arraycopy(obj2, zzbo, obj2, i3, this.mSize - zzbo);
        }
        this.zzanh[zzbo] = i;
        this.zzani[zzbo] = zzis;
        this.mSize++;
    }

    final int size() {
        return this.mSize;
    }

    public final boolean isEmpty() {
        return this.mSize == 0;
    }

    final zzis zzbn(int i) {
        return this.zzani[i];
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzir)) {
            return false;
        }
        zzir zzir = (zzir) obj;
        int i = this.mSize;
        if (i != zzir.mSize) {
            return false;
        }
        Object obj2;
        int[] iArr = this.zzanh;
        int[] iArr2 = zzir.zzanh;
        for (int i2 = 0; i2 < i; i2++) {
            if (iArr[i2] != iArr2[i2]) {
                obj2 = null;
                break;
            }
        }
        obj2 = 1;
        if (obj2 != null) {
            zzis[] zzisArr = this.zzani;
            obj = zzir.zzani;
            int i3 = this.mSize;
            for (int i4 = 0; i4 < i3; i4++) {
                if (!zzisArr[i4].equals(obj[i4])) {
                    obj = null;
                    break;
                }
            }
            obj = true;
            if (obj != null) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i = 17;
        for (int i2 = 0; i2 < this.mSize; i2++) {
            i = (((i * 31) + this.zzanh[i2]) * 31) + this.zzani[i2].hashCode();
        }
        return i;
    }

    private static int idealIntArraySize(int i) {
        i <<= 2;
        for (int i2 = 4; i2 < 32; i2++) {
            int i3 = (1 << i2) - 12;
            if (i <= i3) {
                i = i3;
                break;
            }
        }
        return i / 4;
    }

    private final int zzbo(int i) {
        int i2 = this.mSize - 1;
        int i3 = 0;
        while (i3 <= i2) {
            int i4 = (i3 + i2) >>> 1;
            int i5 = this.zzanh[i4];
            if (i5 < i) {
                i3 = i4 + 1;
            } else if (i5 <= i) {
                return i4;
            } else {
                i2 = i4 - 1;
            }
        }
        return i3 ^ -1;
    }

    public final /* synthetic */ Object clone() throws CloneNotSupportedException {
        int i = this.mSize;
        zzir zzir = new zzir(i);
        int i2 = 0;
        System.arraycopy(this.zzanh, 0, zzir.zzanh, 0, i);
        while (i2 < i) {
            zzis[] zzisArr = this.zzani;
            if (zzisArr[i2] != null) {
                zzir.zzani[i2] = (zzis) zzisArr[i2].clone();
            }
            i2++;
        }
        zzir.mSize = i;
        return zzir;
    }
}
