package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.nio.charset.Charset;

class zzdz extends zzdy {
    protected final byte[] zzacg;

    zzdz(byte[] bArr) {
        if (bArr != null) {
            this.zzacg = bArr;
            return;
        }
        throw new NullPointerException();
    }

    final boolean zza(com.google.android.gms.internal.measurement.zzdp r6, int r7, int r8) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:20:0x0086 in {10, 11, 13, 15, 17, 19} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r5 = this;
        r7 = r6.size();
        if (r8 > r7) goto L_0x0066;
    L_0x0006:
        r7 = r6.size();
        if (r8 > r7) goto L_0x0041;
    L_0x000c:
        r7 = r6 instanceof com.google.android.gms.internal.measurement.zzdz;
        r0 = 0;
        if (r7 == 0) goto L_0x0034;
    L_0x0011:
        r6 = (com.google.android.gms.internal.measurement.zzdz) r6;
        r7 = r5.zzacg;
        r1 = r6.zzacg;
        r2 = r5.zzkg();
        r2 = r2 + r8;
        r8 = r5.zzkg();
        r6 = r6.zzkg();
    L_0x0024:
        if (r8 >= r2) goto L_0x0032;
    L_0x0026:
        r3 = r7[r8];
        r4 = r1[r6];
        if (r3 == r4) goto L_0x002d;
    L_0x002c:
        return r0;
    L_0x002d:
        r8 = r8 + 1;
        r6 = r6 + 1;
        goto L_0x0024;
    L_0x0032:
        r6 = 1;
        return r6;
    L_0x0034:
        r6 = r6.zza(r0, r8);
        r7 = r5.zza(r0, r8);
        r6 = r6.equals(r7);
        return r6;
    L_0x0041:
        r7 = new java.lang.IllegalArgumentException;
        r6 = r6.size();
        r0 = 59;
        r1 = new java.lang.StringBuilder;
        r1.<init>(r0);
        r0 = "Ran off end of other: 0, ";
        r1.append(r0);
        r1.append(r8);
        r8 = ", ";
        r1.append(r8);
        r1.append(r6);
        r6 = r1.toString();
        r7.<init>(r6);
        throw r7;
    L_0x0066:
        r6 = new java.lang.IllegalArgumentException;
        r7 = r5.size();
        r0 = 40;
        r1 = new java.lang.StringBuilder;
        r1.<init>(r0);
        r0 = "Length too large: ";
        r1.append(r0);
        r1.append(r8);
        r1.append(r7);
        r7 = r1.toString();
        r6.<init>(r7);
        throw r6;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzdz.zza(com.google.android.gms.internal.measurement.zzdp, int, int):boolean");
    }

    protected int zzkg() {
        return 0;
    }

    public byte zzr(int i) {
        return this.zzacg[i];
    }

    byte zzs(int i) {
        return this.zzacg[i];
    }

    public int size() {
        return this.zzacg.length;
    }

    public final zzdp zza(int i, int i2) {
        i = zzdp.zzb(0, i2, size());
        if (i == 0) {
            return zzdp.zzaby;
        }
        return new zzdu(this.zzacg, zzkg(), i);
    }

    final void zza(zzdo zzdo) throws IOException {
        zzdo.zza(this.zzacg, zzkg(), size());
    }

    protected final String zza(Charset charset) {
        return new String(this.zzacg, zzkg(), size(), charset);
    }

    public final boolean zzke() {
        int zzkg = zzkg();
        return zzhy.zzf(this.zzacg, zzkg, size() + zzkg);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzdp) || size() != ((zzdp) obj).size()) {
            return false;
        }
        if (size() == 0) {
            return true;
        }
        if (!(obj instanceof zzdz)) {
            return obj.equals(this);
        }
        zzdz zzdz = (zzdz) obj;
        int zzkf = zzkf();
        int zzkf2 = zzdz.zzkf();
        if (zzkf == 0 || zzkf2 == 0 || zzkf == zzkf2) {
            return zza(zzdz, 0, size());
        }
        return false;
    }

    protected final int zza(int i, int i2, int i3) {
        return zzfb.zza(i, this.zzacg, zzkg(), i3);
    }
}
