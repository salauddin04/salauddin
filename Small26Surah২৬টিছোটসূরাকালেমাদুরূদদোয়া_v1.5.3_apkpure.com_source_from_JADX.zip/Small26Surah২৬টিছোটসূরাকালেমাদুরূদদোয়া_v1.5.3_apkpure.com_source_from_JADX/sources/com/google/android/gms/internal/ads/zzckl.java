package com.google.android.gms.internal.ads;

import android.content.Context;
import android.os.RemoteException;
import android.view.View;
import com.google.android.gms.dynamic.ObjectWrapper;

public final class zzckl implements zzcjz<zzbne, zzaow, zzckz> {
    private View view;
    private final zzbob zzfzo;
    private final Context zzlj;

    public zzckl(Context context, zzbob zzbob) {
        this.zzlj = context;
        this.zzfzo = zzbob;
    }

    public final void zza(zzcxt zzcxt, zzcxl zzcxl, zzcjx<zzaow, zzckz> zzcjx) throws RemoteException {
        ((zzaow) zzcjx.zzdge).zza(zzcxl.zzemw, zzcxl.zzgkh.toString(), zzcxt.zzgkx.zzfjp.zzghg, ObjectWrapper.wrap(this.zzlj), new zzcko(this, zzcjx, null), (zzamw) zzcjx.zzfzn, zzcxt.zzgkx.zzfjp.zzdln);
    }

    public final /* synthetic */ Object zzb(zzcxt zzcxt, zzcxl zzcxl, zzcjx zzcjx) throws RemoteException, zzcmv {
        zzbob zzbob = this.zzfzo;
        zzbpq zzbpq = new zzbpq(zzcxt, zzcxl, zzcjx.zzfir);
        View view = this.view;
        zzaow zzaow = (zzaow) zzcjx.zzdge;
        zzaow.getClass();
        zzcxt = zzbob.zza(zzbpq, new zzbnj(view, null, zzckm.zza(zzaow), (zzcxm) zzcxl.zzgkg.get(0)));
        zzcxt.zzadz().zzq(this.view);
        ((zzckz) zzcjx.zzfzn).zza(zzcxt.zzadi());
        return zzcxt.zzadx();
    }
}
