package com.google.android.gms.internal.ads;

public final class zzdtg<T> implements zzdtd<T>, zzdtt<T> {
    private static final Object zzhuh = new Object();
    private volatile Object zzdyb = zzhuh;
    private volatile zzdtt<T> zzhui;

    private zzdtg(zzdtt<T> zzdtt) {
        this.zzhui = zzdtt;
    }

    public final T get() {
        T t = this.zzdyb;
        if (t == zzhuh) {
            synchronized (this) {
                t = this.zzdyb;
                if (t == zzhuh) {
                    t = this.zzhui.get();
                    T t2 = this.zzdyb;
                    Object obj = (t2 == zzhuh || (t2 instanceof zzdtm)) ? null : 1;
                    if (obj != null) {
                        if (t2 != t) {
                            String valueOf = String.valueOf(t2);
                            String valueOf2 = String.valueOf(t);
                            StringBuilder stringBuilder = new StringBuilder((String.valueOf(valueOf).length() + 118) + String.valueOf(valueOf2).length());
                            stringBuilder.append("Scoped provider was invoked recursively returning different results: ");
                            stringBuilder.append(valueOf);
                            stringBuilder.append(" & ");
                            stringBuilder.append(valueOf2);
                            stringBuilder.append(". This is likely due to a circular dependency.");
                            throw new IllegalStateException(stringBuilder.toString());
                        }
                    }
                    this.zzdyb = t;
                    this.zzhui = null;
                }
            }
        }
        return t;
    }

    public static <P extends zzdtt<T>, T> zzdtt<T> zzao(P p) {
        zzdtn.checkNotNull(p);
        if (p instanceof zzdtg) {
            return p;
        }
        return new zzdtg(p);
    }

    public static <P extends zzdtt<T>, T> zzdtd<T> zzap(P p) {
        if (p instanceof zzdtd) {
            return (zzdtd) p;
        }
        return new zzdtg((zzdtt) zzdtn.checkNotNull(p));
    }
}
