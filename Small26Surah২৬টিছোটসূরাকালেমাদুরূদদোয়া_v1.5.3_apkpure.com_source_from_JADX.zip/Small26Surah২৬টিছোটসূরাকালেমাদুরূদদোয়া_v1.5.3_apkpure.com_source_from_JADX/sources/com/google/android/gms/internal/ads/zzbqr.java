package com.google.android.gms.internal.ads;

import android.content.Context;

public final class zzbqr implements zzdth<zzbqq> {
    private final zzdtt<zzcga> zzeoz;
    private final zzdtt<zzaxc> zzerl;
    private final zzdtt<zzbaj> zzfgo;
    private final zzdtt<zzcxu> zzfhq;
    private final zzdtt<Context> zzfjq;

    private zzbqr(zzdtt<Context> zzdtt, zzdtt<zzcxu> zzdtt2, zzdtt<zzbaj> zzdtt3, zzdtt<zzaxc> zzdtt4, zzdtt<zzcga> zzdtt5) {
        this.zzfjq = zzdtt;
        this.zzfhq = zzdtt2;
        this.zzfgo = zzdtt3;
        this.zzerl = zzdtt4;
        this.zzeoz = zzdtt5;
    }

    public static zzbqr zzb(zzdtt<Context> zzdtt, zzdtt<zzcxu> zzdtt2, zzdtt<zzbaj> zzdtt3, zzdtt<zzaxc> zzdtt4, zzdtt<zzcga> zzdtt5) {
        return new zzbqr(zzdtt, zzdtt2, zzdtt3, zzdtt4, zzdtt5);
    }

    public final /* synthetic */ Object get() {
        return new zzbqq((Context) this.zzfjq.get(), (zzcxu) this.zzfhq.get(), (zzbaj) this.zzfgo.get(), (zzaxc) this.zzerl.get(), (zzcga) this.zzeoz.get());
    }
}
