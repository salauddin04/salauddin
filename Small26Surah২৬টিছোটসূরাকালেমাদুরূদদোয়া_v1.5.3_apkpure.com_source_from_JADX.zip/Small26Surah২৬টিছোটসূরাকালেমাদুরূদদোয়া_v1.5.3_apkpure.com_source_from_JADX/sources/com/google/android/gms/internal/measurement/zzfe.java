package com.google.android.gms.internal.measurement;

public interface zzfe {
    boolean zzf(int i);
}
