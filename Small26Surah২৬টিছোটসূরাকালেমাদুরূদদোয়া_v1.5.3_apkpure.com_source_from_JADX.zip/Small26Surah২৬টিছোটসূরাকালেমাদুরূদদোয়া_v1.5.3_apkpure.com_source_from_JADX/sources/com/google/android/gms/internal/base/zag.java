package com.google.android.gms.internal.base;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;

final class zag extends Drawable {
    private static final zag zant = new zag();
    private static final zah zanu = new zah();

    private zag() {
    }

    public final void draw(Canvas canvas) {
    }

    public final int getOpacity() {
        return -2;
    }

    public final void setAlpha(int i) {
    }

    public final void setColorFilter(ColorFilter colorFilter) {
    }

    public final ConstantState getConstantState() {
        return zanu;
    }
}
