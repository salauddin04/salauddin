package com.google.android.gms.internal.measurement;

interface zzgz {
    <T> zzgy<T> zze(Class<T> cls);
}
