package com.google.android.gms.internal.ads;

import java.util.List;

public final class zzche implements zzdth<List<String>> {
    private static final zzche zzfwr = new zzche();

    public static zzche zzake() {
        return zzfwr;
    }

    public final /* synthetic */ Object get() {
        return (List) zzdtn.zza(zzact.zzqn(), "Cannot return null from a non-@Nullable @Provides method");
    }
}
