package com.google.android.gms.internal.measurement;

final class zzid extends zzia {
    zzid() {
    }

    final int zzb(int r16, byte[] r17, int r18, int r19) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:64:0x00dc in {4, 9, 10, 11, 17, 18, 20, 24, 29, 30, 31, 36, 41, 44, 47, 48, 49, 52, 60, 61, 63} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r15 = this;
        r0 = r17;
        r1 = r18;
        r2 = r19;
        r3 = r1 | r2;
        r4 = r0.length;
        r4 = r4 - r2;
        r3 = r3 | r4;
        r4 = 2;
        r5 = 3;
        r6 = 0;
        if (r3 < 0) goto L_0x00ba;
    L_0x0010:
        r7 = (long) r1;
        r1 = (long) r2;
        r1 = r1 - r7;
        r2 = (int) r1;
        r1 = 16;
        r9 = 1;
        if (r2 >= r1) goto L_0x001c;
    L_0x001a:
        r1 = 0;
        goto L_0x002e;
    L_0x001c:
        r11 = r7;
        r1 = 0;
    L_0x001e:
        if (r1 >= r2) goto L_0x002d;
    L_0x0020:
        r13 = r11 + r9;
        r3 = com.google.android.gms.internal.measurement.zzhw.zza(r0, r11);
        if (r3 >= 0) goto L_0x0029;
    L_0x0028:
        goto L_0x002e;
    L_0x0029:
        r1 = r1 + 1;
        r11 = r13;
        goto L_0x001e;
    L_0x002d:
        r1 = r2;
    L_0x002e:
        r2 = r2 - r1;
        r11 = (long) r1;
        r7 = r7 + r11;
    L_0x0031:
        r1 = 0;
    L_0x0032:
        if (r2 <= 0) goto L_0x0040;
    L_0x0034:
        r11 = r7 + r9;
        r1 = com.google.android.gms.internal.measurement.zzhw.zza(r0, r7);
        if (r1 < 0) goto L_0x0041;
    L_0x003c:
        r2 = r2 + -1;
        r7 = r11;
        goto L_0x0032;
    L_0x0040:
        r11 = r7;
    L_0x0041:
        if (r2 != 0) goto L_0x0044;
    L_0x0043:
        return r6;
    L_0x0044:
        r2 = r2 + -1;
        r3 = -32;
        r7 = -65;
        r8 = -1;
        if (r1 >= r3) goto L_0x0062;
    L_0x004d:
        if (r2 != 0) goto L_0x0050;
    L_0x004f:
        return r1;
    L_0x0050:
        r2 = r2 + -1;
        r3 = -62;
        if (r1 < r3) goto L_0x0061;
    L_0x0056:
        r13 = r11 + r9;
        r1 = com.google.android.gms.internal.measurement.zzhw.zza(r0, r11);
        if (r1 <= r7) goto L_0x005f;
    L_0x005e:
        goto L_0x0061;
    L_0x005f:
        r7 = r13;
        goto L_0x0031;
    L_0x0061:
        return r8;
    L_0x0062:
        r13 = -16;
        if (r1 >= r13) goto L_0x008f;
    L_0x0066:
        if (r2 >= r4) goto L_0x006d;
    L_0x0068:
        r0 = zza(r0, r1, r11, r2);
        return r0;
    L_0x006d:
        r2 = r2 + -2;
        r13 = r11 + r9;
        r11 = com.google.android.gms.internal.measurement.zzhw.zza(r0, r11);
        if (r11 > r7) goto L_0x008e;
    L_0x0077:
        r12 = -96;
        if (r1 != r3) goto L_0x007d;
    L_0x007b:
        if (r11 < r12) goto L_0x008e;
    L_0x007d:
        r3 = -19;
        if (r1 != r3) goto L_0x0083;
    L_0x0081:
        if (r11 >= r12) goto L_0x008e;
    L_0x0083:
        r11 = r13 + r9;
        r1 = com.google.android.gms.internal.measurement.zzhw.zza(r0, r13);
        if (r1 <= r7) goto L_0x008c;
    L_0x008b:
        goto L_0x008e;
    L_0x008c:
        r7 = r11;
        goto L_0x0031;
    L_0x008e:
        return r8;
    L_0x008f:
        if (r2 >= r5) goto L_0x0096;
    L_0x0091:
        r0 = zza(r0, r1, r11, r2);
        return r0;
    L_0x0096:
        r2 = r2 + -3;
        r13 = r11 + r9;
        r3 = com.google.android.gms.internal.measurement.zzhw.zza(r0, r11);
        if (r3 > r7) goto L_0x00b9;
    L_0x00a0:
        r1 = r1 << 28;
        r3 = r3 + 112;
        r1 = r1 + r3;
        r1 = r1 >> 30;
        if (r1 != 0) goto L_0x00b9;
    L_0x00a9:
        r11 = r13 + r9;
        r1 = com.google.android.gms.internal.measurement.zzhw.zza(r0, r13);
        if (r1 > r7) goto L_0x00b9;
    L_0x00b1:
        r13 = r11 + r9;
        r1 = com.google.android.gms.internal.measurement.zzhw.zza(r0, r11);
        if (r1 <= r7) goto L_0x005f;
    L_0x00b9:
        return r8;
    L_0x00ba:
        r3 = new java.lang.ArrayIndexOutOfBoundsException;
        r5 = new java.lang.Object[r5];
        r0 = r0.length;
        r0 = java.lang.Integer.valueOf(r0);
        r5[r6] = r0;
        r0 = java.lang.Integer.valueOf(r18);
        r1 = 1;
        r5[r1] = r0;
        r0 = java.lang.Integer.valueOf(r19);
        r5[r4] = r0;
        r0 = "Array length=%d, index=%d, limit=%d";
        r0 = java.lang.String.format(r0, r5);
        r3.<init>(r0);
        throw r3;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzid.zzb(int, byte[], int, int):int");
    }

    final int zzb(java.lang.CharSequence r23, byte[] r24, int r25, int r26) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:56:0x016a in {9, 12, 18, 19, 24, 27, 30, 37, 38, 39, 41, 47, 49, 51, 53, 55} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r22 = this;
        r0 = r23;
        r1 = r24;
        r2 = r25;
        r3 = r26;
        r4 = (long) r2;
        r6 = (long) r3;
        r6 = r6 + r4;
        r8 = r23.length();
        r9 = " at index ";
        r10 = "Failed writing ";
        if (r8 > r3) goto L_0x0146;
    L_0x0015:
        r11 = r1.length;
        r11 = r11 - r3;
        if (r11 < r2) goto L_0x0146;
    L_0x0019:
        r2 = 0;
    L_0x001a:
        r3 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r11 = 1;
        if (r2 >= r8) goto L_0x002f;
    L_0x0020:
        r13 = r0.charAt(r2);
        if (r13 >= r3) goto L_0x002f;
    L_0x0026:
        r11 = r11 + r4;
        r3 = (byte) r13;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r4, r3);
        r2 = r2 + 1;
        r4 = r11;
        goto L_0x001a;
    L_0x002f:
        if (r2 != r8) goto L_0x0033;
    L_0x0031:
        r0 = (int) r4;
        return r0;
    L_0x0033:
        if (r2 >= r8) goto L_0x0144;
    L_0x0035:
        r13 = r0.charAt(r2);
        if (r13 >= r3) goto L_0x004b;
    L_0x003b:
        r14 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r14 >= 0) goto L_0x004b;
    L_0x003f:
        r14 = r4 + r11;
        r13 = (byte) r13;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r4, r13);
        r4 = r11;
        r12 = r14;
    L_0x0047:
        r11 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        goto L_0x00fb;
    L_0x004b:
        r14 = 2048; // 0x800 float:2.87E-42 double:1.0118E-320;
        if (r13 >= r14) goto L_0x0075;
    L_0x004f:
        r14 = 2;
        r14 = r6 - r14;
        r16 = (r4 > r14 ? 1 : (r4 == r14 ? 0 : -1));
        if (r16 > 0) goto L_0x0075;
    L_0x0057:
        r14 = r4 + r11;
        r3 = r13 >>> 6;
        r3 = r3 | 960;
        r3 = (byte) r3;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r4, r3);
        r3 = r14 + r11;
        r5 = r13 & 63;
        r13 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r5 = r5 | r13;
        r5 = (byte) r5;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r14, r5);
        r20 = r11;
        r11 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r12 = r3;
        r4 = r20;
        goto L_0x00fb;
    L_0x0075:
        r3 = 57343; // 0xdfff float:8.0355E-41 double:2.8331E-319;
        r14 = 55296; // 0xd800 float:7.7486E-41 double:2.732E-319;
        if (r13 < r14) goto L_0x007f;
    L_0x007d:
        if (r3 >= r13) goto L_0x00ae;
    L_0x007f:
        r15 = 3;
        r15 = r6 - r15;
        r17 = (r4 > r15 ? 1 : (r4 == r15 ? 0 : -1));
        if (r17 > 0) goto L_0x00ae;
    L_0x0087:
        r14 = r4 + r11;
        r3 = r13 >>> 12;
        r3 = r3 | 480;
        r3 = (byte) r3;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r4, r3);
        r3 = r14 + r11;
        r5 = r13 >>> 6;
        r5 = r5 & 63;
        r11 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r5 = r5 | r11;
        r5 = (byte) r5;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r14, r5);
        r14 = 1;
        r18 = r3 + r14;
        r5 = r13 & 63;
        r5 = r5 | r11;
        r5 = (byte) r5;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r3, r5);
        r12 = r18;
        r4 = 1;
        goto L_0x0047;
    L_0x00ae:
        r11 = 4;
        r11 = r6 - r11;
        r15 = (r4 > r11 ? 1 : (r4 == r11 ? 0 : -1));
        if (r15 > 0) goto L_0x010f;
    L_0x00b6:
        r3 = r2 + 1;
        if (r3 == r8) goto L_0x0107;
    L_0x00ba:
        r2 = r0.charAt(r3);
        r11 = java.lang.Character.isSurrogatePair(r13, r2);
        if (r11 == 0) goto L_0x0106;
    L_0x00c4:
        r2 = java.lang.Character.toCodePoint(r13, r2);
        r11 = 1;
        r13 = r4 + r11;
        r15 = r2 >>> 18;
        r15 = r15 | 240;
        r15 = (byte) r15;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r4, r15);
        r4 = r13 + r11;
        r15 = r2 >>> 12;
        r15 = r15 & 63;
        r11 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r12 = r15 | 128;
        r12 = (byte) r12;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r13, r12);
        r12 = 1;
        r14 = r4 + r12;
        r16 = r2 >>> 6;
        r12 = r16 & 63;
        r12 = r12 | r11;
        r12 = (byte) r12;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r4, r12);
        r4 = 1;
        r12 = r14 + r4;
        r2 = r2 & 63;
        r2 = r2 | r11;
        r2 = (byte) r2;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r14, r2);
        r2 = r3;
    L_0x00fb:
        r2 = r2 + 1;
        r3 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r20 = r4;
        r4 = r12;
        r11 = r20;
        goto L_0x0033;
    L_0x0106:
        r2 = r3;
    L_0x0107:
        r0 = new com.google.android.gms.internal.measurement.zzic;
        r2 = r2 + -1;
        r0.<init>(r2, r8);
        throw r0;
    L_0x010f:
        if (r14 > r13) goto L_0x0127;
    L_0x0111:
        if (r13 > r3) goto L_0x0127;
    L_0x0113:
        r1 = r2 + 1;
        if (r1 == r8) goto L_0x0121;
    L_0x0117:
        r0 = r0.charAt(r1);
        r0 = java.lang.Character.isSurrogatePair(r13, r0);
        if (r0 != 0) goto L_0x0127;
    L_0x0121:
        r0 = new com.google.android.gms.internal.measurement.zzic;
        r0.<init>(r2, r8);
        throw r0;
    L_0x0127:
        r0 = new java.lang.ArrayIndexOutOfBoundsException;
        r1 = 46;
        r2 = new java.lang.StringBuilder;
        r2.<init>(r1);
        r2.append(r10);
        r2.append(r13);
        r2.append(r9);
        r2.append(r4);
        r1 = r2.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0144:
        r0 = (int) r4;
        return r0;
    L_0x0146:
        r1 = new java.lang.ArrayIndexOutOfBoundsException;
        r8 = r8 + -1;
        r0 = r0.charAt(r8);
        r2 = r2 + r3;
        r3 = 37;
        r4 = new java.lang.StringBuilder;
        r4.<init>(r3);
        r4.append(r10);
        r4.append(r0);
        r4.append(r9);
        r4.append(r2);
        r0 = r4.toString();
        r1.<init>(r0);
        throw r1;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzid.zzb(java.lang.CharSequence, byte[], int, int):int");
    }

    final void zzb(java.lang.CharSequence r22, java.nio.ByteBuffer r23) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:54:0x017a in {7, 10, 16, 21, 22, 25, 28, 35, 36, 37, 39, 45, 47, 49, 51, 53} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r21 = this;
        r0 = r22;
        r1 = r23;
        r2 = com.google.android.gms.internal.measurement.zzhw.zzb(r23);
        r4 = r23.position();
        r4 = (long) r4;
        r4 = r4 + r2;
        r6 = r23.limit();
        r6 = (long) r6;
        r6 = r6 + r2;
        r8 = r22.length();
        r9 = (long) r8;
        r11 = r6 - r4;
        r13 = " at index ";
        r14 = "Failed writing ";
        r15 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1));
        if (r15 > 0) goto L_0x0153;
    L_0x0023:
        r9 = 0;
    L_0x0024:
        r10 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r11 = 1;
        if (r9 >= r8) goto L_0x0039;
    L_0x002a:
        r15 = r0.charAt(r9);
        if (r15 >= r10) goto L_0x0039;
    L_0x0030:
        r11 = r11 + r4;
        r10 = (byte) r15;
        com.google.android.gms.internal.measurement.zzhw.zza(r4, r10);
        r9 = r9 + 1;
        r4 = r11;
        goto L_0x0024;
    L_0x0039:
        if (r9 != r8) goto L_0x0041;
    L_0x003b:
        r4 = r4 - r2;
        r0 = (int) r4;
        r1.position(r0);
        return;
    L_0x0041:
        if (r9 >= r8) goto L_0x0148;
    L_0x0043:
        r15 = r0.charAt(r9);
        if (r15 >= r10) goto L_0x005b;
    L_0x0049:
        r16 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r16 >= 0) goto L_0x005b;
    L_0x004d:
        r16 = r4 + r11;
        r15 = (byte) r15;
        com.google.android.gms.internal.measurement.zzhw.zza(r4, r15);
        r4 = r16;
        r15 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r17 = r2;
        goto L_0x0100;
    L_0x005b:
        r10 = 2048; // 0x800 float:2.87E-42 double:1.0118E-320;
        if (r15 >= r10) goto L_0x0083;
    L_0x005f:
        r17 = 2;
        r17 = r6 - r17;
        r10 = (r4 > r17 ? 1 : (r4 == r17 ? 0 : -1));
        if (r10 > 0) goto L_0x0083;
    L_0x0067:
        r17 = r2;
        r1 = r4 + r11;
        r3 = r15 >>> 6;
        r3 = r3 | 960;
        r3 = (byte) r3;
        com.google.android.gms.internal.measurement.zzhw.zza(r4, r3);
        r3 = r1 + r11;
        r5 = r15 & 63;
        r10 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r5 = r5 | r10;
        r5 = (byte) r5;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r5);
        r4 = r3;
    L_0x007f:
        r15 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        goto L_0x0100;
    L_0x0083:
        r17 = r2;
        r1 = 57343; // 0xdfff float:8.0355E-41 double:2.8331E-319;
        r2 = 55296; // 0xd800 float:7.7486E-41 double:2.732E-319;
        if (r15 < r2) goto L_0x008f;
    L_0x008d:
        if (r1 >= r15) goto L_0x00b9;
    L_0x008f:
        r19 = 3;
        r19 = r6 - r19;
        r3 = (r4 > r19 ? 1 : (r4 == r19 ? 0 : -1));
        if (r3 > 0) goto L_0x00b9;
    L_0x0097:
        r1 = r4 + r11;
        r3 = r15 >>> 12;
        r3 = r3 | 480;
        r3 = (byte) r3;
        com.google.android.gms.internal.measurement.zzhw.zza(r4, r3);
        r3 = r1 + r11;
        r5 = r15 >>> 6;
        r5 = r5 & 63;
        r10 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r5 = r5 | r10;
        r5 = (byte) r5;
        com.google.android.gms.internal.measurement.zzhw.zza(r1, r5);
        r1 = r3 + r11;
        r5 = r15 & 63;
        r5 = r5 | r10;
        r5 = (byte) r5;
        com.google.android.gms.internal.measurement.zzhw.zza(r3, r5);
        r4 = r1;
        goto L_0x007f;
    L_0x00b9:
        r19 = 4;
        r19 = r6 - r19;
        r3 = (r4 > r19 ? 1 : (r4 == r19 ? 0 : -1));
        if (r3 > 0) goto L_0x0113;
    L_0x00c1:
        r1 = r9 + 1;
        if (r1 == r8) goto L_0x010a;
    L_0x00c5:
        r2 = r0.charAt(r1);
        r3 = java.lang.Character.isSurrogatePair(r15, r2);
        if (r3 == 0) goto L_0x010b;
    L_0x00cf:
        r2 = java.lang.Character.toCodePoint(r15, r2);
        r9 = r4 + r11;
        r3 = r2 >>> 18;
        r3 = r3 | 240;
        r3 = (byte) r3;
        com.google.android.gms.internal.measurement.zzhw.zza(r4, r3);
        r3 = r9 + r11;
        r5 = r2 >>> 12;
        r5 = r5 & 63;
        r15 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        r5 = r5 | r15;
        r5 = (byte) r5;
        com.google.android.gms.internal.measurement.zzhw.zza(r9, r5);
        r9 = r3 + r11;
        r5 = r2 >>> 6;
        r5 = r5 & 63;
        r5 = r5 | r15;
        r5 = (byte) r5;
        com.google.android.gms.internal.measurement.zzhw.zza(r3, r5);
        r3 = r9 + r11;
        r2 = r2 & 63;
        r2 = r2 | r15;
        r2 = (byte) r2;
        com.google.android.gms.internal.measurement.zzhw.zza(r9, r2);
        r9 = r1;
        r4 = r3;
    L_0x0100:
        r9 = r9 + 1;
        r1 = r23;
        r2 = r17;
        r10 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        goto L_0x0041;
    L_0x010a:
        r1 = r9;
    L_0x010b:
        r0 = new com.google.android.gms.internal.measurement.zzic;
        r1 = r1 + -1;
        r0.<init>(r1, r8);
        throw r0;
    L_0x0113:
        if (r2 > r15) goto L_0x012b;
    L_0x0115:
        if (r15 > r1) goto L_0x012b;
    L_0x0117:
        r1 = r9 + 1;
        if (r1 == r8) goto L_0x0125;
    L_0x011b:
        r0 = r0.charAt(r1);
        r0 = java.lang.Character.isSurrogatePair(r15, r0);
        if (r0 != 0) goto L_0x012b;
    L_0x0125:
        r0 = new com.google.android.gms.internal.measurement.zzic;
        r0.<init>(r9, r8);
        throw r0;
    L_0x012b:
        r0 = new java.lang.ArrayIndexOutOfBoundsException;
        r1 = 46;
        r2 = new java.lang.StringBuilder;
        r2.<init>(r1);
        r2.append(r14);
        r2.append(r15);
        r2.append(r13);
        r2.append(r4);
        r1 = r2.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0148:
        r17 = r2;
        r4 = r4 - r17;
        r0 = (int) r4;
        r1 = r23;
        r1.position(r0);
        return;
    L_0x0153:
        r2 = new java.lang.ArrayIndexOutOfBoundsException;
        r8 = r8 + -1;
        r0 = r0.charAt(r8);
        r1 = r23.limit();
        r3 = 37;
        r4 = new java.lang.StringBuilder;
        r4.<init>(r3);
        r4.append(r14);
        r4.append(r0);
        r4.append(r13);
        r4.append(r1);
        r0 = r4.toString();
        r2.<init>(r0);
        throw r2;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzid.zzb(java.lang.CharSequence, java.nio.ByteBuffer):void");
    }

    final java.lang.String zzh(byte[] r12, int r13, int r14) throws com.google.android.gms.internal.measurement.zzfh {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:39:0x00ea in {6, 15, 16, 20, 22, 27, 29, 32, 34, 36, 38} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r11 = this;
        r0 = r13 | r14;
        r1 = r12.length;
        r1 = r1 - r13;
        r1 = r1 - r14;
        r0 = r0 | r1;
        r1 = 0;
        r2 = 1;
        if (r0 < 0) goto L_0x00c7;
    L_0x000a:
        r0 = r13 + r14;
        r14 = new char[r14];
        r3 = 0;
    L_0x000f:
        if (r13 >= r0) goto L_0x0025;
    L_0x0011:
        r4 = (long) r13;
        r4 = com.google.android.gms.internal.measurement.zzhw.zza(r12, r4);
        r5 = com.google.android.gms.internal.measurement.zzhz.zzd(r4);
        if (r5 == 0) goto L_0x0025;
    L_0x001c:
        r13 = r13 + 1;
        r5 = r3 + 1;
        com.google.android.gms.internal.measurement.zzhz.zza(r4, r14, r3);
        r3 = r5;
        goto L_0x000f;
    L_0x0025:
        r8 = r3;
    L_0x0026:
        if (r13 >= r0) goto L_0x00c1;
    L_0x0028:
        r3 = r13 + 1;
        r4 = (long) r13;
        r13 = com.google.android.gms.internal.measurement.zzhw.zza(r12, r4);
        r4 = com.google.android.gms.internal.measurement.zzhz.zzd(r13);
        if (r4 == 0) goto L_0x0053;
    L_0x0035:
        r4 = r8 + 1;
        com.google.android.gms.internal.measurement.zzhz.zza(r13, r14, r8);
    L_0x003a:
        if (r3 >= r0) goto L_0x0050;
    L_0x003c:
        r5 = (long) r3;
        r13 = com.google.android.gms.internal.measurement.zzhw.zza(r12, r5);
        r5 = com.google.android.gms.internal.measurement.zzhz.zzd(r13);
        if (r5 == 0) goto L_0x0050;
    L_0x0047:
        r3 = r3 + 1;
        r5 = r4 + 1;
        com.google.android.gms.internal.measurement.zzhz.zza(r13, r14, r4);
        r4 = r5;
        goto L_0x003a;
    L_0x0050:
        r13 = r3;
        r8 = r4;
        goto L_0x0026;
    L_0x0053:
        r4 = com.google.android.gms.internal.measurement.zzhz.zze(r13);
        if (r4 == 0) goto L_0x006f;
    L_0x0059:
        if (r3 >= r0) goto L_0x006a;
    L_0x005b:
        r4 = r3 + 1;
        r5 = (long) r3;
        r3 = com.google.android.gms.internal.measurement.zzhw.zza(r12, r5);
        r5 = r8 + 1;
        com.google.android.gms.internal.measurement.zzhz.zza(r13, r3, r14, r8);
        r13 = r4;
        r8 = r5;
        goto L_0x0026;
    L_0x006a:
        r12 = com.google.android.gms.internal.measurement.zzfh.zznc();
        throw r12;
    L_0x006f:
        r4 = com.google.android.gms.internal.measurement.zzhz.zzf(r13);
        if (r4 == 0) goto L_0x0094;
    L_0x0075:
        r4 = r0 + -1;
        if (r3 >= r4) goto L_0x008f;
    L_0x0079:
        r4 = r3 + 1;
        r5 = (long) r3;
        r3 = com.google.android.gms.internal.measurement.zzhw.zza(r12, r5);
        r5 = r4 + 1;
        r6 = (long) r4;
        r4 = com.google.android.gms.internal.measurement.zzhw.zza(r12, r6);
        r6 = r8 + 1;
        com.google.android.gms.internal.measurement.zzhz.zza(r13, r3, r4, r14, r8);
        r13 = r5;
        r8 = r6;
        goto L_0x0026;
    L_0x008f:
        r12 = com.google.android.gms.internal.measurement.zzfh.zznc();
        throw r12;
    L_0x0094:
        r4 = r0 + -2;
        if (r3 >= r4) goto L_0x00bc;
    L_0x0098:
        r4 = r3 + 1;
        r5 = (long) r3;
        r5 = com.google.android.gms.internal.measurement.zzhw.zza(r12, r5);
        r3 = r4 + 1;
        r6 = (long) r4;
        r6 = com.google.android.gms.internal.measurement.zzhw.zza(r12, r6);
        r9 = r3 + 1;
        r3 = (long) r3;
        r7 = com.google.android.gms.internal.measurement.zzhw.zza(r12, r3);
        r10 = r8 + 1;
        r3 = r13;
        r4 = r5;
        r5 = r6;
        r6 = r7;
        r7 = r14;
        com.google.android.gms.internal.measurement.zzhz.zza(r3, r4, r5, r6, r7, r8);
        r10 = r10 + r2;
        r13 = r9;
        r8 = r10;
        goto L_0x0026;
    L_0x00bc:
        r12 = com.google.android.gms.internal.measurement.zzfh.zznc();
        throw r12;
    L_0x00c1:
        r12 = new java.lang.String;
        r12.<init>(r14, r1, r8);
        return r12;
    L_0x00c7:
        r0 = new java.lang.ArrayIndexOutOfBoundsException;
        r3 = 3;
        r3 = new java.lang.Object[r3];
        r12 = r12.length;
        r12 = java.lang.Integer.valueOf(r12);
        r3[r1] = r12;
        r12 = java.lang.Integer.valueOf(r13);
        r3[r2] = r12;
        r12 = java.lang.Integer.valueOf(r14);
        r13 = 2;
        r3[r13] = r12;
        r12 = "buffer length=%d, index=%d, size=%d";
        r12 = java.lang.String.format(r12, r3);
        r0.<init>(r12);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzid.zzh(byte[], int, int):java.lang.String");
    }

    private static int zza(byte[] bArr, int i, long j, int i2) {
        if (i2 == 0) {
            return zzhy.zzbh(i);
        }
        if (i2 == 1) {
            return zzhy.zzr(i, zzhw.zza(bArr, j));
        }
        if (i2 == 2) {
            return zzhy.zzc(i, zzhw.zza(bArr, j), zzhw.zza(bArr, j + 1));
        }
        throw new AssertionError();
    }
}
