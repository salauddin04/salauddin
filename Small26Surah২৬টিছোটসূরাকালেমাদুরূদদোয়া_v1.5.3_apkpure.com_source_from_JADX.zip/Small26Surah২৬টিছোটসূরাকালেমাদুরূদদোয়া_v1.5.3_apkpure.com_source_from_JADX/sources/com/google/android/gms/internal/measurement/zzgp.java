package com.google.android.gms.internal.measurement;

interface zzgp {
    Object newInstance(Object obj);
}
