package com.google.android.gms.internal.ads;

final /* synthetic */ class zzckg implements zzban {
    private final zzbnf zzfzr;

    zzckg(zzbnf zzbnf) {
        this.zzfzr = zzbnf;
    }

    public final Object apply(Object obj) {
        return this.zzfzr.zzadx();
    }
}
