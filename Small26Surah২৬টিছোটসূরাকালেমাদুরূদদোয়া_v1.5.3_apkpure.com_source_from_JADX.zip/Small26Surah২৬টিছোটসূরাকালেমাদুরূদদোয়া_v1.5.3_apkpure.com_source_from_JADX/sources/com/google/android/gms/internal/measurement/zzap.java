package com.google.android.gms.internal.measurement;

import android.os.RemoteException;

final class zzap extends zza {
    private final /* synthetic */ zzaa zzar;
    private final /* synthetic */ zzm zzaw;

    zzap(zzaa zzaa, zzm zzm) {
        this.zzar = zzaa;
        this.zzaw = zzm;
        super(zzaa);
    }

    final void zzl() throws RemoteException {
        this.zzar.zzan.generateEventId(this.zzaw);
    }

    protected final void zzm() {
        this.zzaw.zzb(null);
    }
}
