package com.google.android.gms.internal.ads;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Class;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Constructor;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Field;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Param;

@Class(creator = "MediationConfigurationParcelCreator")
@zzare
public final class zzaix extends AbstractSafeParcelable {
    public static final Creator<zzaix> CREATOR = new zzaiy();
    @Field(id = 2)
    public final Bundle extras;
    @Field(id = 1)
    public final String zzdbf;

    @Constructor
    public zzaix(@Param(id = 1) String str, @Param(id = 2) Bundle bundle) {
        this.zzdbf = str;
        this.extras = bundle;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = SafeParcelWriter.beginObjectHeader(parcel);
        SafeParcelWriter.writeString(parcel, 1, this.zzdbf, false);
        SafeParcelWriter.writeBundle(parcel, 2, this.extras, false);
        SafeParcelWriter.finishObjectHeader(parcel, i);
    }
}
