package com.google.android.gms.internal.measurement;

import java.io.IOException;

final class zzhs extends zzhq<zzhr, zzhr> {
    zzhs() {
    }

    final boolean zza(zzgx zzgx) {
        return false;
    }

    private static void zza(Object obj, zzhr zzhr) {
        ((zzez) obj).zzagn = zzhr;
    }

    final void zzi(Object obj) {
        ((zzez) obj).zzagn.zzjz();
    }

    final /* synthetic */ int zzs(Object obj) {
        return ((zzhr) obj).zzly();
    }

    final /* synthetic */ int zzy(Object obj) {
        return ((zzhr) obj).zzot();
    }

    final /* synthetic */ Object zzg(Object obj, Object obj2) {
        zzhr zzhr = (zzhr) obj;
        zzhr zzhr2 = (zzhr) obj2;
        if (zzhr2.equals(zzhr.zzor())) {
            return zzhr;
        }
        return zzhr.zza(zzhr, zzhr2);
    }

    final /* synthetic */ void zzc(Object obj, zzil zzil) throws IOException {
        ((zzhr) obj).zza(zzil);
    }

    final /* synthetic */ void zza(Object obj, zzil zzil) throws IOException {
        ((zzhr) obj).zzb(zzil);
    }

    final /* synthetic */ void zzf(Object obj, Object obj2) {
        zza(obj, (zzhr) obj2);
    }

    final /* synthetic */ Object zzx(Object obj) {
        zzhr zzhr = ((zzez) obj).zzagn;
        if (zzhr != zzhr.zzor()) {
            return zzhr;
        }
        zzhr = zzhr.zzos();
        zza(obj, zzhr);
        return zzhr;
    }

    final /* synthetic */ Object zzw(Object obj) {
        return ((zzez) obj).zzagn;
    }

    final /* synthetic */ void zze(Object obj, Object obj2) {
        zza(obj, (zzhr) obj2);
    }

    final /* synthetic */ Object zzp(Object obj) {
        zzhr zzhr = (zzhr) obj;
        zzhr.zzjz();
        return zzhr;
    }

    final /* synthetic */ Object zzoq() {
        return zzhr.zzos();
    }

    final /* synthetic */ void zza(Object obj, int i, Object obj2) {
        ((zzhr) obj).zzb((i << 3) | 3, (zzhr) obj2);
    }

    final /* synthetic */ void zza(Object obj, int i, zzdp zzdp) {
        ((zzhr) obj).zzb((i << 3) | 2, (Object) zzdp);
    }

    final /* synthetic */ void zzb(Object obj, int i, long j) {
        ((zzhr) obj).zzb((i << 3) | 1, Long.valueOf(j));
    }

    final /* synthetic */ void zzc(Object obj, int i, int i2) {
        ((zzhr) obj).zzb((i << 3) | 5, Integer.valueOf(i2));
    }

    final /* synthetic */ void zza(Object obj, int i, long j) {
        ((zzhr) obj).zzb(i << 3, Long.valueOf(j));
    }
}
