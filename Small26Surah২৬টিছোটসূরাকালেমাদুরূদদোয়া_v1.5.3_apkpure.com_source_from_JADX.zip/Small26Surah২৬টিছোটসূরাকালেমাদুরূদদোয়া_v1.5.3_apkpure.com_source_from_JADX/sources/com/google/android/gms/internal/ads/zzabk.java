package com.google.android.gms.internal.ads;

import android.os.RemoteException;
import com.google.android.gms.ads.formats.PublisherAdViewOptions;

public final class zzabk extends zzze {
    private zzyx zzcjw;

    public final void zza(PublisherAdViewOptions publisherAdViewOptions) throws RemoteException {
    }

    public final void zza(zzadx zzadx) throws RemoteException {
    }

    public final void zza(zzafh zzafh) throws RemoteException {
    }

    public final void zza(zzafk zzafk) throws RemoteException {
    }

    public final void zza(zzaft zzaft, zzyb zzyb) throws RemoteException {
    }

    public final void zza(zzafw zzafw) throws RemoteException {
    }

    public final void zza(zzaiz zzaiz) throws RemoteException {
    }

    public final void zza(zzajf zzajf) throws RemoteException {
    }

    public final void zza(zzzw zzzw) throws RemoteException {
    }

    public final void zza(String str, zzafq zzafq, zzafn zzafn) throws RemoteException {
    }

    public final void zza(zzyx zzyx) throws RemoteException {
        this.zzcjw = zzyx;
    }

    public final zzza zzpk() throws RemoteException {
        return new zzabm();
    }
}
