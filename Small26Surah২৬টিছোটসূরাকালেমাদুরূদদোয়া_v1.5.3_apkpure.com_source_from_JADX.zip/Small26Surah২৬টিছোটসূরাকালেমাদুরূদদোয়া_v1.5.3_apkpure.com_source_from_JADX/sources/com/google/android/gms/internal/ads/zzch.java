package com.google.android.gms.internal.ads;

import java.util.HashMap;

public final class zzch extends zzcf<Integer, Object> {
    public String zzne;
    public long zznf;
    public String zzng;
    public String zznh;
    public String zzni;

    public zzch(String str) {
        this();
        zzak(str);
    }

    public zzch() {
        String str = "E";
        this.zzne = str;
        this.zznf = -1;
        this.zzng = str;
        this.zznh = str;
        this.zzni = str;
    }

    protected final void zzak(String str) {
        str = zzcf.zzal(str);
        if (str != null) {
            String str2;
            long j;
            String str3 = "E";
            if (str.get(Integer.valueOf(0)) == null) {
                str2 = str3;
            } else {
                str2 = (String) str.get(Integer.valueOf(0));
            }
            this.zzne = str2;
            if (str.get(Integer.valueOf(1)) == null) {
                j = -1;
            } else {
                j = ((Long) str.get(Integer.valueOf(1))).longValue();
            }
            this.zznf = j;
            if (str.get(Integer.valueOf(2)) == null) {
                str2 = str3;
            } else {
                str2 = (String) str.get(Integer.valueOf(2));
            }
            this.zzng = str2;
            if (str.get(Integer.valueOf(3)) == null) {
                str2 = str3;
            } else {
                str2 = (String) str.get(Integer.valueOf(3));
            }
            this.zznh = str2;
            if (str.get(Integer.valueOf(4)) != null) {
                str3 = (String) str.get(Integer.valueOf(4));
            }
            this.zzni = str3;
        }
    }

    protected final HashMap<Integer, Object> zzca() {
        HashMap<Integer, Object> hashMap = new HashMap();
        hashMap.put(Integer.valueOf(0), this.zzne);
        hashMap.put(Integer.valueOf(4), this.zzni);
        hashMap.put(Integer.valueOf(3), this.zznh);
        hashMap.put(Integer.valueOf(2), this.zzng);
        hashMap.put(Integer.valueOf(1), Long.valueOf(this.zznf));
        return hashMap;
    }
}
