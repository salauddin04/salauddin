package com.google.android.gms.internal.ads;

import com.google.android.gms.internal.ads.zzdoa.zze;

final /* synthetic */ class zzdgh {
    static final /* synthetic */ int[] zzdi = new int[zze.zzayb().length];

    static {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = com.google.android.gms.internal.ads.zzdoa.zze.zzayb();
        r0 = r0.length;
        r0 = new int[r0];
        zzdi = r0;
        r0 = 1;
        r1 = zzdi;	 Catch:{ NoSuchFieldError -> 0x0011 }
        r2 = com.google.android.gms.internal.ads.zzdoa.zze.zzhhn;	 Catch:{ NoSuchFieldError -> 0x0011 }
        r2 = r2 - r0;	 Catch:{ NoSuchFieldError -> 0x0011 }
        r1[r2] = r0;	 Catch:{ NoSuchFieldError -> 0x0011 }
    L_0x0011:
        r1 = zzdi;	 Catch:{ NoSuchFieldError -> 0x0019 }
        r2 = com.google.android.gms.internal.ads.zzdoa.zze.zzhho;	 Catch:{ NoSuchFieldError -> 0x0019 }
        r2 = r2 - r0;	 Catch:{ NoSuchFieldError -> 0x0019 }
        r3 = 2;	 Catch:{ NoSuchFieldError -> 0x0019 }
        r1[r2] = r3;	 Catch:{ NoSuchFieldError -> 0x0019 }
    L_0x0019:
        r1 = zzdi;	 Catch:{ NoSuchFieldError -> 0x0021 }
        r2 = com.google.android.gms.internal.ads.zzdoa.zze.zzhhm;	 Catch:{ NoSuchFieldError -> 0x0021 }
        r2 = r2 - r0;	 Catch:{ NoSuchFieldError -> 0x0021 }
        r3 = 3;	 Catch:{ NoSuchFieldError -> 0x0021 }
        r1[r2] = r3;	 Catch:{ NoSuchFieldError -> 0x0021 }
    L_0x0021:
        r1 = zzdi;	 Catch:{ NoSuchFieldError -> 0x0029 }
        r2 = com.google.android.gms.internal.ads.zzdoa.zze.zzhhp;	 Catch:{ NoSuchFieldError -> 0x0029 }
        r2 = r2 - r0;	 Catch:{ NoSuchFieldError -> 0x0029 }
        r3 = 4;	 Catch:{ NoSuchFieldError -> 0x0029 }
        r1[r2] = r3;	 Catch:{ NoSuchFieldError -> 0x0029 }
    L_0x0029:
        r1 = zzdi;	 Catch:{ NoSuchFieldError -> 0x0031 }
        r2 = com.google.android.gms.internal.ads.zzdoa.zze.zzhhq;	 Catch:{ NoSuchFieldError -> 0x0031 }
        r2 = r2 - r0;	 Catch:{ NoSuchFieldError -> 0x0031 }
        r3 = 5;	 Catch:{ NoSuchFieldError -> 0x0031 }
        r1[r2] = r3;	 Catch:{ NoSuchFieldError -> 0x0031 }
    L_0x0031:
        r1 = zzdi;	 Catch:{ NoSuchFieldError -> 0x0039 }
        r2 = com.google.android.gms.internal.ads.zzdoa.zze.zzhhk;	 Catch:{ NoSuchFieldError -> 0x0039 }
        r2 = r2 - r0;	 Catch:{ NoSuchFieldError -> 0x0039 }
        r3 = 6;	 Catch:{ NoSuchFieldError -> 0x0039 }
        r1[r2] = r3;	 Catch:{ NoSuchFieldError -> 0x0039 }
    L_0x0039:
        r1 = zzdi;	 Catch:{ NoSuchFieldError -> 0x0041 }
        r2 = com.google.android.gms.internal.ads.zzdoa.zze.zzhhl;	 Catch:{ NoSuchFieldError -> 0x0041 }
        r2 = r2 - r0;	 Catch:{ NoSuchFieldError -> 0x0041 }
        r0 = 7;	 Catch:{ NoSuchFieldError -> 0x0041 }
        r1[r2] = r0;	 Catch:{ NoSuchFieldError -> 0x0041 }
    L_0x0041:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzdgh.<clinit>():void");
    }
}
