package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzbt.zze.zzb;

final class zzbv implements zzfd<zzb> {
    zzbv() {
    }
}
