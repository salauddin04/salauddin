package com.google.android.gms.internal.measurement;

public interface zzgs<MessageType> {
    MessageType zza(zzeb zzeb, zzem zzem) throws zzfh;
}
