package com.google.android.gms.internal.ads;

import java.util.Map;

final /* synthetic */ class zzaus implements zzbam {
    private final zzaur zzdro;

    zzaus(zzaur zzaur) {
        this.zzdro = zzaur;
    }

    public final zzbbi zzf(Object obj) {
        return this.zzdro.zzh((Map) obj);
    }
}
