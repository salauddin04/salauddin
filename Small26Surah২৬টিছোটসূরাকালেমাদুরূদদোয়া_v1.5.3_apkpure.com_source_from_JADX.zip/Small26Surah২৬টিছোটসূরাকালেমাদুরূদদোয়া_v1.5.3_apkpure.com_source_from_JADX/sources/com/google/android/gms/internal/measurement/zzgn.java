package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map.Entry;

final class zzgn<T> implements zzgy<T> {
    private final zzgh zzaje;
    private final boolean zzajf;
    private final zzhq<?, ?> zzajo;
    private final zzen<?> zzajp;

    private zzgn(zzhq<?, ?> zzhq, zzen<?> zzen, zzgh zzgh) {
        this.zzajo = zzhq;
        this.zzajf = zzen.zze(zzgh);
        this.zzajp = zzen;
        this.zzaje = zzgh;
    }

    public final void zza(T r11, com.google.android.gms.internal.measurement.zzgx r12, com.google.android.gms.internal.measurement.zzem r13) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:46:0x0093 in {6, 14, 15, 16, 22, 26, 27, 29, 34, 35, 36, 39, 42, 45} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r10 = this;
        r0 = r10.zzajo;
        r1 = r10.zzajp;
        r2 = r0.zzx(r11);
        r3 = r1.zzh(r11);
    L_0x000c:
        r4 = r12.zzlh();	 Catch:{ all -> 0x008e }
        r5 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        if (r4 != r5) goto L_0x0019;
    L_0x0015:
        r0.zzf(r11, r2);
        return;
    L_0x0019:
        r4 = r12.getTag();	 Catch:{ all -> 0x008e }
        r6 = 11;	 Catch:{ all -> 0x008e }
        if (r4 == r6) goto L_0x003e;	 Catch:{ all -> 0x008e }
    L_0x0021:
        r5 = r4 & 7;	 Catch:{ all -> 0x008e }
        r6 = 2;	 Catch:{ all -> 0x008e }
        if (r5 != r6) goto L_0x0039;	 Catch:{ all -> 0x008e }
    L_0x0026:
        r5 = r10.zzaje;	 Catch:{ all -> 0x008e }
        r4 = r4 >>> 3;	 Catch:{ all -> 0x008e }
        r4 = r1.zza(r13, r5, r4);	 Catch:{ all -> 0x008e }
        if (r4 == 0) goto L_0x0034;	 Catch:{ all -> 0x008e }
    L_0x0030:
        r1.zza(r12, r4, r13, r3);	 Catch:{ all -> 0x008e }
        goto L_0x0082;	 Catch:{ all -> 0x008e }
    L_0x0034:
        r4 = r0.zza(r2, r12);	 Catch:{ all -> 0x008e }
        goto L_0x0083;	 Catch:{ all -> 0x008e }
    L_0x0039:
        r4 = r12.zzli();	 Catch:{ all -> 0x008e }
        goto L_0x0083;	 Catch:{ all -> 0x008e }
    L_0x003e:
        r4 = 0;	 Catch:{ all -> 0x008e }
        r6 = 0;	 Catch:{ all -> 0x008e }
        r7 = r6;	 Catch:{ all -> 0x008e }
    L_0x0041:
        r8 = r12.zzlh();	 Catch:{ all -> 0x008e }
        if (r8 == r5) goto L_0x006f;	 Catch:{ all -> 0x008e }
    L_0x0047:
        r8 = r12.getTag();	 Catch:{ all -> 0x008e }
        r9 = 16;	 Catch:{ all -> 0x008e }
        if (r8 != r9) goto L_0x005a;	 Catch:{ all -> 0x008e }
    L_0x004f:
        r4 = r12.zzks();	 Catch:{ all -> 0x008e }
        r6 = r10.zzaje;	 Catch:{ all -> 0x008e }
        r6 = r1.zza(r13, r6, r4);	 Catch:{ all -> 0x008e }
        goto L_0x0041;	 Catch:{ all -> 0x008e }
    L_0x005a:
        r9 = 26;	 Catch:{ all -> 0x008e }
        if (r8 != r9) goto L_0x0069;	 Catch:{ all -> 0x008e }
    L_0x005e:
        if (r6 == 0) goto L_0x0064;	 Catch:{ all -> 0x008e }
    L_0x0060:
        r1.zza(r12, r6, r13, r3);	 Catch:{ all -> 0x008e }
        goto L_0x0041;	 Catch:{ all -> 0x008e }
    L_0x0064:
        r7 = r12.zzkr();	 Catch:{ all -> 0x008e }
        goto L_0x0041;	 Catch:{ all -> 0x008e }
    L_0x0069:
        r8 = r12.zzli();	 Catch:{ all -> 0x008e }
        if (r8 != 0) goto L_0x0041;	 Catch:{ all -> 0x008e }
    L_0x006f:
        r5 = r12.getTag();	 Catch:{ all -> 0x008e }
        r8 = 12;	 Catch:{ all -> 0x008e }
        if (r5 != r8) goto L_0x0089;	 Catch:{ all -> 0x008e }
    L_0x0077:
        if (r7 == 0) goto L_0x0082;	 Catch:{ all -> 0x008e }
    L_0x0079:
        if (r6 == 0) goto L_0x007f;	 Catch:{ all -> 0x008e }
    L_0x007b:
        r1.zza(r7, r6, r13, r3);	 Catch:{ all -> 0x008e }
        goto L_0x0082;	 Catch:{ all -> 0x008e }
    L_0x007f:
        r0.zza(r2, r4, r7);	 Catch:{ all -> 0x008e }
    L_0x0082:
        r4 = 1;
    L_0x0083:
        if (r4 != 0) goto L_0x000c;
    L_0x0085:
        r0.zzf(r11, r2);
        return;
    L_0x0089:
        r12 = com.google.android.gms.internal.measurement.zzfh.zzmy();	 Catch:{ all -> 0x008e }
        throw r12;	 Catch:{ all -> 0x008e }
    L_0x008e:
        r12 = move-exception;
        r0.zzf(r11, r2);
        throw r12;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzgn.zza(java.lang.Object, com.google.android.gms.internal.measurement.zzgx, com.google.android.gms.internal.measurement.zzem):void");
    }

    public final void zza(T r10, byte[] r11, int r12, int r13, com.google.android.gms.internal.measurement.zzdm r14) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:39:0x00ac in {2, 11, 13, 14, 21, 24, 26, 28, 31, 33, 34, 36, 38} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r9 = this;
        r0 = r10;
        r0 = (com.google.android.gms.internal.measurement.zzez) r0;
        r1 = r0.zzagn;
        r2 = com.google.android.gms.internal.measurement.zzhr.zzor();
        if (r1 != r2) goto L_0x0011;
    L_0x000b:
        r1 = com.google.android.gms.internal.measurement.zzhr.zzos();
        r0.zzagn = r1;
    L_0x0011:
        r10 = (com.google.android.gms.internal.measurement.zzez.zzc) r10;
        r10.zzms();
        r10 = 0;
        r0 = r10;
    L_0x0018:
        if (r12 >= r13) goto L_0x00a4;
    L_0x001a:
        r4 = com.google.android.gms.internal.measurement.zzdl.zza(r11, r12, r14);
        r2 = r14.zzabs;
        r12 = 11;
        r3 = 2;
        if (r2 == r12) goto L_0x0051;
    L_0x0025:
        r12 = r2 & 7;
        if (r12 != r3) goto L_0x004c;
    L_0x0029:
        r12 = r9.zzajp;
        r0 = r14.zzabv;
        r3 = r9.zzaje;
        r5 = r2 >>> 3;
        r12 = r12.zza(r0, r3, r5);
        r0 = r12;
        r0 = (com.google.android.gms.internal.measurement.zzez.zzd) r0;
        if (r0 != 0) goto L_0x0043;
    L_0x003a:
        r3 = r11;
        r5 = r13;
        r6 = r1;
        r7 = r14;
        r12 = com.google.android.gms.internal.measurement.zzdl.zza(r2, r3, r4, r5, r6, r7);
        goto L_0x0018;
    L_0x0043:
        com.google.android.gms.internal.measurement.zzgu.zznz();
        r10 = new java.lang.NoSuchMethodError;
        r10.<init>();
        throw r10;
    L_0x004c:
        r12 = com.google.android.gms.internal.measurement.zzdl.zza(r2, r11, r4, r13, r14);
        goto L_0x0018;
    L_0x0051:
        r12 = 0;
        r2 = r10;
    L_0x0053:
        if (r4 >= r13) goto L_0x0099;
    L_0x0055:
        r4 = com.google.android.gms.internal.measurement.zzdl.zza(r11, r4, r14);
        r5 = r14.zzabs;
        r6 = r5 >>> 3;
        r7 = r5 & 7;
        if (r6 == r3) goto L_0x007b;
    L_0x0061:
        r8 = 3;
        if (r6 == r8) goto L_0x0065;
    L_0x0064:
        goto L_0x0090;
    L_0x0065:
        if (r0 != 0) goto L_0x0072;
    L_0x0067:
        if (r7 != r3) goto L_0x0090;
    L_0x0069:
        r4 = com.google.android.gms.internal.measurement.zzdl.zze(r11, r4, r14);
        r2 = r14.zzabu;
        r2 = (com.google.android.gms.internal.measurement.zzdp) r2;
        goto L_0x0053;
    L_0x0072:
        com.google.android.gms.internal.measurement.zzgu.zznz();
        r10 = new java.lang.NoSuchMethodError;
        r10.<init>();
        throw r10;
    L_0x007b:
        if (r7 != 0) goto L_0x0090;
    L_0x007d:
        r4 = com.google.android.gms.internal.measurement.zzdl.zza(r11, r4, r14);
        r12 = r14.zzabs;
        r0 = r9.zzajp;
        r5 = r14.zzabv;
        r6 = r9.zzaje;
        r0 = r0.zza(r5, r6, r12);
        r0 = (com.google.android.gms.internal.measurement.zzez.zzd) r0;
        goto L_0x0053;
    L_0x0090:
        r6 = 12;
        if (r5 == r6) goto L_0x0099;
    L_0x0094:
        r4 = com.google.android.gms.internal.measurement.zzdl.zza(r5, r11, r4, r13, r14);
        goto L_0x0053;
    L_0x0099:
        if (r2 == 0) goto L_0x00a1;
    L_0x009b:
        r12 = r12 << 3;
        r12 = r12 | r3;
        r1.zzb(r12, r2);
    L_0x00a1:
        r12 = r4;
        goto L_0x0018;
    L_0x00a4:
        if (r12 != r13) goto L_0x00a7;
    L_0x00a6:
        return;
    L_0x00a7:
        r10 = com.google.android.gms.internal.measurement.zzfh.zznb();
        throw r10;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzgn.zza(java.lang.Object, byte[], int, int, com.google.android.gms.internal.measurement.zzdm):void");
    }

    static <T> zzgn<T> zza(zzhq<?, ?> zzhq, zzen<?> zzen, zzgh zzgh) {
        return new zzgn(zzhq, zzen, zzgh);
    }

    public final T newInstance() {
        return this.zzaje.zzml().zzmq();
    }

    public final boolean equals(T t, T t2) {
        if (this.zzajo.zzw(t).equals(this.zzajo.zzw(t2))) {
            return this.zzajf ? this.zzajp.zzg(t).equals(this.zzajp.zzg(t2)) : true;
        } else {
            return null;
        }
    }

    public final int hashCode(T t) {
        int hashCode = this.zzajo.zzw(t).hashCode();
        return this.zzajf ? (hashCode * 53) + this.zzajp.zzg(t).hashCode() : hashCode;
    }

    public final void zzc(T t, T t2) {
        zzha.zza(this.zzajo, (Object) t, (Object) t2);
        if (this.zzajf) {
            zzha.zza(this.zzajp, (Object) t, (Object) t2);
        }
    }

    public final void zza(T t, zzil zzil) throws IOException {
        Iterator it = this.zzajp.zzg(t).iterator();
        while (it.hasNext()) {
            Entry entry = (Entry) it.next();
            zzes zzes = (zzes) entry.getKey();
            if (zzes.zzmb() != zzik.MESSAGE || zzes.zzmc() || zzes.zzmd()) {
                throw new IllegalStateException("Found invalid MessageSet item.");
            } else if (entry instanceof zzfm) {
                zzil.zza(zzes.zzgp(), ((zzfm) entry).zznf().zzjv());
            } else {
                zzil.zza(zzes.zzgp(), entry.getValue());
            }
        }
        zzhq zzhq = this.zzajo;
        zzhq.zzc(zzhq.zzw(t), zzil);
    }

    public final void zzi(T t) {
        this.zzajo.zzi(t);
        this.zzajp.zzi(t);
    }

    public final boolean zzu(T t) {
        return this.zzajp.zzg(t).isInitialized();
    }

    public final int zzs(T t) {
        zzhq zzhq = this.zzajo;
        int zzy = zzhq.zzy(zzhq.zzw(t)) + 0;
        return this.zzajf ? zzy + this.zzajp.zzg(t).zzlz() : zzy;
    }
}
