package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.util.List;
import java.util.RandomAccess;

final class zzha {
    private static final Class<?> zzajx = zzog();
    private static final zzhq<?, ?> zzajy = zzp(false);
    private static final zzhq<?, ?> zzajz = zzp(true);
    private static final zzhq<?, ?> zzaka = new zzhs();

    public static void zzg(Class<?> cls) {
        if (!zzez.class.isAssignableFrom(cls)) {
            Class cls2 = zzajx;
            if (cls2 == null) {
                return;
            }
            if (cls2.isAssignableFrom(cls) == null) {
                throw new IllegalArgumentException("Message classes must extend GeneratedMessage or GeneratedMessageLite");
            }
        }
    }

    public static void zza(int i, List<Double> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzg(i, list, z);
        }
    }

    public static void zzb(int i, List<Float> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzf(i, list, z);
        }
    }

    public static void zzc(int i, List<Long> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzc(i, list, z);
        }
    }

    public static void zzd(int i, List<Long> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzd(i, list, z);
        }
    }

    public static void zze(int i, List<Long> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzn(i, list, z);
        }
    }

    public static void zzf(int i, List<Long> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zze(i, list, z);
        }
    }

    public static void zzg(int i, List<Long> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzl(i, list, z);
        }
    }

    public static void zzh(int i, List<Integer> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zza(i, (List) list, z);
        }
    }

    public static void zzi(int i, List<Integer> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzj(i, list, z);
        }
    }

    public static void zzj(int i, List<Integer> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzm(i, list, z);
        }
    }

    public static void zzk(int i, List<Integer> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzb(i, (List) list, z);
        }
    }

    public static void zzl(int i, List<Integer> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzk(i, list, z);
        }
    }

    public static void zzm(int i, List<Integer> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzh(i, list, z);
        }
    }

    public static void zzn(int i, List<Boolean> list, zzil zzil, boolean z) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzi(i, list, z);
        }
    }

    public static void zza(int i, List<String> list, zzil zzil) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zza(i, (List) list);
        }
    }

    public static void zzb(int i, List<zzdp> list, zzil zzil) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzb(i, (List) list);
        }
    }

    public static void zza(int i, List<?> list, zzil zzil, zzgy zzgy) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zza(i, (List) list, zzgy);
        }
    }

    public static void zzb(int i, List<?> list, zzil zzil, zzgy zzgy) throws IOException {
        if (list != null && !list.isEmpty()) {
            zzil.zzb(i, (List) list, zzgy);
        }
    }

    static int zzt(List<Long> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzfv) {
            zzfv zzfv = (zzfv) list;
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzat(zzfv.getLong(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzat(((Long) list.get(i)).longValue());
                i++;
            }
        }
        return i2;
    }

    static int zzo(int i, List<Long> list, boolean z) {
        if (list.size()) {
            return zzt(list) + (list.size() * zzeg.zzaj(i));
        }
        return 0;
    }

    static int zzu(List<Long> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzfv) {
            zzfv zzfv = (zzfv) list;
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzau(zzfv.getLong(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzau(((Long) list.get(i)).longValue());
                i++;
            }
        }
        return i2;
    }

    static int zzp(int i, List<Long> list, boolean z) {
        z = list.size();
        if (z) {
            return zzu(list) + (z * zzeg.zzaj(i));
        }
        return 0;
    }

    static int zzv(List<Long> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzfv) {
            zzfv zzfv = (zzfv) list;
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzav(zzfv.getLong(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzav(((Long) list.get(i)).longValue());
                i++;
            }
        }
        return i2;
    }

    static int zzq(int i, List<Long> list, boolean z) {
        z = list.size();
        if (z) {
            return zzv(list) + (z * zzeg.zzaj(i));
        }
        return 0;
    }

    static int zzw(List<Integer> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzfa) {
            zzfa zzfa = (zzfa) list;
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzap(zzfa.getInt(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzap(((Integer) list.get(i)).intValue());
                i++;
            }
        }
        return i2;
    }

    static int zzr(int i, List<Integer> list, boolean z) {
        z = list.size();
        if (z) {
            return zzw(list) + (z * zzeg.zzaj(i));
        }
        return 0;
    }

    static int zzx(List<Integer> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzfa) {
            zzfa zzfa = (zzfa) list;
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzak(zzfa.getInt(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzak(((Integer) list.get(i)).intValue());
                i++;
            }
        }
        return i2;
    }

    static int zzs(int i, List<Integer> list, boolean z) {
        z = list.size();
        if (z) {
            return zzx(list) + (z * zzeg.zzaj(i));
        }
        return 0;
    }

    static int zzy(List<Integer> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzfa) {
            zzfa zzfa = (zzfa) list;
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzal(zzfa.getInt(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzal(((Integer) list.get(i)).intValue());
                i++;
            }
        }
        return i2;
    }

    static int zzt(int i, List<Integer> list, boolean z) {
        z = list.size();
        if (z) {
            return zzy(list) + (z * zzeg.zzaj(i));
        }
        return 0;
    }

    static int zzz(List<Integer> list) {
        int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int i2;
        if (list instanceof zzfa) {
            zzfa zzfa = (zzfa) list;
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzam(zzfa.getInt(i));
                i++;
            }
        } else {
            i2 = 0;
            while (i < size) {
                i2 += zzeg.zzam(((Integer) list.get(i)).intValue());
                i++;
            }
        }
        return i2;
    }

    static int zzu(int i, List<Integer> list, boolean z) {
        z = list.size();
        if (z) {
            return zzz(list) + (z * zzeg.zzaj(i));
        }
        return 0;
    }

    static int zzaa(List<?> list) {
        return list.size() << 2;
    }

    static int zzv(int i, List<?> list, boolean z) {
        list = list.size();
        if (list == null) {
            return 0;
        }
        return list * zzeg.zzj(i, 0);
    }

    static int zzab(List<?> list) {
        return list.size() << 3;
    }

    static int zzw(int i, List<?> list, boolean z) {
        list = list.size();
        if (list == null) {
            return 0;
        }
        return list * zzeg.zzg(i, 0);
    }

    static int zzac(List<?> list) {
        return list.size();
    }

    static int zzx(int i, List<?> list, boolean z) {
        list = list.size();
        if (list == null) {
            return 0;
        }
        return list * zzeg.zzc(i, true);
    }

    static int zzc(int i, List<?> list) {
        int size = list.size();
        int i2 = 0;
        if (size == 0) {
            return 0;
        }
        i = zzeg.zzaj(i) * size;
        Object zzaw;
        int zzb;
        if (list instanceof zzfq) {
            zzfq zzfq = (zzfq) list;
            while (i2 < size) {
                zzaw = zzfq.zzaw(i2);
                if (zzaw instanceof zzdp) {
                    zzb = zzeg.zzb((zzdp) zzaw);
                } else {
                    zzb = zzeg.zzcp((String) zzaw);
                }
                i += zzb;
                i2++;
            }
        } else {
            while (i2 < size) {
                zzaw = list.get(i2);
                if (zzaw instanceof zzdp) {
                    zzb = zzeg.zzb((zzdp) zzaw);
                } else {
                    zzb = zzeg.zzcp((String) zzaw);
                }
                i += zzb;
                i2++;
            }
        }
        return i;
    }

    static int zzc(int i, Object obj, zzgy zzgy) {
        if (obj instanceof zzfo) {
            return zzeg.zza(i, (zzfo) obj);
        }
        return zzeg.zzb(i, (zzgh) obj, zzgy);
    }

    static int zzc(int i, List<?> list, zzgy zzgy) {
        int size = list.size();
        int i2 = 0;
        if (size == 0) {
            return 0;
        }
        i = zzeg.zzaj(i) * size;
        while (i2 < size) {
            int zza;
            Object obj = list.get(i2);
            if (obj instanceof zzfo) {
                zza = zzeg.zza((zzfo) obj);
            } else {
                zza = zzeg.zzb((zzgh) obj, zzgy);
            }
            i += zza;
            i2++;
        }
        return i;
    }

    static int zzd(int i, List<zzdp> list) {
        int size = list.size();
        int i2 = 0;
        if (size == 0) {
            return 0;
        }
        size *= zzeg.zzaj(i);
        while (i2 < list.size()) {
            size += zzeg.zzb((zzdp) list.get(i2));
            i2++;
        }
        return size;
    }

    static int zzd(int i, List<zzgh> list, zzgy zzgy) {
        int size = list.size();
        int i2 = 0;
        if (size == 0) {
            return 0;
        }
        int i3 = 0;
        while (i2 < size) {
            i3 += zzeg.zzc(i, (zzgh) list.get(i2), zzgy);
            i2++;
        }
        return i3;
    }

    public static zzhq<?, ?> zzod() {
        return zzajy;
    }

    public static zzhq<?, ?> zzoe() {
        return zzajz;
    }

    public static zzhq<?, ?> zzof() {
        return zzaka;
    }

    private static com.google.android.gms.internal.measurement.zzhq<?, ?> zzp(boolean r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = 0;
        r1 = zzoh();	 Catch:{ Throwable -> 0x0023 }
        if (r1 != 0) goto L_0x0008;	 Catch:{ Throwable -> 0x0023 }
    L_0x0007:
        return r0;	 Catch:{ Throwable -> 0x0023 }
    L_0x0008:
        r2 = 1;	 Catch:{ Throwable -> 0x0023 }
        r3 = new java.lang.Class[r2];	 Catch:{ Throwable -> 0x0023 }
        r4 = java.lang.Boolean.TYPE;	 Catch:{ Throwable -> 0x0023 }
        r5 = 0;	 Catch:{ Throwable -> 0x0023 }
        r3[r5] = r4;	 Catch:{ Throwable -> 0x0023 }
        r1 = r1.getConstructor(r3);	 Catch:{ Throwable -> 0x0023 }
        r2 = new java.lang.Object[r2];	 Catch:{ Throwable -> 0x0023 }
        r6 = java.lang.Boolean.valueOf(r6);	 Catch:{ Throwable -> 0x0023 }
        r2[r5] = r6;	 Catch:{ Throwable -> 0x0023 }
        r6 = r1.newInstance(r2);	 Catch:{ Throwable -> 0x0023 }
        r6 = (com.google.android.gms.internal.measurement.zzhq) r6;	 Catch:{ Throwable -> 0x0023 }
        return r6;
    L_0x0023:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzha.zzp(boolean):com.google.android.gms.internal.measurement.zzhq<?, ?>");
    }

    private static java.lang.Class<?> zzog() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = "com.google.protobuf.GeneratedMessage";	 Catch:{ Throwable -> 0x0007 }
        r0 = java.lang.Class.forName(r0);	 Catch:{ Throwable -> 0x0007 }
        return r0;
    L_0x0007:
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzha.zzog():java.lang.Class<?>");
    }

    private static java.lang.Class<?> zzoh() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = "com.google.protobuf.UnknownFieldSetSchema";	 Catch:{ Throwable -> 0x0007 }
        r0 = java.lang.Class.forName(r0);	 Catch:{ Throwable -> 0x0007 }
        return r0;
    L_0x0007:
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzha.zzoh():java.lang.Class<?>");
    }

    static boolean zzd(Object obj, Object obj2) {
        if (obj != obj2) {
            if (obj == null || obj.equals(obj2) == null) {
                return null;
            }
        }
        return true;
    }

    static <T> void zza(zzgc zzgc, T t, T t2, long j) {
        zzhw.zza((Object) t, j, zzgc.zzb(zzhw.zzp(t, j), zzhw.zzp(t2, j)));
    }

    static <T, FT extends zzes<FT>> void zza(zzen<FT> zzen, T t, T t2) {
        zzeq zzg = zzen.zzg(t2);
        if (!zzg.isEmpty()) {
            zzen.zzh(t).zza(zzg);
        }
    }

    static <T, UT, UB> void zza(zzhq<UT, UB> zzhq, T t, T t2) {
        zzhq.zze(t, zzhq.zzg(zzhq.zzw(t), zzhq.zzw(t2)));
    }

    static <UT, UB> UB zza(int i, List<Integer> list, zzfe zzfe, UB ub, zzhq<UT, UB> zzhq) {
        if (zzfe == null) {
            return ub;
        }
        UB ub2;
        if (!(list instanceof RandomAccess)) {
            list = list.iterator();
            loop1:
            while (true) {
                ub2 = ub;
                while (list.hasNext() != null) {
                    int intValue = ((Integer) list.next()).intValue();
                    if (!zzfe.zzf(intValue)) {
                        ub = zza(i, intValue, (Object) ub2, (zzhq) zzhq);
                        list.remove();
                    }
                }
                break loop1;
            }
        }
        UB size = list.size();
        ub2 = ub;
        ub = null;
        for (UB ub3 = null; ub3 < size; ub3++) {
            int intValue2 = ((Integer) list.get(ub3)).intValue();
            if (zzfe.zzf(intValue2)) {
                if (ub3 != ub) {
                    list.set(ub, Integer.valueOf(intValue2));
                }
                ub++;
            } else {
                ub2 = zza(i, intValue2, (Object) ub2, (zzhq) zzhq);
            }
        }
        if (ub != size) {
            list.subList(ub, size).clear();
        }
        return ub2;
    }

    static <UT, UB> UB zza(int i, int i2, UB ub, zzhq<UT, UB> zzhq) {
        Object zzoq;
        if (ub == null) {
            zzoq = zzhq.zzoq();
        }
        zzhq.zza(zzoq, i, (long) i2);
        return zzoq;
    }
}
