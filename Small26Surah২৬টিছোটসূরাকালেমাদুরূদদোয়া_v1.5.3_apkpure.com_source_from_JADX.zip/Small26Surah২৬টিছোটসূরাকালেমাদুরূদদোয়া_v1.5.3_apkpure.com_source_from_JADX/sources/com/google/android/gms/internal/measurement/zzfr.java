package com.google.android.gms.internal.measurement;

import java.util.List;

abstract class zzfr {
    private static final zzfr zzaik = new zzft();
    private static final zzfr zzail = new zzfu();

    private zzfr() {
    }

    abstract <L> List<L> zza(Object obj, long j);

    abstract <L> void zza(Object obj, Object obj2, long j);

    abstract void zzb(Object obj, long j);

    static zzfr zzni() {
        return zzaik;
    }

    static zzfr zznj() {
        return zzail;
    }
}
