package com.google.android.gms.internal.ads;

import org.json.JSONObject;

public final class zzcvw implements zzcuy<JSONObject> {
    private final JSONObject zzgix;

    public zzcvw(JSONObject jSONObject) {
        this.zzgix = jSONObject;
    }

    public final /* synthetic */ void zzt(java.lang.Object r5) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r4 = this;
        r5 = (org.json.JSONObject) r5;
        r0 = "content_info";	 Catch:{ JSONException -> 0x0023 }
        r5 = com.google.android.gms.internal.ads.zzazd.zzb(r5, r0);	 Catch:{ JSONException -> 0x0023 }
        r0 = r4.zzgix;	 Catch:{ JSONException -> 0x0023 }
        r1 = r0.keys();	 Catch:{ JSONException -> 0x0023 }
    L_0x000e:
        r2 = r1.hasNext();	 Catch:{ JSONException -> 0x0023 }
        if (r2 == 0) goto L_0x0022;	 Catch:{ JSONException -> 0x0023 }
    L_0x0014:
        r2 = r1.next();	 Catch:{ JSONException -> 0x0023 }
        r2 = (java.lang.String) r2;	 Catch:{ JSONException -> 0x0023 }
        r3 = r0.get(r2);	 Catch:{ JSONException -> 0x0023 }
        r5.put(r2, r3);	 Catch:{ JSONException -> 0x0023 }
        goto L_0x000e;
    L_0x0022:
        return;
    L_0x0023:
        r5 = "Failed putting app indexing json.";
        com.google.android.gms.internal.ads.zzaxa.zzds(r5);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzcvw.zzt(java.lang.Object):void");
    }
}
