package com.google.android.gms.internal.ads;

final /* synthetic */ class zzcpp implements Runnable {
    private final zzcpo zzgea;

    zzcpp(zzcpo zzcpo) {
        this.zzgea = zzcpo;
    }

    public final void run() {
        this.zzgea.zzalc();
    }
}
