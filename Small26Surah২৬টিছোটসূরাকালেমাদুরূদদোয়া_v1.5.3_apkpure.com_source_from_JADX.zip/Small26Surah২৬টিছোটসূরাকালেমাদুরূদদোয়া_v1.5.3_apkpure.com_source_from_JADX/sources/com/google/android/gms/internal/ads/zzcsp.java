package com.google.android.gms.internal.ads;

import java.util.concurrent.Callable;

final /* synthetic */ class zzcsp implements Callable {
    private final zzcso zzghb;

    zzcsp(zzcso zzcso) {
        this.zzghb = zzcso;
    }

    public final Object call() {
        return this.zzghb.zzalq();
    }
}
