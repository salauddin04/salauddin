package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.internal.zzk;

@zzare
public final class zzbfr extends zzaww {
    final zzbdg zzebv;
    private final String zzech;
    private final String[] zzeci;
    final zzbfu zzehs;

    zzbfr(zzbdg zzbdg, zzbfu zzbfu, String str, String[] strArr) {
        this.zzebv = zzbdg;
        this.zzehs = zzbfu;
        this.zzech = str;
        this.zzeci = strArr;
        zzk.zzmc().zza(this);
    }

    public final void zzto() {
        try {
            this.zzehs.zze(this.zzech, this.zzeci);
        } finally {
            zzaxj.zzdvx.post(new zzbfs(this));
        }
    }
}
