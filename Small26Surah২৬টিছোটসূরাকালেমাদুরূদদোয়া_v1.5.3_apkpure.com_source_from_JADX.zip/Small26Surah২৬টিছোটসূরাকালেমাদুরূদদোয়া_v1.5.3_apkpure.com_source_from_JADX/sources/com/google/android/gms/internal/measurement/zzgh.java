package com.google.android.gms.internal.measurement;

import java.io.IOException;

public interface zzgh extends zzgj {
    void zzb(zzeg zzeg) throws IOException;

    zzdp zzjv();

    int zzly();

    zzgi zzmk();

    zzgi zzml();
}
