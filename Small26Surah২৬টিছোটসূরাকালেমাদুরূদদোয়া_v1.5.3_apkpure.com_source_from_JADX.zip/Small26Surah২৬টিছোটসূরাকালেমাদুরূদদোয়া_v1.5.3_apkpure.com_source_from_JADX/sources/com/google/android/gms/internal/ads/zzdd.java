package com.google.android.gms.internal.ads;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import com.google.android.gms.internal.ads.zzbp.zza.zza;
import java.util.LinkedList;

public abstract class zzdd implements zzdc {
    protected static volatile zzdy zzvd;
    protected MotionEvent zzvj;
    protected LinkedList<MotionEvent> zzvk = new LinkedList();
    protected long zzvl = 0;
    protected long zzvm = 0;
    protected long zzvn = 0;
    protected long zzvo = 0;
    protected long zzvp = 0;
    protected long zzvq = 0;
    protected long zzvr = 0;
    protected double zzvs;
    private double zzvt;
    private double zzvu;
    protected float zzvv;
    protected float zzvw;
    protected float zzvx;
    protected float zzvy;
    private boolean zzvz = false;
    protected boolean zzwa = false;
    protected DisplayMetrics zzwb;

    protected zzdd(android.content.Context r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r2 = this;
        r2.<init>();
        r0 = new java.util.LinkedList;
        r0.<init>();
        r2.zzvk = r0;
        r0 = 0;
        r2.zzvl = r0;
        r2.zzvm = r0;
        r2.zzvn = r0;
        r2.zzvo = r0;
        r2.zzvp = r0;
        r2.zzvq = r0;
        r2.zzvr = r0;
        r0 = 0;
        r2.zzvz = r0;
        r2.zzwa = r0;
        r0 = com.google.android.gms.internal.ads.zzact.zzcrn;	 Catch:{ Throwable -> 0x0044 }
        r1 = com.google.android.gms.internal.ads.zzyr.zzpe();	 Catch:{ Throwable -> 0x0044 }
        r0 = r1.zzd(r0);	 Catch:{ Throwable -> 0x0044 }
        r0 = (java.lang.Boolean) r0;	 Catch:{ Throwable -> 0x0044 }
        r0 = r0.booleanValue();	 Catch:{ Throwable -> 0x0044 }
        if (r0 == 0) goto L_0x0035;	 Catch:{ Throwable -> 0x0044 }
    L_0x0031:
        com.google.android.gms.internal.ads.zzci.zzcb();	 Catch:{ Throwable -> 0x0044 }
        goto L_0x003a;	 Catch:{ Throwable -> 0x0044 }
    L_0x0035:
        r0 = zzvd;	 Catch:{ Throwable -> 0x0044 }
        com.google.android.gms.internal.ads.zzed.zzb(r0);	 Catch:{ Throwable -> 0x0044 }
    L_0x003a:
        r3 = r3.getResources();	 Catch:{ Throwable -> 0x0044 }
        r3 = r3.getDisplayMetrics();	 Catch:{ Throwable -> 0x0044 }
        r2.zzwb = r3;	 Catch:{ Throwable -> 0x0044 }
    L_0x0044:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzdd.<init>(android.content.Context):void");
    }

    protected abstract long zza(StackTraceElement[] stackTraceElementArr) throws zzdv;

    protected abstract zza zza(Context context, View view, Activity activity);

    protected abstract zza zza(Context context, zzbk.zza zza);

    protected abstract zzee zzb(MotionEvent motionEvent) throws zzdv;

    public void zzb(View view) {
    }

    public final String zza(Context context) {
        if (zzef.isMainThread()) {
            if (((Boolean) zzyr.zzpe().zzd(zzact.zzcrp)).booleanValue()) {
                throw new IllegalStateException("The caller must not be called from the UI thread.");
            }
        }
        return zza(context, null, false, null, null, null);
    }

    public final String zza(Context context, byte[] bArr) {
        if (zzef.isMainThread()) {
            if (((Boolean) zzyr.zzpe().zzd(zzact.zzcrp)).booleanValue()) {
                throw new IllegalStateException("The caller must not be called from the UI thread.");
            }
        }
        return zza(context, null, false, null, null, bArr);
    }

    public final String zza(Context context, String str, View view) {
        return zza(context, str, view, null);
    }

    public final String zza(Context context, String str, View view, Activity activity) {
        return zza(context, str, true, view, activity, null);
    }

    public final void zza(android.view.MotionEvent r15) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r14 = this;
        r0 = r14.zzvz;
        r1 = 0;
        if (r0 == 0) goto L_0x0035;
    L_0x0005:
        r2 = 0;
        r14.zzvo = r2;
        r14.zzvn = r2;
        r14.zzvm = r2;
        r14.zzvl = r2;
        r14.zzvp = r2;
        r14.zzvr = r2;
        r14.zzvq = r2;
        r0 = r14.zzvk;
        r0 = r0.iterator();
    L_0x001b:
        r2 = r0.hasNext();
        if (r2 == 0) goto L_0x002b;
    L_0x0021:
        r2 = r0.next();
        r2 = (android.view.MotionEvent) r2;
        r2.recycle();
        goto L_0x001b;
    L_0x002b:
        r0 = r14.zzvk;
        r0.clear();
        r0 = 0;
        r14.zzvj = r0;
        r14.zzvz = r1;
    L_0x0035:
        r0 = r15.getAction();
        r2 = 2;
        r3 = 1;
        if (r0 == 0) goto L_0x006d;
    L_0x003d:
        if (r0 == r3) goto L_0x0042;
    L_0x003f:
        if (r0 == r2) goto L_0x0042;
    L_0x0041:
        goto L_0x007f;
    L_0x0042:
        r0 = r15.getRawX();
        r4 = (double) r0;
        r0 = r15.getRawY();
        r6 = (double) r0;
        r8 = r14.zzvt;
        java.lang.Double.isNaN(r4);
        r8 = r4 - r8;
        r10 = r14.zzvu;
        java.lang.Double.isNaN(r6);
        r10 = r6 - r10;
        r12 = r14.zzvs;
        r8 = r8 * r8;
        r10 = r10 * r10;
        r8 = r8 + r10;
        r8 = java.lang.Math.sqrt(r8);
        r12 = r12 + r8;
        r14.zzvs = r12;
        r14.zzvt = r4;
        r14.zzvu = r6;
        goto L_0x007f;
    L_0x006d:
        r4 = 0;
        r14.zzvs = r4;
        r0 = r15.getRawX();
        r4 = (double) r0;
        r14.zzvt = r4;
        r0 = r15.getRawY();
        r4 = (double) r0;
        r14.zzvu = r4;
    L_0x007f:
        r0 = r15.getAction();
        r4 = 1;
        if (r0 == 0) goto L_0x0121;
    L_0x0087:
        if (r0 == r3) goto L_0x00eb;
    L_0x0089:
        if (r0 == r2) goto L_0x0097;
    L_0x008b:
        r15 = 3;
        if (r0 == r15) goto L_0x0090;
    L_0x008e:
        goto L_0x013e;
    L_0x0090:
        r0 = r14.zzvo;
        r0 = r0 + r4;
        r14.zzvo = r0;
        goto L_0x013e;
    L_0x0097:
        r4 = r14.zzvm;
        r0 = r15.getHistorySize();
        r0 = r0 + r3;
        r6 = (long) r0;
        r4 = r4 + r6;
        r14.zzvm = r4;
        r15 = r14.zzb(r15);	 Catch:{ zzdv -> 0x013e }
        if (r15 == 0) goto L_0x00b2;	 Catch:{ zzdv -> 0x013e }
    L_0x00a8:
        r0 = r15.zzye;	 Catch:{ zzdv -> 0x013e }
        if (r0 == 0) goto L_0x00b2;	 Catch:{ zzdv -> 0x013e }
    L_0x00ac:
        r0 = r15.zzyh;	 Catch:{ zzdv -> 0x013e }
        if (r0 == 0) goto L_0x00b2;	 Catch:{ zzdv -> 0x013e }
    L_0x00b0:
        r0 = 1;	 Catch:{ zzdv -> 0x013e }
        goto L_0x00b3;	 Catch:{ zzdv -> 0x013e }
    L_0x00b2:
        r0 = 0;	 Catch:{ zzdv -> 0x013e }
    L_0x00b3:
        if (r0 == 0) goto L_0x00c7;	 Catch:{ zzdv -> 0x013e }
    L_0x00b5:
        r4 = r14.zzvq;	 Catch:{ zzdv -> 0x013e }
        r0 = r15.zzye;	 Catch:{ zzdv -> 0x013e }
        r6 = r0.longValue();	 Catch:{ zzdv -> 0x013e }
        r0 = r15.zzyh;	 Catch:{ zzdv -> 0x013e }
        r8 = r0.longValue();	 Catch:{ zzdv -> 0x013e }
        r6 = r6 + r8;	 Catch:{ zzdv -> 0x013e }
        r4 = r4 + r6;	 Catch:{ zzdv -> 0x013e }
        r14.zzvq = r4;	 Catch:{ zzdv -> 0x013e }
    L_0x00c7:
        r0 = r14.zzwb;	 Catch:{ zzdv -> 0x013e }
        if (r0 == 0) goto L_0x00d6;	 Catch:{ zzdv -> 0x013e }
    L_0x00cb:
        if (r15 == 0) goto L_0x00d6;	 Catch:{ zzdv -> 0x013e }
    L_0x00cd:
        r0 = r15.zzyf;	 Catch:{ zzdv -> 0x013e }
        if (r0 == 0) goto L_0x00d6;	 Catch:{ zzdv -> 0x013e }
    L_0x00d1:
        r0 = r15.zzyi;	 Catch:{ zzdv -> 0x013e }
        if (r0 == 0) goto L_0x00d6;	 Catch:{ zzdv -> 0x013e }
    L_0x00d5:
        r1 = 1;	 Catch:{ zzdv -> 0x013e }
    L_0x00d6:
        if (r1 == 0) goto L_0x013e;	 Catch:{ zzdv -> 0x013e }
    L_0x00d8:
        r0 = r14.zzvr;	 Catch:{ zzdv -> 0x013e }
        r2 = r15.zzyf;	 Catch:{ zzdv -> 0x013e }
        r4 = r2.longValue();	 Catch:{ zzdv -> 0x013e }
        r15 = r15.zzyi;	 Catch:{ zzdv -> 0x013e }
        r6 = r15.longValue();	 Catch:{ zzdv -> 0x013e }
        r4 = r4 + r6;	 Catch:{ zzdv -> 0x013e }
        r0 = r0 + r4;	 Catch:{ zzdv -> 0x013e }
        r14.zzvr = r0;	 Catch:{ zzdv -> 0x013e }
        goto L_0x013e;
    L_0x00eb:
        r15 = android.view.MotionEvent.obtain(r15);
        r14.zzvj = r15;
        r15 = r14.zzvk;
        r0 = r14.zzvj;
        r15.add(r0);
        r15 = r14.zzvk;
        r15 = r15.size();
        r0 = 6;
        if (r15 <= r0) goto L_0x010c;
    L_0x0101:
        r15 = r14.zzvk;
        r15 = r15.remove();
        r15 = (android.view.MotionEvent) r15;
        r15.recycle();
    L_0x010c:
        r0 = r14.zzvn;
        r0 = r0 + r4;
        r14.zzvn = r0;
        r15 = new java.lang.Throwable;	 Catch:{ zzdv -> 0x013e }
        r15.<init>();	 Catch:{ zzdv -> 0x013e }
        r15 = r15.getStackTrace();	 Catch:{ zzdv -> 0x013e }
        r0 = r14.zza(r15);	 Catch:{ zzdv -> 0x013e }
        r14.zzvp = r0;	 Catch:{ zzdv -> 0x013e }
        goto L_0x013e;
    L_0x0121:
        r0 = r15.getX();
        r14.zzvv = r0;
        r0 = r15.getY();
        r14.zzvw = r0;
        r0 = r15.getRawX();
        r14.zzvx = r0;
        r15 = r15.getRawY();
        r14.zzvy = r15;
        r0 = r14.zzvl;
        r0 = r0 + r4;
        r14.zzvl = r0;
    L_0x013e:
        r14.zzwa = r3;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzdd.zza(android.view.MotionEvent):void");
    }

    public final void zza(int i, int i2, int i3) {
        MotionEvent motionEvent = this.zzvj;
        if (motionEvent != null) {
            motionEvent.recycle();
        }
        DisplayMetrics displayMetrics = r0.zzwb;
        if (displayMetrics != null) {
            r0.zzvj = MotionEvent.obtain(0, (long) i3, 1, ((float) i) * displayMetrics.density, r0.zzwb.density * ((float) i2), 0.0f, 0.0f, 0, 0.0f, 0.0f, 0, 0);
        } else {
            r0.zzvj = null;
        }
        r0.zzwa = false;
    }

    private final java.lang.String zza(android.content.Context r10, java.lang.String r11, boolean r12, android.view.View r13, android.app.Activity r14, byte[] r15) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r9 = this;
        r0 = 0;
        if (r15 == 0) goto L_0x000f;
    L_0x0003:
        r1 = r15.length;
        if (r1 <= 0) goto L_0x000f;
    L_0x0006:
        r1 = com.google.android.gms.internal.ads.zzdnn.zzaxe();	 Catch:{ zzdoj -> 0x000f }
        r15 = com.google.android.gms.internal.ads.zzbk.zza.zza(r15, r1);	 Catch:{ zzdoj -> 0x000f }
        goto L_0x0010;
    L_0x000f:
        r15 = r0;
    L_0x0010:
        r1 = zzvd;
        if (r1 == 0) goto L_0x002d;
    L_0x0014:
        r1 = com.google.android.gms.internal.ads.zzact.zzcrd;
        r2 = com.google.android.gms.internal.ads.zzyr.zzpe();
        r1 = r2.zzd(r1);
        r1 = (java.lang.Boolean) r1;
        r1 = r1.booleanValue();
        if (r1 == 0) goto L_0x002d;
    L_0x0026:
        r1 = zzvd;
        r1 = r1.zzcm();
        goto L_0x002e;
    L_0x002d:
        r1 = r0;
    L_0x002e:
        r2 = java.lang.System.currentTimeMillis();
        r8 = -1;
        if (r12 == 0) goto L_0x003d;
    L_0x0035:
        r0 = r9.zza(r10, r13, r14);	 Catch:{ Exception -> 0x0054 }
        r10 = 1;	 Catch:{ Exception -> 0x0054 }
        r9.zzvz = r10;	 Catch:{ Exception -> 0x0054 }
        goto L_0x0042;	 Catch:{ Exception -> 0x0054 }
    L_0x003d:
        r10 = r9.zza(r10, r15);	 Catch:{ Exception -> 0x0054 }
        r0 = r10;	 Catch:{ Exception -> 0x0054 }
    L_0x0042:
        if (r1 == 0) goto L_0x006b;	 Catch:{ Exception -> 0x0054 }
    L_0x0044:
        if (r12 == 0) goto L_0x0049;	 Catch:{ Exception -> 0x0054 }
    L_0x0046:
        r10 = 1002; // 0x3ea float:1.404E-42 double:4.95E-321;	 Catch:{ Exception -> 0x0054 }
        goto L_0x004b;	 Catch:{ Exception -> 0x0054 }
    L_0x0049:
        r10 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;	 Catch:{ Exception -> 0x0054 }
    L_0x004b:
        r13 = java.lang.System.currentTimeMillis();	 Catch:{ Exception -> 0x0054 }
        r13 = r13 - r2;	 Catch:{ Exception -> 0x0054 }
        r1.zza(r10, r8, r13);	 Catch:{ Exception -> 0x0054 }
        goto L_0x006b;
    L_0x0054:
        r10 = move-exception;
        r7 = r10;
        if (r1 == 0) goto L_0x006b;
    L_0x0058:
        if (r12 == 0) goto L_0x005d;
    L_0x005a:
        r10 = 1003; // 0x3eb float:1.406E-42 double:4.955E-321;
        goto L_0x005f;
    L_0x005d:
        r10 = 1001; // 0x3e9 float:1.403E-42 double:4.946E-321;
    L_0x005f:
        r4 = -1;
        r13 = java.lang.System.currentTimeMillis();
        r5 = r13 - r2;
        r2 = r1;
        r3 = r10;
        r2.zza(r3, r4, r5, r7);
    L_0x006b:
        r13 = java.lang.System.currentTimeMillis();
        if (r0 == 0) goto L_0x009e;
    L_0x0071:
        r10 = r0.zzaya();	 Catch:{ Exception -> 0x00a4 }
        r10 = (com.google.android.gms.internal.ads.zzdoa) r10;	 Catch:{ Exception -> 0x00a4 }
        r10 = (com.google.android.gms.internal.ads.zzbp.zza) r10;	 Catch:{ Exception -> 0x00a4 }
        r10 = r10.zzaxj();	 Catch:{ Exception -> 0x00a4 }
        if (r10 != 0) goto L_0x0080;	 Catch:{ Exception -> 0x00a4 }
    L_0x007f:
        goto L_0x009e;	 Catch:{ Exception -> 0x00a4 }
    L_0x0080:
        r10 = r0.zzaya();	 Catch:{ Exception -> 0x00a4 }
        r10 = (com.google.android.gms.internal.ads.zzdoa) r10;	 Catch:{ Exception -> 0x00a4 }
        r10 = (com.google.android.gms.internal.ads.zzbp.zza) r10;	 Catch:{ Exception -> 0x00a4 }
        r10 = com.google.android.gms.internal.ads.zzci.zzj(r10, r11);	 Catch:{ Exception -> 0x00a4 }
        if (r1 == 0) goto L_0x00c3;	 Catch:{ Exception -> 0x00a4 }
    L_0x008e:
        if (r12 == 0) goto L_0x0093;	 Catch:{ Exception -> 0x00a4 }
    L_0x0090:
        r11 = 1006; // 0x3ee float:1.41E-42 double:4.97E-321;	 Catch:{ Exception -> 0x00a4 }
        goto L_0x0095;	 Catch:{ Exception -> 0x00a4 }
    L_0x0093:
        r11 = 1004; // 0x3ec float:1.407E-42 double:4.96E-321;	 Catch:{ Exception -> 0x00a4 }
    L_0x0095:
        r2 = java.lang.System.currentTimeMillis();	 Catch:{ Exception -> 0x00a4 }
        r2 = r2 - r13;	 Catch:{ Exception -> 0x00a4 }
        r1.zza(r11, r8, r2);	 Catch:{ Exception -> 0x00a4 }
        goto L_0x00c3;	 Catch:{ Exception -> 0x00a4 }
    L_0x009e:
        r10 = 5;	 Catch:{ Exception -> 0x00a4 }
        r10 = java.lang.Integer.toString(r10);	 Catch:{ Exception -> 0x00a4 }
        goto L_0x00c3;
    L_0x00a4:
        r10 = move-exception;
        r7 = r10;
        r10 = 7;
        r10 = java.lang.Integer.toString(r10);
        if (r1 == 0) goto L_0x00c3;
    L_0x00ad:
        if (r12 == 0) goto L_0x00b4;
    L_0x00af:
        r11 = 1007; // 0x3ef float:1.411E-42 double:4.975E-321;
        r3 = 1007; // 0x3ef float:1.411E-42 double:4.975E-321;
        goto L_0x00b8;
    L_0x00b4:
        r11 = 1005; // 0x3ed float:1.408E-42 double:4.965E-321;
        r3 = 1005; // 0x3ed float:1.408E-42 double:4.965E-321;
    L_0x00b8:
        r4 = -1;
        r11 = java.lang.System.currentTimeMillis();
        r5 = r11 - r13;
        r2 = r1;
        r2.zza(r3, r4, r5, r7);
    L_0x00c3:
        return r10;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzdd.zza(android.content.Context, java.lang.String, boolean, android.view.View, android.app.Activity, byte[]):java.lang.String");
    }
}
