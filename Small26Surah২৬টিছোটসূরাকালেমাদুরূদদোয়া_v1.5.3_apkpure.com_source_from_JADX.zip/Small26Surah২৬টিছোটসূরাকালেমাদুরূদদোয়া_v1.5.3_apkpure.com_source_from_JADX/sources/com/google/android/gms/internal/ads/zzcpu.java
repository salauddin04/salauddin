package com.google.android.gms.internal.ads;

import javax.annotation.concurrent.GuardedBy;

public final class zzcpu implements zzxp {
    @GuardedBy("this")
    private zzyu zzgen;

    public final synchronized void zzb(zzyu zzyu) {
        this.zzgen = zzyu;
    }

    public final synchronized void onAdClicked() {
        if (this.zzgen != null) {
            try {
                this.zzgen.onAdClicked();
            } catch (Throwable e) {
                zzbae.zzd("Remote Exception at onAdClicked.", e);
            }
        }
    }
}
