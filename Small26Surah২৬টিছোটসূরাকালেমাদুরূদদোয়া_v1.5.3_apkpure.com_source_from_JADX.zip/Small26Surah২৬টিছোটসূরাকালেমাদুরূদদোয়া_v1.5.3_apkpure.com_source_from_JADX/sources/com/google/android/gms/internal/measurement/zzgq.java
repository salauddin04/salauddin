package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzez.zze;

final class zzgq implements zzgp {
    zzgq() {
    }

    public final Object newInstance(Object obj) {
        return ((zzez) obj).zza(zze.zzagx, null, null);
    }
}
