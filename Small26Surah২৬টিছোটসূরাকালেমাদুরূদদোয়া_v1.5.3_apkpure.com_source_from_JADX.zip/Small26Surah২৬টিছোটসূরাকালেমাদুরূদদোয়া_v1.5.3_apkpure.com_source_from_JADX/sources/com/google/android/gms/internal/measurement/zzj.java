package com.google.android.gms.internal.measurement;

public interface zzj {
    boolean zze();
}
