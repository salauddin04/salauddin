package com.google.android.gms.internal.ads;

import android.media.MediaCodec.CodecException;

public final class zzgv extends Exception {
    private final String zzaeo;
    private final String zzaep;

    public zzgv(zzhj zzhj, Throwable th, int i) {
        zzhj = String.valueOf(zzhj);
        StringBuilder stringBuilder = new StringBuilder(String.valueOf(zzhj).length() + 36);
        stringBuilder.append("Decoder init failed: [");
        stringBuilder.append(i);
        stringBuilder.append("], ");
        stringBuilder.append(zzhj);
        super(stringBuilder.toString(), th);
        this.zzaeo = null;
        zzhj = i < 0 ? "neg_" : "";
        th = Math.abs(i);
        i = new StringBuilder(zzhj.length() + 64);
        i.append("com.google.android.gms.ads.exoplayer1.MediaCodecTrackRenderer_");
        i.append(zzhj);
        i.append(th);
        this.zzaep = i.toString();
    }

    public zzgv(zzhj zzhj, Throwable th, String str) {
        zzhj = String.valueOf(zzhj);
        StringBuilder stringBuilder = new StringBuilder((String.valueOf(str).length() + 23) + String.valueOf(zzhj).length());
        stringBuilder.append("Decoder init failed: ");
        stringBuilder.append(str);
        stringBuilder.append(", ");
        stringBuilder.append(zzhj);
        super(stringBuilder.toString(), th);
        this.zzaeo = str;
        str = null;
        if (zzkq.SDK_INT >= 21 && (th instanceof CodecException) != null) {
            str = ((CodecException) th).getDiagnosticInfo();
        }
        this.zzaep = str;
    }
}
