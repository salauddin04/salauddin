package com.google.android.gms.internal.measurement;

import java.util.Map;
import java.util.Map.Entry;

final class zzgd implements zzgc {
    zzgd() {
    }

    public final Map<?, ?> zzm(Object obj) {
        return (zzgb) obj;
    }

    public final zzga<?, ?> zzr(Object obj) {
        throw new NoSuchMethodError();
    }

    public final Map<?, ?> zzn(Object obj) {
        return (zzgb) obj;
    }

    public final boolean zzo(Object obj) {
        return ((zzgb) obj).isMutable() == null ? true : null;
    }

    public final Object zzp(Object obj) {
        ((zzgb) obj).zzjz();
        return obj;
    }

    public final Object zzq(Object obj) {
        return zzgb.zznm().zznn();
    }

    public final Object zzb(Object obj, Object obj2) {
        obj = (zzgb) obj;
        zzgb zzgb = (zzgb) obj2;
        if (!zzgb.isEmpty()) {
            if (!obj.isMutable()) {
                obj = obj.zznn();
            }
            obj.zza(zzgb);
        }
        return obj;
    }

    public final int zzb(int i, Object obj, Object obj2) {
        zzgb zzgb = (zzgb) obj;
        if (zzgb.isEmpty() != 0) {
            return 0;
        }
        i = zzgb.entrySet().iterator();
        if (i.hasNext() == null) {
            return 0;
        }
        Entry entry = (Entry) i.next();
        entry.getKey();
        entry.getValue();
        throw new NoSuchMethodError();
    }
}
