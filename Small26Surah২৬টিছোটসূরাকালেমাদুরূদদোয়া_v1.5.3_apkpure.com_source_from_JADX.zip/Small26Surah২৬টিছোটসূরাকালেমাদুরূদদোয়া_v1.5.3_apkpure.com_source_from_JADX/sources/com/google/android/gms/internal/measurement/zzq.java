package com.google.android.gms.internal.measurement;

import android.os.Bundle;
import android.os.IInterface;
import android.os.RemoteException;

public interface zzq extends IInterface {
    void zzb(Bundle bundle) throws RemoteException;
}
