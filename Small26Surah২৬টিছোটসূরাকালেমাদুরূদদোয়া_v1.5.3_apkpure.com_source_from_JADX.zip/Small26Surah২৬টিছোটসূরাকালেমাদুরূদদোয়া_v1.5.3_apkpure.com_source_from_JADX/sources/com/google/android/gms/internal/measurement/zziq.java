package com.google.android.gms.internal.measurement;

public final class zziq<M extends zzip<M>, T> {
    protected final Class<T> zzane;

    public final boolean equals(Object obj) {
        throw new NoSuchMethodError();
    }

    public final int hashCode() {
        throw new NoSuchMethodError();
    }
}
