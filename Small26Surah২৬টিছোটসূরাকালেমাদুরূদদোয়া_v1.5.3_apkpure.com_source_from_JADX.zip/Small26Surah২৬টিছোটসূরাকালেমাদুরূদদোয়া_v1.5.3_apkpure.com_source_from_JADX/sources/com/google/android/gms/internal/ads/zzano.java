package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.mediation.InitializationCompleteCallback;

final class zzano implements InitializationCompleteCallback {
    private final /* synthetic */ zzaip zzdgm;

    zzano(zzanm zzanm, zzaip zzaip) {
        this.zzdgm = zzaip;
    }

    public final void onInitializationSucceeded() {
        try {
            this.zzdgm.onInitializationSucceeded();
        } catch (Throwable e) {
            zzbae.zzc("", e);
        }
    }

    public final void onInitializationFailed(String str) {
        try {
            this.zzdgm.onInitializationFailed(str);
        } catch (String str2) {
            zzbae.zzc("", str2);
        }
    }
}
