package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.internal.zzk;

final class zzbfs implements Runnable {
    private final /* synthetic */ zzbfr zzeht;

    zzbfs(zzbfr zzbfr) {
        this.zzeht = zzbfr;
    }

    public final void run() {
        zzk.zzmc().zzb(this.zzeht);
    }
}
