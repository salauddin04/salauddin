package com.google.android.gms.internal.ads;

import android.media.MediaCodec.CryptoException;
import java.lang.ref.WeakReference;

final class zzbdn implements zzgq {
    private WeakReference<zzgq> zzefn;
    private final /* synthetic */ zzbdl zzefo;

    private zzbdn(zzbdl zzbdl) {
        this.zzefo = zzbdl;
        this.zzefn = new WeakReference(null);
    }

    public final void zza(zzgq zzgq) {
        this.zzefn = new WeakReference(zzgq);
    }

    public final void zza(zzhu zzhu) {
        this.zzefo.zzm("AudioTrackInitializationError", zzhu.getMessage());
        zzgq zzgq = (zzgq) this.zzefn.get();
        if (zzgq != null) {
            zzgq.zza(zzhu);
        }
    }

    public final void zza(zzhv zzhv) {
        this.zzefo.zzm("AudioTrackWriteError", zzhv.getMessage());
        zzgq zzgq = (zzgq) this.zzefn.get();
        if (zzgq != null) {
            zzgq.zza(zzhv);
        }
    }

    public final void zzb(zzgv zzgv) {
        this.zzefo.zzm("DecoderInitializationError", zzgv.getMessage());
        zzgq zzgq = (zzgq) this.zzefn.get();
        if (zzgq != null) {
            zzgq.zzb(zzgv);
        }
    }

    public final void zzb(CryptoException cryptoException) {
        this.zzefo.zzm("CryptoError", cryptoException.getMessage());
        zzgq zzgq = (zzgq) this.zzefn.get();
        if (zzgq != null) {
            zzgq.zzb(cryptoException);
        }
    }

    public final void zza(String str, long j, long j2) {
        zzgq zzgq = (zzgq) this.zzefn.get();
        if (zzgq != null) {
            zzgq.zza(str, j, j2);
        }
    }
}
