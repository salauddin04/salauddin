package com.google.android.gms.internal.ads;

final /* synthetic */ class zzbup implements zzbtt {
    static final zzbtt zzfka = new zzbup();

    private zzbup() {
    }

    public final void zzr(Object obj) {
        ((zzbuq) obj).zzagu();
    }
}
