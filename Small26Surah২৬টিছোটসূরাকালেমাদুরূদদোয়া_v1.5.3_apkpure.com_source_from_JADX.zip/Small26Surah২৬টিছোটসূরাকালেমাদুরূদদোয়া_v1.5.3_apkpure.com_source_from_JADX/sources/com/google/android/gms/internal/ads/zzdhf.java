package com.google.android.gms.internal.ads;

import com.google.android.gms.internal.ads.zzdoa.zzb;

public final class zzdhf extends zzdoa<zzdhf, zza> implements zzdpl {
    private static volatile zzdpu<zzdhf> zzdv;
    private static final zzdhf zzgvk = new zzdhf();
    private String zzgvj = "";

    public static final class zza extends com.google.android.gms.internal.ads.zzdoa.zza<zzdhf, zza> implements zzdpl {
        private zza() {
            super(zzdhf.zzgvk);
        }
    }

    private zzdhf() {
    }

    public final String zzasz() {
        return this.zzgvj;
    }

    public static zzdhf zzbq(zzdmq zzdmq) throws zzdoj {
        return (zzdhf) zzdoa.zza(zzgvk, zzdmq);
    }

    protected final Object zza(int i, Object obj, Object obj2) {
        switch (zzdhg.zzdi[i - 1]) {
            case 1:
                return new zzdhf();
            case 2:
                return new zza();
            case 3:
                return zzdoa.zza((zzdpj) zzgvk, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", (Object[]) new Object[]{"zzgvj"});
            case 4:
                return zzgvk;
            case 5:
                i = zzdv;
                if (i == 0) {
                    synchronized (zzdhf.class) {
                        i = zzdv;
                        if (i == 0) {
                            i = new zzb(zzgvk);
                            zzdv = i;
                        }
                    }
                }
                return i;
            case 6:
                return Byte.valueOf((byte) 1);
            case 7:
                return null;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public static zzdhf zzata() {
        return zzgvk;
    }

    static {
        zzdoa.zza(zzdhf.class, zzgvk);
    }
}
