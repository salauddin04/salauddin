package com.google.android.gms.internal.ads;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import com.google.android.gms.ads.formats.NativeAppInstallAd;
import com.google.android.gms.ads.formats.NativeContentAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdAssetNames;
import com.google.android.gms.ads.internal.zzk;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.ObjectWrapper;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nullable;
import javax.annotation.concurrent.GuardedBy;

public final class zzbzi extends zzaem implements OnGlobalLayoutListener, OnScrollChangedListener, zzcaa {
    public static final String[] zzfpm = new String[]{NativeAppInstallAd.ASSET_MEDIA_VIDEO, NativeContentAd.ASSET_MEDIA_VIDEO, UnifiedNativeAdAssetNames.ASSET_MEDIA_VIDEO};
    private FrameLayout zzbqi;
    private boolean zzela = false;
    @GuardedBy("this")
    private zzbym zzfpj;
    private zzty zzfpk;
    private final String zzfpl;
    @GuardedBy("this")
    private Map<String, WeakReference<View>> zzfpn = new HashMap();
    private FrameLayout zzfpo;
    private zzbbm zzfpp;
    private View zzfpq;

    public zzbzi(FrameLayout frameLayout, FrameLayout frameLayout2) {
        this.zzfpo = frameLayout;
        this.zzbqi = frameLayout2;
        frameLayout2 = frameLayout.getClass().getCanonicalName();
        if ("com.google.android.gms.ads.formats.NativeContentAdView".equals(frameLayout2)) {
            frameLayout2 = NativeContentAd.ASSET_ATTRIBUTION_ICON_IMAGE;
        } else if ("com.google.android.gms.ads.formats.NativeAppInstallAdView".equals(frameLayout2)) {
            frameLayout2 = NativeAppInstallAd.ASSET_ATTRIBUTION_ICON_IMAGE;
        } else {
            "com.google.android.gms.ads.formats.UnifiedNativeAdView".equals(frameLayout2);
            frameLayout2 = "3012";
        }
        this.zzfpl = frameLayout2;
        zzk.zzmd();
        zzbca.zza((View) frameLayout, (OnGlobalLayoutListener) this);
        zzk.zzmd();
        zzbca.zza((View) frameLayout, (OnScrollChangedListener) this);
        this.zzfpp = zzbbn.zzeai;
        this.zzfpk = new zzty(this.zzfpo.getContext(), this.zzfpo);
        frameLayout.setOnTouchListener(this);
        frameLayout.setOnClickListener(this);
    }

    public final synchronized void zzc(String str, IObjectWrapper iObjectWrapper) {
        zza(str, (View) ObjectWrapper.unwrap(iObjectWrapper), true);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized void zza(java.lang.String r2, android.view.View r3, boolean r4) {
        /*
        r1 = this;
        monitor-enter(r1);
        r4 = r1.zzela;	 Catch:{ all -> 0x0039 }
        if (r4 == 0) goto L_0x0007;
    L_0x0005:
        monitor-exit(r1);
        return;
    L_0x0007:
        if (r3 != 0) goto L_0x0010;
    L_0x0009:
        r3 = r1.zzfpn;	 Catch:{ all -> 0x0039 }
        r3.remove(r2);	 Catch:{ all -> 0x0039 }
        monitor-exit(r1);
        return;
    L_0x0010:
        r4 = r1.zzfpn;	 Catch:{ all -> 0x0039 }
        r0 = new java.lang.ref.WeakReference;	 Catch:{ all -> 0x0039 }
        r0.<init>(r3);	 Catch:{ all -> 0x0039 }
        r4.put(r2, r0);	 Catch:{ all -> 0x0039 }
        r4 = "1098";
        r4 = r4.equals(r2);	 Catch:{ all -> 0x0039 }
        if (r4 != 0) goto L_0x0037;
    L_0x0022:
        r4 = "3011";
        r2 = r4.equals(r2);	 Catch:{ all -> 0x0039 }
        if (r2 == 0) goto L_0x002b;
    L_0x002a:
        goto L_0x0037;
    L_0x002b:
        r3.setOnTouchListener(r1);	 Catch:{ all -> 0x0039 }
        r2 = 1;
        r3.setClickable(r2);	 Catch:{ all -> 0x0039 }
        r3.setOnClickListener(r1);	 Catch:{ all -> 0x0039 }
        monitor-exit(r1);
        return;
    L_0x0037:
        monitor-exit(r1);
        return;
    L_0x0039:
        r2 = move-exception;
        monitor-exit(r1);
        throw r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzbzi.zza(java.lang.String, android.view.View, boolean):void");
    }

    public final synchronized IObjectWrapper zzcf(String str) {
        return ObjectWrapper.wrap(zzfp(str));
    }

    public final synchronized View zzfp(String str) {
        if (this.zzela) {
            return null;
        }
        WeakReference weakReference = (WeakReference) this.zzfpn.get(str);
        if (weakReference == null) {
            return null;
        }
        return (View) weakReference.get();
    }

    public final synchronized void zze(IObjectWrapper iObjectWrapper) {
        if (!this.zzela) {
            iObjectWrapper = ObjectWrapper.unwrap(iObjectWrapper);
            if (iObjectWrapper instanceof zzbym) {
                if (this.zzfpj != null) {
                    this.zzfpj.zzb(this);
                }
                zzaix();
                this.zzfpj = (zzbym) iObjectWrapper;
                this.zzfpj.zza((zzcaa) this);
                this.zzfpj.zzy(this.zzfpo);
                return;
            }
            zzbae.zzep("Not an instance of native engine. This is most likely a transient error");
        }
    }

    private final synchronized void zzaix() {
        this.zzfpp.execute(new zzbzj(this));
    }

    public final synchronized void destroy() {
        if (!this.zzela) {
            if (this.zzfpj != null) {
                this.zzfpj.zzb(this);
                this.zzfpj = null;
            }
            this.zzfpn.clear();
            this.zzfpo.removeAllViews();
            this.zzbqi.removeAllViews();
            this.zzfpn = null;
            this.zzfpo = null;
            this.zzbqi = null;
            this.zzfpq = null;
            this.zzfpk = null;
            this.zzela = true;
        }
    }

    public final synchronized void zzc(IObjectWrapper iObjectWrapper, int i) {
    }

    public final synchronized void onClick(View view) {
        if (this.zzfpj != null) {
            this.zzfpj.cancelUnconfirmedClick();
            this.zzfpj.zza(view, this.zzfpo, zzait(), zzaiu(), false);
        }
    }

    public final synchronized boolean onTouch(View view, MotionEvent motionEvent) {
        if (this.zzfpj != null) {
            this.zzfpj.zza(view, motionEvent, this.zzfpo);
        }
        return null;
    }

    public final synchronized void onGlobalLayout() {
        if (this.zzfpj != null) {
            this.zzfpj.zzb(this.zzfpo, zzait(), zzaiu(), zzbym.zzx(this.zzfpo));
        }
    }

    public final synchronized void onScrollChanged() {
        if (this.zzfpj != null) {
            this.zzfpj.zzb(this.zzfpo, zzait(), zzaiu(), zzbym.zzx(this.zzfpo));
        }
    }

    public final synchronized Map<String, WeakReference<View>> zzait() {
        return this.zzfpn;
    }

    public final synchronized Map<String, WeakReference<View>> zzaiu() {
        return this.zzfpn;
    }

    @Nullable
    public final synchronized Map<String, WeakReference<View>> zzaiv() {
        return null;
    }

    public final synchronized String zzaiw() {
        return this.zzfpl;
    }

    public final FrameLayout zzair() {
        return this.zzbqi;
    }

    public final zzty zzais() {
        return this.zzfpk;
    }

    public final synchronized void zzi(IObjectWrapper iObjectWrapper) {
        this.zzfpj.setClickConfirmingView((View) ObjectWrapper.unwrap(iObjectWrapper));
    }

    public final /* synthetic */ View zzafi() {
        return this.zzfpo;
    }

    final /* synthetic */ void zzaiy() {
        if (this.zzfpq == null) {
            this.zzfpq = new View(this.zzfpo.getContext());
            this.zzfpq.setLayoutParams(new LayoutParams(-1, 0));
        }
        if (this.zzfpo != this.zzfpq.getParent()) {
            this.zzfpo.addView(this.zzfpq);
        }
    }
}
