package com.google.android.gms.internal.ads;

import android.content.Context;
import android.support.annotation.Nullable;
import com.google.android.gms.internal.ads.zzbqx.zza;
import javax.annotation.concurrent.GuardedBy;

public final class zzcpo extends zzzb {
    private final zzbjn zzgbc;
    private final Context zzgdr;
    private final zzcxw zzgds;
    private final zzbzb zzgdu;
    private final zzcpv zzgdv = new zzcpv();
    private final zzbrn zzgdw;
    @Nullable
    @GuardedBy("this")
    private zzbpj zzgdx;
    @Nullable
    @GuardedBy("this")
    private String zzgdy;
    @Nullable
    @GuardedBy("this")
    private String zzgdz;

    public zzcpo(Context context, zzbjn zzbjn, zzcxw zzcxw, zzbzb zzbzb, zzyx zzyx) {
        this.zzgdr = context;
        this.zzgbc = zzbjn;
        this.zzgds = zzcxw;
        this.zzgdu = zzbzb;
        this.zzgdv.zzc(zzyx);
        this.zzgdw = new zzcpq(this.zzgdv, zzbzb.zzaim());
    }

    public final synchronized boolean isLoading() throws android.os.RemoteException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:13:0x0015 in {6, 8, 9, 12} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r1 = this;
        monitor-enter(r1);
        r0 = r1.zzgdx;	 Catch:{ all -> 0x0012 }
        if (r0 == 0) goto L_0x0010;	 Catch:{ all -> 0x0012 }
    L_0x0005:
        r0 = r1.zzgdx;	 Catch:{ all -> 0x0012 }
        r0 = r0.isLoading();	 Catch:{ all -> 0x0012 }
        if (r0 == 0) goto L_0x0010;
    L_0x000d:
        r0 = 1;
    L_0x000e:
        monitor-exit(r1);
        return r0;
    L_0x0010:
        r0 = 0;
        goto L_0x000e;
    L_0x0012:
        r0 = move-exception;
        monitor-exit(r1);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzcpo.isLoading():boolean");
    }

    public final void zza(zzxx zzxx) {
        zza(zzxx, 1);
    }

    public final synchronized void zza(zzxx zzxx, int i) {
        if (this.zzgds.zzamp() == null) {
            zzbae.zzen("Ad unit ID should not be null for AdLoader.");
            this.zzgbc.zzace().execute(new zzcpp(this));
            return;
        }
        zzcxz.zze(this.zzgdr, zzxx.zzcgr);
        this.zzgdy = null;
        this.zzgdz = null;
        zzcxu zzamq = this.zzgds.zzg(zzxx).zzdp(i).zzamq();
        zzxx = this.zzgbc.zzacl().zza(new zza().zzbt(this.zzgdr).zza(zzamq).zzagh()).zza(new zzbtu.zza().zza(this.zzgdv, this.zzgbc.zzace()).zza(this.zzgdw, this.zzgbc.zzace()).zza(this.zzgdv, this.zzgbc.zzace()).zza(this.zzgdv, this.zzgbc.zzace()).zza(this.zzgdv, this.zzgbc.zzace()).zza(zzamq.zzgli, this.zzgbc.zzace()).zzagt()).zza(new zzbxj(this.zzgdu, this.zzgdv.zzald())).zzacy();
        zzxx.zzadc().zzdq(1);
        this.zzgdx = zzxx.zzacz();
        this.zzgdx.zza(new zzcpr(this, zzxx));
    }

    public final synchronized String getMediationAdapterClassName() {
        return this.zzgdy;
    }

    public final synchronized String zzpj() {
        return this.zzgdz;
    }

    final /* synthetic */ void zzalc() {
        this.zzgdw.onAdFailedToLoad(1);
    }
}
