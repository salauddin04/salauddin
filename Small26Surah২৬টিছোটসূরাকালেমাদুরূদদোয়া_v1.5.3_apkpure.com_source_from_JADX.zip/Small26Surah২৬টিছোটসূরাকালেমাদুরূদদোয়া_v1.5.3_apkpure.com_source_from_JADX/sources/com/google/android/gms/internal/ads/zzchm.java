package com.google.android.gms.internal.ads;

final /* synthetic */ class zzchm implements zzbam {
    static final zzbam zzbra = new zzchm();

    private zzchm() {
    }

    public final zzbbi zzf(Object obj) {
        return zzbas.zzd(new zzcie("Timed out waiting for ad response.", 2));
    }
}
