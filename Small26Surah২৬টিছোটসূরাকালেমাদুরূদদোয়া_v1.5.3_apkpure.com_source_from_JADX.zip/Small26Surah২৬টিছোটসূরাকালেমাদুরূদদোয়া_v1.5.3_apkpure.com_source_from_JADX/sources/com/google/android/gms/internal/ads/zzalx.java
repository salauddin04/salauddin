package com.google.android.gms.internal.ads;

final class zzalx implements zzbbu {
    private final /* synthetic */ zzbbs zzdar;
    private final /* synthetic */ zzakx zzddt;

    zzalx(zzalv zzalv, zzbbs zzbbs, zzakx zzakx) {
        this.zzdar = zzbbs;
        this.zzddt = zzakx;
    }

    public final void run() {
        this.zzdar.setException(new zzalj("Unable to obtain a JavascriptEngine."));
        this.zzddt.release();
    }
}
