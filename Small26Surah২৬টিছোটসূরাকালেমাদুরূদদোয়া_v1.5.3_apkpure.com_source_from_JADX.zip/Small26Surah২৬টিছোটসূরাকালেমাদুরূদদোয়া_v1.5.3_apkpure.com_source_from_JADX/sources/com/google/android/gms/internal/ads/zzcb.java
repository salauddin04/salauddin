package com.google.android.gms.internal.ads;

final class zzcb implements zzdof {
    static final zzdof zzei = new zzcb();

    private zzcb() {
    }

    public final boolean zzf(int i) {
        return zzbz.zzj(i) != 0;
    }
}
