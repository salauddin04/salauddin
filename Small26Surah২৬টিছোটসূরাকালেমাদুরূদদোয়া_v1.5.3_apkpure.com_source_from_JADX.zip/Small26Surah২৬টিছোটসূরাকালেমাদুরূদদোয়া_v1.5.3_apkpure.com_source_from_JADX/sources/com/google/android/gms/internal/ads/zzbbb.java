package com.google.android.gms.internal.ads;

import java.util.concurrent.ExecutionException;

final /* synthetic */ class zzbbb implements Runnable {
    private final zzbbs zzbxi;
    private final zzbbi zzdzk;

    zzbbb(zzbbs zzbbs, zzbbi zzbbi) {
        this.zzbxi = zzbbs;
        this.zzdzk = zzbbi;
    }

    public final void run() {
        zzbbs zzbbs = this.zzbxi;
        try {
            zzbbs.set(this.zzdzk.get());
        } catch (ExecutionException e) {
            zzbbs.setException(e.getCause());
        } catch (Throwable e2) {
            Thread.currentThread().interrupt();
            zzbbs.setException(e2);
        } catch (Throwable e22) {
            zzbbs.setException(e22);
        }
    }
}
