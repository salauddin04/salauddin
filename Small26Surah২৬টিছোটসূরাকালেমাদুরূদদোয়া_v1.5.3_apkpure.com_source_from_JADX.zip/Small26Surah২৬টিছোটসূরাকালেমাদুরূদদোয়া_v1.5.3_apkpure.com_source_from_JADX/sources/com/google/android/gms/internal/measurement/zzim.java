package com.google.android.gms.internal.measurement;

import java.io.IOException;

public final class zzim {
    private final byte[] buffer;
    private int zzach;
    private int zzaci = 64;
    private int zzacj = 67108864;
    private int zzacn;
    private int zzacp;
    private int zzacq = Integer.MAX_VALUE;
    private final int zzamw;
    private final int zzamx;
    private int zzamy;
    private int zzamz;
    private zzeb zzana;

    public static zzim zzj(byte[] bArr, int i, int i2) {
        return new zzim(bArr, 0, i2);
    }

    public final long zzlc() throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:9:0x001d in {5, 6, 8} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r6 = this;
        r0 = 0;
        r1 = 0;
    L_0x0003:
        r3 = 64;
        if (r0 >= r3) goto L_0x0018;
    L_0x0007:
        r3 = r6.zzlg();
        r4 = r3 & 127;
        r4 = (long) r4;
        r4 = r4 << r0;
        r1 = r1 | r4;
        r3 = r3 & 128;
        if (r3 != 0) goto L_0x0015;
    L_0x0014:
        return r1;
    L_0x0015:
        r0 = r0 + 7;
        goto L_0x0003;
    L_0x0018:
        r0 = com.google.android.gms.internal.measurement.zziu.zzpi();
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzim.zzlc():long");
    }

    public final int zzkj() throws IOException {
        if (this.zzamz == this.zzamy) {
            this.zzacp = 0;
            return 0;
        }
        this.zzacp = zzlb();
        int i = this.zzacp;
        if (i != 0) {
            return i;
        }
        throw new zziu("Protocol message contained an invalid tag (zero).");
    }

    public final void zzu(int i) throws zziu {
        if (this.zzacp != i) {
            throw new zziu("Protocol message end-group tag did not match expected tag.");
        }
    }

    public final boolean zzv(int i) throws IOException {
        int i2 = i & 7;
        if (i2 == 0) {
            zzlb();
            return true;
        } else if (i2 == 1) {
            zzlg();
            zzlg();
            zzlg();
            zzlg();
            zzlg();
            zzlg();
            zzlg();
            zzlg();
            return true;
        } else if (i2 == 2) {
            zzz(zzlb());
            return true;
        } else if (i2 == 3) {
            do {
                i2 = zzkj();
                if (i2 == 0) {
                    break;
                }
            } while (zzv(i2));
            zzu(((i >>> 3) << 3) | 4);
            return true;
        } else if (i2 == 4) {
            return false;
        } else {
            if (i2 == 5) {
                zzlg();
                zzlg();
                zzlg();
                zzlg();
                return true;
            }
            throw new zziu("Protocol message tag had invalid wire type.");
        }
    }

    public final boolean zzkp() throws IOException {
        return zzlb() != 0;
    }

    public final String readString() throws IOException {
        int zzlb = zzlb();
        if (zzlb >= 0) {
            int i = this.zzamy;
            int i2 = this.zzamz;
            if (zzlb <= i - i2) {
                String str = new String(this.buffer, i2, zzlb, zzit.UTF_8);
                this.zzamz += zzlb;
                return str;
            }
            throw zziu.zzpg();
        }
        throw zziu.zzph();
    }

    public final void zza(zziv zziv) throws IOException {
        int zzlb = zzlb();
        if (this.zzach < this.zzaci) {
            zzlb = zzx(zzlb);
            this.zzach++;
            zziv.zza(this);
            zzu(null);
            this.zzach--;
            zzy(zzlb);
            return;
        }
        throw new zziu("Protocol message had too many levels of nesting.  May be malicious.  Use CodedInputStream.setRecursionLimit() to increase the depth limit.");
    }

    public final int zzlb() throws IOException {
        byte zzlg = zzlg();
        if (zzlg >= (byte) 0) {
            return zzlg;
        }
        int i;
        int i2 = zzlg & 127;
        byte zzlg2 = zzlg();
        if (zzlg2 >= (byte) 0) {
            i = zzlg2 << 7;
        } else {
            i2 |= (zzlg2 & 127) << 7;
            zzlg2 = zzlg();
            if (zzlg2 >= (byte) 0) {
                i = zzlg2 << 14;
            } else {
                i2 |= (zzlg2 & 127) << 14;
                zzlg2 = zzlg();
                if (zzlg2 >= (byte) 0) {
                    i = zzlg2 << 21;
                } else {
                    i2 |= (zzlg2 & 127) << 21;
                    zzlg2 = zzlg();
                    i2 |= zzlg2 << 28;
                    if (zzlg2 < (byte) 0) {
                        for (i = 0; i < 5; i++) {
                            if (zzlg() >= (byte) 0) {
                                return i2;
                            }
                        }
                        throw zziu.zzpi();
                    }
                    return i2;
                }
            }
        }
        i2 |= i;
        return i2;
    }

    private zzim(byte[] bArr, int i, int i2) {
        this.buffer = bArr;
        this.zzamw = i;
        i2 += i;
        this.zzamy = i2;
        this.zzamx = i2;
        this.zzamz = i;
    }

    public final <T extends zzez<T, ?>> T zza(zzgs<T> zzgs) throws IOException {
        try {
            if (this.zzana == null) {
                this.zzana = zzeb.zzd(this.buffer, this.zzamw, this.zzamx);
            }
            int zzla = this.zzana.zzla();
            int i = this.zzamz - this.zzamw;
            if (zzla <= i) {
                this.zzana.zzz(i - zzla);
                this.zzana.zzw(this.zzaci - this.zzach);
                zzez zzez = (zzez) this.zzana.zza(zzgs, zzem.zzlt());
                zzv(this.zzacp);
                return zzez;
            }
            throw new IOException(String.format("CodedInputStream read ahead of CodedInputByteBufferNano: %s > %s", new Object[]{Integer.valueOf(zzla), Integer.valueOf(i)}));
        } catch (zzgs<T> zzgs2) {
            throw new zziu("", zzgs2);
        }
    }

    public final int zzx(int i) throws zziu {
        if (i >= 0) {
            i += this.zzamz;
            int i2 = this.zzacq;
            if (i <= i2) {
                this.zzacq = i;
                zzlf();
                return i2;
            }
            throw zziu.zzpg();
        }
        throw zziu.zzph();
    }

    private final void zzlf() {
        this.zzamy += this.zzacn;
        int i = this.zzamy;
        int i2 = this.zzacq;
        if (i > i2) {
            this.zzacn = i - i2;
            this.zzamy = i - this.zzacn;
            return;
        }
        this.zzacn = 0;
    }

    public final void zzy(int i) {
        this.zzacq = i;
        zzlf();
    }

    public final int zzpd() {
        int i = this.zzacq;
        if (i == Integer.MAX_VALUE) {
            return -1;
        }
        return i - this.zzamz;
    }

    public final int getPosition() {
        return this.zzamz - this.zzamw;
    }

    public final byte[] zzt(int i, int i2) {
        if (i2 == 0) {
            return zziy.zzanx;
        }
        Object obj = new byte[i2];
        System.arraycopy(this.buffer, this.zzamw + i, obj, 0, i2);
        return obj;
    }

    public final void zzbj(int i) {
        zzu(i, this.zzacp);
    }

    final void zzu(int i, int i2) {
        int i3 = this.zzamz;
        int i4 = this.zzamw;
        if (i > i3 - i4) {
            i3 -= i4;
            StringBuilder stringBuilder = new StringBuilder(50);
            stringBuilder.append("Position ");
            stringBuilder.append(i);
            stringBuilder.append(" is beyond current ");
            stringBuilder.append(i3);
            throw new IllegalArgumentException(stringBuilder.toString());
        } else if (i >= 0) {
            this.zzamz = i4 + i;
            this.zzacp = i2;
        } else {
            StringBuilder stringBuilder2 = new StringBuilder(24);
            stringBuilder2.append("Bad position ");
            stringBuilder2.append(i);
            throw new IllegalArgumentException(stringBuilder2.toString());
        }
    }

    private final byte zzlg() throws IOException {
        int i = this.zzamz;
        if (i != this.zzamy) {
            byte[] bArr = this.buffer;
            this.zzamz = i + 1;
            return bArr[i];
        }
        throw zziu.zzpg();
    }

    private final void zzz(int i) throws IOException {
        if (i >= 0) {
            int i2 = this.zzamz;
            int i3 = i2 + i;
            int i4 = this.zzacq;
            if (i3 > i4) {
                zzz(i4 - i2);
                throw zziu.zzpg();
            } else if (i <= this.zzamy - i2) {
                this.zzamz = i2 + i;
                return;
            } else {
                throw zziu.zzpg();
            }
        }
        throw zziu.zzph();
    }
}
