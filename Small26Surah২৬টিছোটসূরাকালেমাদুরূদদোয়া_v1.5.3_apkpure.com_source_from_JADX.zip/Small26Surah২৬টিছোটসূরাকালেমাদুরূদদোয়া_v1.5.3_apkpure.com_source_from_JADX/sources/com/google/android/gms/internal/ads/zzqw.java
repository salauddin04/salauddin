package com.google.android.gms.internal.ads;

import java.io.IOException;

public interface zzqw {
    boolean isReady();

    int zzb(zzlj zzlj, zznd zznd, boolean z);

    void zzeo(long j);

    void zzjb() throws IOException;
}
