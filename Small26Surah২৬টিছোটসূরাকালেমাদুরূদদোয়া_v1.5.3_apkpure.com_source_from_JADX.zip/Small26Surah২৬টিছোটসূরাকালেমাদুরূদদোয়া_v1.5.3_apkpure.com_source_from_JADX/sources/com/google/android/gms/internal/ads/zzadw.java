package com.google.android.gms.internal.ads;

import android.view.MotionEvent;

public interface zzadw {
    void zzc(MotionEvent motionEvent);

    void zzrg();
}
