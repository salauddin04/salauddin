package com.google.android.gms.internal.measurement;

final class zzfy implements zzgg {
    private zzgg[] zzair;

    zzfy(zzgg... zzggArr) {
        this.zzair = zzggArr;
    }

    public final com.google.android.gms.internal.measurement.zzgf zzc(java.lang.Class<?> r6) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:13:0x0036 in {5, 6, 9, 10, 12} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = r5.zzair;
        r1 = r0.length;
        r2 = 0;
    L_0x0004:
        if (r2 >= r1) goto L_0x0016;
    L_0x0006:
        r3 = r0[r2];
        r4 = r3.zzb(r6);
        if (r4 == 0) goto L_0x0013;
    L_0x000e:
        r6 = r3.zzc(r6);
        return r6;
    L_0x0013:
        r2 = r2 + 1;
        goto L_0x0004;
    L_0x0016:
        r0 = new java.lang.UnsupportedOperationException;
        r1 = "No factory is available for message type: ";
        r6 = r6.getName();
        r6 = java.lang.String.valueOf(r6);
        r2 = r6.length();
        if (r2 == 0) goto L_0x002d;
    L_0x0028:
        r6 = r1.concat(r6);
        goto L_0x0032;
    L_0x002d:
        r6 = new java.lang.String;
        r6.<init>(r1);
    L_0x0032:
        r0.<init>(r6);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzfy.zzc(java.lang.Class):com.google.android.gms.internal.measurement.zzgf");
    }

    public final boolean zzb(Class<?> cls) {
        for (zzgg zzb : this.zzair) {
            if (zzb.zzb(cls)) {
                return true;
            }
        }
        return false;
    }
}
