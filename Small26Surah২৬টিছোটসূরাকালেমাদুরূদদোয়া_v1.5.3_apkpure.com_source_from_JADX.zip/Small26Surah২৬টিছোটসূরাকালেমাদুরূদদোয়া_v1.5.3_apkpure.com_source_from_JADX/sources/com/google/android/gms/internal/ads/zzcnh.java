package com.google.android.gms.internal.ads;

import android.os.Bundle;
import android.os.RemoteException;

public final class zzcnh extends zzcoi {
    private zzbvi zzgbr;
    private zzbro zzgbs;

    public zzcnh(zzbrh zzbrh, zzbrs zzbrs, zzbsd zzbsd, zzbsn zzbsn, zzbro zzbro, zzbto zzbto, zzbvp zzbvp, zzbsu zzbsu, zzbvi zzbvi) {
        super(zzbrh, zzbrs, zzbsd, zzbsn, zzbto, zzbsu, zzbvp);
        this.zzgbr = zzbvi;
        this.zzgbs = zzbro;
    }

    public final void zzb(Bundle bundle) throws RemoteException {
    }

    public final void zzsm() {
        this.zzgbr.zzrq();
    }

    public final void zzcs(int i) throws RemoteException {
        this.zzgbs.zzcs(i);
    }

    public final void zzsn() throws RemoteException {
        this.zzgbr.zzrr();
    }

    public final void zza(zzatr zzatr) throws RemoteException {
        this.zzgbr.zza(new zzatp(zzatr.getType(), zzatr.getAmount()));
    }

    public final void zzb(zzatp zzatp) {
        this.zzgbr.zza(zzatp);
    }

    public final void onVideoEnd() {
        this.zzgbr.zzrr();
    }
}
