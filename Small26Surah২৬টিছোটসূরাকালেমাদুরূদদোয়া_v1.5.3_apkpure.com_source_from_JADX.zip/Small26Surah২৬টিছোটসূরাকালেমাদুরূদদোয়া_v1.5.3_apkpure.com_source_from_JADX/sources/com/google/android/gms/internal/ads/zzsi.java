package com.google.android.gms.internal.ads;

import java.io.IOException;

public final class zzsi extends IOException {
    public zzsi(Throwable th) {
        String simpleName = th.getClass().getSimpleName();
        String message = th.getMessage();
        StringBuilder stringBuilder = new StringBuilder((String.valueOf(simpleName).length() + 13) + String.valueOf(message).length());
        stringBuilder.append("Unexpected ");
        stringBuilder.append(simpleName);
        stringBuilder.append(": ");
        stringBuilder.append(message);
        super(stringBuilder.toString(), th);
    }
}
