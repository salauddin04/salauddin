package com.google.android.gms.internal.measurement;

final class zzhm {
    static String zzd(zzdp zzdp) {
        zzho zzhn = new zzhn(zzdp);
        zzdp = new StringBuilder(zzhn.size());
        for (int i = 0; i < zzhn.size(); i++) {
            byte zzr = zzhn.zzr(i);
            if (zzr == (byte) 34) {
                zzdp.append("\\\"");
            } else if (zzr == (byte) 39) {
                zzdp.append("\\'");
            } else if (zzr != (byte) 92) {
                switch (zzr) {
                    case (byte) 7:
                        zzdp.append("\\a");
                        break;
                    case (byte) 8:
                        zzdp.append("\\b");
                        break;
                    case (byte) 9:
                        zzdp.append("\\t");
                        break;
                    case (byte) 10:
                        zzdp.append("\\n");
                        break;
                    case (byte) 11:
                        zzdp.append("\\v");
                        break;
                    case (byte) 12:
                        zzdp.append("\\f");
                        break;
                    case (byte) 13:
                        zzdp.append("\\r");
                        break;
                    default:
                        if (zzr >= (byte) 32 && zzr <= (byte) 126) {
                            zzdp.append((char) zzr);
                            break;
                        }
                        zzdp.append('\\');
                        zzdp.append((char) (((zzr >>> 6) & 3) + 48));
                        zzdp.append((char) (((zzr >>> 3) & 7) + 48));
                        zzdp.append((char) ((zzr & 7) + 48));
                        break;
                }
            } else {
                zzdp.append("\\\\");
            }
        }
        return zzdp.toString();
    }
}
