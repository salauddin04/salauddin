package com.google.android.gms.internal.measurement;

import java.io.IOException;

final class zzdl {
    static int zza(int r2, byte[] r3, int r4, int r5, com.google.android.gms.internal.measurement.zzdm r6) throws com.google.android.gms.internal.measurement.zzfh {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:34:0x004f in {13, 15, 20, 23, 25, 27, 29, 31, 33} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = r2 >>> 3;
        if (r0 == 0) goto L_0x004a;
    L_0x0004:
        r0 = r2 & 7;
        if (r0 == 0) goto L_0x0045;
    L_0x0008:
        r1 = 1;
        if (r0 == r1) goto L_0x0042;
    L_0x000b:
        r1 = 2;
        if (r0 == r1) goto L_0x003a;
    L_0x000e:
        r1 = 3;
        if (r0 == r1) goto L_0x001c;
    L_0x0011:
        r2 = 5;
        if (r0 != r2) goto L_0x0017;
    L_0x0014:
        r4 = r4 + 4;
        return r4;
    L_0x0017:
        r2 = com.google.android.gms.internal.measurement.zzfh.zzmx();
        throw r2;
    L_0x001c:
        r2 = r2 & -8;
        r2 = r2 | 4;
        r0 = 0;
    L_0x0021:
        if (r4 >= r5) goto L_0x0030;
    L_0x0023:
        r4 = zza(r3, r4, r6);
        r0 = r6.zzabs;
        if (r0 == r2) goto L_0x0030;
    L_0x002b:
        r4 = zza(r0, r3, r4, r5, r6);
        goto L_0x0021;
    L_0x0030:
        if (r4 > r5) goto L_0x0035;
    L_0x0032:
        if (r0 != r2) goto L_0x0035;
    L_0x0034:
        return r4;
    L_0x0035:
        r2 = com.google.android.gms.internal.measurement.zzfh.zznb();
        throw r2;
    L_0x003a:
        r2 = zza(r3, r4, r6);
        r3 = r6.zzabs;
        r2 = r2 + r3;
        return r2;
    L_0x0042:
        r4 = r4 + 8;
        return r4;
    L_0x0045:
        r2 = zzb(r3, r4, r6);
        return r2;
    L_0x004a:
        r2 = com.google.android.gms.internal.measurement.zzfh.zzmx();
        throw r2;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzdl.zza(int, byte[], int, int, com.google.android.gms.internal.measurement.zzdm):int");
    }

    static int zza(int r9, byte[] r10, int r11, int r12, com.google.android.gms.internal.measurement.zzhr r13, com.google.android.gms.internal.measurement.zzdm r14) throws com.google.android.gms.internal.measurement.zzfh {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:47:0x009e in {13, 15, 20, 21, 25, 27, 33, 34, 36, 38, 40, 42, 44, 46} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = r9 >>> 3;
        if (r0 == 0) goto L_0x0099;
    L_0x0004:
        r0 = r9 & 7;
        if (r0 == 0) goto L_0x008b;
    L_0x0008:
        r1 = 1;
        if (r0 == r1) goto L_0x007d;
    L_0x000b:
        r1 = 2;
        if (r0 == r1) goto L_0x0056;
    L_0x000e:
        r1 = 3;
        if (r0 == r1) goto L_0x0027;
    L_0x0011:
        r12 = 5;
        if (r0 != r12) goto L_0x0022;
    L_0x0014:
        r10 = zza(r10, r11);
        r10 = java.lang.Integer.valueOf(r10);
        r13.zzb(r9, r10);
        r11 = r11 + 4;
        return r11;
    L_0x0022:
        r9 = com.google.android.gms.internal.measurement.zzfh.zzmx();
        throw r9;
    L_0x0027:
        r6 = com.google.android.gms.internal.measurement.zzhr.zzos();
        r0 = r9 & -8;
        r7 = r0 | 4;
        r0 = 0;
    L_0x0030:
        if (r11 >= r12) goto L_0x0049;
    L_0x0032:
        r2 = zza(r10, r11, r14);
        r11 = r14.zzabs;
        if (r11 == r7) goto L_0x0047;
    L_0x003a:
        r0 = r11;
        r1 = r10;
        r3 = r12;
        r4 = r6;
        r5 = r14;
        r0 = zza(r0, r1, r2, r3, r4, r5);
        r8 = r0;
        r0 = r11;
        r11 = r8;
        goto L_0x0030;
    L_0x0047:
        r0 = r11;
        r11 = r2;
    L_0x0049:
        if (r11 > r12) goto L_0x0051;
    L_0x004b:
        if (r0 != r7) goto L_0x0051;
    L_0x004d:
        r13.zzb(r9, r6);
        return r11;
    L_0x0051:
        r9 = com.google.android.gms.internal.measurement.zzfh.zznb();
        throw r9;
    L_0x0056:
        r11 = zza(r10, r11, r14);
        r12 = r14.zzabs;
        if (r12 < 0) goto L_0x0078;
    L_0x005e:
        r14 = r10.length;
        r14 = r14 - r11;
        if (r12 > r14) goto L_0x0073;
    L_0x0062:
        if (r12 != 0) goto L_0x006a;
    L_0x0064:
        r10 = com.google.android.gms.internal.measurement.zzdp.zzaby;
        r13.zzb(r9, r10);
        goto L_0x0071;
    L_0x006a:
        r10 = com.google.android.gms.internal.measurement.zzdp.zzb(r10, r11, r12);
        r13.zzb(r9, r10);
    L_0x0071:
        r11 = r11 + r12;
        return r11;
    L_0x0073:
        r9 = com.google.android.gms.internal.measurement.zzfh.zzmu();
        throw r9;
    L_0x0078:
        r9 = com.google.android.gms.internal.measurement.zzfh.zzmv();
        throw r9;
    L_0x007d:
        r0 = zzb(r10, r11);
        r10 = java.lang.Long.valueOf(r0);
        r13.zzb(r9, r10);
        r11 = r11 + 8;
        return r11;
    L_0x008b:
        r10 = zzb(r10, r11, r14);
        r11 = r14.zzabt;
        r11 = java.lang.Long.valueOf(r11);
        r13.zzb(r9, r11);
        return r10;
    L_0x0099:
        r9 = com.google.android.gms.internal.measurement.zzfh.zzmx();
        throw r9;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzdl.zza(int, byte[], int, int, com.google.android.gms.internal.measurement.zzhr, com.google.android.gms.internal.measurement.zzdm):int");
    }

    static int zza(byte[] bArr, int i, zzdm zzdm) {
        int i2 = i + 1;
        i = bArr[i];
        if (i < 0) {
            return zza(i, bArr, i2, zzdm);
        }
        zzdm.zzabs = i;
        return i2;
    }

    static int zza(byte[] r2, int r3, com.google.android.gms.internal.measurement.zzfg<?> r4, com.google.android.gms.internal.measurement.zzdm r5) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:7:0x001d in {2, 4, 6} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r4 = (com.google.android.gms.internal.measurement.zzfa) r4;
        r3 = zza(r2, r3, r5);
        r0 = r5.zzabs;
        r0 = r0 + r3;
    L_0x0009:
        if (r3 >= r0) goto L_0x0015;
    L_0x000b:
        r3 = zza(r2, r3, r5);
        r1 = r5.zzabs;
        r4.zzau(r1);
        goto L_0x0009;
    L_0x0015:
        if (r3 != r0) goto L_0x0018;
    L_0x0017:
        return r3;
    L_0x0018:
        r2 = com.google.android.gms.internal.measurement.zzfh.zzmu();
        throw r2;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzdl.zza(byte[], int, com.google.android.gms.internal.measurement.zzfg, com.google.android.gms.internal.measurement.zzdm):int");
    }

    static int zza(int i, byte[] bArr, int i2, zzdm zzdm) {
        i &= 127;
        int i3 = i2 + 1;
        i2 = bArr[i2];
        if (i2 >= 0) {
            zzdm.zzabs = i | (i2 << 7);
            return i3;
        }
        i |= (i2 & 127) << 7;
        i2 = i3 + 1;
        byte b = bArr[i3];
        if (b >= (byte) 0) {
            zzdm.zzabs = i | (b << 14);
            return i2;
        }
        i |= (b & 127) << 14;
        i3 = i2 + 1;
        i2 = bArr[i2];
        if (i2 >= 0) {
            zzdm.zzabs = i | (i2 << 21);
            return i3;
        }
        i |= (i2 & 127) << 21;
        i2 = i3 + 1;
        b = bArr[i3];
        if (b >= (byte) 0) {
            zzdm.zzabs = i | (b << 28);
            return i2;
        }
        i |= (b & 127) << 28;
        while (true) {
            i3 = i2 + 1;
            if (bArr[i2] >= 0) {
                zzdm.zzabs = i;
                return i3;
            }
            i2 = i3;
        }
    }

    static int zzb(byte[] bArr, int i, zzdm zzdm) {
        int i2 = i + 1;
        long j = (long) bArr[i];
        if (j >= 0) {
            zzdm.zzabt = j;
            return i2;
        }
        j &= 127;
        i = i2 + 1;
        byte b = bArr[i2];
        j |= ((long) (b & 127)) << 7;
        int i3 = 7;
        while (b < (byte) 0) {
            i2 = i + 1;
            byte b2 = bArr[i];
            i3 += 7;
            j |= ((long) (b2 & 127)) << i3;
            int i4 = i2;
            b = b2;
            i = i4;
        }
        zzdm.zzabt = j;
        return i;
    }

    static int zza(byte[] bArr, int i) {
        return ((bArr[i + 3] & 255) << 24) | (((bArr[i] & 255) | ((bArr[i + 1] & 255) << 8)) | ((bArr[i + 2] & 255) << 16));
    }

    static long zzb(byte[] bArr, int i) {
        return ((((long) bArr[i + 7]) & 255) << 56) | (((((((((long) bArr[i]) & 255) | ((((long) bArr[i + 1]) & 255) << 8)) | ((((long) bArr[i + 2]) & 255) << 16)) | ((((long) bArr[i + 3]) & 255) << 24)) | ((((long) bArr[i + 4]) & 255) << 32)) | ((((long) bArr[i + 5]) & 255) << 40)) | ((((long) bArr[i + 6]) & 255) << 48));
    }

    static double zzc(byte[] bArr, int i) {
        return Double.longBitsToDouble(zzb(bArr, i));
    }

    static float zzd(byte[] bArr, int i) {
        return Float.intBitsToFloat(zza(bArr, i));
    }

    static int zzc(byte[] bArr, int i, zzdm zzdm) throws zzfh {
        i = zza(bArr, i, zzdm);
        int i2 = zzdm.zzabs;
        if (i2 < 0) {
            throw zzfh.zzmv();
        } else if (i2 == 0) {
            zzdm.zzabu = "";
            return i;
        } else {
            zzdm.zzabu = new String(bArr, i, i2, zzfb.UTF_8);
            return i + i2;
        }
    }

    static int zzd(byte[] bArr, int i, zzdm zzdm) throws zzfh {
        i = zza(bArr, i, zzdm);
        int i2 = zzdm.zzabs;
        if (i2 < 0) {
            throw zzfh.zzmv();
        } else if (i2 == 0) {
            zzdm.zzabu = "";
            return i;
        } else {
            zzdm.zzabu = zzhy.zzh(bArr, i, i2);
            return i + i2;
        }
    }

    static int zze(byte[] bArr, int i, zzdm zzdm) throws zzfh {
        i = zza(bArr, i, zzdm);
        int i2 = zzdm.zzabs;
        if (i2 < 0) {
            throw zzfh.zzmv();
        } else if (i2 > bArr.length - i) {
            throw zzfh.zzmu();
        } else if (i2 == 0) {
            zzdm.zzabu = zzdp.zzaby;
            return i;
        } else {
            zzdm.zzabu = zzdp.zzb(bArr, i, i2);
            return i + i2;
        }
    }

    static int zza(zzgy zzgy, byte[] bArr, int i, int i2, zzdm zzdm) throws IOException {
        int i3 = i + 1;
        i = bArr[i];
        if (i < 0) {
            i3 = zza(i, bArr, i3, zzdm);
            i = zzdm.zzabs;
        }
        int i4 = i3;
        if (i < 0 || i > i2 - i4) {
            throw zzfh.zzmu();
        }
        i2 = zzgy.newInstance();
        i += i4;
        zzgy.zza(i2, bArr, i4, i, zzdm);
        zzgy.zzi(i2);
        zzdm.zzabu = i2;
        return i;
    }

    static int zza(zzgy zzgy, byte[] bArr, int i, int i2, int i3, zzdm zzdm) throws IOException {
        zzgl zzgl = (zzgl) zzgy;
        Object newInstance = zzgl.newInstance();
        bArr = zzgl.zza(newInstance, bArr, i, i2, i3, zzdm);
        zzgl.zzi(newInstance);
        zzdm.zzabu = newInstance;
        return bArr;
    }

    static int zza(int i, byte[] bArr, int i2, int i3, zzfg<?> zzfg, zzdm zzdm) {
        zzfa zzfa = (zzfa) zzfg;
        i2 = zza(bArr, i2, zzdm);
        zzfa.zzau(zzdm.zzabs);
        while (i2 < i3) {
            int zza = zza(bArr, i2, zzdm);
            if (i != zzdm.zzabs) {
                break;
            }
            i2 = zza(bArr, zza, zzdm);
            zzfa.zzau(zzdm.zzabs);
        }
        return i2;
    }

    static int zza(zzgy<?> zzgy, int i, byte[] bArr, int i2, int i3, zzfg<?> zzfg, zzdm zzdm) throws IOException {
        i2 = zza((zzgy) zzgy, bArr, i2, i3, zzdm);
        zzfg.add(zzdm.zzabu);
        while (i2 < i3) {
            int zza = zza(bArr, i2, zzdm);
            if (i != zzdm.zzabs) {
                break;
            }
            i2 = zza((zzgy) zzgy, bArr, zza, i3, zzdm);
            zzfg.add(zzdm.zzabu);
        }
        return i2;
    }
}
