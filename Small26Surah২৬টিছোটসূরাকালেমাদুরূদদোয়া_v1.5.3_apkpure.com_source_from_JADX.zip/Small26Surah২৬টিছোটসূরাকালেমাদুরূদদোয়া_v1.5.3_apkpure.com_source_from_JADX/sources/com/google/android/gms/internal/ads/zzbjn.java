package com.google.android.gms.internal.ads;

import android.content.Context;
import com.google.android.gms.ads.internal.zzk;
import com.google.android.gms.internal.ads.zzbkx.zza;
import java.util.concurrent.Executor;
import javax.annotation.concurrent.GuardedBy;

public abstract class zzbjn implements zzblq {
    @GuardedBy("AppComponent.class")
    private static zzbjn zzeof;

    protected abstract zzcvr zza(zzcww zzcww);

    public abstract Executor zzace();

    public abstract zzbbm zzacf();

    public abstract zzbta zzacg();

    public abstract zzclb zzach();

    public abstract zzbla zzaci();

    public abstract zzboc zzacj();

    public abstract zzbws zzack();

    public abstract zzbxo zzacl();

    public abstract zzcdf zzacm();

    public abstract zzcqo zzacn();

    public static zzbjn zza(Context context, zzamq zzamq, int i) {
        context = zzd(context, i);
        context.zzach().zzb(zzamq);
        return context;
    }

    @Deprecated
    public static zzbjn zzd(Context context, int i) {
        synchronized (zzbjn.class) {
            if (zzeof != null) {
                context = zzeof;
                return context;
            }
            return zza(new zzbaj(15000000, i, true, false), context, new zzbkc());
        }
    }

    @Deprecated
    private static zzbjn zza(zzbaj zzbaj, Context context, zza zza) {
        synchronized (zzbjn.class) {
            if (zzeof == null) {
                zzeof = new zzbko().zzc(new zzbjo(new zzbjo.zza().zza(zzbaj).zzbo(context))).zza(new zzbkx(zza)).zzaec();
                zzact.initialize(context);
                zzk.zzlk().zzd(context, zzbaj);
                zzk.zzlm().initialize(context);
                zzk.zzlg().zzak(context);
                zzk.zzlg().zzal(context);
                zzawy.zzaj(context);
                zzk.zzlj().initialize(context);
                zzk.zzmb().initialize(context);
                if (((Boolean) zzyr.zzpe().zzd(zzact.zzcwt)).booleanValue() != null) {
                    new zzcjq(context, zzbaj, new zzwh(new zzwm(context)), new zzcjb(new zzciz(context), zzeof.zzacf())).zzakp();
                }
            }
            zzbaj = zzeof;
        }
        return zzbaj;
    }

    public final zzcvr zza(zzary zzary) {
        return zza(new zzcww(zzary));
    }
}
