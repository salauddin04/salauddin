package com.google.android.gms.internal.ads;

import java.util.List;

public interface zzdos extends List {
    List<?> zzayo();

    zzdos zzayp();

    void zzdb(zzdmq zzdmq);

    Object zzgq(int i);
}
