package com.google.android.gms.internal.measurement;

enum zzig extends zzif {
    zzig(String str, int i, zzik zzik, int i2) {
        super(str, 8, zzik, 2);
    }
}
