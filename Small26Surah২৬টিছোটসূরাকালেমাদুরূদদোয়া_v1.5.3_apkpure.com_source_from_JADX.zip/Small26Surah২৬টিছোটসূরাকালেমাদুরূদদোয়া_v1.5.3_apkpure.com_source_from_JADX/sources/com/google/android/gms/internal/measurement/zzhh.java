package com.google.android.gms.internal.measurement;

import java.util.Iterator;

final class zzhh implements Iterable<Object> {
    zzhh() {
    }

    public final Iterator<Object> iterator() {
        return zzhf.zzakj;
    }
}
