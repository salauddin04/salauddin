package com.google.android.gms.internal.ads;

import android.support.v4.app.NotificationCompat;
import java.util.HashMap;
import java.util.Map;

final class zzbfx implements Runnable {
    private final /* synthetic */ String zzdlk;
    private final /* synthetic */ String zzehw;
    private final /* synthetic */ boolean zzehz;
    private final /* synthetic */ zzbfu zzeia;
    private final /* synthetic */ long zzeid;
    private final /* synthetic */ long zzeie;

    zzbfx(zzbfu zzbfu, String str, String str2, long j, long j2, boolean z) {
        this.zzeia = zzbfu;
        this.zzdlk = str;
        this.zzehw = str2;
        this.zzeid = j;
        this.zzeie = j2;
        this.zzehz = z;
    }

    public final void run() {
        Map hashMap = new HashMap();
        hashMap.put(NotificationCompat.CATEGORY_EVENT, "precacheProgress");
        hashMap.put("src", this.zzdlk);
        hashMap.put("cachedSrc", this.zzehw);
        hashMap.put("bufferedDuration", Long.toString(this.zzeid));
        hashMap.put("totalDuration", Long.toString(this.zzeie));
        hashMap.put("cacheReady", this.zzehz ? "1" : "0");
        this.zzeia.zza("onPrecacheEvent", hashMap);
    }
}
