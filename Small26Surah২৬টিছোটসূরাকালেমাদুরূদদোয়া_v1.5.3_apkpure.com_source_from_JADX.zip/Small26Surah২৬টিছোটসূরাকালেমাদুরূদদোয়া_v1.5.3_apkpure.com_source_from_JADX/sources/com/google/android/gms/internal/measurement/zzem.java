package com.google.android.gms.internal.measurement;

import android.support.v4.internal.view.SupportMenu;
import com.google.android.gms.internal.measurement.zzez.zzd;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class zzem {
    private static volatile boolean zzadj = false;
    private static final Class<?> zzadk = zzlr();
    private static volatile zzem zzadl;
    static final zzem zzadm = new zzem(true);
    private final Map<zza, zzd<?, ?>> zzadn;

    static final class zza {
        private final int number;
        private final Object object;

        zza(Object obj, int i) {
            this.object = obj;
            this.number = i;
        }

        public final int hashCode() {
            return (System.identityHashCode(this.object) * SupportMenu.USER_MASK) + this.number;
        }

        public final boolean equals(Object obj) {
            if (!(obj instanceof zza)) {
                return false;
            }
            zza zza = (zza) obj;
            if (this.object == zza.object && this.number == zza.number) {
                return true;
            }
            return false;
        }
    }

    private static java.lang.Class<?> zzlr() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = "com.google.protobuf.Extension";	 Catch:{ ClassNotFoundException -> 0x0007 }
        r0 = java.lang.Class.forName(r0);	 Catch:{ ClassNotFoundException -> 0x0007 }
        return r0;
    L_0x0007:
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzem.zzlr():java.lang.Class<?>");
    }

    public static zzem zzls() {
        return zzel.zzlp();
    }

    public static zzem zzlt() {
        zzem zzem = zzadl;
        if (zzem == null) {
            synchronized (zzem.class) {
                zzem = zzadl;
                if (zzem == null) {
                    zzem = zzel.zzlq();
                    zzadl = zzem;
                }
            }
        }
        return zzem;
    }

    static zzem zzlq() {
        return zzex.zza(zzem.class);
    }

    public final <ContainingType extends zzgh> zzd<ContainingType, ?> zza(ContainingType containingType, int i) {
        return (zzd) this.zzadn.get(new zza(containingType, i));
    }

    zzem() {
        this.zzadn = new HashMap();
    }

    private zzem(boolean z) {
        this.zzadn = Collections.emptyMap();
    }
}
