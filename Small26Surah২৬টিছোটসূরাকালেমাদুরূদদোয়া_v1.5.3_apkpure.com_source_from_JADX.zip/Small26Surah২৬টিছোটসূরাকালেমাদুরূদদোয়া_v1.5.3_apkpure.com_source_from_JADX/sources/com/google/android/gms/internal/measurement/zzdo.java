package com.google.android.gms.internal.measurement;

import java.io.IOException;

public abstract class zzdo {
    public abstract void zza(byte[] bArr, int i, int i2) throws IOException;
}
