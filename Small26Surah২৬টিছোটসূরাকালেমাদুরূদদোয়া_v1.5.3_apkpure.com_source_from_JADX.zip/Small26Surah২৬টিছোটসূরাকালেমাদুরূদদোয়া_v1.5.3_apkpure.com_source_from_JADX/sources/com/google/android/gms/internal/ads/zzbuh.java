package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.reward.AdMetadataListener;
import java.util.Set;

public final class zzbuh implements zzdth<Set<zzbuy<AdMetadataListener>>> {
    private final zzbtu zzfky;

    private zzbuh(zzbtu zzbtu) {
        this.zzfky = zzbtu;
    }

    public static zzbuh zzp(zzbtu zzbtu) {
        return new zzbuh(zzbtu);
    }

    public final /* synthetic */ Object get() {
        return (Set) zzdtn.zza(this.zzfky.zzagp(), "Cannot return null from a non-@Nullable @Provides method");
    }
}
