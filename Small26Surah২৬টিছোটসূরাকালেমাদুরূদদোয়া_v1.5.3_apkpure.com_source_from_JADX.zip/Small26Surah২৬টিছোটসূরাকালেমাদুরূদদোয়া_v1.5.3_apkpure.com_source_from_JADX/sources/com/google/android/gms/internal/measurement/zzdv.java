package com.google.android.gms.internal.measurement;

interface zzdv {
    byte[] zzc(byte[] bArr, int i, int i2);
}
