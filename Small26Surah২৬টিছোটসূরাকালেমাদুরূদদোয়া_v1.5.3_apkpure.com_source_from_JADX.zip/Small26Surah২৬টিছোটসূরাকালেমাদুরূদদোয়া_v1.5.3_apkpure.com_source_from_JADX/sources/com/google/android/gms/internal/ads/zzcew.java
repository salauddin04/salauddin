package com.google.android.gms.internal.ads;

import java.util.Map;

public final class zzcew implements zzczy {
    private zzwh zzftz;
    private Map<zzczr, zzcey> zzfuj;

    zzcew(zzwh zzwh, Map<zzczr, zzcey> map) {
        this.zzfuj = map;
        this.zzftz = zzwh;
    }

    public final void zza(zzczr zzczr, String str) {
    }

    public final void zzb(zzczr zzczr, String str) {
        if (this.zzfuj.containsKey(zzczr) != null) {
            this.zzftz.zza(((zzcey) this.zzfuj.get(zzczr)).zzfuk);
        }
    }

    public final void zza(zzczr zzczr, String str, Throwable th) {
        if (this.zzfuj.containsKey(zzczr) != null) {
            this.zzftz.zza(((zzcey) this.zzfuj.get(zzczr)).zzfum);
        }
    }

    public final void zzc(zzczr zzczr, String str) {
        if (this.zzfuj.containsKey(zzczr) != null) {
            this.zzftz.zza(((zzcey) this.zzfuj.get(zzczr)).zzful);
        }
    }
}
