package com.google.android.gms.internal.ads;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;

public interface zzajb extends IInterface {
    void destroy() throws RemoteException;

    zzaap getVideoController() throws RemoteException;

    void zza(IObjectWrapper iObjectWrapper, zzajd zzajd) throws RemoteException;
}
