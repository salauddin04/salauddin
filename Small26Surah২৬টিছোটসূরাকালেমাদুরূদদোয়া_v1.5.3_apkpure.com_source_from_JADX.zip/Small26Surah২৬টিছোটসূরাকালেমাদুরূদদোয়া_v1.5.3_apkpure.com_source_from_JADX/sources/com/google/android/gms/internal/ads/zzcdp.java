package com.google.android.gms.internal.ads;

final /* synthetic */ class zzcdp implements zzxp {
    private final zzcdo zzftl;

    zzcdp(zzcdo zzcdo) {
        this.zzftl = zzcdo;
    }

    public final void onAdClicked() {
        this.zzftl.zzajn();
    }
}
