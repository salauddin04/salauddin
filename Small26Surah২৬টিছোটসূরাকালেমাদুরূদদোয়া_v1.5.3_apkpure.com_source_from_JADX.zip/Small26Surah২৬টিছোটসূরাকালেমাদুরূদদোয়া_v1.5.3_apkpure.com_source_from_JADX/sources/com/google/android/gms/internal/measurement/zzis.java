package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

final class zzis implements Cloneable {
    private Object value;
    private zziq<?, ?> zzanj;
    private List<zzix> zzank = new ArrayList();

    zzis() {
    }

    private final com.google.android.gms.internal.measurement.zzis zzpf() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:46:0x00de in {4, 5, 10, 13, 19, 22, 25, 28, 31, 34, 41, 42, 45} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = new com.google.android.gms.internal.measurement.zzis;
        r0.<init>();
        r1 = r5.zzanj;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r0.zzanj = r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r5.zzank;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r1 != 0) goto L_0x0011;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x000d:
        r1 = 0;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r0.zzank = r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        goto L_0x0018;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0011:
        r1 = r0.zzank;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r2 = r5.zzank;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1.addAll(r2);	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0018:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r1 == 0) goto L_0x00d6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x001c:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1 instanceof com.google.android.gms.internal.measurement.zziv;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r1 == 0) goto L_0x0030;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0022:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = (com.google.android.gms.internal.measurement.zziv) r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1.clone();	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = (com.google.android.gms.internal.measurement.zziv) r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r0.value = r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        goto L_0x00d6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0030:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1 instanceof byte[];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r1 == 0) goto L_0x0042;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0036:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = (byte[]) r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1.clone();	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r0.value = r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        goto L_0x00d6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0042:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1 instanceof byte[][];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r2 = 0;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r1 == 0) goto L_0x0062;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0049:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = (byte[][]) r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r3 = r1.length;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r3 = new byte[r3][];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r0.value = r3;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0052:
        r4 = r1.length;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r2 >= r4) goto L_0x00d6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0055:
        r4 = r1[r2];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r4 = r4.clone();	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r4 = (byte[]) r4;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r3[r2] = r4;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r2 = r2 + 1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        goto L_0x0052;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0062:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1 instanceof boolean[];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r1 == 0) goto L_0x0073;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0068:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = (boolean[]) r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1.clone();	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r0.value = r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        goto L_0x00d6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0073:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1 instanceof int[];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r1 == 0) goto L_0x0084;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0079:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = (int[]) r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1.clone();	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r0.value = r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        goto L_0x00d6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0084:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1 instanceof long[];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r1 == 0) goto L_0x0095;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x008a:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = (long[]) r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1.clone();	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r0.value = r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        goto L_0x00d6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x0095:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1 instanceof float[];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r1 == 0) goto L_0x00a6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x009b:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = (float[]) r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1.clone();	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r0.value = r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        goto L_0x00d6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x00a6:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1 instanceof double[];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r1 == 0) goto L_0x00b7;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x00ac:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = (double[]) r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1.clone();	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r0.value = r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        goto L_0x00d6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x00b7:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = r1 instanceof com.google.android.gms.internal.measurement.zziv[];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r1 == 0) goto L_0x00d6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x00bd:
        r1 = r5.value;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r1 = (com.google.android.gms.internal.measurement.zziv[]) r1;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r3 = r1.length;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r3 = new com.google.android.gms.internal.measurement.zziv[r3];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r0.value = r3;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x00c6:
        r4 = r1.length;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        if (r2 >= r4) goto L_0x00d6;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
    L_0x00c9:
        r4 = r1[r2];	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r4 = r4.clone();	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r4 = (com.google.android.gms.internal.measurement.zziv) r4;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r3[r2] = r4;	 Catch:{ CloneNotSupportedException -> 0x00d7 }
        r2 = r2 + 1;
        goto L_0x00c6;
    L_0x00d6:
        return r0;
    L_0x00d7:
        r0 = move-exception;
        r1 = new java.lang.AssertionError;
        r1.<init>(r0);
        throw r1;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzis.zzpf():com.google.android.gms.internal.measurement.zzis");
    }

    final void zza(com.google.android.gms.internal.measurement.zzin r4) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:9:0x0028 in {5, 6, 8} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r3 = this;
        r0 = r3.value;
        if (r0 != 0) goto L_0x0022;
    L_0x0004:
        r0 = r3.zzank;
        r0 = r0.iterator();
    L_0x000a:
        r1 = r0.hasNext();
        if (r1 == 0) goto L_0x0021;
    L_0x0010:
        r1 = r0.next();
        r1 = (com.google.android.gms.internal.measurement.zzix) r1;
        r2 = r1.tag;
        r4.zzbl(r2);
        r1 = r1.zzacg;
        r4.zzm(r1);
        goto L_0x000a;
    L_0x0021:
        return;
    L_0x0022:
        r4 = new java.lang.NoSuchMethodError;
        r4.<init>();
        throw r4;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzis.zza(com.google.android.gms.internal.measurement.zzin):void");
    }

    final int zzja() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:9:0x002c in {5, 6, 8} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = r5.value;
        if (r0 != 0) goto L_0x0026;
    L_0x0004:
        r0 = r5.zzank;
        r0 = r0.iterator();
        r1 = 0;
        r2 = 0;
    L_0x000c:
        r3 = r0.hasNext();
        if (r3 == 0) goto L_0x0025;
    L_0x0012:
        r3 = r0.next();
        r3 = (com.google.android.gms.internal.measurement.zzix) r3;
        r4 = r3.tag;
        r4 = com.google.android.gms.internal.measurement.zzin.zzar(r4);
        r4 = r4 + r1;
        r3 = r3.zzacg;
        r3 = r3.length;
        r4 = r4 + r3;
        r2 = r2 + r4;
        goto L_0x000c;
    L_0x0025:
        return r2;
    L_0x0026:
        r0 = new java.lang.NoSuchMethodError;
        r0.<init>();
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzis.zzja():int");
    }

    final void zza(zzix zzix) throws IOException {
        List list = this.zzank;
        if (list != null) {
            list.add(zzix);
            return;
        }
        Object obj = this.value;
        if (obj instanceof zziv) {
            zzix = zzix.zzacg;
            zzim zzj = zzim.zzj(zzix, 0, zzix.length);
            int zzlb = zzj.zzlb();
            if (zzlb == zzix.length - zzin.zzak(zzlb)) {
                zzix = ((zziv) this.value).zza(zzj);
                this.zzanj = this.zzanj;
                this.value = zzix;
                this.zzank = null;
                return;
            }
            throw zziu.zzpg();
        } else if (obj instanceof zziv[]) {
            Collections.singletonList(zzix);
            throw new NoSuchMethodError();
        } else if (obj instanceof zzgh) {
            Collections.singletonList(zzix);
            throw new NoSuchMethodError();
        } else if (obj instanceof zzgh[]) {
            Collections.singletonList(zzix);
            throw new NoSuchMethodError();
        } else {
            Collections.singletonList(zzix);
            throw new NoSuchMethodError();
        }
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzis)) {
            return false;
        }
        zzis zzis = (zzis) obj;
        if (this.value == null || zzis.value == null) {
            List list = this.zzank;
            if (list != null) {
                List list2 = zzis.zzank;
                if (list2 != null) {
                    return list.equals(list2);
                }
            }
            try {
                return Arrays.equals(toByteArray(), zzis.toByteArray());
            } catch (Object obj2) {
                throw new IllegalStateException(obj2);
            }
        }
        zziq zziq = this.zzanj;
        if (zziq != zzis.zzanj) {
            return false;
        }
        if (!zziq.zzane.isArray()) {
            return this.value.equals(zzis.value);
        }
        Object obj3 = this.value;
        if (obj3 instanceof byte[]) {
            return Arrays.equals((byte[]) obj3, (byte[]) zzis.value);
        }
        if (obj3 instanceof int[]) {
            return Arrays.equals((int[]) obj3, (int[]) zzis.value);
        }
        if (obj3 instanceof long[]) {
            return Arrays.equals((long[]) obj3, (long[]) zzis.value);
        }
        if (obj3 instanceof float[]) {
            return Arrays.equals((float[]) obj3, (float[]) zzis.value);
        }
        if (obj3 instanceof double[]) {
            return Arrays.equals((double[]) obj3, (double[]) zzis.value);
        }
        if (obj3 instanceof boolean[]) {
            return Arrays.equals((boolean[]) obj3, (boolean[]) zzis.value);
        }
        return Arrays.deepEquals((Object[]) obj3, (Object[]) zzis.value);
    }

    public final int hashCode() {
        try {
            return Arrays.hashCode(toByteArray()) + 527;
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    private final byte[] toByteArray() throws IOException {
        byte[] bArr = new byte[zzja()];
        zza(zzin.zzl(bArr));
        return bArr;
    }

    public final /* synthetic */ Object clone() throws CloneNotSupportedException {
        return zzpf();
    }
}
