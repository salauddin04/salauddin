package com.google.android.gms.internal.measurement;

abstract class zzds implements zzdw {
    zzds() {
    }

    public final void remove() {
        throw new UnsupportedOperationException();
    }

    public /* synthetic */ Object next() {
        return Byte.valueOf(nextByte());
    }
}
