package com.google.android.gms.internal.ads;

public abstract class zzbnf extends zzbpc {
    public abstract zzbne zzadx();

    public abstract zzcdo zzady();

    public abstract zzbuz zzadz();

    public abstract zzcon zzaea();
}
