package com.google.android.gms.internal.measurement;

import android.os.RemoteException;

final class zzaq extends zza {
    private final /* synthetic */ zzaa zzar;
    private final /* synthetic */ zzm zzaw;

    zzaq(zzaa zzaa, zzm zzm) {
        this.zzar = zzaa;
        this.zzaw = zzm;
        super(zzaa);
    }

    final void zzl() throws RemoteException {
        this.zzar.zzan.getCurrentScreenName(this.zzaw);
    }

    protected final void zzm() {
        this.zzaw.zzb(null);
    }
}
