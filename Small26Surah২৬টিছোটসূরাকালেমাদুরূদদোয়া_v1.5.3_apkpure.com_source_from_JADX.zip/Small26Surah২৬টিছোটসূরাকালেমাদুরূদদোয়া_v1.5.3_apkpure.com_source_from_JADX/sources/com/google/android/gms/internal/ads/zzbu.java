package com.google.android.gms.internal.ads;

import com.google.android.gms.internal.ads.zzbp.zza.zzc;

final class zzbu implements zzdof {
    static final zzdof zzei = new zzbu();

    private zzbu() {
    }

    public final boolean zzf(int i) {
        return zzc.zzh(i) != 0;
    }
}
