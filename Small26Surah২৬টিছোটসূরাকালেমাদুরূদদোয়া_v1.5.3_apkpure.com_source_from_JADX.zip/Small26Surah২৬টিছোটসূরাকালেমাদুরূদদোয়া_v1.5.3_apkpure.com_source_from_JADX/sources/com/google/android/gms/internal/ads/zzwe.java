package com.google.android.gms.internal.ads;

import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;

final class zzwe extends PushbackInputStream {
    private final /* synthetic */ zzwb zzbxk;

    zzwe(zzwb zzwb, InputStream inputStream, int i) {
        this.zzbxk = zzwb;
        super(inputStream, 1);
    }

    public final synchronized void close() throws IOException {
        this.zzbxk.zzbxb.disconnect();
        super.close();
    }
}
