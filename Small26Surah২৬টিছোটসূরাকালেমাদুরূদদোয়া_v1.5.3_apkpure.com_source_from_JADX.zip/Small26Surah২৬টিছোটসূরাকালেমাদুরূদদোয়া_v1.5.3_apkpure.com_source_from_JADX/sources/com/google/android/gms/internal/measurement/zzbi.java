package com.google.android.gms.internal.measurement;

import android.app.Activity;
import android.os.RemoteException;
import com.google.android.gms.dynamic.ObjectWrapper;

final class zzbi extends zza {
    private final /* synthetic */ Activity val$activity;
    private final /* synthetic */ zzd zzbx;

    zzbi(zzd zzd, Activity activity) {
        this.zzbx = zzd;
        this.val$activity = activity;
        super(zzd.zzar);
    }

    final void zzl() throws RemoteException {
        this.zzbx.zzar.zzan.onActivityStopped(ObjectWrapper.wrap(this.val$activity), this.zzbs);
    }
}
