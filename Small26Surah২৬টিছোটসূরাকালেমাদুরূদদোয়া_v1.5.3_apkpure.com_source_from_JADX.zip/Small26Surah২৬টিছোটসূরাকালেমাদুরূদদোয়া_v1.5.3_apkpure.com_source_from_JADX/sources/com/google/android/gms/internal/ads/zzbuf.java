package com.google.android.gms.internal.ads;

import java.util.Set;

public final class zzbuf implements zzdth<Set<zzbuy<zzbrk>>> {
    private final zzbtu zzfky;

    private zzbuf(zzbtu zzbtu) {
        this.zzfky = zzbtu;
    }

    public static zzbuf zzm(zzbtu zzbtu) {
        return new zzbuf(zzbtu);
    }

    public final /* synthetic */ Object get() {
        return (Set) zzdtn.zza(this.zzfky.zzagl(), "Cannot return null from a non-@Nullable @Provides method");
    }
}
