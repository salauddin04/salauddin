package com.google.android.gms.internal.ads;

import android.content.Context;
import java.util.concurrent.Executor;

public final class zzcoa implements zzdth<zzcnv> {
    private final zzdtt<Context> zzeol;
    private final zzdtt<Executor> zzfhh;
    private final zzdtt<zzcde> zzfzs;

    public zzcoa(zzdtt<Context> zzdtt, zzdtt<Executor> zzdtt2, zzdtt<zzcde> zzdtt3) {
        this.zzeol = zzdtt;
        this.zzfhh = zzdtt2;
        this.zzfzs = zzdtt3;
    }

    public final /* synthetic */ Object get() {
        return new zzcnv((Context) this.zzeol.get(), (Executor) this.zzfhh.get(), (zzcde) this.zzfzs.get());
    }
}
