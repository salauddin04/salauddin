package com.google.android.gms.internal.ads;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract class zzaaq extends zzfn implements zzaap {
    public zzaaq() {
        super("com.google.android.gms.ads.internal.client.IVideoController");
    }

    public static zzaap zzh(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IVideoController");
        if (queryLocalInterface instanceof zzaap) {
            return (zzaap) queryLocalInterface;
        }
        return new zzaar(iBinder);
    }

    protected final boolean dispatchTransaction(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
        switch (i) {
            case 1:
                play();
                parcel2.writeNoException();
                break;
            case 2:
                pause();
                parcel2.writeNoException();
                break;
            case 3:
                mute(zzfo.zza(parcel));
                parcel2.writeNoException();
                break;
            case 4:
                i = isMuted();
                parcel2.writeNoException();
                zzfo.writeBoolean(parcel2, i);
                break;
            case 5:
                i = getPlaybackState();
                parcel2.writeNoException();
                parcel2.writeInt(i);
                break;
            case 6:
                i = zzpv();
                parcel2.writeNoException();
                parcel2.writeFloat(i);
                break;
            case 7:
                i = zzpw();
                parcel2.writeNoException();
                parcel2.writeFloat(i);
                break;
            case 8:
                i = parcel.readStrongBinder();
                if (i == 0) {
                    i = 0;
                } else {
                    parcel = i.queryLocalInterface("com.google.android.gms.ads.internal.client.IVideoLifecycleCallbacks");
                    if ((parcel instanceof zzaas) != 0) {
                        i = (zzaas) parcel;
                    } else {
                        i = new zzaau(i);
                    }
                }
                zza(i);
                parcel2.writeNoException();
                break;
            case 9:
                i = getAspectRatio();
                parcel2.writeNoException();
                parcel2.writeFloat(i);
                break;
            case 10:
                i = isCustomControlsEnabled();
                parcel2.writeNoException();
                zzfo.writeBoolean(parcel2, i);
                break;
            case 11:
                IInterface zzpx = zzpx();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzpx);
                break;
            case 12:
                i = isClickToExpandEnabled();
                parcel2.writeNoException();
                zzfo.writeBoolean(parcel2, i);
                break;
            default:
                return false;
        }
        return true;
    }
}
