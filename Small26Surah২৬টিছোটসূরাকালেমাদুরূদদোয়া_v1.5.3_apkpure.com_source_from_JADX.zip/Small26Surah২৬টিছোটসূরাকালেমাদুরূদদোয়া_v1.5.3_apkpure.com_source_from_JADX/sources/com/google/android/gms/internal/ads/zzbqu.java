package com.google.android.gms.internal.ads;

import android.content.Context;

final /* synthetic */ class zzbqu implements zzban {
    private final Context zzdeh;
    private final zzbaj zzfhk;
    private final zzcxu zzfjs;

    zzbqu(Context context, zzbaj zzbaj, zzcxu zzcxu) {
        this.zzdeh = context;
        this.zzfhk = zzbaj;
        this.zzfjs = zzcxu;
    }

    public final Object apply(Object obj) {
        Context context = this.zzdeh;
        zzbaj zzbaj = this.zzfhk;
        zzcxu zzcxu = this.zzfjs;
        zzcxl zzcxl = (zzcxl) obj;
        zzayc zzayc = new zzayc(context);
        zzayc.zzee(zzcxl.zzdnq);
        zzayc.zzef(zzcxl.zzgkj.toString());
        zzayc.zzp(zzbaj.zzbsy);
        zzayc.setAdUnitId(zzcxu.zzglb);
        return zzayc;
    }
}
