package com.google.android.gms.internal.measurement;

interface zzgg {
    boolean zzb(Class<?> cls);

    zzgf zzc(Class<?> cls);
}
