package com.google.android.gms.internal.measurement;

import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

final class zzew extends zzdj<Float> implements zzfg<Float>, zzgt, RandomAccess {
    private static final zzew zzagj;
    private int size;
    private float[] zzagk;

    zzew() {
        this(new float[10], 0);
    }

    private zzew(float[] fArr, int i) {
        this.zzagk = fArr;
        this.size = i;
    }

    protected final void removeRange(int i, int i2) {
        zzka();
        if (i2 >= i) {
            Object obj = this.zzagk;
            System.arraycopy(obj, i2, obj, i, this.size - i2);
            this.size -= i2 - i;
            this.modCount++;
            return;
        }
        throw new IndexOutOfBoundsException("toIndex < fromIndex");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzew)) {
            return super.equals(obj);
        }
        zzew zzew = (zzew) obj;
        if (this.size != zzew.size) {
            return false;
        }
        obj = zzew.zzagk;
        for (int i = 0; i < this.size; i++) {
            if (Float.floatToIntBits(this.zzagk[i]) != Float.floatToIntBits(obj[i])) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int i = 1;
        for (int i2 = 0; i2 < this.size; i2++) {
            i = (i * 31) + Float.floatToIntBits(this.zzagk[i2]);
        }
        return i;
    }

    public final int size() {
        return this.size;
    }

    public final void zzc(float f) {
        zzc(this.size, f);
    }

    private final void zzc(int i, float f) {
        zzka();
        if (i >= 0) {
            int i2 = this.size;
            if (i <= i2) {
                Object obj = this.zzagk;
                if (i2 < obj.length) {
                    System.arraycopy(obj, i, obj, i + 1, i2 - i);
                } else {
                    Object obj2 = new float[(((i2 * 3) / 2) + 1)];
                    System.arraycopy(obj, 0, obj2, 0, i);
                    System.arraycopy(this.zzagk, i, obj2, i + 1, this.size - i);
                    this.zzagk = obj2;
                }
                this.zzagk[i] = f;
                this.size++;
                this.modCount++;
                return;
            }
        }
        throw new IndexOutOfBoundsException(zzp(i));
    }

    public final boolean addAll(Collection<? extends Float> collection) {
        zzka();
        zzfb.checkNotNull(collection);
        if (!(collection instanceof zzew)) {
            return super.addAll(collection);
        }
        zzew zzew = (zzew) collection;
        int i = zzew.size;
        if (i == 0) {
            return false;
        }
        int i2 = this.size;
        if (Integer.MAX_VALUE - i2 >= i) {
            i2 += i;
            float[] fArr = this.zzagk;
            if (i2 > fArr.length) {
                this.zzagk = Arrays.copyOf(fArr, i2);
            }
            System.arraycopy(zzew.zzagk, 0, this.zzagk, this.size, zzew.size);
            this.size = i2;
            this.modCount += 1;
            return true;
        }
        throw new OutOfMemoryError();
    }

    public final boolean remove(Object obj) {
        zzka();
        for (int i = 0; i < this.size; i++) {
            if (obj.equals(Float.valueOf(this.zzagk[i]))) {
                obj = this.zzagk;
                System.arraycopy(obj, i + 1, obj, i, (this.size - i) - 1);
                this.size -= 1;
                this.modCount += 1;
                return true;
            }
        }
        return false;
    }

    private final void zzo(int i) {
        if (i < 0 || i >= this.size) {
            throw new IndexOutOfBoundsException(zzp(i));
        }
    }

    private final String zzp(int i) {
        int i2 = this.size;
        StringBuilder stringBuilder = new StringBuilder(35);
        stringBuilder.append("Index:");
        stringBuilder.append(i);
        stringBuilder.append(", Size:");
        stringBuilder.append(i2);
        return stringBuilder.toString();
    }

    public final /* synthetic */ Object set(int i, Object obj) {
        obj = ((Float) obj).floatValue();
        zzka();
        zzo(i);
        float[] fArr = this.zzagk;
        float f = fArr[i];
        fArr[i] = obj;
        return Float.valueOf(f);
    }

    public final /* synthetic */ Object remove(int i) {
        zzka();
        zzo(i);
        Object obj = this.zzagk;
        float f = obj[i];
        int i2 = this.size;
        if (i < i2 - 1) {
            System.arraycopy(obj, i + 1, obj, i, (i2 - i) - 1);
        }
        this.size--;
        this.modCount++;
        return Float.valueOf(f);
    }

    public final /* synthetic */ void add(int i, Object obj) {
        zzc(i, ((Float) obj).floatValue());
    }

    public final /* synthetic */ zzfg zzq(int i) {
        if (i >= this.size) {
            return new zzew(Arrays.copyOf(this.zzagk, i), this.size);
        }
        throw new IllegalArgumentException();
    }

    public final /* synthetic */ Object get(int i) {
        zzo(i);
        return Float.valueOf(this.zzagk[i]);
    }

    static {
        zzdj zzew = new zzew(new float[0], 0);
        zzagj = zzew;
        zzew.zzjz();
    }
}
