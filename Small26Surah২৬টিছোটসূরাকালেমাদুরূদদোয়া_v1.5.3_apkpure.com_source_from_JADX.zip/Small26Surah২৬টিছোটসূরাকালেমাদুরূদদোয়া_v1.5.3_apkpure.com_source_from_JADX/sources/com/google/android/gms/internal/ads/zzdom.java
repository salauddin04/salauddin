package com.google.android.gms.internal.ads;

public final class zzdom extends zzdoq {
    public static zzdpj zzaym() {
        throw new NoSuchMethodError();
    }

    public final int hashCode() {
        throw new NoSuchMethodError();
    }

    public final boolean equals(Object obj) {
        throw new NoSuchMethodError();
    }

    public final String toString() {
        throw new NoSuchMethodError();
    }
}
