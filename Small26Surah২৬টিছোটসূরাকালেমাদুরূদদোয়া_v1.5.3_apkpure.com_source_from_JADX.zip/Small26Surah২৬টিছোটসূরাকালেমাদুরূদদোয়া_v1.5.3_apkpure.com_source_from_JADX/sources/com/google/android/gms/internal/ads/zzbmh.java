package com.google.android.gms.internal.ads;

import android.support.annotation.Nullable;
import android.text.TextUtils;
import java.util.Map;

public final class zzbmh {
    private final String zzbsx;
    private final zzalz zzffj;
    private zzbmm zzffk;
    private final zzahn<Object> zzffl = new zzbmi(this);
    private final zzahn<Object> zzffm = new zzbmj(this);

    public zzbmh(String str, zzalz zzalz) {
        this.zzbsx = str;
        this.zzffj = zzalz;
    }

    public final void zza(zzbmm zzbmm) {
        this.zzffj.zzc("/updateActiveView", this.zzffl);
        this.zzffj.zzc("/untrackActiveViewUnit", this.zzffm);
        this.zzffk = zzbmm;
    }

    public final void zzd(zzbha zzbha) {
        zzbha.zza("/updateActiveView", this.zzffl);
        zzbha.zza("/untrackActiveViewUnit", this.zzffm);
    }

    public final void zze(zzbha zzbha) {
        zzbha.zzb("/updateActiveView", this.zzffl);
        zzbha.zzb("/untrackActiveViewUnit", this.zzffm);
    }

    public final void zzafc() {
        this.zzffj.zzd("/updateActiveView", this.zzffl);
        this.zzffj.zzd("/untrackActiveViewUnit", this.zzffm);
    }

    private final boolean zzl(@Nullable Map<String, String> map) {
        if (map == null) {
            return false;
        }
        String str = (String) map.get("hashCode");
        if (TextUtils.isEmpty(str) || str.equals(this.zzbsx) == null) {
            return false;
        }
        return true;
    }
}
