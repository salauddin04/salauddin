package com.google.android.gms.internal.measurement;

import android.os.RemoteException;

final class zzah extends zza {
    private final /* synthetic */ zzaa zzar;

    zzah(zzaa zzaa) {
        this.zzar = zzaa;
        super(zzaa);
    }

    final void zzl() throws RemoteException {
        this.zzar.zzan.resetAnalyticsData(this.timestamp);
    }
}
