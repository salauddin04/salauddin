package com.google.android.gms.internal.measurement;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Process;
import android.os.UserManager;
import android.support.annotation.RequiresApi;
import android.support.annotation.VisibleForTesting;
import android.util.Log;

public class zzck {
    private static volatile UserManager zzzg;
    private static volatile boolean zzzh = (zzji() ^ 1);

    private zzck() {
    }

    public static boolean zzji() {
        return VERSION.SDK_INT >= 24;
    }

    public static boolean isUserUnlocked(Context context) {
        if (zzji()) {
            if (zzn(context) == null) {
                return null;
            }
        }
        return true;
    }

    @TargetApi(24)
    @RequiresApi(24)
    private static boolean zzn(Context context) {
        boolean z = zzzh;
        if (!z) {
            boolean z2 = z;
            int i = 1;
            while (i <= 2) {
                UserManager zzo = zzo(context);
                if (zzo == null) {
                    zzzh = true;
                    return true;
                }
                try {
                    if (!zzo.isUserUnlocked()) {
                        if (zzo.isUserRunning(Process.myUserHandle())) {
                            z2 = false;
                            zzzh = z2;
                            z = z2;
                            if (z) {
                                zzzg = null;
                            }
                        }
                    }
                    z2 = true;
                    zzzh = z2;
                    z = z2;
                    if (z) {
                        zzzg = null;
                    }
                } catch (Throwable e) {
                    Log.w("DirectBootUtils", "Failed to check if user is unlocked", e);
                    zzzg = null;
                    i++;
                }
            }
            z = z2;
            if (z) {
                zzzg = null;
            }
        }
        return z;
    }

    @VisibleForTesting
    @TargetApi(24)
    @RequiresApi(24)
    private static UserManager zzo(Context context) {
        UserManager userManager = zzzg;
        if (userManager == null) {
            synchronized (zzck.class) {
                userManager = zzzg;
                if (userManager == null) {
                    UserManager userManager2 = (UserManager) context.getSystemService(UserManager.class);
                    zzzg = userManager2;
                    userManager = userManager2;
                }
            }
        }
        return userManager;
    }
}
