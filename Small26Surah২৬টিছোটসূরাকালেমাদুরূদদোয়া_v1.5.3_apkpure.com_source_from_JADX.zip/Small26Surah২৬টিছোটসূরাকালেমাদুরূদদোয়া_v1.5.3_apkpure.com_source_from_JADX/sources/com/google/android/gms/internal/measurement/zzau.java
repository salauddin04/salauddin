package com.google.android.gms.internal.measurement;

import android.os.Bundle;
import android.os.RemoteException;

final class zzau extends zza {
    private final /* synthetic */ zzaa zzar;
    private final /* synthetic */ zzm zzaw;
    private final /* synthetic */ Bundle zzbj;

    zzau(zzaa zzaa, Bundle bundle, zzm zzm) {
        this.zzar = zzaa;
        this.zzbj = bundle;
        this.zzaw = zzm;
        super(zzaa);
    }

    final void zzl() throws RemoteException {
        this.zzar.zzan.performAction(this.zzbj, this.zzaw, this.timestamp);
    }

    protected final void zzm() {
        this.zzaw.zzb(null);
    }
}
