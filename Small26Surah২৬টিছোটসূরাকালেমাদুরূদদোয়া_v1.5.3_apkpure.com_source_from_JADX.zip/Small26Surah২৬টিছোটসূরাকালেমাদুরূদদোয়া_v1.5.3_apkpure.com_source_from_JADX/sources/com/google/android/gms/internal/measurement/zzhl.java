package com.google.android.gms.internal.measurement;

final class zzhl implements zzgf {
    public final int zzns() {
        throw new NoSuchMethodError();
    }

    public final boolean zznt() {
        throw new NoSuchMethodError();
    }

    public final zzgh zznu() {
        throw new NoSuchMethodError();
    }
}
