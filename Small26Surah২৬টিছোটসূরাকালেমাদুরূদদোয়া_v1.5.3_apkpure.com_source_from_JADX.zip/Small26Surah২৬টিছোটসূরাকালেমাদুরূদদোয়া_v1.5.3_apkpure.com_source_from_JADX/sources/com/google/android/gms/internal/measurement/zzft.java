package com.google.android.gms.internal.measurement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class zzft extends zzfr {
    private static final Class<?> zzaim = Collections.unmodifiableList(Collections.emptyList()).getClass();

    private zzft() {
        super();
    }

    final <L> List<L> zza(Object obj, long j) {
        return zza(obj, j, 10);
    }

    final void zzb(Object obj, long j) {
        Object zznh;
        List list = (List) zzhw.zzp(obj, j);
        if (list instanceof zzfq) {
            zznh = ((zzfq) list).zznh();
        } else if (!zzaim.isAssignableFrom(list.getClass())) {
            if ((list instanceof zzgt) && (list instanceof zzfg)) {
                zzfg zzfg = (zzfg) list;
                if (zzfg.zzjy() != null) {
                    zzfg.zzjz();
                }
                return;
            }
            zznh = Collections.unmodifiableList(list);
        } else {
            return;
        }
        zzhw.zza(obj, j, zznh);
    }

    private static <L> List<L> zza(Object obj, long j, int i) {
        List<L> zzc = zzc(obj, j);
        Object zzfp;
        if (zzc.isEmpty()) {
            if (zzc instanceof zzfq) {
                zzfp = new zzfp(i);
            } else if ((zzc instanceof zzgt) && (zzc instanceof zzfg)) {
                zzfp = ((zzfg) zzc).zzq(i);
            } else {
                zzfp = new ArrayList(i);
            }
            zzhw.zza(obj, j, zzfp);
            return zzfp;
        }
        ArrayList arrayList;
        if (zzaim.isAssignableFrom(zzc.getClass())) {
            arrayList = new ArrayList(zzc.size() + i);
            arrayList.addAll(zzc);
            zzhw.zza(obj, j, (Object) arrayList);
        } else if (zzc instanceof zzht) {
            Object zzfp2 = new zzfp(zzc.size() + i);
            zzfp2.addAll((zzht) zzc);
            zzhw.zza(obj, j, zzfp2);
        } else if (!(zzc instanceof zzgt) || !(zzc instanceof zzfg)) {
            return zzc;
        } else {
            zzfg zzfg = (zzfg) zzc;
            if (zzfg.zzjy()) {
                return zzc;
            }
            zzfp = zzfg.zzq(zzc.size() + i);
            zzhw.zza(obj, j, zzfp);
            return zzfp;
        }
        return arrayList;
    }

    final <E> void zza(Object obj, Object obj2, long j) {
        obj2 = zzc(obj2, j);
        List zza = zza(obj, j, obj2.size());
        int size = zza.size();
        int size2 = obj2.size();
        if (size > 0 && size2 > 0) {
            zza.addAll(obj2);
        }
        if (size > 0) {
            obj2 = zza;
        }
        zzhw.zza(obj, j, obj2);
    }

    private static <E> List<E> zzc(Object obj, long j) {
        return (List) zzhw.zzp(obj, j);
    }
}
