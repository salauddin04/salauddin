package com.google.android.gms.internal.measurement;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

class zzhb<K extends Comparable<K>, V> extends AbstractMap<K, V> {
    private boolean zzadr;
    private final int zzakb;
    private List<zzhi> zzakc;
    private Map<K, V> zzakd;
    private volatile zzhk zzake;
    private Map<K, V> zzakf;
    private volatile zzhe zzakg;

    static <FieldDescriptorType extends zzes<FieldDescriptorType>> zzhb<FieldDescriptorType, Object> zzbe(int i) {
        return new zzhc(i);
    }

    private zzhb(int i) {
        this.zzakb = i;
        this.zzakc = Collections.emptyList();
        this.zzakd = Collections.emptyMap();
        this.zzakf = Collections.emptyMap();
    }

    public void zzjz() {
        if (!this.zzadr) {
            Map emptyMap;
            if (this.zzakd.isEmpty()) {
                emptyMap = Collections.emptyMap();
            } else {
                emptyMap = Collections.unmodifiableMap(this.zzakd);
            }
            this.zzakd = emptyMap;
            if (this.zzakf.isEmpty()) {
                emptyMap = Collections.emptyMap();
            } else {
                emptyMap = Collections.unmodifiableMap(this.zzakf);
            }
            this.zzakf = emptyMap;
            this.zzadr = true;
        }
    }

    public final boolean isImmutable() {
        return this.zzadr;
    }

    public final int zzoi() {
        return this.zzakc.size();
    }

    public final Entry<K, V> zzbf(int i) {
        return (Entry) this.zzakc.get(i);
    }

    public final Iterable<Entry<K, V>> zzoj() {
        if (this.zzakd.isEmpty()) {
            return zzhf.zzoo();
        }
        return this.zzakd.entrySet();
    }

    public int size() {
        return this.zzakc.size() + this.zzakd.size();
    }

    public boolean containsKey(Object obj) {
        Comparable comparable = (Comparable) obj;
        if (zza(comparable) < 0) {
            if (this.zzakd.containsKey(comparable) == null) {
                return null;
            }
        }
        return true;
    }

    public V get(Object obj) {
        Comparable comparable = (Comparable) obj;
        int zza = zza(comparable);
        if (zza >= 0) {
            return ((zzhi) this.zzakc.get(zza)).getValue();
        }
        return this.zzakd.get(comparable);
    }

    public final V zza(K k, V v) {
        zzol();
        int zza = zza((Comparable) k);
        if (zza >= 0) {
            return ((zzhi) this.zzakc.get(zza)).setValue(v);
        }
        zzol();
        if (this.zzakc.isEmpty() && !(this.zzakc instanceof ArrayList)) {
            this.zzakc = new ArrayList(this.zzakb);
        }
        zza = -(zza + 1);
        if (zza >= this.zzakb) {
            return zzom().put(k, v);
        }
        int size = this.zzakc.size();
        int i = this.zzakb;
        if (size == i) {
            zzhi zzhi = (zzhi) this.zzakc.remove(i - 1);
            zzom().put((Comparable) zzhi.getKey(), zzhi.getValue());
        }
        this.zzakc.add(zza, new zzhi(this, k, v));
        return null;
    }

    public void clear() {
        zzol();
        if (!this.zzakc.isEmpty()) {
            this.zzakc.clear();
        }
        if (!this.zzakd.isEmpty()) {
            this.zzakd.clear();
        }
    }

    public V remove(Object obj) {
        zzol();
        Comparable comparable = (Comparable) obj;
        int zza = zza(comparable);
        if (zza >= 0) {
            return zzbg(zza);
        }
        if (this.zzakd.isEmpty()) {
            return null;
        }
        return this.zzakd.remove(comparable);
    }

    private final V zzbg(int i) {
        zzol();
        i = ((zzhi) this.zzakc.remove(i)).getValue();
        if (!this.zzakd.isEmpty()) {
            Iterator it = zzom().entrySet().iterator();
            this.zzakc.add(new zzhi(this, (Entry) it.next()));
            it.remove();
        }
        return i;
    }

    private final int zza(K k) {
        int compareTo;
        int size = this.zzakc.size() - 1;
        if (size >= 0) {
            compareTo = k.compareTo((Comparable) ((zzhi) this.zzakc.get(size)).getKey());
            if (compareTo > 0) {
                return -(size + 2);
            }
            if (compareTo == 0) {
                return size;
            }
        }
        compareTo = 0;
        while (compareTo <= size) {
            int i = (compareTo + size) / 2;
            int compareTo2 = k.compareTo((Comparable) ((zzhi) this.zzakc.get(i)).getKey());
            if (compareTo2 < 0) {
                size = i - 1;
            } else if (compareTo2 <= 0) {
                return i;
            } else {
                compareTo = i + 1;
            }
        }
        return -(compareTo + 1);
    }

    public Set<Entry<K, V>> entrySet() {
        if (this.zzake == null) {
            this.zzake = new zzhk();
        }
        return this.zzake;
    }

    final Set<Entry<K, V>> zzok() {
        if (this.zzakg == null) {
            this.zzakg = new zzhe();
        }
        return this.zzakg;
    }

    private final void zzol() {
        if (this.zzadr) {
            throw new UnsupportedOperationException();
        }
    }

    private final SortedMap<K, V> zzom() {
        zzol();
        if (this.zzakd.isEmpty() && !(this.zzakd instanceof TreeMap)) {
            this.zzakd = new TreeMap();
            this.zzakf = ((TreeMap) this.zzakd).descendingMap();
        }
        return (SortedMap) this.zzakd;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzhb)) {
            return super.equals(obj);
        }
        zzhb zzhb = (zzhb) obj;
        int size = size();
        if (size != zzhb.size()) {
            return false;
        }
        int zzoi = zzoi();
        if (zzoi != zzhb.zzoi()) {
            return entrySet().equals(zzhb.entrySet());
        }
        for (int i = 0; i < zzoi; i++) {
            if (!zzbf(i).equals(zzhb.zzbf(i))) {
                return false;
            }
        }
        if (zzoi != size) {
            return this.zzakd.equals(zzhb.zzakd);
        }
        return true;
    }

    public int hashCode() {
        int i = 0;
        for (int i2 = 0; i2 < zzoi(); i2++) {
            i += ((zzhi) this.zzakc.get(i2)).hashCode();
        }
        return this.zzakd.size() > 0 ? i + this.zzakd.hashCode() : i;
    }

    public /* synthetic */ Object put(Object obj, Object obj2) {
        return zza((Comparable) obj, obj2);
    }
}
