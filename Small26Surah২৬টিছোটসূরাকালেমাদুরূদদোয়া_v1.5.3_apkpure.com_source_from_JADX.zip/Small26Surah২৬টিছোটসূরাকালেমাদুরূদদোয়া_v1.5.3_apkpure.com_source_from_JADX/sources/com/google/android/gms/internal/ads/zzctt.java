package com.google.android.gms.internal.ads;

import android.content.pm.PackageInfo;

public final class zzctt implements zzdth<zzcto> {
    private final zzdtt<zzaxc> zzerl;
    private final zzdtt<zzbbm> zzfgg;
    private final zzdtt<zzcxu> zzfhq;
    private final zzdtt<PackageInfo> zzfwk;

    public zzctt(zzdtt<zzbbm> zzdtt, zzdtt<zzcxu> zzdtt2, zzdtt<PackageInfo> zzdtt3, zzdtt<zzaxc> zzdtt4) {
        this.zzfgg = zzdtt;
        this.zzfhq = zzdtt2;
        this.zzfwk = zzdtt3;
        this.zzerl = zzdtt4;
    }

    public final /* synthetic */ Object get() {
        return new zzcto((zzbbm) this.zzfgg.get(), (zzcxu) this.zzfhq.get(), (PackageInfo) this.zzfwk.get(), (zzaxc) this.zzerl.get());
    }
}
