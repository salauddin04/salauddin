package com.google.android.gms.internal.measurement;

public final class zzfi extends zzfh {
    public zzfi(String str) {
        super(str);
    }
}
