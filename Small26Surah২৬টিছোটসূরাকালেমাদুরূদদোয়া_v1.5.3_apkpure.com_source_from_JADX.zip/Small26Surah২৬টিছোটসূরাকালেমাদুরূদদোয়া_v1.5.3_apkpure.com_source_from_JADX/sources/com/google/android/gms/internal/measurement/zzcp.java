package com.google.android.gms.internal.measurement;

import android.support.annotation.Nullable;

interface zzcp {
    @Nullable
    Object zzca(String str);
}
