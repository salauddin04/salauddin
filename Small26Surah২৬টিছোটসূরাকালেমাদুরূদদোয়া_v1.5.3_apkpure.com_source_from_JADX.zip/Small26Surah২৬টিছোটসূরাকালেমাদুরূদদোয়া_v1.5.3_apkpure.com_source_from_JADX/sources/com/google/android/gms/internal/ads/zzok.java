package com.google.android.gms.internal.ads;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class zzok extends zzoj {
    public final List<zzol> zzama = new ArrayList();
    public final List<zzok> zzamb = new ArrayList();
    public final long zzbdz;

    public zzok(int i, long j) {
        super(i);
        this.zzbdz = j;
    }

    public final zzol zzay(int i) {
        int size = this.zzama.size();
        for (int i2 = 0; i2 < size; i2++) {
            zzol zzol = (zzol) this.zzama.get(i2);
            if (zzol.type == i) {
                return zzol;
            }
        }
        return 0;
    }

    public final zzok zzaz(int i) {
        int size = this.zzamb.size();
        for (int i2 = 0; i2 < size; i2++) {
            zzok zzok = (zzok) this.zzamb.get(i2);
            if (zzok.type == i) {
                return zzok;
            }
        }
        return 0;
    }

    public final String toString() {
        String zzu = zzoj.zzu(this.type);
        String arrays = Arrays.toString(this.zzama.toArray());
        String arrays2 = Arrays.toString(this.zzamb.toArray());
        StringBuilder stringBuilder = new StringBuilder(((String.valueOf(zzu).length() + 22) + String.valueOf(arrays).length()) + String.valueOf(arrays2).length());
        stringBuilder.append(zzu);
        stringBuilder.append(" leaves: ");
        stringBuilder.append(arrays);
        stringBuilder.append(" containers: ");
        stringBuilder.append(arrays2);
        return stringBuilder.toString();
    }
}
