package com.google.android.gms.internal.ads;

final /* synthetic */ class zzcpg implements Runnable {
    private final zzcpe zzgdi;

    zzcpg(zzcpe zzcpe) {
        this.zzgdi = zzcpe;
    }

    public final void run() {
        this.zzgdi.zzakz();
    }
}
