package com.google.android.gms.internal.base;

import android.graphics.Canvas;
import android.net.Uri;
import android.widget.ImageView;

public final class zaj extends ImageView {
    public static void zaa(Uri uri) {
        throw new NoSuchMethodError();
    }

    public static int zach() {
        throw new NoSuchMethodError();
    }

    public static void zai(int i) {
        throw new NoSuchMethodError();
    }

    protected final void onMeasure(int i, int i2) {
        throw new NoSuchMethodError();
    }

    protected final void onDraw(Canvas canvas) {
        throw new NoSuchMethodError();
    }
}
