package com.google.android.gms.internal.measurement;

import java.io.IOException;

public final class zzbz extends zzip<zzbz> {
    private static volatile zzbz[] zzwf;
    public zzcc zzwg;
    public zzca zzwh;
    public Boolean zzwi;
    public String zzwj;

    public static zzbz[] zzjc() {
        if (zzwf == null) {
            synchronized (zzit.zzanl) {
                if (zzwf == null) {
                    zzwf = new zzbz[0];
                }
            }
        }
        return zzwf;
    }

    public zzbz() {
        this.zzwg = null;
        this.zzwh = null;
        this.zzwi = null;
        this.zzwj = null;
        this.zzand = null;
        this.zzanm = -1;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzbz)) {
            return false;
        }
        zzbz zzbz = (zzbz) obj;
        zzcc zzcc = this.zzwg;
        if (zzcc == null) {
            if (zzbz.zzwg != null) {
                return false;
            }
        } else if (!zzcc.equals(zzbz.zzwg)) {
            return false;
        }
        zzca zzca = this.zzwh;
        if (zzca == null) {
            if (zzbz.zzwh != null) {
                return false;
            }
        } else if (!zzca.equals(zzbz.zzwh)) {
            return false;
        }
        Boolean bool = this.zzwi;
        if (bool == null) {
            if (zzbz.zzwi != null) {
                return false;
            }
        } else if (!bool.equals(zzbz.zzwi)) {
            return false;
        }
        String str = this.zzwj;
        if (str == null) {
            if (zzbz.zzwj != null) {
                return false;
            }
        } else if (!str.equals(zzbz.zzwj)) {
            return false;
        }
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                return this.zzand.equals(zzbz.zzand);
            }
        }
        if (zzbz.zzand != null) {
            if (zzbz.zzand.isEmpty() == null) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int i;
        int hashCode = getClass().getName().hashCode() + 527;
        zzcc zzcc = this.zzwg;
        hashCode *= 31;
        int i2 = 0;
        if (zzcc == null) {
            i = 0;
        } else {
            i = zzcc.hashCode();
        }
        hashCode += i;
        zzca zzca = this.zzwh;
        hashCode *= 31;
        if (zzca == null) {
            i = 0;
        } else {
            i = zzca.hashCode();
        }
        hashCode = (hashCode + i) * 31;
        Boolean bool = this.zzwi;
        hashCode = (hashCode + (bool == null ? 0 : bool.hashCode())) * 31;
        String str = this.zzwj;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                i2 = this.zzand.hashCode();
            }
        }
        return hashCode + i2;
    }

    public final void zza(zzin zzin) throws IOException {
        zziv zziv = this.zzwg;
        if (zziv != null) {
            zzin.zza(1, zziv);
        }
        zziv = this.zzwh;
        if (zziv != null) {
            zzin.zza(2, zziv);
        }
        Boolean bool = this.zzwi;
        if (bool != null) {
            zzin.zzb(3, bool.booleanValue());
        }
        String str = this.zzwj;
        if (str != null) {
            zzin.zzb(4, str);
        }
        super.zza(zzin);
    }

    protected final int zzja() {
        int zzja = super.zzja();
        zziv zziv = this.zzwg;
        if (zziv != null) {
            zzja += zzin.zzb(1, zziv);
        }
        zziv = this.zzwh;
        if (zziv != null) {
            zzja += zzin.zzb(2, zziv);
        }
        Boolean bool = this.zzwi;
        if (bool != null) {
            bool.booleanValue();
            zzja += zzin.zzaj(3) + 1;
        }
        String str = this.zzwj;
        return str != null ? zzja + zzin.zzc(4, str) : zzja;
    }

    public final /* synthetic */ zziv zza(zzim zzim) throws IOException {
        while (true) {
            int zzkj = zzim.zzkj();
            if (zzkj == 0) {
                return this;
            }
            if (zzkj == 10) {
                if (this.zzwg == null) {
                    this.zzwg = new zzcc();
                }
                zzim.zza(this.zzwg);
            } else if (zzkj == 18) {
                if (this.zzwh == null) {
                    this.zzwh = new zzca();
                }
                zzim.zza(this.zzwh);
            } else if (zzkj == 24) {
                this.zzwi = Boolean.valueOf(zzim.zzkp());
            } else if (zzkj == 34) {
                this.zzwj = zzim.readString();
            } else if (!super.zza(zzim, zzkj)) {
                return this;
            }
        }
    }
}
