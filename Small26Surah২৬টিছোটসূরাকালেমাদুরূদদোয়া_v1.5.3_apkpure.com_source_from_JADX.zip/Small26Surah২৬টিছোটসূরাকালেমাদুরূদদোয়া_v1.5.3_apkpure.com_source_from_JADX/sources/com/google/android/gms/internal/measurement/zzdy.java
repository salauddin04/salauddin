package com.google.android.gms.internal.measurement;

abstract class zzdy extends zzdp {
    zzdy() {
    }

    abstract boolean zza(zzdp zzdp, int i, int i2);
}
