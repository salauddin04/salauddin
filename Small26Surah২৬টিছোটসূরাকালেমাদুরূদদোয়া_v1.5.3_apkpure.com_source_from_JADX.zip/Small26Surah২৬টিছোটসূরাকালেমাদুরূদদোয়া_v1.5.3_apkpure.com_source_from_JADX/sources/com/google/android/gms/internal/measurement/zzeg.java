package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class zzeg extends zzdo {
    private static final Logger logger = Logger.getLogger(zzeg.class.getName());
    private static final boolean zzacv = zzhw.zzou();
    zzei zzacw = this;

    public static class zzc extends IOException {
        zzc() {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.");
        }

        zzc(String str) {
            str = String.valueOf(str);
            String str2 = "CodedOutputStream was writing to a flat byte array and ran out of space.: ";
            super(str.length() != 0 ? str2.concat(str) : new String(str2));
        }

        zzc(Throwable th) {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.", th);
        }

        zzc(String str, Throwable th) {
            str = String.valueOf(str);
            String str2 = "CodedOutputStream was writing to a flat byte array and ran out of space.: ";
            super(str.length() != 0 ? str2.concat(str) : new String(str2), th);
        }
    }

    static class zza extends zzeg {
        private final byte[] buffer;
        private final int limit;
        private final int offset;
        private int position;

        zza(byte[] bArr, int i, int i2) {
            super();
            if (bArr != null) {
                int i3 = i + i2;
                if (((i | i2) | (bArr.length - i3)) >= 0) {
                    this.buffer = bArr;
                    this.offset = i;
                    this.position = i;
                    this.limit = i3;
                    return;
                }
                throw new IllegalArgumentException(String.format("Array range is invalid. Buffer.length=%d, offset=%d, length=%d", new Object[]{Integer.valueOf(bArr.length), Integer.valueOf(i), Integer.valueOf(i2)}));
            }
            throw new NullPointerException("buffer");
        }

        public void flush() {
        }

        public final void zzag(int r5) throws java.io.IOException {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:19:0x007f in {7, 8, 13, 15, 18} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
            /*
            r4 = this;
            r0 = com.google.android.gms.internal.measurement.zzeg.zzacv;
            if (r0 == 0) goto L_0x0034;
        L_0x0006:
            r0 = r4.zzlj();
            r1 = 10;
            if (r0 < r1) goto L_0x0034;
        L_0x000e:
            r0 = r5 & -128;
            if (r0 != 0) goto L_0x0020;
        L_0x0012:
            r0 = r4.buffer;
            r1 = r4.position;
            r2 = r1 + 1;
            r4.position = r2;
            r1 = (long) r1;
            r5 = (byte) r5;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r1, r5);
            return;
        L_0x0020:
            r0 = r4.buffer;
            r1 = r4.position;
            r2 = r1 + 1;
            r4.position = r2;
            r1 = (long) r1;
            r3 = r5 & 127;
            r3 = r3 | 128;
            r3 = (byte) r3;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r1, r3);
            r5 = r5 >>> 7;
            goto L_0x000e;
        L_0x0034:
            r0 = r5 & -128;
            if (r0 != 0) goto L_0x0044;
        L_0x0038:
            r0 = r4.buffer;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r1 = r4.position;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r2 = r1 + 1;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r4.position = r2;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r5 = (byte) r5;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r0[r1] = r5;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            return;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
        L_0x0044:
            r0 = r4.buffer;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r1 = r4.position;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r2 = r1 + 1;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r4.position = r2;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r2 = r5 & 127;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r2 = r2 | 128;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r2 = (byte) r2;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r0[r1] = r2;	 Catch:{ IndexOutOfBoundsException -> 0x0056 }
            r5 = r5 >>> 7;
            goto L_0x0034;
        L_0x0056:
            r5 = move-exception;
            r0 = new com.google.android.gms.internal.measurement.zzeg$zzc;
            r1 = 3;
            r1 = new java.lang.Object[r1];
            r2 = 0;
            r3 = r4.position;
            r3 = java.lang.Integer.valueOf(r3);
            r1[r2] = r3;
            r2 = r4.limit;
            r2 = java.lang.Integer.valueOf(r2);
            r3 = 1;
            r1[r3] = r2;
            r2 = 2;
            r3 = java.lang.Integer.valueOf(r3);
            r1[r2] = r3;
            r2 = "Pos: %d, limit: %d, len: %d";
            r1 = java.lang.String.format(r2, r1);
            r0.<init>(r1, r5);
            throw r0;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzeg.zza.zzag(int):void");
        }

        public final void zzaq(long r10) throws java.io.IOException {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:19:0x008a in {7, 8, 13, 15, 18} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
            /*
            r9 = this;
            r0 = com.google.android.gms.internal.measurement.zzeg.zzacv;
            r1 = 7;
            r2 = 0;
            r4 = -128; // 0xffffffffffffff80 float:NaN double:NaN;
            if (r0 == 0) goto L_0x003c;
        L_0x000b:
            r0 = r9.zzlj();
            r6 = 10;
            if (r0 < r6) goto L_0x003c;
        L_0x0013:
            r6 = r10 & r4;
            r0 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1));
            if (r0 != 0) goto L_0x0028;
        L_0x0019:
            r0 = r9.buffer;
            r1 = r9.position;
            r2 = r1 + 1;
            r9.position = r2;
            r1 = (long) r1;
            r11 = (int) r10;
            r10 = (byte) r11;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r1, r10);
            return;
        L_0x0028:
            r0 = r9.buffer;
            r6 = r9.position;
            r7 = r6 + 1;
            r9.position = r7;
            r6 = (long) r6;
            r8 = (int) r10;
            r8 = r8 & 127;
            r8 = r8 | 128;
            r8 = (byte) r8;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r6, r8);
            r10 = r10 >>> r1;
            goto L_0x0013;
        L_0x003c:
            r6 = r10 & r4;
            r0 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1));
            if (r0 != 0) goto L_0x004f;
        L_0x0042:
            r0 = r9.buffer;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r1 = r9.position;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r2 = r1 + 1;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r9.position = r2;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r11 = (int) r10;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r10 = (byte) r11;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r0[r1] = r10;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            return;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
        L_0x004f:
            r0 = r9.buffer;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r6 = r9.position;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r7 = r6 + 1;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r9.position = r7;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r7 = (int) r10;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r7 = r7 & 127;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r7 = r7 | 128;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r7 = (byte) r7;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r0[r6] = r7;	 Catch:{ IndexOutOfBoundsException -> 0x0061 }
            r10 = r10 >>> r1;
            goto L_0x003c;
        L_0x0061:
            r10 = move-exception;
            r11 = new com.google.android.gms.internal.measurement.zzeg$zzc;
            r0 = 3;
            r0 = new java.lang.Object[r0];
            r1 = 0;
            r2 = r9.position;
            r2 = java.lang.Integer.valueOf(r2);
            r0[r1] = r2;
            r1 = r9.limit;
            r1 = java.lang.Integer.valueOf(r1);
            r2 = 1;
            r0[r2] = r1;
            r1 = 2;
            r2 = java.lang.Integer.valueOf(r2);
            r0[r1] = r2;
            r1 = "Pos: %d, limit: %d, len: %d";
            r0 = java.lang.String.format(r1, r0);
            r11.<init>(r0, r10);
            throw r11;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzeg.zza.zzaq(long):void");
        }

        public final void zzb(int i, int i2) throws IOException {
            zzag((i << 3) | i2);
        }

        public final void zzc(int i, int i2) throws IOException {
            zzb(i, 0);
            zzaf(i2);
        }

        public final void zzd(int i, int i2) throws IOException {
            zzb(i, 0);
            zzag(i2);
        }

        public final void zzf(int i, int i2) throws IOException {
            zzb(i, 5);
            zzai(i2);
        }

        public final void zza(int i, long j) throws IOException {
            zzb(i, 0);
            zzaq(j);
        }

        public final void zzc(int i, long j) throws IOException {
            zzb(i, 1);
            zzas(j);
        }

        public final void zzb(int i, boolean z) throws IOException {
            zzb(i, 0);
            zzc((byte) z);
        }

        public final void zzb(int i, String str) throws IOException {
            zzb(i, 2);
            zzco(str);
        }

        public final void zza(int i, zzdp zzdp) throws IOException {
            zzb(i, 2);
            zza(zzdp);
        }

        public final void zza(zzdp zzdp) throws IOException {
            zzag(zzdp.size());
            zzdp.zza((zzdo) this);
        }

        public final void zze(byte[] bArr, int i, int i2) throws IOException {
            zzag(i2);
            write(bArr, 0, i2);
        }

        public final void zza(int i, zzgh zzgh) throws IOException {
            zzb(i, 2);
            zzb(zzgh);
        }

        final void zza(int i, zzgh zzgh, zzgy zzgy) throws IOException {
            zzb(i, 2);
            zzdg zzdg = (zzdg) zzgh;
            int zzjw = zzdg.zzjw();
            if (zzjw == -1) {
                zzjw = zzgy.zzs(zzdg);
                zzdg.zzn(zzjw);
            }
            zzag(zzjw);
            zzgy.zza(zzgh, this.zzacw);
        }

        public final void zzb(int i, zzgh zzgh) throws IOException {
            zzb(1, 3);
            zzd(2, i);
            zza(3, zzgh);
            zzb(1, 4);
        }

        public final void zzb(int i, zzdp zzdp) throws IOException {
            zzb(1, 3);
            zzd(2, i);
            zza(3, zzdp);
            zzb(1, 4);
        }

        public final void zzb(zzgh zzgh) throws IOException {
            zzag(zzgh.zzly());
            zzgh.zzb(this);
        }

        final void zza(zzgh zzgh, zzgy zzgy) throws IOException {
            zzdg zzdg = (zzdg) zzgh;
            int zzjw = zzdg.zzjw();
            if (zzjw == -1) {
                zzjw = zzgy.zzs(zzdg);
                zzdg.zzn(zzjw);
            }
            zzag(zzjw);
            zzgy.zza(zzgh, this.zzacw);
        }

        public final void zzc(byte b) throws IOException {
            try {
                byte[] bArr = this.buffer;
                int i = this.position;
                this.position = i + 1;
                bArr[i] = b;
            } catch (byte b2) {
                throw new zzc(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Integer.valueOf(this.position), Integer.valueOf(this.limit), Integer.valueOf(1)}), b2);
            }
        }

        public final void zzaf(int i) throws IOException {
            if (i >= 0) {
                zzag(i);
            } else {
                zzaq((long) i);
            }
        }

        public final void zzai(int i) throws IOException {
            try {
                byte[] bArr = this.buffer;
                int i2 = this.position;
                this.position = i2 + 1;
                bArr[i2] = (byte) i;
                bArr = this.buffer;
                i2 = this.position;
                this.position = i2 + 1;
                bArr[i2] = (byte) (i >> 8);
                bArr = this.buffer;
                i2 = this.position;
                this.position = i2 + 1;
                bArr[i2] = (byte) (i >> 16);
                bArr = this.buffer;
                i2 = this.position;
                this.position = i2 + 1;
                bArr[i2] = (byte) (i >>> 24);
            } catch (int i3) {
                throw new zzc(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Integer.valueOf(this.position), Integer.valueOf(this.limit), Integer.valueOf(1)}), i3);
            }
        }

        public final void zzas(long j) throws IOException {
            try {
                byte[] bArr = this.buffer;
                int i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) j);
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 8));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 16));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 24));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 32));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 40));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 48));
                bArr = this.buffer;
                i = this.position;
                this.position = i + 1;
                bArr[i] = (byte) ((int) (j >> 56));
            } catch (long j2) {
                throw new zzc(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Integer.valueOf(this.position), Integer.valueOf(this.limit), Integer.valueOf(1)}), j2);
            }
        }

        public final void write(byte[] bArr, int i, int i2) throws IOException {
            try {
                System.arraycopy(bArr, i, this.buffer, this.position, i2);
                this.position += i2;
            } catch (byte[] bArr2) {
                throw new zzc(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Integer.valueOf(this.position), Integer.valueOf(this.limit), Integer.valueOf(i2)}), bArr2);
            }
        }

        public final void zza(byte[] bArr, int i, int i2) throws IOException {
            write(bArr, i, i2);
        }

        public final void zzco(String str) throws IOException {
            int i = this.position;
            try {
                int zzal = zzeg.zzal(str.length() * 3);
                int zzal2 = zzeg.zzal(str.length());
                if (zzal2 == zzal) {
                    this.position = i + zzal2;
                    zzal = zzhy.zza(str, this.buffer, this.position, zzlj());
                    this.position = i;
                    zzag((zzal - i) - zzal2);
                    this.position = zzal;
                    return;
                }
                zzag(zzhy.zza(str));
                this.position = zzhy.zza(str, this.buffer, this.position, zzlj());
            } catch (zzic e) {
                this.position = i;
                zza(str, e);
            } catch (Throwable e2) {
                throw new zzc(e2);
            }
        }

        public final int zzlj() {
            return this.limit - this.position;
        }

        public final int zzlm() {
            return this.position - this.offset;
        }
    }

    static final class zzd extends zzeg {
        private final int zzacy;
        private final ByteBuffer zzacz;
        private final ByteBuffer zzada;

        zzd(ByteBuffer byteBuffer) {
            super();
            this.zzacz = byteBuffer;
            this.zzada = byteBuffer.duplicate().order(ByteOrder.LITTLE_ENDIAN);
            this.zzacy = byteBuffer.position();
        }

        public final void zzag(int r3) throws java.io.IOException {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:10:0x001f in {4, 6, 9} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
            /*
            r2 = this;
        L_0x0000:
            r0 = r3 & -128;
            if (r0 != 0) goto L_0x000b;
        L_0x0004:
            r0 = r2.zzada;	 Catch:{ BufferOverflowException -> 0x0018 }
            r3 = (byte) r3;	 Catch:{ BufferOverflowException -> 0x0018 }
            r0.put(r3);	 Catch:{ BufferOverflowException -> 0x0018 }
            return;	 Catch:{ BufferOverflowException -> 0x0018 }
        L_0x000b:
            r0 = r2.zzada;	 Catch:{ BufferOverflowException -> 0x0018 }
            r1 = r3 & 127;	 Catch:{ BufferOverflowException -> 0x0018 }
            r1 = r1 | 128;	 Catch:{ BufferOverflowException -> 0x0018 }
            r1 = (byte) r1;	 Catch:{ BufferOverflowException -> 0x0018 }
            r0.put(r1);	 Catch:{ BufferOverflowException -> 0x0018 }
            r3 = r3 >>> 7;
            goto L_0x0000;
        L_0x0018:
            r3 = move-exception;
            r0 = new com.google.android.gms.internal.measurement.zzeg$zzc;
            r0.<init>(r3);
            throw r0;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzeg.zzd.zzag(int):void");
        }

        public final void zzaq(long r6) throws java.io.IOException {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:10:0x0026 in {4, 6, 9} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
            /*
            r5 = this;
        L_0x0000:
            r0 = -128; // 0xffffffffffffff80 float:NaN double:NaN;
            r0 = r0 & r6;
            r2 = 0;
            r4 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
            if (r4 != 0) goto L_0x0011;
        L_0x0009:
            r0 = r5.zzada;	 Catch:{ BufferOverflowException -> 0x001f }
            r7 = (int) r6;	 Catch:{ BufferOverflowException -> 0x001f }
            r6 = (byte) r7;	 Catch:{ BufferOverflowException -> 0x001f }
            r0.put(r6);	 Catch:{ BufferOverflowException -> 0x001f }
            return;	 Catch:{ BufferOverflowException -> 0x001f }
        L_0x0011:
            r0 = r5.zzada;	 Catch:{ BufferOverflowException -> 0x001f }
            r1 = (int) r6;	 Catch:{ BufferOverflowException -> 0x001f }
            r1 = r1 & 127;	 Catch:{ BufferOverflowException -> 0x001f }
            r1 = r1 | 128;	 Catch:{ BufferOverflowException -> 0x001f }
            r1 = (byte) r1;	 Catch:{ BufferOverflowException -> 0x001f }
            r0.put(r1);	 Catch:{ BufferOverflowException -> 0x001f }
            r0 = 7;
            r6 = r6 >>> r0;
            goto L_0x0000;
        L_0x001f:
            r6 = move-exception;
            r7 = new com.google.android.gms.internal.measurement.zzeg$zzc;
            r7.<init>(r6);
            throw r7;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzeg.zzd.zzaq(long):void");
        }

        public final void zzb(int i, int i2) throws IOException {
            zzag((i << 3) | i2);
        }

        public final void zzc(int i, int i2) throws IOException {
            zzb(i, 0);
            zzaf(i2);
        }

        public final void zzd(int i, int i2) throws IOException {
            zzb(i, 0);
            zzag(i2);
        }

        public final void zzf(int i, int i2) throws IOException {
            zzb(i, 5);
            zzai(i2);
        }

        public final void zza(int i, long j) throws IOException {
            zzb(i, 0);
            zzaq(j);
        }

        public final void zzc(int i, long j) throws IOException {
            zzb(i, 1);
            zzas(j);
        }

        public final void zzb(int i, boolean z) throws IOException {
            zzb(i, 0);
            zzc((byte) z);
        }

        public final void zzb(int i, String str) throws IOException {
            zzb(i, 2);
            zzco(str);
        }

        public final void zza(int i, zzdp zzdp) throws IOException {
            zzb(i, 2);
            zza(zzdp);
        }

        public final void zza(int i, zzgh zzgh) throws IOException {
            zzb(i, 2);
            zzb(zzgh);
        }

        final void zza(int i, zzgh zzgh, zzgy zzgy) throws IOException {
            zzb(i, 2);
            zza(zzgh, zzgy);
        }

        public final void zzb(int i, zzgh zzgh) throws IOException {
            zzb(1, 3);
            zzd(2, i);
            zza(3, zzgh);
            zzb(1, 4);
        }

        public final void zzb(int i, zzdp zzdp) throws IOException {
            zzb(1, 3);
            zzd(2, i);
            zza(3, zzdp);
            zzb(1, 4);
        }

        public final void zzb(zzgh zzgh) throws IOException {
            zzag(zzgh.zzly());
            zzgh.zzb(this);
        }

        final void zza(zzgh zzgh, zzgy zzgy) throws IOException {
            zzdg zzdg = (zzdg) zzgh;
            int zzjw = zzdg.zzjw();
            if (zzjw == -1) {
                zzjw = zzgy.zzs(zzdg);
                zzdg.zzn(zzjw);
            }
            zzag(zzjw);
            zzgy.zza(zzgh, this.zzacw);
        }

        public final void zzc(byte b) throws IOException {
            try {
                this.zzada.put(b);
            } catch (Throwable e) {
                throw new zzc(e);
            }
        }

        public final void zza(zzdp zzdp) throws IOException {
            zzag(zzdp.size());
            zzdp.zza((zzdo) this);
        }

        public final void zze(byte[] bArr, int i, int i2) throws IOException {
            zzag(i2);
            write(bArr, 0, i2);
        }

        public final void zzaf(int i) throws IOException {
            if (i >= 0) {
                zzag(i);
            } else {
                zzaq((long) i);
            }
        }

        public final void zzai(int i) throws IOException {
            try {
                this.zzada.putInt(i);
            } catch (Throwable e) {
                throw new zzc(e);
            }
        }

        public final void zzas(long j) throws IOException {
            try {
                this.zzada.putLong(j);
            } catch (Throwable e) {
                throw new zzc(e);
            }
        }

        public final void write(byte[] bArr, int i, int i2) throws IOException {
            try {
                this.zzada.put(bArr, i, i2);
            } catch (Throwable e) {
                throw new zzc(e);
            } catch (Throwable e2) {
                throw new zzc(e2);
            }
        }

        public final void zza(byte[] bArr, int i, int i2) throws IOException {
            write(bArr, i, i2);
        }

        public final void zzco(String str) throws IOException {
            int position = this.zzada.position();
            try {
                int zzal = zzeg.zzal(str.length() * 3);
                int zzal2 = zzeg.zzal(str.length());
                if (zzal2 == zzal) {
                    zzal = this.zzada.position() + zzal2;
                    this.zzada.position(zzal);
                    zzcq(str);
                    zzal2 = this.zzada.position();
                    this.zzada.position(position);
                    zzag(zzal2 - zzal);
                    this.zzada.position(zzal2);
                    return;
                }
                zzag(zzhy.zza(str));
                zzcq(str);
            } catch (zzic e) {
                this.zzada.position(position);
                zza(str, e);
            } catch (Throwable e2) {
                throw new zzc(e2);
            }
        }

        public final void flush() {
            this.zzacz.position(this.zzada.position());
        }

        public final int zzlj() {
            return this.zzada.remaining();
        }

        private final void zzcq(String str) throws IOException {
            try {
                zzhy.zza(str, this.zzada);
            } catch (Throwable e) {
                throw new zzc(e);
            }
        }
    }

    static final class zze extends zzeg {
        private final ByteBuffer zzacz;
        private final ByteBuffer zzada;
        private final long zzadb;
        private final long zzadc;
        private final long zzadd;
        private final long zzade = (this.zzadd - 10);
        private long zzadf = this.zzadc;

        zze(ByteBuffer byteBuffer) {
            super();
            this.zzacz = byteBuffer;
            this.zzada = byteBuffer.duplicate().order(ByteOrder.LITTLE_ENDIAN);
            this.zzadb = zzhw.zzb(byteBuffer);
            this.zzadc = this.zzadb + ((long) byteBuffer.position());
            this.zzadd = this.zzadb + ((long) byteBuffer.limit());
        }

        public final void zzag(int r8) throws java.io.IOException {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:16:0x0072 in {5, 6, 12, 13, 15} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
            /*
            r7 = this;
            r0 = r7.zzadf;
            r2 = r7.zzade;
            r4 = 1;
            r6 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
            if (r6 > 0) goto L_0x0029;
        L_0x000a:
            r0 = r8 & -128;
            if (r0 != 0) goto L_0x0018;
        L_0x000e:
            r0 = r7.zzadf;
            r4 = r4 + r0;
            r7.zzadf = r4;
            r8 = (byte) r8;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r8);
            return;
        L_0x0018:
            r0 = r7.zzadf;
            r2 = r0 + r4;
            r7.zzadf = r2;
            r2 = r8 & 127;
            r2 = r2 | 128;
            r2 = (byte) r2;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r2);
            r8 = r8 >>> 7;
            goto L_0x000a;
        L_0x0029:
            r0 = r7.zzadf;
            r2 = r7.zzadd;
            r6 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
            if (r6 >= 0) goto L_0x004c;
        L_0x0031:
            r2 = r8 & -128;
            if (r2 != 0) goto L_0x003d;
        L_0x0035:
            r4 = r4 + r0;
            r7.zzadf = r4;
            r8 = (byte) r8;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r8);
            return;
        L_0x003d:
            r2 = r0 + r4;
            r7.zzadf = r2;
            r2 = r8 & 127;
            r2 = r2 | 128;
            r2 = (byte) r2;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r2);
            r8 = r8 >>> 7;
            goto L_0x0029;
        L_0x004c:
            r8 = new com.google.android.gms.internal.measurement.zzeg$zzc;
            r2 = 3;
            r2 = new java.lang.Object[r2];
            r3 = 0;
            r0 = java.lang.Long.valueOf(r0);
            r2[r3] = r0;
            r0 = r7.zzadd;
            r0 = java.lang.Long.valueOf(r0);
            r1 = 1;
            r2[r1] = r0;
            r0 = 2;
            r1 = java.lang.Integer.valueOf(r1);
            r2[r0] = r1;
            r0 = "Pos: %d, limit: %d, len: %d";
            r0 = java.lang.String.format(r0, r2);
            r8.<init>(r0);
            throw r8;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzeg.zze.zzag(int):void");
        }

        public final void zzaq(long r13) throws java.io.IOException {
            /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:16:0x007d in {5, 6, 12, 13, 15} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
            /*
            r12 = this;
            r0 = r12.zzadf;
            r2 = r12.zzade;
            r4 = 7;
            r5 = 0;
            r7 = -128; // 0xffffffffffffff80 float:NaN double:NaN;
            r9 = 1;
            r11 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
            if (r11 > 0) goto L_0x0031;
        L_0x000f:
            r0 = r13 & r7;
            r2 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1));
            if (r2 != 0) goto L_0x0020;
        L_0x0015:
            r0 = r12.zzadf;
            r9 = r9 + r0;
            r12.zzadf = r9;
            r14 = (int) r13;
            r13 = (byte) r14;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r13);
            return;
        L_0x0020:
            r0 = r12.zzadf;
            r2 = r0 + r9;
            r12.zzadf = r2;
            r2 = (int) r13;
            r2 = r2 & 127;
            r2 = r2 | 128;
            r2 = (byte) r2;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r2);
            r13 = r13 >>> r4;
            goto L_0x000f;
        L_0x0031:
            r0 = r12.zzadf;
            r2 = r12.zzadd;
            r11 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
            if (r11 >= 0) goto L_0x0057;
        L_0x0039:
            r2 = r13 & r7;
            r11 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1));
            if (r11 != 0) goto L_0x0048;
        L_0x003f:
            r9 = r9 + r0;
            r12.zzadf = r9;
            r14 = (int) r13;
            r13 = (byte) r14;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r13);
            return;
        L_0x0048:
            r2 = r0 + r9;
            r12.zzadf = r2;
            r2 = (int) r13;
            r2 = r2 & 127;
            r2 = r2 | 128;
            r2 = (byte) r2;
            com.google.android.gms.internal.measurement.zzhw.zza(r0, r2);
            r13 = r13 >>> r4;
            goto L_0x0031;
        L_0x0057:
            r13 = new com.google.android.gms.internal.measurement.zzeg$zzc;
            r14 = 3;
            r14 = new java.lang.Object[r14];
            r2 = 0;
            r0 = java.lang.Long.valueOf(r0);
            r14[r2] = r0;
            r0 = r12.zzadd;
            r0 = java.lang.Long.valueOf(r0);
            r1 = 1;
            r14[r1] = r0;
            r0 = 2;
            r1 = java.lang.Integer.valueOf(r1);
            r14[r0] = r1;
            r0 = "Pos: %d, limit: %d, len: %d";
            r14 = java.lang.String.format(r0, r14);
            r13.<init>(r14);
            throw r13;
            return;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzeg.zze.zzaq(long):void");
        }

        public final void zzb(int i, int i2) throws IOException {
            zzag((i << 3) | i2);
        }

        public final void zzc(int i, int i2) throws IOException {
            zzb(i, 0);
            zzaf(i2);
        }

        public final void zzd(int i, int i2) throws IOException {
            zzb(i, 0);
            zzag(i2);
        }

        public final void zzf(int i, int i2) throws IOException {
            zzb(i, 5);
            zzai(i2);
        }

        public final void zza(int i, long j) throws IOException {
            zzb(i, 0);
            zzaq(j);
        }

        public final void zzc(int i, long j) throws IOException {
            zzb(i, 1);
            zzas(j);
        }

        public final void zzb(int i, boolean z) throws IOException {
            zzb(i, 0);
            zzc((byte) z);
        }

        public final void zzb(int i, String str) throws IOException {
            zzb(i, 2);
            zzco(str);
        }

        public final void zza(int i, zzdp zzdp) throws IOException {
            zzb(i, 2);
            zza(zzdp);
        }

        public final void zza(int i, zzgh zzgh) throws IOException {
            zzb(i, 2);
            zzb(zzgh);
        }

        final void zza(int i, zzgh zzgh, zzgy zzgy) throws IOException {
            zzb(i, 2);
            zza(zzgh, zzgy);
        }

        public final void zzb(int i, zzgh zzgh) throws IOException {
            zzb(1, 3);
            zzd(2, i);
            zza(3, zzgh);
            zzb(1, 4);
        }

        public final void zzb(int i, zzdp zzdp) throws IOException {
            zzb(1, 3);
            zzd(2, i);
            zza(3, zzdp);
            zzb(1, 4);
        }

        public final void zzb(zzgh zzgh) throws IOException {
            zzag(zzgh.zzly());
            zzgh.zzb(this);
        }

        final void zza(zzgh zzgh, zzgy zzgy) throws IOException {
            zzdg zzdg = (zzdg) zzgh;
            int zzjw = zzdg.zzjw();
            if (zzjw == -1) {
                zzjw = zzgy.zzs(zzdg);
                zzdg.zzn(zzjw);
            }
            zzag(zzjw);
            zzgy.zza(zzgh, this.zzacw);
        }

        public final void zzc(byte b) throws IOException {
            long j = this.zzadf;
            if (j < this.zzadd) {
                this.zzadf = 1 + j;
                zzhw.zza(j, b);
                return;
            }
            throw new zzc(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Long.valueOf(j), Long.valueOf(this.zzadd), Integer.valueOf(1)}));
        }

        public final void zza(zzdp zzdp) throws IOException {
            zzag(zzdp.size());
            zzdp.zza((zzdo) this);
        }

        public final void zze(byte[] bArr, int i, int i2) throws IOException {
            zzag(i2);
            write(bArr, 0, i2);
        }

        public final void zzaf(int i) throws IOException {
            if (i >= 0) {
                zzag(i);
            } else {
                zzaq((long) i);
            }
        }

        public final void zzai(int i) throws IOException {
            this.zzada.putInt((int) (this.zzadf - this.zzadb), i);
            this.zzadf += 4;
        }

        public final void zzas(long j) throws IOException {
            this.zzada.putLong((int) (this.zzadf - this.zzadb), j);
            this.zzadf += 8;
        }

        public final void write(byte[] bArr, int i, int i2) throws IOException {
            if (bArr != null && i >= 0 && i2 >= 0 && bArr.length - i2 >= i) {
                long j = (long) i2;
                long j2 = this.zzadd - j;
                long j3 = this.zzadf;
                if (j2 >= j3) {
                    zzhw.zza(bArr, (long) i, j3, j);
                    this.zzadf += j;
                    return;
                }
            }
            if (bArr == null) {
                throw new NullPointerException("value");
            }
            throw new zzc(String.format("Pos: %d, limit: %d, len: %d", new Object[]{Long.valueOf(this.zzadf), Long.valueOf(this.zzadd), Integer.valueOf(i2)}));
        }

        public final void zza(byte[] bArr, int i, int i2) throws IOException {
            write(bArr, i, i2);
        }

        public final void zzco(String str) throws IOException {
            long j = this.zzadf;
            try {
                int zzal = zzeg.zzal(str.length() * 3);
                int zzal2 = zzeg.zzal(str.length());
                if (zzal2 == zzal) {
                    zzal = ((int) (this.zzadf - this.zzadb)) + zzal2;
                    this.zzada.position(zzal);
                    zzhy.zza(str, this.zzada);
                    zzal2 = this.zzada.position() - zzal;
                    zzag(zzal2);
                    this.zzadf += (long) zzal2;
                    return;
                }
                zzal = zzhy.zza(str);
                zzag(zzal);
                zzaz(this.zzadf);
                zzhy.zza(str, this.zzada);
                this.zzadf += (long) zzal;
            } catch (zzic e) {
                this.zzadf = j;
                zzaz(this.zzadf);
                zza(str, e);
            } catch (Throwable e2) {
                throw new zzc(e2);
            } catch (Throwable e22) {
                throw new zzc(e22);
            }
        }

        public final void flush() {
            this.zzacz.position((int) (this.zzadf - this.zzadb));
        }

        public final int zzlj() {
            return (int) (this.zzadd - this.zzadf);
        }

        private final void zzaz(long j) {
            this.zzada.position((int) (j - this.zzadb));
        }
    }

    static final class zzb extends zza {
        private final ByteBuffer zzacx;
        private int zzacy;

        zzb(ByteBuffer byteBuffer) {
            super(byteBuffer.array(), byteBuffer.arrayOffset() + byteBuffer.position(), byteBuffer.remaining());
            this.zzacx = byteBuffer;
            this.zzacy = byteBuffer.position();
        }

        public final void flush() {
            this.zzacx.position(this.zzacy + zzlm());
        }
    }

    public static int zzal(int i) {
        return (i & -128) == 0 ? 1 : (i & -16384) == 0 ? 2 : (-2097152 & i) == 0 ? 3 : (i & -268435456) == 0 ? 4 : 5;
    }

    public static int zzan(int i) {
        return 4;
    }

    public static int zzao(int i) {
        return 4;
    }

    private static int zzaq(int i) {
        return (i >> 31) ^ (i << 1);
    }

    public static int zzau(long j) {
        if ((-128 & j) == 0) {
            return 1;
        }
        if (j < 0) {
            return 10;
        }
        int i;
        if ((-34359738368L & j) != 0) {
            i = 6;
            j >>>= 28;
        } else {
            i = 2;
        }
        if ((-2097152 & j) != 0) {
            i += 2;
            j >>>= 14;
        }
        if ((j & -16384) != 0) {
            i++;
        }
        return i;
    }

    public static int zzaw(long j) {
        return 8;
    }

    public static int zzax(long j) {
        return 8;
    }

    private static long zzay(long j) {
        return (j >> 63) ^ (j << 1);
    }

    public static int zzb(float f) {
        return 4;
    }

    public static int zze(double d) {
        return 8;
    }

    public static zzeg zzh(byte[] bArr) {
        return new zza(bArr, 0, bArr.length);
    }

    public static int zzn(boolean z) {
        return 1;
    }

    public abstract void flush() throws IOException;

    public abstract void write(byte[] bArr, int i, int i2) throws IOException;

    public abstract void zza(int i, long j) throws IOException;

    public abstract void zza(int i, zzdp zzdp) throws IOException;

    public abstract void zza(int i, zzgh zzgh) throws IOException;

    abstract void zza(int i, zzgh zzgh, zzgy zzgy) throws IOException;

    public abstract void zza(zzdp zzdp) throws IOException;

    abstract void zza(zzgh zzgh, zzgy zzgy) throws IOException;

    public abstract void zzaf(int i) throws IOException;

    public abstract void zzag(int i) throws IOException;

    public abstract void zzai(int i) throws IOException;

    public abstract void zzaq(long j) throws IOException;

    public abstract void zzas(long j) throws IOException;

    public abstract void zzb(int i, int i2) throws IOException;

    public abstract void zzb(int i, zzdp zzdp) throws IOException;

    public abstract void zzb(int i, zzgh zzgh) throws IOException;

    public abstract void zzb(int i, String str) throws IOException;

    public abstract void zzb(int i, boolean z) throws IOException;

    public abstract void zzb(zzgh zzgh) throws IOException;

    public abstract void zzc(byte b) throws IOException;

    public abstract void zzc(int i, int i2) throws IOException;

    public abstract void zzc(int i, long j) throws IOException;

    public abstract void zzco(String str) throws IOException;

    public abstract void zzd(int i, int i2) throws IOException;

    abstract void zze(byte[] bArr, int i, int i2) throws IOException;

    public abstract void zzf(int i, int i2) throws IOException;

    public abstract int zzlj();

    public static zzeg zza(ByteBuffer byteBuffer) {
        if (byteBuffer.hasArray()) {
            return new zzb(byteBuffer);
        }
        if (!byteBuffer.isDirect() || byteBuffer.isReadOnly()) {
            throw new IllegalArgumentException("ByteBuffer is read-only");
        } else if (zzhw.zzov()) {
            return new zze(byteBuffer);
        } else {
            return new zzd(byteBuffer);
        }
    }

    private zzeg() {
    }

    public final void zze(int i, int i2) throws IOException {
        zzd(i, zzaq(i2));
    }

    public final void zzb(int i, long j) throws IOException {
        zza(i, zzay(j));
    }

    public final void zza(int i, float f) throws IOException {
        zzf(i, Float.floatToRawIntBits(f));
    }

    public final void zza(int i, double d) throws IOException {
        zzc(i, Double.doubleToRawLongBits(d));
    }

    public final void zzah(int i) throws IOException {
        zzag(zzaq(i));
    }

    public final void zzar(long j) throws IOException {
        zzaq(zzay(j));
    }

    public final void zza(float f) throws IOException {
        zzai(Float.floatToRawIntBits(f));
    }

    public final void zzd(double d) throws IOException {
        zzas(Double.doubleToRawLongBits(d));
    }

    public final void zzm(boolean z) throws IOException {
        zzc((byte) z);
    }

    public static int zzg(int i, int i2) {
        return zzaj(i) + zzak(i2);
    }

    public static int zzh(int i, int i2) {
        return zzaj(i) + zzal(i2);
    }

    public static int zzi(int i, int i2) {
        return zzaj(i) + zzal(zzaq(i2));
    }

    public static int zzj(int i, int i2) {
        return zzaj(i) + 4;
    }

    public static int zzk(int i, int i2) {
        return zzaj(i) + 4;
    }

    public static int zzd(int i, long j) {
        return zzaj(i) + zzau(j);
    }

    public static int zze(int i, long j) {
        return zzaj(i) + zzau(j);
    }

    public static int zzf(int i, long j) {
        return zzaj(i) + zzau(zzay(j));
    }

    public static int zzg(int i, long j) {
        return zzaj(i) + 8;
    }

    public static int zzh(int i, long j) {
        return zzaj(i) + 8;
    }

    public static int zzb(int i, float f) {
        return zzaj(i) + 4;
    }

    public static int zzb(int i, double d) {
        return zzaj(i) + 8;
    }

    public static int zzc(int i, boolean z) {
        return zzaj(i) + 1;
    }

    public static int zzl(int i, int i2) {
        return zzaj(i) + zzak(i2);
    }

    public static int zzc(int i, String str) {
        return zzaj(i) + zzcp(str);
    }

    public static int zzc(int i, zzdp zzdp) {
        i = zzaj(i);
        zzdp = zzdp.size();
        return i + (zzal(zzdp) + zzdp);
    }

    public static int zza(int i, zzfo zzfo) {
        i = zzaj(i);
        zzfo = zzfo.zzly();
        return i + (zzal(zzfo) + zzfo);
    }

    public static int zzc(int i, zzgh zzgh) {
        return zzaj(i) + zzc(zzgh);
    }

    static int zzb(int i, zzgh zzgh, zzgy zzgy) {
        return zzaj(i) + zzb(zzgh, zzgy);
    }

    public static int zzd(int i, zzgh zzgh) {
        return ((zzaj(1) << 1) + zzh(2, i)) + zzc(3, zzgh);
    }

    public static int zzd(int i, zzdp zzdp) {
        return ((zzaj(1) << 1) + zzh(2, i)) + zzc(3, zzdp);
    }

    public static int zzb(int i, zzfo zzfo) {
        return ((zzaj(1) << 1) + zzh(2, i)) + zza(3, zzfo);
    }

    public static int zzaj(int i) {
        return zzal(i << 3);
    }

    public static int zzak(int i) {
        return i >= 0 ? zzal(i) : 10;
    }

    public static int zzam(int i) {
        return zzal(zzaq(i));
    }

    public static int zzat(long j) {
        return zzau(j);
    }

    public static int zzav(long j) {
        return zzau(zzay(j));
    }

    public static int zzap(int i) {
        return zzak(i);
    }

    public static int zzcp(java.lang.String r1) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r1 = com.google.android.gms.internal.measurement.zzhy.zza(r1);	 Catch:{ zzic -> 0x0005 }
        goto L_0x000c;
    L_0x0005:
        r0 = com.google.android.gms.internal.measurement.zzfb.UTF_8;
        r1 = r1.getBytes(r0);
        r1 = r1.length;
    L_0x000c:
        r0 = zzal(r1);
        r0 = r0 + r1;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzeg.zzcp(java.lang.String):int");
    }

    public static int zza(zzfo zzfo) {
        zzfo = zzfo.zzly();
        return zzal(zzfo) + zzfo;
    }

    public static int zzb(zzdp zzdp) {
        zzdp = zzdp.size();
        return zzal(zzdp) + zzdp;
    }

    public static int zzi(byte[] bArr) {
        bArr = bArr.length;
        return zzal(bArr) + bArr;
    }

    public static int zzc(zzgh zzgh) {
        zzgh = zzgh.zzly();
        return zzal(zzgh) + zzgh;
    }

    static int zzb(zzgh zzgh, zzgy zzgy) {
        zzdg zzdg = (zzdg) zzgh;
        int zzjw = zzdg.zzjw();
        if (zzjw == -1) {
            zzjw = zzgy.zzs(zzdg);
            zzdg.zzn(zzjw);
        }
        return zzal(zzjw) + zzjw;
    }

    public final void zzlk() {
        if (zzlj() != 0) {
            throw new IllegalStateException("Did not write as much data as expected.");
        }
    }

    final void zza(String str, zzic zzic) throws IOException {
        logger.logp(Level.WARNING, "com.google.protobuf.CodedOutputStream", "inefficientWriteStringNoTag", "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", zzic);
        str = str.getBytes(zzfb.UTF_8);
        try {
            zzag(str.length);
            zza(str, null, str.length);
        } catch (Throwable e) {
            throw new zzc(e);
        } catch (String str2) {
            throw str2;
        }
    }

    @Deprecated
    static int zzc(int i, zzgh zzgh, zzgy zzgy) {
        i = zzaj(i) << 1;
        zzdg zzdg = (zzdg) zzgh;
        int zzjw = zzdg.zzjw();
        if (zzjw == -1) {
            zzjw = zzgy.zzs(zzdg);
            zzdg.zzn(zzjw);
        }
        return i + zzjw;
    }

    @Deprecated
    public static int zzd(zzgh zzgh) {
        return zzgh.zzly();
    }

    @Deprecated
    public static int zzar(int i) {
        return zzal(i);
    }
}
