package com.google.android.gms.internal.measurement;

import java.util.logging.Logger;

abstract class zzex<T extends zzem> {
    private static final Logger logger = Logger.getLogger(zzeg.class.getName());
    private static String zzagl = "com.google.protobuf.BlazeGeneratedExtensionRegistryLiteLoader";

    zzex() {
    }

    static <T extends com.google.android.gms.internal.measurement.zzem> T zza(java.lang.Class<T> r11) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:58:0x0113 in {2, 5, 12, 15, 18, 21, 24, 30, 34, 35, 36, 40, 43, 46, 49, 52, 55, 57} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = com.google.android.gms.internal.measurement.zzex.class;
        r0 = r0.getClassLoader();
        r1 = com.google.android.gms.internal.measurement.zzem.class;
        r1 = r11.equals(r1);
        r2 = 1;
        r3 = 0;
        if (r1 == 0) goto L_0x0013;
    L_0x0010:
        r1 = zzagl;
        goto L_0x003c;
    L_0x0013:
        r1 = r11.getPackage();
        r4 = com.google.android.gms.internal.measurement.zzex.class;
        r4 = r4.getPackage();
        r1 = r1.equals(r4);
        if (r1 == 0) goto L_0x0109;
    L_0x0023:
        r1 = 2;
        r1 = new java.lang.Object[r1];
        r4 = r11.getPackage();
        r4 = r4.getName();
        r1[r3] = r4;
        r4 = r11.getSimpleName();
        r1[r2] = r4;
        r4 = "%s.BlazeGenerated%sLoader";
        r1 = java.lang.String.format(r4, r1);
    L_0x003c:
        r1 = java.lang.Class.forName(r1, r2, r0);	 Catch:{ ClassNotFoundException -> 0x0075 }
        r4 = new java.lang.Class[r3];	 Catch:{ NoSuchMethodException -> 0x006e, InstantiationException -> 0x0067, IllegalAccessException -> 0x0060, InvocationTargetException -> 0x0059 }
        r1 = r1.getConstructor(r4);	 Catch:{ NoSuchMethodException -> 0x006e, InstantiationException -> 0x0067, IllegalAccessException -> 0x0060, InvocationTargetException -> 0x0059 }
        r4 = new java.lang.Object[r3];	 Catch:{ NoSuchMethodException -> 0x006e, InstantiationException -> 0x0067, IllegalAccessException -> 0x0060, InvocationTargetException -> 0x0059 }
        r1 = r1.newInstance(r4);	 Catch:{ NoSuchMethodException -> 0x006e, InstantiationException -> 0x0067, IllegalAccessException -> 0x0060, InvocationTargetException -> 0x0059 }
        r1 = (com.google.android.gms.internal.measurement.zzex) r1;	 Catch:{ NoSuchMethodException -> 0x006e, InstantiationException -> 0x0067, IllegalAccessException -> 0x0060, InvocationTargetException -> 0x0059 }
        r1 = r1.zzme();	 Catch:{ ClassNotFoundException -> 0x0075 }
        r1 = r11.cast(r1);	 Catch:{ ClassNotFoundException -> 0x0075 }
        r1 = (com.google.android.gms.internal.measurement.zzem) r1;	 Catch:{ ClassNotFoundException -> 0x0075 }
        return r1;	 Catch:{ ClassNotFoundException -> 0x0075 }
    L_0x0059:
        r1 = move-exception;	 Catch:{ ClassNotFoundException -> 0x0075 }
        r4 = new java.lang.IllegalStateException;	 Catch:{ ClassNotFoundException -> 0x0075 }
        r4.<init>(r1);	 Catch:{ ClassNotFoundException -> 0x0075 }
        throw r4;	 Catch:{ ClassNotFoundException -> 0x0075 }
    L_0x0060:
        r1 = move-exception;	 Catch:{ ClassNotFoundException -> 0x0075 }
        r4 = new java.lang.IllegalStateException;	 Catch:{ ClassNotFoundException -> 0x0075 }
        r4.<init>(r1);	 Catch:{ ClassNotFoundException -> 0x0075 }
        throw r4;	 Catch:{ ClassNotFoundException -> 0x0075 }
    L_0x0067:
        r1 = move-exception;	 Catch:{ ClassNotFoundException -> 0x0075 }
        r4 = new java.lang.IllegalStateException;	 Catch:{ ClassNotFoundException -> 0x0075 }
        r4.<init>(r1);	 Catch:{ ClassNotFoundException -> 0x0075 }
        throw r4;	 Catch:{ ClassNotFoundException -> 0x0075 }
    L_0x006e:
        r1 = move-exception;	 Catch:{ ClassNotFoundException -> 0x0075 }
        r4 = new java.lang.IllegalStateException;	 Catch:{ ClassNotFoundException -> 0x0075 }
        r4.<init>(r1);	 Catch:{ ClassNotFoundException -> 0x0075 }
        throw r4;	 Catch:{ ClassNotFoundException -> 0x0075 }
    L_0x0075:
        r1 = com.google.android.gms.internal.measurement.zzex.class;
        r0 = java.util.ServiceLoader.load(r1, r0);
        r0 = r0.iterator();
        r1 = new java.util.ArrayList;
        r1.<init>();
    L_0x0084:
        r4 = r0.hasNext();
        if (r4 == 0) goto L_0x00c8;
    L_0x008a:
        r4 = r0.next();	 Catch:{ ServiceConfigurationError -> 0x009e }
        r4 = (com.google.android.gms.internal.measurement.zzex) r4;	 Catch:{ ServiceConfigurationError -> 0x009e }
        r4 = r4.zzme();	 Catch:{ ServiceConfigurationError -> 0x009e }
        r4 = r11.cast(r4);	 Catch:{ ServiceConfigurationError -> 0x009e }
        r4 = (com.google.android.gms.internal.measurement.zzem) r4;	 Catch:{ ServiceConfigurationError -> 0x009e }
        r1.add(r4);	 Catch:{ ServiceConfigurationError -> 0x009e }
        goto L_0x0084;
    L_0x009e:
        r4 = move-exception;
        r10 = r4;
        r5 = logger;
        r6 = java.util.logging.Level.SEVERE;
        r4 = "Unable to load ";
        r7 = r11.getSimpleName();
        r7 = java.lang.String.valueOf(r7);
        r8 = r7.length();
        if (r8 == 0) goto L_0x00ba;
    L_0x00b4:
        r4 = r4.concat(r7);
        r9 = r4;
        goto L_0x00c0;
    L_0x00ba:
        r7 = new java.lang.String;
        r7.<init>(r4);
        r9 = r7;
    L_0x00c0:
        r7 = "com.google.protobuf.GeneratedExtensionRegistryLoader";
        r8 = "load";
        r5.logp(r6, r7, r8, r9, r10);
        goto L_0x0084;
    L_0x00c8:
        r0 = r1.size();
        if (r0 != r2) goto L_0x00d5;
    L_0x00ce:
        r11 = r1.get(r3);
        r11 = (com.google.android.gms.internal.measurement.zzem) r11;
        return r11;
    L_0x00d5:
        r0 = r1.size();
        r4 = 0;
        if (r0 != 0) goto L_0x00dd;
    L_0x00dc:
        return r4;
    L_0x00dd:
        r0 = "combine";	 Catch:{ NoSuchMethodException -> 0x0102, IllegalAccessException -> 0x00fb, InvocationTargetException -> 0x00f4 }
        r5 = new java.lang.Class[r2];	 Catch:{ NoSuchMethodException -> 0x0102, IllegalAccessException -> 0x00fb, InvocationTargetException -> 0x00f4 }
        r6 = java.util.Collection.class;	 Catch:{ NoSuchMethodException -> 0x0102, IllegalAccessException -> 0x00fb, InvocationTargetException -> 0x00f4 }
        r5[r3] = r6;	 Catch:{ NoSuchMethodException -> 0x0102, IllegalAccessException -> 0x00fb, InvocationTargetException -> 0x00f4 }
        r11 = r11.getMethod(r0, r5);	 Catch:{ NoSuchMethodException -> 0x0102, IllegalAccessException -> 0x00fb, InvocationTargetException -> 0x00f4 }
        r0 = new java.lang.Object[r2];	 Catch:{ NoSuchMethodException -> 0x0102, IllegalAccessException -> 0x00fb, InvocationTargetException -> 0x00f4 }
        r0[r3] = r1;	 Catch:{ NoSuchMethodException -> 0x0102, IllegalAccessException -> 0x00fb, InvocationTargetException -> 0x00f4 }
        r11 = r11.invoke(r4, r0);	 Catch:{ NoSuchMethodException -> 0x0102, IllegalAccessException -> 0x00fb, InvocationTargetException -> 0x00f4 }
        r11 = (com.google.android.gms.internal.measurement.zzem) r11;	 Catch:{ NoSuchMethodException -> 0x0102, IllegalAccessException -> 0x00fb, InvocationTargetException -> 0x00f4 }
        return r11;
    L_0x00f4:
        r11 = move-exception;
        r0 = new java.lang.IllegalStateException;
        r0.<init>(r11);
        throw r0;
    L_0x00fb:
        r11 = move-exception;
        r0 = new java.lang.IllegalStateException;
        r0.<init>(r11);
        throw r0;
    L_0x0102:
        r11 = move-exception;
        r0 = new java.lang.IllegalStateException;
        r0.<init>(r11);
        throw r0;
    L_0x0109:
        r0 = new java.lang.IllegalArgumentException;
        r11 = r11.getName();
        r0.<init>(r11);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzex.zza(java.lang.Class):T");
    }

    protected abstract T zzme();
}
