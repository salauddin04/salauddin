package com.google.android.gms.internal.ads;

import java.util.Set;

public final class zzbuc implements zzdth<Set<zzbuy<zzbrn>>> {
    private final zzbtu zzfky;

    private zzbuc(zzbtu zzbtu) {
        this.zzfky = zzbtu;
    }

    public static zzbuc zzk(zzbtu zzbtu) {
        return new zzbuc(zzbtu);
    }

    public final /* synthetic */ Object get() {
        return (Set) zzdtn.zza(this.zzfky.zzagn(), "Cannot return null from a non-@Nullable @Provides method");
    }
}
