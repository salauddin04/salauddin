package com.google.android.gms.internal.ads;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzaai extends IInterface {
    String getDescription() throws RemoteException;

    String zzpt() throws RemoteException;
}
