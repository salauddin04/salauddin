package com.google.android.gms.internal.measurement;

import android.os.RemoteException;

final class zzad extends zza {
    private final /* synthetic */ String zzao;
    private final /* synthetic */ zzaa zzar;
    private final /* synthetic */ String zzav;
    private final /* synthetic */ zzm zzaw;

    zzad(zzaa zzaa, String str, String str2, zzm zzm) {
        this.zzar = zzaa;
        this.zzao = str;
        this.zzav = str2;
        this.zzaw = zzm;
        super(zzaa);
    }

    final void zzl() throws RemoteException {
        this.zzar.zzan.getConditionalUserProperties(this.zzao, this.zzav, this.zzaw);
    }

    protected final void zzm() {
        this.zzaw.zzb(null);
    }
}
