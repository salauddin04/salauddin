package com.google.android.gms.internal.measurement;

final class zzda extends zzcw<Double> {
    zzda(zzdc zzdc, String str, Double d) {
        super(zzdc, str, d);
    }

    private final java.lang.Double zzf(java.lang.Object r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r3 = this;
        r0 = r4 instanceof java.lang.Double;
        if (r0 == 0) goto L_0x0007;
    L_0x0004:
        r4 = (java.lang.Double) r4;
        return r4;
    L_0x0007:
        r0 = r4 instanceof java.lang.Float;
        if (r0 == 0) goto L_0x0016;
    L_0x000b:
        r4 = (java.lang.Float) r4;
        r0 = r4.doubleValue();
        r4 = java.lang.Double.valueOf(r0);
        return r4;
    L_0x0016:
        r0 = r4 instanceof java.lang.String;
        if (r0 == 0) goto L_0x0026;
    L_0x001a:
        r0 = r4;	 Catch:{ NumberFormatException -> 0x0026 }
        r0 = (java.lang.String) r0;	 Catch:{ NumberFormatException -> 0x0026 }
        r0 = java.lang.Double.parseDouble(r0);	 Catch:{ NumberFormatException -> 0x0026 }
        r4 = java.lang.Double.valueOf(r0);	 Catch:{ NumberFormatException -> 0x0026 }
        return r4;
    L_0x0026:
        r0 = super.zzjq();
        r4 = java.lang.String.valueOf(r4);
        r1 = java.lang.String.valueOf(r0);
        r1 = r1.length();
        r1 = r1 + 27;
        r2 = java.lang.String.valueOf(r4);
        r2 = r2.length();
        r1 = r1 + r2;
        r2 = new java.lang.StringBuilder;
        r2.<init>(r1);
        r1 = "Invalid double value for ";
        r2.append(r1);
        r2.append(r0);
        r0 = ": ";
        r2.append(r0);
        r2.append(r4);
        r4 = r2.toString();
        r0 = "PhenotypeFlag";
        android.util.Log.e(r0, r4);
        r4 = 0;
        return r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzda.zzf(java.lang.Object):java.lang.Double");
    }

    final /* synthetic */ Object zzc(Object obj) {
        return zzf(obj);
    }
}
