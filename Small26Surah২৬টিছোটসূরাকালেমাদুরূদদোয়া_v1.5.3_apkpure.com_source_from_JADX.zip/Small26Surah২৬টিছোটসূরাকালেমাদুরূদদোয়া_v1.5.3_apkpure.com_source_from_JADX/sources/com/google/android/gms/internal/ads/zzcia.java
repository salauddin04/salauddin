package com.google.android.gms.internal.ads;

import android.content.Context;

public final class zzcia implements zzdth<zzchy> {
    private final zzdtt<Context> zzeol;

    public zzcia(zzdtt<Context> zzdtt) {
        this.zzeol = zzdtt;
    }

    public final /* synthetic */ Object get() {
        return new zzchy((Context) this.zzeol.get());
    }
}
