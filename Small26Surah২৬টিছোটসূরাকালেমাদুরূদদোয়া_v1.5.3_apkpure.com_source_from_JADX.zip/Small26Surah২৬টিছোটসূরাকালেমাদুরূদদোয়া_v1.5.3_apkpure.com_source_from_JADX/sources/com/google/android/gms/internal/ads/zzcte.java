package com.google.android.gms.internal.ads;

public final class zzcte implements zzdth<zzctc> {
    private final zzdtt<zzbbm> zzfgg;

    private zzcte(zzdtt<zzbbm> zzdtt) {
        this.zzfgg = zzdtt;
    }

    public static zzcte zzal(zzdtt<zzbbm> zzdtt) {
        return new zzcte(zzdtt);
    }

    public final /* synthetic */ Object get() {
        return new zzctc((zzbbm) this.zzfgg.get());
    }
}
