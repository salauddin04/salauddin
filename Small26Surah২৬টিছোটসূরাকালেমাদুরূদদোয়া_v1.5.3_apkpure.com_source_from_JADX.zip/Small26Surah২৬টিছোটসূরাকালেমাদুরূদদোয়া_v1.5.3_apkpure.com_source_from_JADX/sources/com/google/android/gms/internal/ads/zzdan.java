package com.google.android.gms.internal.ads;

import android.content.Context;
import android.os.Binder;
import android.os.Looper;
import android.support.annotation.NonNull;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.BaseGmsClient.BaseConnectionCallbacks;
import com.google.android.gms.common.internal.BaseGmsClient.BaseOnConnectionFailedListener;

final class zzdan implements BaseConnectionCallbacks, BaseOnConnectionFailedListener {
    private final Object lock = new Object();
    private boolean zzfxf = false;
    private boolean zzfxg = false;
    private final zzdaz zzgoc;
    private final zzdat zzgod;

    zzdan(@NonNull Context context, @NonNull Looper looper, @NonNull zzdat zzdat) {
        this.zzgod = zzdat;
        this.zzgoc = new zzdaz(context, looper, this, this);
    }

    public final void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    public final void onConnectionSuspended(int i) {
    }

    final void zzanh() {
        synchronized (this.lock) {
            if (!this.zzfxf) {
                this.zzfxf = true;
                this.zzgoc.checkAvailabilityAndConnect();
            }
        }
    }

    private final void zzakh() {
        synchronized (this.lock) {
            if (this.zzgoc.isConnected() || this.zzgoc.isConnecting()) {
                this.zzgoc.disconnect();
            }
            Binder.flushPendingCommands();
        }
    }

    public final void onConnected(@android.support.annotation.Nullable android.os.Bundle r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r3 = this;
        r4 = r3.lock;
        monitor-enter(r4);
        r0 = r3.zzfxg;	 Catch:{ all -> 0x002e }
        if (r0 == 0) goto L_0x0009;	 Catch:{ all -> 0x002e }
    L_0x0007:
        monitor-exit(r4);	 Catch:{ all -> 0x002e }
        return;	 Catch:{ all -> 0x002e }
    L_0x0009:
        r0 = 1;	 Catch:{ all -> 0x002e }
        r3.zzfxg = r0;	 Catch:{ all -> 0x002e }
        r0 = r3.zzgoc;	 Catch:{ Exception -> 0x0029, all -> 0x0024 }
        r0 = r0.zzanm();	 Catch:{ Exception -> 0x0029, all -> 0x0024 }
        r1 = new com.google.android.gms.internal.ads.zzdax;	 Catch:{ Exception -> 0x0029, all -> 0x0024 }
        r2 = r3.zzgod;	 Catch:{ Exception -> 0x0029, all -> 0x0024 }
        r2 = r2.toByteArray();	 Catch:{ Exception -> 0x0029, all -> 0x0024 }
        r1.<init>(r2);	 Catch:{ Exception -> 0x0029, all -> 0x0024 }
        r0.zza(r1);	 Catch:{ Exception -> 0x0029, all -> 0x0024 }
        r3.zzakh();	 Catch:{ all -> 0x002e }
        goto L_0x002c;	 Catch:{ all -> 0x002e }
    L_0x0024:
        r0 = move-exception;	 Catch:{ all -> 0x002e }
        r3.zzakh();	 Catch:{ all -> 0x002e }
        throw r0;	 Catch:{ all -> 0x002e }
    L_0x0029:
        r3.zzakh();	 Catch:{ all -> 0x002e }
    L_0x002c:
        monitor-exit(r4);	 Catch:{ all -> 0x002e }
        return;	 Catch:{ all -> 0x002e }
    L_0x002e:
        r0 = move-exception;	 Catch:{ all -> 0x002e }
        monitor-exit(r4);	 Catch:{ all -> 0x002e }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzdan.onConnected(android.os.Bundle):void");
    }
}
