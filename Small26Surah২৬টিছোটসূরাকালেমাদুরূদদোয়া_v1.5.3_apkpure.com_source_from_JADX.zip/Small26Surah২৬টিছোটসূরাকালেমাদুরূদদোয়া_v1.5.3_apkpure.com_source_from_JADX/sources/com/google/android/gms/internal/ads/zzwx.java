package com.google.android.gms.internal.ads;

final class zzwx implements zzdof {
    static final zzdof zzei = new zzwx();

    private zzwx() {
    }

    public final boolean zzf(int i) {
        return zzwv.zzca(i) != 0;
    }
}
