package com.google.android.gms.internal.measurement;

public class zzek<ContainingType extends zzgh, Type> {
}
