package com.google.android.gms.internal.ads;

public final class zzgg {
    public static zzge zzn(int i) {
        return new zzgi(2, 2500, 5000);
    }
}
