package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzbl.zzb.zzb;

final class zzbp implements zzfd<zzb> {
    zzbp() {
    }
}
