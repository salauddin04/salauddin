package com.google.android.gms.internal.ads;

public final class zzbxd implements zzbut {
    private final zzbrx zzflw;

    public zzbxd(zzbrx zzbrx) {
        this.zzflw = zzbrx;
    }

    public final void zzagw() {
    }

    public final void onHide() {
        this.zzflw.zzbr(null);
    }
}
