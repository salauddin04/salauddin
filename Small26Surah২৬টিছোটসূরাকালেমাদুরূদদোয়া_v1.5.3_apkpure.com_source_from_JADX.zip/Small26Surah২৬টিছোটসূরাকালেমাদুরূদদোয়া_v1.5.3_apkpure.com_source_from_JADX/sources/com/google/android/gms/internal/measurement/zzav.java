package com.google.android.gms.internal.measurement;

import android.os.RemoteException;

final class zzav extends zza {
    private final /* synthetic */ String zzao;
    private final /* synthetic */ zzaa zzar;
    private final /* synthetic */ zzm zzaw;

    zzav(zzaa zzaa, String str, zzm zzm) {
        this.zzar = zzaa;
        this.zzao = str;
        this.zzaw = zzm;
        super(zzaa);
    }

    final void zzl() throws RemoteException {
        this.zzar.zzan.getMaxUserProperties(this.zzao, this.zzaw);
    }

    protected final void zzm() {
        this.zzaw.zzb(null);
    }
}
