package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzbl.zza.zzb;
import java.io.IOException;

public final class zzca extends zzip<zzca> {
    public zzb zzwk;
    public Boolean zzwl;
    public String zzwm;
    public String zzwn;
    public String zzwo;

    public zzca() {
        this.zzwk = null;
        this.zzwl = null;
        this.zzwm = null;
        this.zzwn = null;
        this.zzwo = null;
        this.zzand = null;
        this.zzanm = -1;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzca)) {
            return false;
        }
        zzca zzca = (zzca) obj;
        zzb zzb = this.zzwk;
        if (zzb == null) {
            if (zzca.zzwk != null) {
                return false;
            }
        } else if (!zzb.equals(zzca.zzwk)) {
            return false;
        }
        Boolean bool = this.zzwl;
        if (bool == null) {
            if (zzca.zzwl != null) {
                return false;
            }
        } else if (!bool.equals(zzca.zzwl)) {
            return false;
        }
        String str = this.zzwm;
        if (str == null) {
            if (zzca.zzwm != null) {
                return false;
            }
        } else if (!str.equals(zzca.zzwm)) {
            return false;
        }
        str = this.zzwn;
        if (str == null) {
            if (zzca.zzwn != null) {
                return false;
            }
        } else if (!str.equals(zzca.zzwn)) {
            return false;
        }
        str = this.zzwo;
        if (str == null) {
            if (zzca.zzwo != null) {
                return false;
            }
        } else if (!str.equals(zzca.zzwo)) {
            return false;
        }
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                return this.zzand.equals(zzca.zzand);
            }
        }
        if (zzca.zzand != null) {
            if (zzca.zzand.isEmpty() == null) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int hashCode = (getClass().getName().hashCode() + 527) * 31;
        zzb zzb = this.zzwk;
        int i = 0;
        hashCode = (hashCode + (zzb == null ? 0 : zzb.hashCode())) * 31;
        Boolean bool = this.zzwl;
        hashCode = (hashCode + (bool == null ? 0 : bool.hashCode())) * 31;
        String str = this.zzwm;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        str = this.zzwn;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        str = this.zzwo;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                i = this.zzand.hashCode();
            }
        }
        return hashCode + i;
    }

    public final void zza(zzin zzin) throws IOException {
        zzb zzb = this.zzwk;
        if (!(zzb == null || zzb == null)) {
            zzin.zzc(1, zzb.zzgp());
        }
        Boolean bool = this.zzwl;
        if (bool != null) {
            zzin.zzb(2, bool.booleanValue());
        }
        String str = this.zzwm;
        if (str != null) {
            zzin.zzb(3, str);
        }
        str = this.zzwn;
        if (str != null) {
            zzin.zzb(4, str);
        }
        str = this.zzwo;
        if (str != null) {
            zzin.zzb(5, str);
        }
        super.zza(zzin);
    }

    protected final int zzja() {
        int zzja = super.zzja();
        zzb zzb = this.zzwk;
        if (!(zzb == null || zzb == null)) {
            zzja += zzin.zzg(1, zzb.zzgp());
        }
        Boolean bool = this.zzwl;
        if (bool != null) {
            bool.booleanValue();
            zzja += zzin.zzaj(2) + 1;
        }
        String str = this.zzwm;
        if (str != null) {
            zzja += zzin.zzc(3, str);
        }
        str = this.zzwn;
        if (str != null) {
            zzja += zzin.zzc(4, str);
        }
        str = this.zzwo;
        return str != null ? zzja + zzin.zzc(5, str) : zzja;
    }

    public final /* synthetic */ zziv zza(zzim zzim) throws IOException {
        while (true) {
            int zzkj = zzim.zzkj();
            if (zzkj == 0) {
                return this;
            }
            if (zzkj == 8) {
                int position = zzim.getPosition();
                int zzlb = zzim.zzlb();
                if (zzlb == 0 || zzlb == 1 || zzlb == 2 || zzlb == 3 || zzlb == 4) {
                    this.zzwk = zzb.zze(zzlb);
                } else {
                    zzim.zzbj(position);
                    zza(zzim, zzkj);
                }
            } else if (zzkj == 16) {
                this.zzwl = Boolean.valueOf(zzim.zzkp());
            } else if (zzkj == 26) {
                this.zzwm = zzim.readString();
            } else if (zzkj == 34) {
                this.zzwn = zzim.readString();
            } else if (zzkj == 42) {
                this.zzwo = zzim.readString();
            } else if (!super.zza(zzim, zzkj)) {
                return this;
            }
        }
    }
}
