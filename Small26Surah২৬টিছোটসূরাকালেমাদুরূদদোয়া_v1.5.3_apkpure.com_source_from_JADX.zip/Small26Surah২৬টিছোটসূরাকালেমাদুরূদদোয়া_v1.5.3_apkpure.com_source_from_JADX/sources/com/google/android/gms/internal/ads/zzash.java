package com.google.android.gms.internal.ads;

import android.content.Context;
import java.util.WeakHashMap;
import java.util.concurrent.Future;

@zzare
public final class zzash {
    private WeakHashMap<Context, zzasj> zzdqg = new WeakHashMap();

    public final Future<zzasf> zzt(Context context) {
        return zzaxh.zza(new zzasi(this, context));
    }
}
