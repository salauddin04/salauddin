package com.google.android.gms.internal.ads;

public final class zzjk {
    public final byte[] data;
    private final int offset = null;

    public zzjk(byte[] bArr, int i) {
        this.data = bArr;
    }
}
