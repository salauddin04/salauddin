package com.google.android.gms.internal.ads;

final /* synthetic */ class zzayd implements Runnable {
    private final zzayc zzdwk;

    zzayd(zzayc zzayc) {
        this.zzdwk = zzayc;
    }

    public final void run() {
        this.zzdwk.zzwm();
    }
}
