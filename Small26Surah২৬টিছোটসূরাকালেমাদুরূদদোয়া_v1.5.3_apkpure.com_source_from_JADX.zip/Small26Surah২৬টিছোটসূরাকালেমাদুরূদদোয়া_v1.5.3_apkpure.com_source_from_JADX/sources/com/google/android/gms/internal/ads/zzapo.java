package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.internal.overlay.zzm;
import com.google.android.gms.ads.internal.zzk;

final class zzapo implements Runnable {
    private final /* synthetic */ zzapm zzdhr;
    private final /* synthetic */ AdOverlayInfoParcel zzdhs;

    zzapo(zzapm zzapm, AdOverlayInfoParcel adOverlayInfoParcel) {
        this.zzdhr = zzapm;
        this.zzdhs = adOverlayInfoParcel;
    }

    public final void run() {
        zzk.zzlf();
        zzm.zza(this.zzdhr.zzdhp, this.zzdhs, true);
    }
}
