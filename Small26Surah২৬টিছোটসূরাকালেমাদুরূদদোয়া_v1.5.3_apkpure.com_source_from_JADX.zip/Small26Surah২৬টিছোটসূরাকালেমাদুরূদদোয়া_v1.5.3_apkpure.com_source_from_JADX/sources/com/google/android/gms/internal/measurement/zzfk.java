package com.google.android.gms.internal.measurement;

public final class zzfk extends zzfo {
    public static zzgh zzne() {
        throw new NoSuchMethodError();
    }

    public final int hashCode() {
        throw new NoSuchMethodError();
    }

    public final boolean equals(Object obj) {
        throw new NoSuchMethodError();
    }

    public final String toString() {
        throw new NoSuchMethodError();
    }
}
