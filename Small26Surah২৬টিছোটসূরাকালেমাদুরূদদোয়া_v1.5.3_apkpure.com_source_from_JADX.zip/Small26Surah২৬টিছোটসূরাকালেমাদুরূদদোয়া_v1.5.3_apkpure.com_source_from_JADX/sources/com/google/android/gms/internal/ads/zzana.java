package com.google.android.gms.internal.ads;

import android.os.IBinder;

public final class zzana extends zzfm implements zzamz {
    zzana(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.mediation.client.IMediationResponseMetadata");
    }
}
