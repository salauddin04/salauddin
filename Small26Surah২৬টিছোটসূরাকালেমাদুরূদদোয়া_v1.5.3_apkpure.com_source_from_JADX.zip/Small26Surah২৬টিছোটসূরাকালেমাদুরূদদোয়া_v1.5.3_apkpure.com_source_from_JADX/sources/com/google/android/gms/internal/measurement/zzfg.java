package com.google.android.gms.internal.measurement;

import java.util.List;
import java.util.RandomAccess;

public interface zzfg<E> extends List<E>, RandomAccess {
    boolean zzjy();

    void zzjz();

    zzfg<E> zzq(int i);
}
