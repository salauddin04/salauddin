package com.google.android.gms.internal.measurement;

final class zzea implements zzdv {
    private zzea() {
    }

    public final byte[] zzc(byte[] bArr, int i, int i2) {
        Object obj = new byte[i2];
        System.arraycopy(bArr, i, obj, 0, i2);
        return obj;
    }
}
