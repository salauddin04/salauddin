package com.google.android.gms.internal.ads;

import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

final class zzdnk extends zzdmk<Double> implements zzdoi<Double>, zzdpv, RandomAccess {
    private static final zzdnk zzhdw;
    private int size;
    private double[] zzhdx;

    zzdnk() {
        this(new double[10], 0);
    }

    private zzdnk(double[] dArr, int i) {
        this.zzhdx = dArr;
        this.size = i;
    }

    protected final void removeRange(int i, int i2) {
        zzavk();
        if (i2 >= i) {
            Object obj = this.zzhdx;
            System.arraycopy(obj, i2, obj, i, this.size - i2);
            this.size -= i2 - i;
            this.modCount++;
            return;
        }
        throw new IndexOutOfBoundsException("toIndex < fromIndex");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzdnk)) {
            return super.equals(obj);
        }
        zzdnk zzdnk = (zzdnk) obj;
        if (this.size != zzdnk.size) {
            return false;
        }
        obj = zzdnk.zzhdx;
        for (int i = 0; i < this.size; i++) {
            if (Double.doubleToLongBits(this.zzhdx[i]) != Double.doubleToLongBits(obj[i])) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int i = 1;
        for (int i2 = 0; i2 < this.size; i2++) {
            i = (i * 31) + zzdoc.zzft(Double.doubleToLongBits(this.zzhdx[i2]));
        }
        return i;
    }

    public final int size() {
        return this.size;
    }

    public final void zzd(double d) {
        zzd(this.size, d);
    }

    private final void zzd(int i, double d) {
        zzavk();
        if (i >= 0) {
            int i2 = this.size;
            if (i <= i2) {
                Object obj = this.zzhdx;
                if (i2 < obj.length) {
                    System.arraycopy(obj, i, obj, i + 1, i2 - i);
                } else {
                    Object obj2 = new double[(((i2 * 3) / 2) + 1)];
                    System.arraycopy(obj, 0, obj2, 0, i);
                    System.arraycopy(this.zzhdx, i, obj2, i + 1, this.size - i);
                    this.zzhdx = obj2;
                }
                this.zzhdx[i] = d;
                this.size++;
                this.modCount++;
                return;
            }
        }
        throw new IndexOutOfBoundsException(zzfk(i));
    }

    public final boolean addAll(Collection<? extends Double> collection) {
        zzavk();
        zzdoc.checkNotNull(collection);
        if (!(collection instanceof zzdnk)) {
            return super.addAll(collection);
        }
        zzdnk zzdnk = (zzdnk) collection;
        int i = zzdnk.size;
        if (i == 0) {
            return false;
        }
        int i2 = this.size;
        if (Integer.MAX_VALUE - i2 >= i) {
            i2 += i;
            double[] dArr = this.zzhdx;
            if (i2 > dArr.length) {
                this.zzhdx = Arrays.copyOf(dArr, i2);
            }
            System.arraycopy(zzdnk.zzhdx, 0, this.zzhdx, this.size, zzdnk.size);
            this.size = i2;
            this.modCount += 1;
            return true;
        }
        throw new OutOfMemoryError();
    }

    public final boolean remove(Object obj) {
        zzavk();
        for (int i = 0; i < this.size; i++) {
            if (obj.equals(Double.valueOf(this.zzhdx[i]))) {
                obj = this.zzhdx;
                System.arraycopy(obj, i + 1, obj, i, (this.size - i) - 1);
                this.size -= 1;
                this.modCount += 1;
                return true;
            }
        }
        return false;
    }

    private final void zzfj(int i) {
        if (i < 0 || i >= this.size) {
            throw new IndexOutOfBoundsException(zzfk(i));
        }
    }

    private final String zzfk(int i) {
        int i2 = this.size;
        StringBuilder stringBuilder = new StringBuilder(35);
        stringBuilder.append("Index:");
        stringBuilder.append(i);
        stringBuilder.append(", Size:");
        stringBuilder.append(i2);
        return stringBuilder.toString();
    }

    public final /* synthetic */ Object set(int i, Object obj) {
        double doubleValue = ((Double) obj).doubleValue();
        zzavk();
        zzfj(i);
        obj = this.zzhdx;
        double d = obj[i];
        obj[i] = doubleValue;
        return Double.valueOf(d);
    }

    public final /* synthetic */ Object remove(int i) {
        zzavk();
        zzfj(i);
        Object obj = this.zzhdx;
        double d = obj[i];
        int i2 = this.size;
        if (i < i2 - 1) {
            System.arraycopy(obj, i + 1, obj, i, (i2 - i) - 1);
        }
        this.size--;
        this.modCount++;
        return Double.valueOf(d);
    }

    public final /* synthetic */ void add(int i, Object obj) {
        zzd(i, ((Double) obj).doubleValue());
    }

    public final /* synthetic */ zzdoi zzfl(int i) {
        if (i >= this.size) {
            return new zzdnk(Arrays.copyOf(this.zzhdx, i), this.size);
        }
        throw new IllegalArgumentException();
    }

    public final /* synthetic */ Object get(int i) {
        zzfj(i);
        return Double.valueOf(this.zzhdx[i]);
    }

    static {
        zzdmk zzdnk = new zzdnk(new double[0], 0);
        zzhdw = zzdnk;
        zzdnk.zzavj();
    }
}
