package com.google.android.gms.internal.measurement;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public final class zzgb<K, V> extends LinkedHashMap<K, V> {
    private static final zzgb zzaiv;
    private boolean zzabp = true;

    private zzgb() {
    }

    private zzgb(Map<K, V> map) {
        super(map);
    }

    public static <K, V> zzgb<K, V> zznm() {
        return zzaiv;
    }

    public final void zza(zzgb<K, V> zzgb) {
        zzno();
        if (!zzgb.isEmpty()) {
            putAll(zzgb);
        }
    }

    public final Set<Entry<K, V>> entrySet() {
        return isEmpty() ? Collections.emptySet() : super.entrySet();
    }

    public final void clear() {
        zzno();
        super.clear();
    }

    public final V put(K k, V v) {
        zzno();
        zzfb.checkNotNull(k);
        zzfb.checkNotNull(v);
        return super.put(k, v);
    }

    public final void putAll(Map<? extends K, ? extends V> map) {
        zzno();
        for (Object next : map.keySet()) {
            zzfb.checkNotNull(next);
            zzfb.checkNotNull(map.get(next));
        }
        super.putAll(map);
    }

    public final V remove(Object obj) {
        zzno();
        return super.remove(obj);
    }

    public final boolean equals(Object obj) {
        if (obj instanceof Map) {
            obj = (Map) obj;
            if (this != obj) {
                if (size() == obj.size()) {
                    for (Entry entry : entrySet()) {
                        if (obj.containsKey(entry.getKey())) {
                            boolean equals;
                            Object value = entry.getValue();
                            Object obj2 = obj.get(entry.getKey());
                            if ((value instanceof byte[]) && (obj2 instanceof byte[])) {
                                equals = Arrays.equals((byte[]) value, (byte[]) obj2);
                                continue;
                            } else {
                                equals = value.equals(obj2);
                                continue;
                            }
                            if (!equals) {
                            }
                        }
                    }
                }
                obj = null;
                if (obj != null) {
                }
            }
            obj = true;
            return obj != null;
        }
    }

    private static int zzl(Object obj) {
        if (obj instanceof byte[]) {
            return zzfb.hashCode((byte[]) obj);
        }
        if (!(obj instanceof zzfc)) {
            return obj.hashCode();
        }
        throw new UnsupportedOperationException();
    }

    public final int hashCode() {
        int i = 0;
        for (Entry entry : entrySet()) {
            i += zzl(entry.getValue()) ^ zzl(entry.getKey());
        }
        return i;
    }

    public final zzgb<K, V> zznn() {
        return isEmpty() ? new zzgb() : new zzgb(this);
    }

    public final void zzjz() {
        this.zzabp = false;
    }

    public final boolean isMutable() {
        return this.zzabp;
    }

    private final void zzno() {
        if (!this.zzabp) {
            throw new UnsupportedOperationException();
        }
    }

    static {
        zzgb zzgb = new zzgb();
        zzaiv = zzgb;
        zzgb.zzabp = false;
    }
}
