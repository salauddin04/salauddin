package com.google.android.gms.internal.measurement;

import java.nio.ByteBuffer;

final class zzib extends zzia {
    zzib() {
    }

    final java.lang.String zzh(byte[] r12, int r13, int r14) throws com.google.android.gms.internal.measurement.zzfh {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:39:0x00ce in {6, 15, 16, 20, 22, 27, 29, 32, 34, 36, 38} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r11 = this;
        r0 = r13 | r14;
        r1 = r12.length;
        r1 = r1 - r13;
        r1 = r1 - r14;
        r0 = r0 | r1;
        r1 = 0;
        r2 = 1;
        if (r0 < 0) goto L_0x00ab;
    L_0x000a:
        r0 = r13 + r14;
        r14 = new char[r14];
        r3 = 0;
    L_0x000f:
        if (r13 >= r0) goto L_0x0022;
    L_0x0011:
        r4 = r12[r13];
        r5 = com.google.android.gms.internal.measurement.zzhz.zzd(r4);
        if (r5 == 0) goto L_0x0022;
    L_0x0019:
        r13 = r13 + 1;
        r5 = r3 + 1;
        com.google.android.gms.internal.measurement.zzhz.zza(r4, r14, r3);
        r3 = r5;
        goto L_0x000f;
    L_0x0022:
        r8 = r3;
    L_0x0023:
        if (r13 >= r0) goto L_0x00a5;
    L_0x0025:
        r3 = r13 + 1;
        r13 = r12[r13];
        r4 = com.google.android.gms.internal.measurement.zzhz.zzd(r13);
        if (r4 == 0) goto L_0x004a;
    L_0x002f:
        r4 = r8 + 1;
        com.google.android.gms.internal.measurement.zzhz.zza(r13, r14, r8);
    L_0x0034:
        if (r3 >= r0) goto L_0x0047;
    L_0x0036:
        r13 = r12[r3];
        r5 = com.google.android.gms.internal.measurement.zzhz.zzd(r13);
        if (r5 == 0) goto L_0x0047;
    L_0x003e:
        r3 = r3 + 1;
        r5 = r4 + 1;
        com.google.android.gms.internal.measurement.zzhz.zza(r13, r14, r4);
        r4 = r5;
        goto L_0x0034;
    L_0x0047:
        r13 = r3;
        r8 = r4;
        goto L_0x0023;
    L_0x004a:
        r4 = com.google.android.gms.internal.measurement.zzhz.zze(r13);
        if (r4 == 0) goto L_0x0063;
    L_0x0050:
        if (r3 >= r0) goto L_0x005e;
    L_0x0052:
        r4 = r3 + 1;
        r3 = r12[r3];
        r5 = r8 + 1;
        com.google.android.gms.internal.measurement.zzhz.zza(r13, r3, r14, r8);
        r13 = r4;
        r8 = r5;
        goto L_0x0023;
    L_0x005e:
        r12 = com.google.android.gms.internal.measurement.zzfh.zznc();
        throw r12;
    L_0x0063:
        r4 = com.google.android.gms.internal.measurement.zzhz.zzf(r13);
        if (r4 == 0) goto L_0x0082;
    L_0x0069:
        r4 = r0 + -1;
        if (r3 >= r4) goto L_0x007d;
    L_0x006d:
        r4 = r3 + 1;
        r3 = r12[r3];
        r5 = r4 + 1;
        r4 = r12[r4];
        r6 = r8 + 1;
        com.google.android.gms.internal.measurement.zzhz.zza(r13, r3, r4, r14, r8);
        r13 = r5;
        r8 = r6;
        goto L_0x0023;
    L_0x007d:
        r12 = com.google.android.gms.internal.measurement.zzfh.zznc();
        throw r12;
    L_0x0082:
        r4 = r0 + -2;
        if (r3 >= r4) goto L_0x00a0;
    L_0x0086:
        r4 = r3 + 1;
        r5 = r12[r3];
        r3 = r4 + 1;
        r6 = r12[r4];
        r9 = r3 + 1;
        r7 = r12[r3];
        r10 = r8 + 1;
        r3 = r13;
        r4 = r5;
        r5 = r6;
        r6 = r7;
        r7 = r14;
        com.google.android.gms.internal.measurement.zzhz.zza(r3, r4, r5, r6, r7, r8);
        r10 = r10 + r2;
        r13 = r9;
        r8 = r10;
        goto L_0x0023;
    L_0x00a0:
        r12 = com.google.android.gms.internal.measurement.zzfh.zznc();
        throw r12;
    L_0x00a5:
        r12 = new java.lang.String;
        r12.<init>(r14, r1, r8);
        return r12;
    L_0x00ab:
        r0 = new java.lang.ArrayIndexOutOfBoundsException;
        r3 = 3;
        r3 = new java.lang.Object[r3];
        r12 = r12.length;
        r12 = java.lang.Integer.valueOf(r12);
        r3[r1] = r12;
        r12 = java.lang.Integer.valueOf(r13);
        r3[r2] = r12;
        r12 = java.lang.Integer.valueOf(r14);
        r13 = 2;
        r3[r13] = r12;
        r12 = "buffer length=%d, index=%d, size=%d";
        r12 = java.lang.String.format(r12, r3);
        r0.<init>(r12);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzib.zzh(byte[], int, int):java.lang.String");
    }

    final int zzb(int i, byte[] bArr, int i2, int i3) {
        while (i2 < i3 && bArr[i2] >= 0) {
            i2++;
        }
        if (i2 >= i3) {
            return 0;
        }
        while (i2 < i3) {
            int i4 = i2 + 1;
            i2 = bArr[i2];
            if (i2 < 0) {
                if (i2 < -32) {
                    if (i4 >= i3) {
                        return i2;
                    }
                    if (i2 >= -62) {
                        i2 = i4 + 1;
                        if (bArr[i4] > (byte) -65) {
                        }
                    }
                    return -1;
                } else if (i2 < -16) {
                    if (i4 >= i3 - 1) {
                        return zzhy.zzg(bArr, i4, i3);
                    }
                    int i5 = i4 + 1;
                    r0 = bArr[i4];
                    if (r0 <= (byte) -65 && ((i2 != -32 || r0 >= (byte) -96) && (i2 != -19 || r0 < (byte) -96))) {
                        i2 = i5 + 1;
                        if (bArr[i5] > (byte) -65) {
                        }
                    }
                    return -1;
                } else if (i4 >= i3 - 2) {
                    return zzhy.zzg(bArr, i4, i3);
                } else {
                    int i6 = i4 + 1;
                    r0 = bArr[i4];
                    if (r0 <= (byte) -65 && (((i2 << 28) + (r0 + 112)) >> 30) == 0) {
                        i2 = i6 + 1;
                        if (bArr[i6] <= (byte) -65) {
                            i4 = i2 + 1;
                            if (bArr[i2] > -65) {
                            }
                        }
                    }
                    return -1;
                }
            }
            i2 = i4;
        }
        return 0;
    }

    final int zzb(CharSequence charSequence, byte[] bArr, int i, int i2) {
        int length = charSequence.length();
        i2 += i;
        int i3 = 0;
        while (i3 < length) {
            int i4 = i3 + i;
            if (i4 >= i2) {
                break;
            }
            char charAt = charSequence.charAt(i3);
            if (charAt >= '') {
                break;
            }
            bArr[i4] = (byte) charAt;
            i3++;
        }
        if (i3 == length) {
            return i + length;
        }
        i += i3;
        while (i3 < length) {
            int i5;
            char charAt2 = charSequence.charAt(i3);
            if (charAt2 < '' && i < i2) {
                i5 = i + 1;
                bArr[i] = (byte) charAt2;
            } else if (charAt2 < 'ࠀ' && i <= i2 - 2) {
                i5 = i + 1;
                bArr[i] = (byte) ((charAt2 >>> 6) | 960);
                i = i5 + 1;
                bArr[i5] = (byte) ((charAt2 & 63) | 128);
                i3++;
            } else if ((charAt2 < '?' || '?' < charAt2) && i <= i2 - 3) {
                i5 = i + 1;
                bArr[i] = (byte) ((charAt2 >>> 12) | 480);
                i = i5 + 1;
                bArr[i5] = (byte) (((charAt2 >>> 6) & 63) | 128);
                i5 = i + 1;
                bArr[i] = (byte) ((charAt2 & 63) | 128);
            } else if (i <= i2 - 4) {
                i5 = i3 + 1;
                if (i5 != charSequence.length()) {
                    char charAt3 = charSequence.charAt(i5);
                    if (Character.isSurrogatePair(charAt2, charAt3)) {
                        i3 = Character.toCodePoint(charAt2, charAt3);
                        i4 = i + 1;
                        bArr[i] = (byte) ((i3 >>> 18) | 240);
                        i = i4 + 1;
                        bArr[i4] = (byte) (((i3 >>> 12) & 63) | 128);
                        i4 = i + 1;
                        bArr[i] = (byte) (((i3 >>> 6) & 63) | 128);
                        i = i4 + 1;
                        bArr[i4] = (byte) ((i3 & 63) | 128);
                        i3 = i5;
                        i3++;
                    } else {
                        i3 = i5;
                    }
                }
                throw new zzic(i3 - 1, length);
            } else {
                if ('?' <= charAt2 && charAt2 <= '?') {
                    bArr = i3 + 1;
                    if (bArr == charSequence.length() || Character.isSurrogatePair(charAt2, charSequence.charAt(bArr)) == null) {
                        throw new zzic(i3, length);
                    }
                }
                i2 = new StringBuilder(37);
                i2.append("Failed writing ");
                i2.append(charAt2);
                i2.append(" at index ");
                i2.append(i);
                throw new ArrayIndexOutOfBoundsException(i2.toString());
            }
            i = i5;
            i3++;
        }
        return i;
    }

    final void zzb(CharSequence charSequence, ByteBuffer byteBuffer) {
        zzia.zzc(charSequence, byteBuffer);
    }
}
