package com.google.android.gms.internal.measurement;

final class zzdu extends zzdz {
    private final int zzacd;
    private final int zzace;

    zzdu(byte[] bArr, int i, int i2) {
        super(bArr);
        zzdp.zzb(i, i + i2, (int) bArr.length);
        this.zzacd = i;
        this.zzace = i2;
    }

    public final byte zzr(int i) {
        int size = size();
        if (((size - (i + 1)) | i) >= 0) {
            return this.zzacg[this.zzacd + i];
        }
        if (i < 0) {
            StringBuilder stringBuilder = new StringBuilder(22);
            stringBuilder.append("Index < 0: ");
            stringBuilder.append(i);
            throw new ArrayIndexOutOfBoundsException(stringBuilder.toString());
        }
        StringBuilder stringBuilder2 = new StringBuilder(40);
        stringBuilder2.append("Index > length: ");
        stringBuilder2.append(i);
        stringBuilder2.append(", ");
        stringBuilder2.append(size);
        throw new ArrayIndexOutOfBoundsException(stringBuilder2.toString());
    }

    final byte zzs(int i) {
        return this.zzacg[this.zzacd + i];
    }

    public final int size() {
        return this.zzace;
    }

    protected final int zzkg() {
        return this.zzacd;
    }
}
