package com.google.android.gms.internal.ads;

import android.content.Context;
import com.google.android.gms.ads.internal.zzk;
import org.json.JSONObject;

@zzare
public final class zzasp implements zzasc {
    private zzalk<JSONObject, JSONObject> zzdql;
    private zzalk<JSONObject, JSONObject> zzdqn;

    public zzasp(Context context) {
        this.zzdqn = zzk.zzlt().zza(context, zzbaj.zzxc()).zza("google.afma.request.getAdDictionary", zzalp.zzddk, zzalp.zzddk);
        this.zzdql = zzk.zzlt().zza(context, zzbaj.zzxc()).zza("google.afma.sdkConstants.getSdkConstants", zzalp.zzddk, zzalp.zzddk);
    }

    public final zzalk<JSONObject, JSONObject> zztt() {
        return this.zzdql;
    }
}
