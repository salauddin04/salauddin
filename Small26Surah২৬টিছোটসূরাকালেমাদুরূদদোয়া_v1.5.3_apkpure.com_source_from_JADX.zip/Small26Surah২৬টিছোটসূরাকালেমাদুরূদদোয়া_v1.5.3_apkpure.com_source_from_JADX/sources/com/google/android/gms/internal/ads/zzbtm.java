package com.google.android.gms.internal.ads;

import java.util.Set;

public final class zzbtm implements zzdth<zzbtk> {
    private final zzdtt<Set<zzbuy<zzbtn>>> zzfhp;

    private zzbtm(zzdtt<Set<zzbuy<zzbtn>>> zzdtt) {
        this.zzfhp = zzdtt;
    }

    public static zzbtm zzu(zzdtt<Set<zzbuy<zzbtn>>> zzdtt) {
        return new zzbtm(zzdtt);
    }

    public final /* synthetic */ Object get() {
        return new zzbtk((Set) this.zzfhp.get());
    }
}
