package com.google.android.gms.internal.measurement;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.support.annotation.GuardedBy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class zzdd implements zzcp {
    @GuardedBy("SharedPreferencesLoader.class")
    static final Map<String, zzdd> zzaai = new HashMap();
    private final SharedPreferences zzaaj;
    private final OnSharedPreferenceChangeListener zzaak = new zzde(this);
    private final Object zzzk = new Object();
    private volatile Map<String, ?> zzzl;
    @GuardedBy("this")
    private final List<zzco> zzzm = new ArrayList();

    final /* synthetic */ void zza(android.content.SharedPreferences r1, java.lang.String r2) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:21:0x0029 in {11, 13, 16, 20} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = this;
        r1 = r0.zzzk;
        monitor-enter(r1);
        r2 = 0;
        r0.zzzl = r2;	 Catch:{ all -> 0x0026 }
        com.google.android.gms.internal.measurement.zzcw.zzjp();	 Catch:{ all -> 0x0026 }
        monitor-exit(r1);	 Catch:{ all -> 0x0026 }
        monitor-enter(r0);
        r1 = r0.zzzm;	 Catch:{ all -> 0x0023 }
        r1 = r1.iterator();	 Catch:{ all -> 0x0023 }
    L_0x0011:
        r2 = r1.hasNext();	 Catch:{ all -> 0x0023 }
        if (r2 == 0) goto L_0x0021;	 Catch:{ all -> 0x0023 }
    L_0x0017:
        r2 = r1.next();	 Catch:{ all -> 0x0023 }
        r2 = (com.google.android.gms.internal.measurement.zzco) r2;	 Catch:{ all -> 0x0023 }
        r2.zzjo();	 Catch:{ all -> 0x0023 }
        goto L_0x0011;	 Catch:{ all -> 0x0023 }
    L_0x0021:
        monitor-exit(r0);	 Catch:{ all -> 0x0023 }
        return;	 Catch:{ all -> 0x0023 }
    L_0x0023:
        r1 = move-exception;	 Catch:{ all -> 0x0023 }
        monitor-exit(r0);	 Catch:{ all -> 0x0023 }
        throw r1;
    L_0x0026:
        r2 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0026 }
        throw r2;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzdd.zza(android.content.SharedPreferences, java.lang.String):void");
    }

    static zzdd zze(Context context, String str) {
        boolean isUserUnlocked = (!zzck.zzji() || str.startsWith("direct_boot:")) ? true : zzck.isUserUnlocked(context);
        if (!isUserUnlocked) {
            return null;
        }
        zzdd zzdd;
        synchronized (zzdd.class) {
            zzdd = (zzdd) zzaai.get(str);
            if (zzdd == null) {
                if (str.startsWith("direct_boot:")) {
                    if (zzck.zzji()) {
                        context = context.createDeviceProtectedStorageContext();
                    }
                    context = context.getSharedPreferences(str.substring(12), 0);
                } else {
                    context = context.getSharedPreferences(str, 0);
                }
                zzdd = new zzdd(context);
                zzaai.put(str, zzdd);
            }
        }
        return zzdd;
    }

    private zzdd(SharedPreferences sharedPreferences) {
        this.zzaaj = sharedPreferences;
        this.zzaaj.registerOnSharedPreferenceChangeListener(this.zzaak);
    }

    public final Object zzca(String str) {
        Map map = this.zzzl;
        if (map == null) {
            synchronized (this.zzzk) {
                map = this.zzzl;
                if (map == null) {
                    map = this.zzaaj.getAll();
                    this.zzzl = map;
                }
            }
        }
        return map != null ? map.get(str) : null;
    }
}
