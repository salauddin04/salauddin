package com.google.android.gms.internal.measurement;

public interface zzes<T extends zzes<T>> extends Comparable<T> {
    zzgi zza(zzgi zzgi, zzgh zzgh);

    zzgo zza(zzgo zzgo, zzgo zzgo2);

    int zzgp();

    zzif zzma();

    zzik zzmb();

    boolean zzmc();

    boolean zzmd();
}
