package com.google.android.gms.internal.ads;

import android.content.Context;
import java.util.concurrent.Callable;

final /* synthetic */ class zzcgv implements Callable {
    private final Context zzcju;
    private final zzdh zzfwa;

    zzcgv(zzdh zzdh, Context context) {
        this.zzfwa = zzdh;
        this.zzcju = context;
    }

    public final Object call() {
        zzdh zzdh = this.zzfwa;
        return zzdh.zzcg().zza(this.zzcju);
    }
}
