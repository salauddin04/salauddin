package com.google.android.gms.internal.ads;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.dynamic.ObjectWrapper;

final class zzyk extends zzyq<zzzd> {
    private final /* synthetic */ Context val$context;
    private final /* synthetic */ String zzchv;
    private final /* synthetic */ zzamq zzchw;
    private final /* synthetic */ zzyf zzchx;

    zzyk(zzyf zzyf, Context context, String str, zzamq zzamq) {
        this.zzchx = zzyf;
        this.val$context = context;
        this.zzchv = str;
        this.zzchw = zzamq;
    }

    protected final /* synthetic */ Object zzov() {
        zzyf.zza(this.val$context, "native_ad");
        return new zzabk();
    }

    public final /* synthetic */ Object zzow() throws RemoteException {
        return this.zzchx.zzchn.zza(this.val$context, this.zzchv, this.zzchw);
    }

    public final /* synthetic */ Object zza(zzzt zzzt) throws RemoteException {
        return zzzt.zza(ObjectWrapper.wrap(this.val$context), this.zzchv, this.zzchw, 15000000);
    }
}
