package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzbt.zza;
import com.google.android.gms.internal.measurement.zzbt.zze;
import com.google.android.gms.internal.measurement.zzbt.zzh;
import java.io.IOException;

public final class zzch extends zzip<zzch> {
    private static volatile zzch[] zzxm;
    public String zzcf;
    public String zzcg;
    public String zzch;
    public String zzcj;
    public String zzcn;
    public String zzcp;
    public String zzdn;
    public String zzex;
    public String zzxf;
    public Integer zzxn;
    public zzcf[] zzxo;
    public zzh[] zzxp;
    public Long zzxq;
    public Long zzxr;
    public Long zzxs;
    public Long zzxt;
    public Long zzxu;
    public String zzxv;
    public String zzxw;
    public String zzxx;
    public Integer zzxy;
    public Long zzxz;
    public Long zzya;
    public String zzyb;
    public Boolean zzyc;
    public Long zzyd;
    public Integer zzye;
    public Boolean zzyf;
    public zza[] zzyg;
    public Integer zzyh;
    private Integer zzyi;
    private Integer zzyj;
    public String zzyk;
    public Long zzyl;
    public Long zzym;
    public String zzyn;
    private String zzyo;
    public Integer zzyp;
    public zze zzyq;
    public int[] zzyr;
    public Long zzys;
    public Long zzyt;

    public static zzch[] zzjg() {
        if (zzxm == null) {
            synchronized (zzit.zzanl) {
                if (zzxm == null) {
                    zzxm = new zzch[0];
                }
            }
        }
        return zzxm;
    }

    public zzch() {
        this.zzxn = null;
        this.zzxo = zzcf.zzjf();
        this.zzxp = new zzh[0];
        this.zzxq = null;
        this.zzxr = null;
        this.zzxs = null;
        this.zzxt = null;
        this.zzxu = null;
        this.zzxv = null;
        this.zzxw = null;
        this.zzxx = null;
        this.zzex = null;
        this.zzxy = null;
        this.zzcp = null;
        this.zzcf = null;
        this.zzcn = null;
        this.zzxz = null;
        this.zzya = null;
        this.zzyb = null;
        this.zzyc = null;
        this.zzcg = null;
        this.zzyd = null;
        this.zzye = null;
        this.zzdn = null;
        this.zzch = null;
        this.zzyf = null;
        this.zzyg = new zza[0];
        this.zzcj = null;
        this.zzyh = null;
        this.zzyi = null;
        this.zzyj = null;
        this.zzyk = null;
        this.zzyl = null;
        this.zzym = null;
        this.zzyn = null;
        this.zzyo = null;
        this.zzyp = null;
        this.zzxf = null;
        this.zzyq = null;
        this.zzyr = zziy.zzaiy;
        this.zzys = null;
        this.zzyt = null;
        this.zzand = null;
        this.zzanm = -1;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzch)) {
            return false;
        }
        zzch zzch = (zzch) obj;
        Integer num = this.zzxn;
        if (num == null) {
            if (zzch.zzxn != null) {
                return false;
            }
        } else if (!num.equals(zzch.zzxn)) {
            return false;
        }
        if (!zzit.equals(this.zzxo, zzch.zzxo) || !zzit.equals(this.zzxp, zzch.zzxp)) {
            return false;
        }
        Long l = this.zzxq;
        if (l == null) {
            if (zzch.zzxq != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzxq)) {
            return false;
        }
        l = this.zzxr;
        if (l == null) {
            if (zzch.zzxr != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzxr)) {
            return false;
        }
        l = this.zzxs;
        if (l == null) {
            if (zzch.zzxs != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzxs)) {
            return false;
        }
        l = this.zzxt;
        if (l == null) {
            if (zzch.zzxt != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzxt)) {
            return false;
        }
        l = this.zzxu;
        if (l == null) {
            if (zzch.zzxu != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzxu)) {
            return false;
        }
        String str = this.zzxv;
        if (str == null) {
            if (zzch.zzxv != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzxv)) {
            return false;
        }
        str = this.zzxw;
        if (str == null) {
            if (zzch.zzxw != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzxw)) {
            return false;
        }
        str = this.zzxx;
        if (str == null) {
            if (zzch.zzxx != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzxx)) {
            return false;
        }
        str = this.zzex;
        if (str == null) {
            if (zzch.zzex != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzex)) {
            return false;
        }
        num = this.zzxy;
        if (num == null) {
            if (zzch.zzxy != null) {
                return false;
            }
        } else if (!num.equals(zzch.zzxy)) {
            return false;
        }
        str = this.zzcp;
        if (str == null) {
            if (zzch.zzcp != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzcp)) {
            return false;
        }
        str = this.zzcf;
        if (str == null) {
            if (zzch.zzcf != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzcf)) {
            return false;
        }
        str = this.zzcn;
        if (str == null) {
            if (zzch.zzcn != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzcn)) {
            return false;
        }
        l = this.zzxz;
        if (l == null) {
            if (zzch.zzxz != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzxz)) {
            return false;
        }
        l = this.zzya;
        if (l == null) {
            if (zzch.zzya != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzya)) {
            return false;
        }
        str = this.zzyb;
        if (str == null) {
            if (zzch.zzyb != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzyb)) {
            return false;
        }
        Boolean bool = this.zzyc;
        if (bool == null) {
            if (zzch.zzyc != null) {
                return false;
            }
        } else if (!bool.equals(zzch.zzyc)) {
            return false;
        }
        str = this.zzcg;
        if (str == null) {
            if (zzch.zzcg != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzcg)) {
            return false;
        }
        l = this.zzyd;
        if (l == null) {
            if (zzch.zzyd != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzyd)) {
            return false;
        }
        num = this.zzye;
        if (num == null) {
            if (zzch.zzye != null) {
                return false;
            }
        } else if (!num.equals(zzch.zzye)) {
            return false;
        }
        str = this.zzdn;
        if (str == null) {
            if (zzch.zzdn != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzdn)) {
            return false;
        }
        str = this.zzch;
        if (str == null) {
            if (zzch.zzch != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzch)) {
            return false;
        }
        bool = this.zzyf;
        if (bool == null) {
            if (zzch.zzyf != null) {
                return false;
            }
        } else if (!bool.equals(zzch.zzyf)) {
            return false;
        }
        if (!zzit.equals(this.zzyg, zzch.zzyg)) {
            return false;
        }
        str = this.zzcj;
        if (str == null) {
            if (zzch.zzcj != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzcj)) {
            return false;
        }
        num = this.zzyh;
        if (num == null) {
            if (zzch.zzyh != null) {
                return false;
            }
        } else if (!num.equals(zzch.zzyh)) {
            return false;
        }
        num = this.zzyi;
        if (num == null) {
            if (zzch.zzyi != null) {
                return false;
            }
        } else if (!num.equals(zzch.zzyi)) {
            return false;
        }
        num = this.zzyj;
        if (num == null) {
            if (zzch.zzyj != null) {
                return false;
            }
        } else if (!num.equals(zzch.zzyj)) {
            return false;
        }
        str = this.zzyk;
        if (str == null) {
            if (zzch.zzyk != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzyk)) {
            return false;
        }
        l = this.zzyl;
        if (l == null) {
            if (zzch.zzyl != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzyl)) {
            return false;
        }
        l = this.zzym;
        if (l == null) {
            if (zzch.zzym != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzym)) {
            return false;
        }
        str = this.zzyn;
        if (str == null) {
            if (zzch.zzyn != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzyn)) {
            return false;
        }
        str = this.zzyo;
        if (str == null) {
            if (zzch.zzyo != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzyo)) {
            return false;
        }
        num = this.zzyp;
        if (num == null) {
            if (zzch.zzyp != null) {
                return false;
            }
        } else if (!num.equals(zzch.zzyp)) {
            return false;
        }
        str = this.zzxf;
        if (str == null) {
            if (zzch.zzxf != null) {
                return false;
            }
        } else if (!str.equals(zzch.zzxf)) {
            return false;
        }
        zzez zzez = this.zzyq;
        if (zzez == null) {
            if (zzch.zzyq != null) {
                return false;
            }
        } else if (!zzez.equals(zzch.zzyq)) {
            return false;
        }
        if (!zzit.equals(this.zzyr, zzch.zzyr)) {
            return false;
        }
        l = this.zzys;
        if (l == null) {
            if (zzch.zzys != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzys)) {
            return false;
        }
        l = this.zzyt;
        if (l == null) {
            if (zzch.zzyt != null) {
                return false;
            }
        } else if (!l.equals(zzch.zzyt)) {
            return false;
        }
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                return this.zzand.equals(zzch.zzand);
            }
        }
        if (zzch.zzand != null) {
            if (zzch.zzand.isEmpty() == null) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int i;
        int hashCode = (getClass().getName().hashCode() + 527) * 31;
        Integer num = this.zzxn;
        int i2 = 0;
        hashCode = (((((hashCode + (num == null ? 0 : num.hashCode())) * 31) + zzit.hashCode(this.zzxo)) * 31) + zzit.hashCode(this.zzxp)) * 31;
        Long l = this.zzxq;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        l = this.zzxr;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        l = this.zzxs;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        l = this.zzxt;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        l = this.zzxu;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        String str = this.zzxv;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        str = this.zzxw;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        str = this.zzxx;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        str = this.zzex;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        num = this.zzxy;
        hashCode = (hashCode + (num == null ? 0 : num.hashCode())) * 31;
        str = this.zzcp;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        str = this.zzcf;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        str = this.zzcn;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        l = this.zzxz;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        l = this.zzya;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        str = this.zzyb;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        Boolean bool = this.zzyc;
        hashCode = (hashCode + (bool == null ? 0 : bool.hashCode())) * 31;
        str = this.zzcg;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        l = this.zzyd;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        num = this.zzye;
        hashCode = (hashCode + (num == null ? 0 : num.hashCode())) * 31;
        str = this.zzdn;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        str = this.zzch;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        bool = this.zzyf;
        hashCode = (((hashCode + (bool == null ? 0 : bool.hashCode())) * 31) + zzit.hashCode(this.zzyg)) * 31;
        str = this.zzcj;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        num = this.zzyh;
        hashCode = (hashCode + (num == null ? 0 : num.hashCode())) * 31;
        num = this.zzyi;
        hashCode = (hashCode + (num == null ? 0 : num.hashCode())) * 31;
        num = this.zzyj;
        hashCode = (hashCode + (num == null ? 0 : num.hashCode())) * 31;
        str = this.zzyk;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        l = this.zzyl;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        l = this.zzym;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        str = this.zzyn;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        str = this.zzyo;
        hashCode = (hashCode + (str == null ? 0 : str.hashCode())) * 31;
        num = this.zzyp;
        hashCode = (hashCode + (num == null ? 0 : num.hashCode())) * 31;
        str = this.zzxf;
        hashCode += str == null ? 0 : str.hashCode();
        zzez zzez = this.zzyq;
        hashCode *= 31;
        if (zzez == null) {
            i = 0;
        } else {
            i = zzez.hashCode();
        }
        hashCode = (((hashCode + i) * 31) + zzit.hashCode(this.zzyr)) * 31;
        l = this.zzys;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        l = this.zzyt;
        hashCode = (hashCode + (l == null ? 0 : l.hashCode())) * 31;
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                i2 = this.zzand.hashCode();
            }
        }
        return hashCode + i2;
    }

    public final void zza(zzin zzin) throws IOException {
        int i;
        zzgh zzgh;
        Integer num = this.zzxn;
        if (num != null) {
            zzin.zzc(1, num.intValue());
        }
        zzcf[] zzcfArr = this.zzxo;
        if (zzcfArr != null && zzcfArr.length > 0) {
            i = 0;
            while (true) {
                zzcf[] zzcfArr2 = this.zzxo;
                if (i >= zzcfArr2.length) {
                    break;
                }
                zziv zziv = zzcfArr2[i];
                if (zziv != null) {
                    zzin.zza(2, zziv);
                }
                i++;
            }
        }
        zzh[] zzhArr = this.zzxp;
        if (zzhArr != null && zzhArr.length > 0) {
            i = 0;
            while (true) {
                zzh[] zzhArr2 = this.zzxp;
                if (i >= zzhArr2.length) {
                    break;
                }
                zzgh = zzhArr2[i];
                if (zzgh != null) {
                    zzin.zze(3, zzgh);
                }
                i++;
            }
        }
        Long l = this.zzxq;
        if (l != null) {
            zzin.zzi(4, l.longValue());
        }
        l = this.zzxr;
        if (l != null) {
            zzin.zzi(5, l.longValue());
        }
        l = this.zzxs;
        if (l != null) {
            zzin.zzi(6, l.longValue());
        }
        l = this.zzxu;
        if (l != null) {
            zzin.zzi(7, l.longValue());
        }
        String str = this.zzxv;
        if (str != null) {
            zzin.zzb(8, str);
        }
        str = this.zzxw;
        if (str != null) {
            zzin.zzb(9, str);
        }
        str = this.zzxx;
        if (str != null) {
            zzin.zzb(10, str);
        }
        str = this.zzex;
        if (str != null) {
            zzin.zzb(11, str);
        }
        num = this.zzxy;
        if (num != null) {
            zzin.zzc(12, num.intValue());
        }
        str = this.zzcp;
        if (str != null) {
            zzin.zzb(13, str);
        }
        str = this.zzcf;
        if (str != null) {
            zzin.zzb(14, str);
        }
        str = this.zzcn;
        if (str != null) {
            zzin.zzb(16, str);
        }
        l = this.zzxz;
        if (l != null) {
            zzin.zzi(17, l.longValue());
        }
        l = this.zzya;
        if (l != null) {
            zzin.zzi(18, l.longValue());
        }
        str = this.zzyb;
        if (str != null) {
            zzin.zzb(19, str);
        }
        Boolean bool = this.zzyc;
        if (bool != null) {
            zzin.zzb(20, bool.booleanValue());
        }
        str = this.zzcg;
        if (str != null) {
            zzin.zzb(21, str);
        }
        l = this.zzyd;
        if (l != null) {
            zzin.zzi(22, l.longValue());
        }
        num = this.zzye;
        if (num != null) {
            zzin.zzc(23, num.intValue());
        }
        str = this.zzdn;
        if (str != null) {
            zzin.zzb(24, str);
        }
        str = this.zzch;
        if (str != null) {
            zzin.zzb(25, str);
        }
        l = this.zzxt;
        if (l != null) {
            zzin.zzi(26, l.longValue());
        }
        bool = this.zzyf;
        if (bool != null) {
            zzin.zzb(28, bool.booleanValue());
        }
        zza[] zzaArr = this.zzyg;
        if (zzaArr != null && zzaArr.length > 0) {
            i = 0;
            while (true) {
                zza[] zzaArr2 = this.zzyg;
                if (i >= zzaArr2.length) {
                    break;
                }
                zzgh = zzaArr2[i];
                if (zzgh != null) {
                    zzin.zze(29, zzgh);
                }
                i++;
            }
        }
        str = this.zzcj;
        if (str != null) {
            zzin.zzb(30, str);
        }
        num = this.zzyh;
        if (num != null) {
            zzin.zzc(31, num.intValue());
        }
        num = this.zzyi;
        if (num != null) {
            zzin.zzc(32, num.intValue());
        }
        num = this.zzyj;
        if (num != null) {
            zzin.zzc(33, num.intValue());
        }
        str = this.zzyk;
        if (str != null) {
            zzin.zzb(34, str);
        }
        l = this.zzyl;
        if (l != null) {
            zzin.zzi(35, l.longValue());
        }
        l = this.zzym;
        if (l != null) {
            zzin.zzi(36, l.longValue());
        }
        str = this.zzyn;
        if (str != null) {
            zzin.zzb(37, str);
        }
        str = this.zzyo;
        if (str != null) {
            zzin.zzb(38, str);
        }
        num = this.zzyp;
        if (num != null) {
            zzin.zzc(39, num.intValue());
        }
        str = this.zzxf;
        if (str != null) {
            zzin.zzb(41, str);
        }
        zzgh zzgh2 = this.zzyq;
        if (zzgh2 != null) {
            zzin.zze(44, zzgh2);
        }
        int[] iArr = this.zzyr;
        if (iArr != null && iArr.length > 0) {
            i = 0;
            while (true) {
                int[] iArr2 = this.zzyr;
                if (i >= iArr2.length) {
                    break;
                }
                int i2 = iArr2[i];
                zzin.zzb(45, 0);
                zzin.zzbl(i2);
                i++;
            }
        }
        l = this.zzys;
        if (l != null) {
            zzin.zzi(46, l.longValue());
        }
        l = this.zzyt;
        if (l != null) {
            zzin.zzi(47, l.longValue());
        }
        super.zza(zzin);
    }

    protected final int zzja() {
        int i;
        int zzja = super.zzja();
        Integer num = this.zzxn;
        if (num != null) {
            zzja += zzin.zzg(1, num.intValue());
        }
        zzcf[] zzcfArr = this.zzxo;
        int i2 = 0;
        if (zzcfArr != null && zzcfArr.length > 0) {
            i = zzja;
            zzja = 0;
            while (true) {
                zzcf[] zzcfArr2 = this.zzxo;
                if (zzja >= zzcfArr2.length) {
                    break;
                }
                zziv zziv = zzcfArr2[zzja];
                if (zziv != null) {
                    i += zzin.zzb(2, zziv);
                }
                zzja++;
            }
            zzja = i;
        }
        zzh[] zzhArr = this.zzxp;
        if (zzhArr != null && zzhArr.length > 0) {
            i = zzja;
            zzja = 0;
            while (true) {
                zzh[] zzhArr2 = this.zzxp;
                if (zzja >= zzhArr2.length) {
                    break;
                }
                zzgh zzgh = zzhArr2[zzja];
                if (zzgh != null) {
                    i += zzeg.zzc(3, zzgh);
                }
                zzja++;
            }
            zzja = i;
        }
        Long l = this.zzxq;
        if (l != null) {
            zzja += zzin.zzd(4, l.longValue());
        }
        l = this.zzxr;
        if (l != null) {
            zzja += zzin.zzd(5, l.longValue());
        }
        l = this.zzxs;
        if (l != null) {
            zzja += zzin.zzd(6, l.longValue());
        }
        l = this.zzxu;
        if (l != null) {
            zzja += zzin.zzd(7, l.longValue());
        }
        String str = this.zzxv;
        if (str != null) {
            zzja += zzin.zzc(8, str);
        }
        str = this.zzxw;
        if (str != null) {
            zzja += zzin.zzc(9, str);
        }
        str = this.zzxx;
        if (str != null) {
            zzja += zzin.zzc(10, str);
        }
        str = this.zzex;
        if (str != null) {
            zzja += zzin.zzc(11, str);
        }
        num = this.zzxy;
        if (num != null) {
            zzja += zzin.zzg(12, num.intValue());
        }
        str = this.zzcp;
        if (str != null) {
            zzja += zzin.zzc(13, str);
        }
        str = this.zzcf;
        if (str != null) {
            zzja += zzin.zzc(14, str);
        }
        str = this.zzcn;
        if (str != null) {
            zzja += zzin.zzc(16, str);
        }
        l = this.zzxz;
        if (l != null) {
            zzja += zzin.zzd(17, l.longValue());
        }
        l = this.zzya;
        if (l != null) {
            zzja += zzin.zzd(18, l.longValue());
        }
        str = this.zzyb;
        if (str != null) {
            zzja += zzin.zzc(19, str);
        }
        Boolean bool = this.zzyc;
        if (bool != null) {
            bool.booleanValue();
            zzja += zzin.zzaj(20) + 1;
        }
        str = this.zzcg;
        if (str != null) {
            zzja += zzin.zzc(21, str);
        }
        l = this.zzyd;
        if (l != null) {
            zzja += zzin.zzd(22, l.longValue());
        }
        num = this.zzye;
        if (num != null) {
            zzja += zzin.zzg(23, num.intValue());
        }
        str = this.zzdn;
        if (str != null) {
            zzja += zzin.zzc(24, str);
        }
        str = this.zzch;
        if (str != null) {
            zzja += zzin.zzc(25, str);
        }
        l = this.zzxt;
        if (l != null) {
            zzja += zzin.zzd(26, l.longValue());
        }
        bool = this.zzyf;
        if (bool != null) {
            bool.booleanValue();
            zzja += zzin.zzaj(28) + 1;
        }
        zza[] zzaArr = this.zzyg;
        if (zzaArr != null && zzaArr.length > 0) {
            i = zzja;
            zzja = 0;
            while (true) {
                zza[] zzaArr2 = this.zzyg;
                if (zzja >= zzaArr2.length) {
                    break;
                }
                zzgh zzgh2 = zzaArr2[zzja];
                if (zzgh2 != null) {
                    i += zzeg.zzc(29, zzgh2);
                }
                zzja++;
            }
            zzja = i;
        }
        str = this.zzcj;
        if (str != null) {
            zzja += zzin.zzc(30, str);
        }
        num = this.zzyh;
        if (num != null) {
            zzja += zzin.zzg(31, num.intValue());
        }
        num = this.zzyi;
        if (num != null) {
            zzja += zzin.zzg(32, num.intValue());
        }
        num = this.zzyj;
        if (num != null) {
            zzja += zzin.zzg(33, num.intValue());
        }
        str = this.zzyk;
        if (str != null) {
            zzja += zzin.zzc(34, str);
        }
        l = this.zzyl;
        if (l != null) {
            zzja += zzin.zzd(35, l.longValue());
        }
        l = this.zzym;
        if (l != null) {
            zzja += zzin.zzd(36, l.longValue());
        }
        str = this.zzyn;
        if (str != null) {
            zzja += zzin.zzc(37, str);
        }
        str = this.zzyo;
        if (str != null) {
            zzja += zzin.zzc(38, str);
        }
        num = this.zzyp;
        if (num != null) {
            zzja += zzin.zzg(39, num.intValue());
        }
        str = this.zzxf;
        if (str != null) {
            zzja += zzin.zzc(41, str);
        }
        zzgh zzgh3 = this.zzyq;
        if (zzgh3 != null) {
            zzja += zzeg.zzc(44, zzgh3);
        }
        int[] iArr = this.zzyr;
        if (iArr != null && iArr.length > 0) {
            int[] iArr2;
            i = 0;
            while (true) {
                iArr2 = this.zzyr;
                if (i2 >= iArr2.length) {
                    break;
                }
                i += zzin.zzar(iArr2[i2]);
                i2++;
            }
            zzja = (zzja + i) + (iArr2.length * 2);
        }
        l = this.zzys;
        if (l != null) {
            zzja += zzin.zzd(46, l.longValue());
        }
        l = this.zzyt;
        return l != null ? zzja + zzin.zzd(47, l.longValue()) : zzja;
    }

    public static zzch zzf(byte[] bArr) throws zziu {
        return (zzch) zziv.zza(new zzch(), bArr);
    }

    public final /* synthetic */ zziv zza(zzim zzim) throws IOException {
        while (true) {
            int zzkj = zzim.zzkj();
            int length;
            Object obj;
            int[] iArr;
            switch (zzkj) {
                case 0:
                    return this;
                case 8:
                    this.zzxn = Integer.valueOf(zzim.zzlb());
                    break;
                case 18:
                    zzkj = zziy.zzb(zzim, 18);
                    zzcf[] zzcfArr = this.zzxo;
                    length = zzcfArr == null ? 0 : zzcfArr.length;
                    obj = new zzcf[(zzkj + length)];
                    if (length != 0) {
                        System.arraycopy(this.zzxo, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = new zzcf();
                        zzim.zza(obj[length]);
                        zzim.zzkj();
                        length++;
                    }
                    obj[length] = new zzcf();
                    zzim.zza(obj[length]);
                    this.zzxo = obj;
                    break;
                case 26:
                    zzkj = zziy.zzb(zzim, 26);
                    zzh[] zzhArr = this.zzxp;
                    length = zzhArr == null ? 0 : zzhArr.length;
                    obj = new zzh[(zzkj + length)];
                    if (length != 0) {
                        System.arraycopy(this.zzxp, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = (zzh) zzim.zza(zzh.zzgs());
                        zzim.zzkj();
                        length++;
                    }
                    obj[length] = (zzh) zzim.zza(zzh.zzgs());
                    this.zzxp = obj;
                    break;
                case 32:
                    this.zzxq = Long.valueOf(zzim.zzlc());
                    break;
                case 40:
                    this.zzxr = Long.valueOf(zzim.zzlc());
                    break;
                case 48:
                    this.zzxs = Long.valueOf(zzim.zzlc());
                    break;
                case 56:
                    this.zzxu = Long.valueOf(zzim.zzlc());
                    break;
                case 66:
                    this.zzxv = zzim.readString();
                    break;
                case 74:
                    this.zzxw = zzim.readString();
                    break;
                case 82:
                    this.zzxx = zzim.readString();
                    break;
                case 90:
                    this.zzex = zzim.readString();
                    break;
                case 96:
                    this.zzxy = Integer.valueOf(zzim.zzlb());
                    break;
                case 106:
                    this.zzcp = zzim.readString();
                    break;
                case 114:
                    this.zzcf = zzim.readString();
                    break;
                case 130:
                    this.zzcn = zzim.readString();
                    break;
                case 136:
                    this.zzxz = Long.valueOf(zzim.zzlc());
                    break;
                case 144:
                    this.zzya = Long.valueOf(zzim.zzlc());
                    break;
                case 154:
                    this.zzyb = zzim.readString();
                    break;
                case 160:
                    this.zzyc = Boolean.valueOf(zzim.zzkp());
                    break;
                case 170:
                    this.zzcg = zzim.readString();
                    break;
                case 176:
                    this.zzyd = Long.valueOf(zzim.zzlc());
                    break;
                case 184:
                    this.zzye = Integer.valueOf(zzim.zzlb());
                    break;
                case 194:
                    this.zzdn = zzim.readString();
                    break;
                case 202:
                    this.zzch = zzim.readString();
                    break;
                case 208:
                    this.zzxt = Long.valueOf(zzim.zzlc());
                    break;
                case 224:
                    this.zzyf = Boolean.valueOf(zzim.zzkp());
                    break;
                case 234:
                    zzkj = zziy.zzb(zzim, 234);
                    zza[] zzaArr = this.zzyg;
                    length = zzaArr == null ? 0 : zzaArr.length;
                    obj = new zza[(zzkj + length)];
                    if (length != 0) {
                        System.arraycopy(this.zzyg, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = (zza) zzim.zza(zza.zzgs());
                        zzim.zzkj();
                        length++;
                    }
                    obj[length] = (zza) zzim.zza(zza.zzgs());
                    this.zzyg = obj;
                    break;
                case 242:
                    this.zzcj = zzim.readString();
                    break;
                case 248:
                    this.zzyh = Integer.valueOf(zzim.zzlb());
                    break;
                case 256:
                    this.zzyi = Integer.valueOf(zzim.zzlb());
                    break;
                case 264:
                    this.zzyj = Integer.valueOf(zzim.zzlb());
                    break;
                case 274:
                    this.zzyk = zzim.readString();
                    break;
                case 280:
                    this.zzyl = Long.valueOf(zzim.zzlc());
                    break;
                case 288:
                    this.zzym = Long.valueOf(zzim.zzlc());
                    break;
                case 298:
                    this.zzyn = zzim.readString();
                    break;
                case 306:
                    this.zzyo = zzim.readString();
                    break;
                case 312:
                    this.zzyp = Integer.valueOf(zzim.zzlb());
                    break;
                case 330:
                    this.zzxf = zzim.readString();
                    break;
                case 354:
                    zze zze = (zze) zzim.zza(zze.zzgs());
                    zzez zzez = this.zzyq;
                    if (zzez != null) {
                        zze = (zze) ((zzez) ((zze.zza) ((zze.zza) zzez.zzmh()).zza((zzez) zze)).zzmr());
                    }
                    this.zzyq = zze;
                    break;
                case 360:
                    zzkj = zziy.zzb(zzim, 360);
                    iArr = this.zzyr;
                    length = iArr == null ? 0 : iArr.length;
                    obj = new int[(zzkj + length)];
                    if (length != 0) {
                        System.arraycopy(this.zzyr, 0, obj, 0, length);
                    }
                    while (length < obj.length - 1) {
                        obj[length] = zzim.zzlb();
                        zzim.zzkj();
                        length++;
                    }
                    obj[length] = zzim.zzlb();
                    this.zzyr = obj;
                    break;
                case 362:
                    zzkj = zzim.zzx(zzim.zzlb());
                    length = zzim.getPosition();
                    int i = 0;
                    while (zzim.zzpd() > 0) {
                        zzim.zzlb();
                        i++;
                    }
                    zzim.zzbj(length);
                    iArr = this.zzyr;
                    length = iArr == null ? 0 : iArr.length;
                    Object obj2 = new int[(i + length)];
                    if (length != 0) {
                        System.arraycopy(this.zzyr, 0, obj2, 0, length);
                    }
                    while (length < obj2.length) {
                        obj2[length] = zzim.zzlb();
                        length++;
                    }
                    this.zzyr = obj2;
                    zzim.zzy(zzkj);
                    break;
                case 368:
                    this.zzys = Long.valueOf(zzim.zzlc());
                    break;
                case 376:
                    this.zzyt = Long.valueOf(zzim.zzlc());
                    break;
                default:
                    if (super.zza(zzim, zzkj)) {
                        break;
                    }
                    return this;
            }
        }
    }
}
