package com.google.android.gms.internal.ads;

import android.content.Context;

final /* synthetic */ class zzcnp implements zzbwy {
    private final zzbbs zzbxh;
    private final zzcxl zzfhl;
    private final zzbha zzfrw;
    private final zzcnk zzgbv;

    zzcnp(zzcnk zzcnk, zzbha zzbha, zzcxl zzcxl, zzbbs zzbbs) {
        this.zzgbv = zzcnk;
        this.zzfrw = zzbha;
        this.zzfhl = zzcxl;
        this.zzbxh = zzbbs;
    }

    public final void zza(boolean z, Context context) {
        this.zzgbv.zzb(this.zzfrw, this.zzfhl, this.zzbxh, z, context);
    }
}
