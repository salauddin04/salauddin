package com.google.android.gms.internal.ads;

public interface zzdpk extends zzdpl, Cloneable {
    zzdpj zzaxz();

    zzdpj zzaya();

    zzdpk zzi(zzdpj zzdpj);
}
