package com.google.android.gms.internal.ads;

import android.database.sqlite.SQLiteDatabase;
import com.google.android.gms.internal.ads.zzwr.zzi.zza;
import java.util.ArrayList;

public final class zzcjp {
    public static ArrayList<zza> zza(SQLiteDatabase sQLiteDatabase) {
        ArrayList<zza> arrayList = new ArrayList();
        String[] strArr = new String[1];
        String str = "serialized_proto_data";
        strArr[0] = str;
        sQLiteDatabase = sQLiteDatabase.query("offline_signal_contents", strArr, null, null, null, null, null);
        while (sQLiteDatabase.moveToNext()) {
            try {
                arrayList.add(zza.zzh(sQLiteDatabase.getBlob(sQLiteDatabase.getColumnIndexOrThrow(str))));
            } catch (zzdoj e) {
                zzbae.zzen("Unable to deserialize proto from offline signals database:");
                zzbae.zzen(e.getMessage());
            }
        }
        sQLiteDatabase.close();
        return arrayList;
    }

    public static int zza(SQLiteDatabase sQLiteDatabase, int i) {
        String[] strArr = new String[1];
        String str = "total";
        int i2 = 0;
        strArr[0] = str;
        String[] strArr2 = new String[1];
        if (i == 1) {
            strArr2[0] = "failed_requests";
        } else if (i == 2) {
            strArr2[0] = "total_requests";
        }
        SQLiteDatabase sQLiteDatabase2 = sQLiteDatabase;
        sQLiteDatabase = sQLiteDatabase2.query("offline_signal_statistics", strArr, "statistic_name = ?", strArr2, null, null, null);
        if (sQLiteDatabase.getCount() > 0) {
            sQLiteDatabase.moveToNext();
            i2 = 0 + sQLiteDatabase.getInt(sQLiteDatabase.getColumnIndexOrThrow(str));
        }
        sQLiteDatabase.close();
        return i2;
    }
}
