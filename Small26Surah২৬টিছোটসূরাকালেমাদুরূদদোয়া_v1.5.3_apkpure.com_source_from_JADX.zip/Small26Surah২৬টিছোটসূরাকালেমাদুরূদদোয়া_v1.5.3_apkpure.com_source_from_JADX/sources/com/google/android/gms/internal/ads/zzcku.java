package com.google.android.gms.internal.ads;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class zzcku implements zzcju<zzbne> {
    private final ScheduledExecutorService zzfiw;
    private final zzbrl zzfkw;
    private final zzbbm zzfqw;
    private final zzbob zzgad;
    private final zzcka zzgae;

    public zzcku(zzbob zzbob, zzcka zzcka, zzbrl zzbrl, ScheduledExecutorService scheduledExecutorService, zzbbm zzbbm) {
        this.zzgad = zzbob;
        this.zzgae = zzcka;
        this.zzfkw = zzbrl;
        this.zzfiw = scheduledExecutorService;
        this.zzfqw = zzbbm;
    }

    public final boolean zza(zzcxt zzcxt, zzcxl zzcxl) {
        return (zzcxt.zzgkx.zzfjp.zzamn() == null || this.zzgae.zza(zzcxt, zzcxl) == null) ? null : true;
    }

    public final zzbbi<zzbne> zzb(zzcxt zzcxt, zzcxl zzcxl) {
        return this.zzfqw.zza(new zzckv(this, zzcxt, zzcxl));
    }

    final /* synthetic */ zzbne zzc(zzcxt zzcxt, zzcxl zzcxl) throws Exception {
        return this.zzgad.zza(new zzbpq(zzcxt, zzcxl, null), new zzboo(zzcxt.zzgkx.zzfjp.zzamn(), new zzckw(this, zzcxt, zzcxl))).zzaeb();
    }

    final /* synthetic */ void zzd(zzcxt zzcxt, zzcxl zzcxl) {
        zzbas.zza(zzbas.zza(this.zzgae.zzb(zzcxt, zzcxl), (long) zzcxl.zzgkn, TimeUnit.SECONDS, this.zzfiw), new zzckx(this), this.zzfqw);
    }
}
