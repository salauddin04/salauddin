package com.google.android.gms.internal.ads;

final /* synthetic */ class zzclj implements Runnable {
    private final zzbha zzemh;

    zzclj(zzbha zzbha) {
        this.zzemh = zzbha;
    }

    public final void run() {
        this.zzemh.zzaac();
    }
}
