package com.google.android.gms.internal.ads;

import javax.annotation.concurrent.GuardedBy;
import org.json.JSONObject;

public final class zzcpk extends zzapa {
    private final zzcpj zzgdk;
    private zzbbs<JSONObject> zzgdl;
    private final JSONObject zzgdm = new JSONObject();
    @GuardedBy("this")
    private boolean zzgdn = false;

    public zzcpk(com.google.android.gms.internal.ads.zzcpj r2, com.google.android.gms.internal.ads.zzbbs<org.json.JSONObject> r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r1 = this;
        r1.<init>();
        r0 = new org.json.JSONObject;
        r0.<init>();
        r1.zzgdm = r0;
        r0 = 0;
        r1.zzgdn = r0;
        r1.zzgdl = r3;
        r1.zzgdk = r2;
        r2 = r1.zzgdm;	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r3 = "adapter_version";	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r0 = r1.zzgdk;	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r0 = r0.zzgdj;	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r0 = r0.zzsx();	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r0 = r0.toString();	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r2.put(r3, r0);	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r2 = r1.zzgdm;	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r3 = "sdk_version";	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r0 = r1.zzgdk;	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r0 = r0.zzgdj;	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r0 = r0.zzsy();	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r0 = r0.toString();	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r2.put(r3, r0);	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r2 = r1.zzgdm;	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r3 = "name";	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r0 = r1.zzgdk;	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r0 = r0.zzfir;	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
        r2.put(r3, r0);	 Catch:{ JSONException -> 0x0042, JSONException -> 0x0042, JSONException -> 0x0042 }
    L_0x0042:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzcpk.<init>(com.google.android.gms.internal.ads.zzcpj, com.google.android.gms.internal.ads.zzbbs):void");
    }

    public final synchronized void zzdc(java.lang.String r3) throws android.os.RemoteException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r2 = this;
        monitor-enter(r2);
        r0 = r2.zzgdn;	 Catch:{ all -> 0x0023 }
        if (r0 == 0) goto L_0x0007;
    L_0x0005:
        monitor-exit(r2);
        return;
    L_0x0007:
        if (r3 != 0) goto L_0x0010;
    L_0x0009:
        r3 = "Adapter returned null signals";	 Catch:{ all -> 0x0023 }
        r2.onFailure(r3);	 Catch:{ all -> 0x0023 }
        monitor-exit(r2);
        return;
    L_0x0010:
        r0 = r2.zzgdm;	 Catch:{ JSONException -> 0x0017 }
        r1 = "signals";	 Catch:{ JSONException -> 0x0017 }
        r0.put(r1, r3);	 Catch:{ JSONException -> 0x0017 }
    L_0x0017:
        r3 = r2.zzgdl;	 Catch:{ all -> 0x0023 }
        r0 = r2.zzgdm;	 Catch:{ all -> 0x0023 }
        r3.set(r0);	 Catch:{ all -> 0x0023 }
        r3 = 1;	 Catch:{ all -> 0x0023 }
        r2.zzgdn = r3;	 Catch:{ all -> 0x0023 }
        monitor-exit(r2);
        return;
    L_0x0023:
        r3 = move-exception;
        monitor-exit(r2);
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzcpk.zzdc(java.lang.String):void");
    }

    public final synchronized void onFailure(java.lang.String r3) throws android.os.RemoteException {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r2 = this;
        monitor-enter(r2);
        r0 = r2.zzgdn;	 Catch:{ all -> 0x001a }
        if (r0 == 0) goto L_0x0007;
    L_0x0005:
        monitor-exit(r2);
        return;
    L_0x0007:
        r0 = r2.zzgdm;	 Catch:{ JSONException -> 0x000e }
        r1 = "signal_error";	 Catch:{ JSONException -> 0x000e }
        r0.put(r1, r3);	 Catch:{ JSONException -> 0x000e }
    L_0x000e:
        r3 = r2.zzgdl;	 Catch:{ all -> 0x001a }
        r0 = r2.zzgdm;	 Catch:{ all -> 0x001a }
        r3.set(r0);	 Catch:{ all -> 0x001a }
        r3 = 1;	 Catch:{ all -> 0x001a }
        r2.zzgdn = r3;	 Catch:{ all -> 0x001a }
        monitor-exit(r2);
        return;
    L_0x001a:
        r3 = move-exception;
        monitor-exit(r2);
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzcpk.onFailure(java.lang.String):void");
    }
}
