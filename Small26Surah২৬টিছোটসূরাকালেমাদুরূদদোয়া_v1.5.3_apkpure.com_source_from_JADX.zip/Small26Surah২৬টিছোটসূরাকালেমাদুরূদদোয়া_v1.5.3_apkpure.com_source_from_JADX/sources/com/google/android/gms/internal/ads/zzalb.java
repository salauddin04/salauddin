package com.google.android.gms.internal.ads;

import com.google.android.gms.common.internal.Preconditions;

public final class zzalb extends zzbbx<zzajx> {
    private final Object lock = new Object();
    private zzayq<zzajx> zzdce;
    private boolean zzdcy;
    private int zzdcz;

    public zzalb(zzayq<zzajx> zzayq) {
        this.zzdce = zzayq;
        this.zzdcy = false;
        this.zzdcz = 0;
    }

    public final zzakx zzrx() {
        zzakx zzakx = new zzakx(this);
        synchronized (this.lock) {
            zza(new zzalc(this, zzakx), new zzald(this, zzakx));
            Preconditions.checkState(this.zzdcz >= 0);
            this.zzdcz++;
        }
        return zzakx;
    }

    protected final void zzry() {
        synchronized (this.lock) {
            Preconditions.checkState(this.zzdcz > 0);
            zzaxa.zzds("Releasing 1 reference for JS Engine");
            this.zzdcz--;
            zzsa();
        }
    }

    public final void zzrz() {
        synchronized (this.lock) {
            Preconditions.checkState(this.zzdcz >= 0);
            zzaxa.zzds("Releasing root reference. JS Engine will be destroyed once other references are released.");
            this.zzdcy = true;
            zzsa();
        }
    }

    private final void zzsa() {
        synchronized (this.lock) {
            Preconditions.checkState(this.zzdcz >= 0);
            if (this.zzdcy && this.zzdcz == 0) {
                zzaxa.zzds("No reference is left (including root). Cleaning up engine.");
                zza(new zzale(this), new zzbbv());
            } else {
                zzaxa.zzds("There are still references to the engine. Not destroying.");
            }
        }
    }
}
