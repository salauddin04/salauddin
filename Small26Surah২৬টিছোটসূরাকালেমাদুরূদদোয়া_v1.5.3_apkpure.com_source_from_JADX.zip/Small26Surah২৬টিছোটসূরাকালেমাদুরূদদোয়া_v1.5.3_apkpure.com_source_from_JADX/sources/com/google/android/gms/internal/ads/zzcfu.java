package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.doubleclick.AppEventListener;
import java.util.Set;
import java.util.concurrent.Executor;

public final class zzcfu implements zzdth<Set<zzbuy<AppEventListener>>> {
    private final zzdtt<Executor> zzfgg;
    private final zzdtt<zzcfy> zzfuc;
    private final zzcfo zzfux;

    private zzcfu(zzcfo zzcfo, zzdtt<zzcfy> zzdtt, zzdtt<Executor> zzdtt2) {
        this.zzfux = zzcfo;
        this.zzfuc = zzdtt;
        this.zzfgg = zzdtt2;
    }

    public static zzcfu zzf(zzcfo zzcfo, zzdtt<zzcfy> zzdtt, zzdtt<Executor> zzdtt2) {
        return new zzcfu(zzcfo, zzdtt, zzdtt2);
    }

    public final /* synthetic */ Object get() {
        return (Set) zzdtn.zza(zzcfo.zzb((zzcfy) this.zzfuc.get(), (Executor) this.zzfgg.get()), "Cannot return null from a non-@Nullable @Provides method");
    }
}
