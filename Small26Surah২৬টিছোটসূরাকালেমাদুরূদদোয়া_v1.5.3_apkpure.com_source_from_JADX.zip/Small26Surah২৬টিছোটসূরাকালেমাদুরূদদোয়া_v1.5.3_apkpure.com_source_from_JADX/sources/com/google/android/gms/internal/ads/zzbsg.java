package com.google.android.gms.internal.ads;

final /* synthetic */ class zzbsg implements zzbtt {
    static final zzbtt zzfka = new zzbsg();

    private zzbsg() {
    }

    public final void zzr(Object obj) {
        ((zzbrk) obj).onAdOpened();
    }
}
