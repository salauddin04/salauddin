package com.google.android.gms.internal.ads;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;

public interface zzaok extends IInterface {
    void zzdb(String str) throws RemoteException;

    void zzw(IObjectWrapper iObjectWrapper) throws RemoteException;
}
