package com.google.android.gms.internal.measurement;

import android.database.ContentObserver;
import android.os.Handler;

final class zzcu extends ContentObserver {
    zzcu(zzcs zzcs, Handler handler) {
        super(null);
    }

    public final void onChange(boolean z) {
        zzcw.zzjp();
    }
}
