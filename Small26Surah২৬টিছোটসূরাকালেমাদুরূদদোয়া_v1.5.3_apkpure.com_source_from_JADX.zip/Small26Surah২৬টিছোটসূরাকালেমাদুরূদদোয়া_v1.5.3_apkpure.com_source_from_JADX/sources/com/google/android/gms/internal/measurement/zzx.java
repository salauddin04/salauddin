package com.google.android.gms.internal.measurement;

import android.os.IBinder;

public final class zzx extends zza implements zzw {
    zzx(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.measurement.api.internal.IStringProvider");
    }
}
