package com.google.android.gms.internal.ads;

public interface zznu {
    long getDurationUs();

    long zzdq(long j);

    boolean zzfc();
}
