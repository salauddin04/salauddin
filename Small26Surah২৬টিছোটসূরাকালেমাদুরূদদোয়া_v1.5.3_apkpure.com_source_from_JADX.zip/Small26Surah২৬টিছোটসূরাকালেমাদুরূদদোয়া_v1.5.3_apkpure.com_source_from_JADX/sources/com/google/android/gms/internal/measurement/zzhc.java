package com.google.android.gms.internal.measurement;

import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;

final class zzhc extends zzhb<FieldDescriptorType, Object> {
    zzhc(int i) {
        super(i);
    }

    public final void zzjz() {
        if (!isImmutable()) {
            Entry zzbf;
            for (int i = 0; i < zzoi(); i++) {
                zzbf = zzbf(i);
                if (((zzes) zzbf.getKey()).zzmc()) {
                    zzbf.setValue(Collections.unmodifiableList((List) zzbf.getValue()));
                }
            }
            for (Entry zzbf2 : zzoj()) {
                if (((zzes) zzbf2.getKey()).zzmc()) {
                    zzbf2.setValue(Collections.unmodifiableList((List) zzbf2.getValue()));
                }
            }
        }
        super.zzjz();
    }
}
