package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzez.zzc;
import java.io.IOException;
import java.util.Map.Entry;

final class zzeo extends zzen<Object> {
    zzeo() {
    }

    final boolean zze(zzgh zzgh) {
        return zzgh instanceof zzc;
    }

    final zzeq<Object> zzg(Object obj) {
        return ((zzc) obj).zzagt;
    }

    final zzeq<Object> zzh(Object obj) {
        return ((zzc) obj).zzms();
    }

    final void zzi(Object obj) {
        zzg(obj).zzjz();
    }

    final <UT, UB> UB zza(zzgx zzgx, Object obj, zzem zzem, zzeq<Object> zzeq, UB ub, zzhq<UT, UB> zzhq) throws IOException {
        throw new NoSuchMethodError();
    }

    final int zza(Entry<?, ?> entry) {
        entry.getKey();
        throw new NoSuchMethodError();
    }

    final void zza(zzil zzil, Entry<?, ?> entry) throws IOException {
        entry.getKey();
        throw new NoSuchMethodError();
    }

    final Object zza(zzem zzem, zzgh zzgh, int i) {
        return zzem.zza(zzgh, i);
    }

    final void zza(zzgx zzgx, Object obj, zzem zzem, zzeq<Object> zzeq) throws IOException {
        throw new NoSuchMethodError();
    }

    final void zza(zzdp zzdp, Object obj, zzem zzem, zzeq<Object> zzeq) throws IOException {
        throw new NoSuchMethodError();
    }
}
