package com.google.android.gms.internal.measurement;

public abstract class zzdi<MessageType extends zzgh> implements zzgs<MessageType> {
    private static final zzem zzabo = zzem.zzls();
}
