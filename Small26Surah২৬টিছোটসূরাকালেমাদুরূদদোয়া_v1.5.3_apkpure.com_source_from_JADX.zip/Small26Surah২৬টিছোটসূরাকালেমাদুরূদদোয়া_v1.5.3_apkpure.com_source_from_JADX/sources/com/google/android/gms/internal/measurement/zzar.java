package com.google.android.gms.internal.measurement;

import android.os.RemoteException;

final class zzar extends zza {
    private final /* synthetic */ zzaa zzar;
    private final /* synthetic */ zzm zzaw;

    zzar(zzaa zzaa, zzm zzm) {
        this.zzar = zzaa;
        this.zzaw = zzm;
        super(zzaa);
    }

    final void zzl() throws RemoteException {
        this.zzar.zzan.getCurrentScreenClass(this.zzaw);
    }

    protected final void zzm() {
        this.zzaw.zzb(null);
    }
}
