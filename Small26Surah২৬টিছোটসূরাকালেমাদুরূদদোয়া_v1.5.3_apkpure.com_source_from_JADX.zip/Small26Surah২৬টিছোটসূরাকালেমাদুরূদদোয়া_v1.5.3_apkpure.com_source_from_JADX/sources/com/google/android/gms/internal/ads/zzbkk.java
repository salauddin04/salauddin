package com.google.android.gms.internal.ads;

final class zzbkk implements zzboc {
    private zzcyn zzepy;
    private zzbqx zzepz;
    private zzcfo zzeqa;
    private zzbpw zzeqb;
    private zzbqs zzeqc;
    private zzbtu zzeqd;
    private zzbxj zzeqe;
    private zzcyf zzeqf;
    private final /* synthetic */ zzbkd zzeqg;
    private zzbnb zzezu;
    private zzbow zzezv;
    private zzcov zzezw;

    private zzbkk(zzbkd zzbkd) {
        this.zzeqg = zzbkd;
    }

    public final zzbob zzads() {
        zzdtn.zza(this.zzeqd, zzbtu.class);
        if (this.zzeqf == null) {
            r0.zzeqf = new zzcyf();
        }
        if (r0.zzepy == null) {
            r0.zzepy = new zzcyn();
        }
        zzdtn.zza(r0.zzepz, zzbqx.class);
        if (r0.zzeqa == null) {
            r0.zzeqa = new zzcfo();
        }
        zzdtn.zza(r0.zzezu, zzbnb.class);
        if (r0.zzeqb == null) {
            r0.zzeqb = new zzbpw();
        }
        if (r0.zzeqc == null) {
            r0.zzeqc = new zzbqs();
        }
        zzdtn.zza(r0.zzezv, zzbow.class);
        zzdtn.zza(r0.zzezw, zzcov.class);
        zzdtn.zza(r0.zzeqe, zzbxj.class);
        return new zzbkl(r0.zzeqg, r0.zzeqd, r0.zzeqf, r0.zzepy, r0.zzepz, r0.zzeqa, r0.zzezu, r0.zzeqb, r0.zzeqc, r0.zzezv, r0.zzezw, r0.zzeqe, null);
    }

    public final /* synthetic */ zzboc zzb(zzbxj zzbxj) {
        this.zzeqe = (zzbxj) zzdtn.checkNotNull(zzbxj);
        return this;
    }

    public final /* synthetic */ zzboc zza(zzbnb zzbnb) {
        this.zzezu = (zzbnb) zzdtn.checkNotNull(zzbnb);
        return this;
    }

    public final /* synthetic */ zzboc zza(zzbow zzbow) {
        this.zzezv = (zzbow) zzdtn.checkNotNull(zzbow);
        return this;
    }

    public final /* synthetic */ zzboc zza(zzcov zzcov) {
        this.zzezw = (zzcov) zzdtn.checkNotNull(zzcov);
        return this;
    }

    public final /* synthetic */ zzboc zzb(zzbqx zzbqx) {
        this.zzepz = (zzbqx) zzdtn.checkNotNull(zzbqx);
        return this;
    }

    public final /* synthetic */ zzboc zzb(zzbtu zzbtu) {
        this.zzeqd = (zzbtu) zzdtn.checkNotNull(zzbtu);
        return this;
    }
}
