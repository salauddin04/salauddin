package com.google.android.gms.internal.ads;

import java.util.concurrent.TimeUnit;

public final class zzbqp {
    public static <T> zzbbi<T> zza(zzczs zzczs, zzbbi<zzcxt> zzbbi, zzblr zzblr, zzcmw<T> zzcmw) {
        if (((Boolean) zzyr.zzpe().zzd(zzact.zzcvn)).booleanValue()) {
            return zzczs.zza(zzczr.RENDERER, (zzbbi) zzbbi).zza(zzblr).zza(zzcmw).zzane();
        }
        return zzczs.zza(zzczr.RENDERER, (zzbbi) zzbbi).zza(zzblr).zza(zzcmw).zza((long) ((Integer) zzyr.zzpe().zzd(zzact.zzcvo)).intValue(), TimeUnit.SECONDS).zzane();
    }
}
