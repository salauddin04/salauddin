package com.google.android.gms.internal.measurement;

import android.content.ContentResolver;
import android.net.Uri;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

public class zzci {
    public static final Uri CONTENT_URI = Uri.parse("content://com.google.android.gsf.gservices");
    private static final Uri zzyu = Uri.parse("content://com.google.android.gsf.gservices/prefix");
    public static final Pattern zzyv = Pattern.compile("^(1|true|t|on|yes|y)$", 2);
    public static final Pattern zzyw = Pattern.compile("^(0|false|f|off|no|n)$", 2);
    private static final AtomicBoolean zzyx = new AtomicBoolean();
    private static HashMap<String, String> zzyy;
    private static final HashMap<String, Boolean> zzyz = new HashMap();
    private static final HashMap<String, Integer> zzza = new HashMap();
    private static final HashMap<String, Long> zzzb = new HashMap();
    private static final HashMap<String, Float> zzzc = new HashMap();
    private static Object zzzd;
    private static boolean zzze;
    private static String[] zzzf = new String[0];

    public static java.lang.String zza(android.content.ContentResolver r13, java.lang.String r14, java.lang.String r15) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:65:0x00ad in {7, 8, 10, 19, 24, 25, 27, 29, 30, 35, 36, 42, 43, 49, 52, 53, 55, 56, 59, 60, 64} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r15 = com.google.android.gms.internal.measurement.zzci.class;
        monitor-enter(r15);
        zza(r13);	 Catch:{ all -> 0x00aa }
        r0 = zzzd;	 Catch:{ all -> 0x00aa }
        r1 = zzyy;	 Catch:{ all -> 0x00aa }
        r1 = r1.containsKey(r14);	 Catch:{ all -> 0x00aa }
        r2 = 0;	 Catch:{ all -> 0x00aa }
        if (r1 == 0) goto L_0x001f;	 Catch:{ all -> 0x00aa }
    L_0x0011:
        r13 = zzyy;	 Catch:{ all -> 0x00aa }
        r13 = r13.get(r14);	 Catch:{ all -> 0x00aa }
        r13 = (java.lang.String) r13;	 Catch:{ all -> 0x00aa }
        if (r13 == 0) goto L_0x001c;	 Catch:{ all -> 0x00aa }
    L_0x001b:
        goto L_0x001d;	 Catch:{ all -> 0x00aa }
    L_0x001c:
        r13 = r2;	 Catch:{ all -> 0x00aa }
    L_0x001d:
        monitor-exit(r15);	 Catch:{ all -> 0x00aa }
        return r13;	 Catch:{ all -> 0x00aa }
    L_0x001f:
        r1 = zzzf;	 Catch:{ all -> 0x00aa }
        r3 = r1.length;	 Catch:{ all -> 0x00aa }
        r4 = 0;	 Catch:{ all -> 0x00aa }
        r5 = 0;	 Catch:{ all -> 0x00aa }
    L_0x0024:
        r6 = 1;	 Catch:{ all -> 0x00aa }
        if (r5 >= r3) goto L_0x0063;	 Catch:{ all -> 0x00aa }
    L_0x0027:
        r7 = r1[r5];	 Catch:{ all -> 0x00aa }
        r7 = r14.startsWith(r7);	 Catch:{ all -> 0x00aa }
        if (r7 == 0) goto L_0x0060;	 Catch:{ all -> 0x00aa }
    L_0x002f:
        r0 = zzze;	 Catch:{ all -> 0x00aa }
        if (r0 == 0) goto L_0x003b;	 Catch:{ all -> 0x00aa }
    L_0x0033:
        r0 = zzyy;	 Catch:{ all -> 0x00aa }
        r0 = r0.isEmpty();	 Catch:{ all -> 0x00aa }
        if (r0 == 0) goto L_0x005e;	 Catch:{ all -> 0x00aa }
    L_0x003b:
        r0 = zzzf;	 Catch:{ all -> 0x00aa }
        r1 = zzyy;	 Catch:{ all -> 0x00aa }
        r13 = zza(r13, r0);	 Catch:{ all -> 0x00aa }
        r1.putAll(r13);	 Catch:{ all -> 0x00aa }
        zzze = r6;	 Catch:{ all -> 0x00aa }
        r13 = zzyy;	 Catch:{ all -> 0x00aa }
        r13 = r13.containsKey(r14);	 Catch:{ all -> 0x00aa }
        if (r13 == 0) goto L_0x005e;	 Catch:{ all -> 0x00aa }
    L_0x0050:
        r13 = zzyy;	 Catch:{ all -> 0x00aa }
        r13 = r13.get(r14);	 Catch:{ all -> 0x00aa }
        r13 = (java.lang.String) r13;	 Catch:{ all -> 0x00aa }
        if (r13 == 0) goto L_0x005b;	 Catch:{ all -> 0x00aa }
    L_0x005a:
        goto L_0x005c;	 Catch:{ all -> 0x00aa }
    L_0x005b:
        r13 = r2;	 Catch:{ all -> 0x00aa }
    L_0x005c:
        monitor-exit(r15);	 Catch:{ all -> 0x00aa }
        return r13;	 Catch:{ all -> 0x00aa }
    L_0x005e:
        monitor-exit(r15);	 Catch:{ all -> 0x00aa }
        return r2;	 Catch:{ all -> 0x00aa }
    L_0x0060:
        r5 = r5 + 1;	 Catch:{ all -> 0x00aa }
        goto L_0x0024;	 Catch:{ all -> 0x00aa }
    L_0x0063:
        monitor-exit(r15);	 Catch:{ all -> 0x00aa }
        r8 = CONTENT_URI;
        r9 = 0;
        r10 = 0;
        r11 = new java.lang.String[r6];
        r11[r4] = r14;
        r12 = 0;
        r7 = r13;
        r13 = r7.query(r8, r9, r10, r11, r12);
        if (r13 != 0) goto L_0x007a;
    L_0x0074:
        if (r13 == 0) goto L_0x0079;
    L_0x0076:
        r13.close();
    L_0x0079:
        return r2;
    L_0x007a:
        r15 = r13.moveToFirst();	 Catch:{ all -> 0x00a3 }
        if (r15 != 0) goto L_0x0089;	 Catch:{ all -> 0x00a3 }
    L_0x0080:
        zza(r0, r14, r2);	 Catch:{ all -> 0x00a3 }
        if (r13 == 0) goto L_0x0088;
    L_0x0085:
        r13.close();
    L_0x0088:
        return r2;
    L_0x0089:
        r15 = r13.getString(r6);	 Catch:{ all -> 0x00a3 }
        if (r15 == 0) goto L_0x0096;	 Catch:{ all -> 0x00a3 }
    L_0x008f:
        r1 = r15.equals(r2);	 Catch:{ all -> 0x00a3 }
        if (r1 == 0) goto L_0x0096;	 Catch:{ all -> 0x00a3 }
    L_0x0095:
        r15 = r2;	 Catch:{ all -> 0x00a3 }
    L_0x0096:
        zza(r0, r14, r15);	 Catch:{ all -> 0x00a3 }
        if (r15 == 0) goto L_0x009c;
    L_0x009b:
        goto L_0x009d;
    L_0x009c:
        r15 = r2;
    L_0x009d:
        if (r13 == 0) goto L_0x00a2;
    L_0x009f:
        r13.close();
    L_0x00a2:
        return r15;
    L_0x00a3:
        r14 = move-exception;
        if (r13 == 0) goto L_0x00a9;
    L_0x00a6:
        r13.close();
    L_0x00a9:
        throw r14;
    L_0x00aa:
        r13 = move-exception;
        monitor-exit(r15);	 Catch:{ all -> 0x00aa }
        throw r13;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzci.zza(android.content.ContentResolver, java.lang.String, java.lang.String):java.lang.String");
    }

    private static java.util.Map<java.lang.String, java.lang.String> zza(android.content.ContentResolver r6, java.lang.String... r7) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:13:0x0030 in {2, 7, 9, 12} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r1 = zzyu;
        r2 = 0;
        r3 = 0;
        r5 = 0;
        r0 = r6;
        r4 = r7;
        r6 = r0.query(r1, r2, r3, r4, r5);
        r7 = new java.util.TreeMap;
        r7.<init>();
        if (r6 != 0) goto L_0x0013;
    L_0x0012:
        return r7;
    L_0x0013:
        r0 = r6.moveToNext();	 Catch:{ all -> 0x002b }
        if (r0 == 0) goto L_0x0027;	 Catch:{ all -> 0x002b }
    L_0x0019:
        r0 = 0;	 Catch:{ all -> 0x002b }
        r0 = r6.getString(r0);	 Catch:{ all -> 0x002b }
        r1 = 1;	 Catch:{ all -> 0x002b }
        r1 = r6.getString(r1);	 Catch:{ all -> 0x002b }
        r7.put(r0, r1);	 Catch:{ all -> 0x002b }
        goto L_0x0013;
    L_0x0027:
        r6.close();
        return r7;
    L_0x002b:
        r7 = move-exception;
        r6.close();
        throw r7;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzci.zza(android.content.ContentResolver, java.lang.String[]):java.util.Map<java.lang.String, java.lang.String>");
    }

    private static void zza(ContentResolver contentResolver) {
        if (zzyy == null) {
            zzyx.set(false);
            zzyy = new HashMap();
            zzzd = new Object();
            zzze = false;
            contentResolver.registerContentObserver(CONTENT_URI, true, new zzcj(null));
            return;
        }
        if (zzyx.getAndSet(false) != null) {
            zzyy.clear();
            zzyz.clear();
            zzza.clear();
            zzzb.clear();
            zzzc.clear();
            zzzd = new Object();
            zzze = false;
        }
    }

    private static void zza(Object obj, String str, String str2) {
        synchronized (zzci.class) {
            if (obj == zzzd) {
                zzyy.put(str, str2);
            }
        }
    }
}
