package com.google.android.gms.internal.ads;

import java.util.Iterator;

public interface zzdmx extends Iterator<Byte> {
    byte nextByte();
}
