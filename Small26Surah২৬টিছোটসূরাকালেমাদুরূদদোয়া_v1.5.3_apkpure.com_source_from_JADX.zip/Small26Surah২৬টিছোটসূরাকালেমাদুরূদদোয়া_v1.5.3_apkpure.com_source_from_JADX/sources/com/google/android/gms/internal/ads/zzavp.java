package com.google.android.gms.internal.ads;

final /* synthetic */ class zzavp implements zzavw {
    static final zzavw zzdsv = new zzavp();

    private zzavp() {
    }

    public final Object zzb(zzbjg zzbjg) {
        return zzbjg.getGmpAppId();
    }
}
