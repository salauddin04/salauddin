package com.google.android.gms.internal.measurement;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.IObjectWrapper.Stub;

public abstract class zzo extends zzb implements zzn {
    public zzo() {
        super("com.google.android.gms.measurement.api.internal.IAppMeasurementDynamiteService");
    }

    public static zzn asInterface(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.measurement.api.internal.IAppMeasurementDynamiteService");
        if (queryLocalInterface instanceof zzn) {
            return (zzn) queryLocalInterface;
        }
        return new zzp(iBinder);
    }

    protected final boolean zza(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
        String str = "com.google.android.gms.measurement.api.internal.IEventHandlerProxy";
        String str2 = "com.google.android.gms.measurement.api.internal.IBundleReceiver";
        zzq zzq = null;
        String readString;
        IInterface queryLocalInterface;
        IBinder readStrongBinder;
        IInterface queryLocalInterface2;
        IBinder readStrongBinder2;
        zzt zzt;
        switch (i) {
            case 1:
                initialize(Stub.asInterface(parcel.readStrongBinder()), (zzy) zzc.zza(parcel, zzy.CREATOR), parcel.readLong());
                break;
            case 2:
                logEvent(parcel.readString(), parcel.readString(), (Bundle) zzc.zza(parcel, Bundle.CREATOR), zzc.zza(parcel), zzc.zza(parcel), parcel.readLong());
                break;
            case 3:
                zzq zzq2;
                str = parcel.readString();
                readString = parcel.readString();
                Bundle bundle = (Bundle) zzc.zza(parcel, Bundle.CREATOR);
                IBinder readStrongBinder3 = parcel.readStrongBinder();
                if (readStrongBinder3 == null) {
                    zzq2 = null;
                } else {
                    zzq zzq3;
                    queryLocalInterface = readStrongBinder3.queryLocalInterface(str2);
                    if (queryLocalInterface instanceof zzq) {
                        zzq3 = (zzq) queryLocalInterface;
                    } else {
                        zzq3 = new zzs(readStrongBinder3);
                    }
                    zzq2 = zzq3;
                }
                logEventAndBundle(str, readString, bundle, zzq2, parcel.readLong());
                break;
            case 4:
                setUserProperty(parcel.readString(), parcel.readString(), Stub.asInterface(parcel.readStrongBinder()), zzc.zza(parcel), parcel.readLong());
                break;
            case 5:
                str = parcel.readString();
                readString = parcel.readString();
                boolean zza = zzc.zza(parcel);
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface = readStrongBinder.queryLocalInterface(str2);
                    if (queryLocalInterface instanceof zzq) {
                        zzq = (zzq) queryLocalInterface;
                    } else {
                        zzq = new zzs(readStrongBinder);
                    }
                }
                getUserProperties(str, readString, zza, zzq);
                break;
            case 6:
                str = parcel.readString();
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface = readStrongBinder.queryLocalInterface(str2);
                    if (queryLocalInterface instanceof zzq) {
                        zzq = (zzq) queryLocalInterface;
                    } else {
                        zzq = new zzs(readStrongBinder);
                    }
                }
                getMaxUserProperties(str, zzq);
                break;
            case 7:
                setUserId(parcel.readString(), parcel.readLong());
                break;
            case 8:
                setConditionalUserProperty((Bundle) zzc.zza(parcel, Bundle.CREATOR), parcel.readLong());
                break;
            case 9:
                clearConditionalUserProperty(parcel.readString(), parcel.readString(), (Bundle) zzc.zza(parcel, Bundle.CREATOR));
                break;
            case 10:
                str = parcel.readString();
                readString = parcel.readString();
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface = readStrongBinder.queryLocalInterface(str2);
                    if (queryLocalInterface instanceof zzq) {
                        zzq = (zzq) queryLocalInterface;
                    } else {
                        zzq = new zzs(readStrongBinder);
                    }
                }
                getConditionalUserProperties(str, readString, zzq);
                break;
            case 11:
                setMeasurementEnabled(zzc.zza(parcel), parcel.readLong());
                break;
            case 12:
                resetAnalyticsData(parcel.readLong());
                break;
            case 13:
                setMinimumSessionDuration(parcel.readLong());
                break;
            case 14:
                setSessionTimeoutDuration(parcel.readLong());
                break;
            case 15:
                setCurrentScreen(Stub.asInterface(parcel.readStrongBinder()), parcel.readString(), parcel.readString(), parcel.readLong());
                break;
            case 16:
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface2 = readStrongBinder.queryLocalInterface(str2);
                    if (queryLocalInterface2 instanceof zzq) {
                        zzq = (zzq) queryLocalInterface2;
                    } else {
                        zzq = new zzs(readStrongBinder);
                    }
                }
                getCurrentScreenName(zzq);
                break;
            case 17:
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface2 = readStrongBinder.queryLocalInterface(str2);
                    if (queryLocalInterface2 instanceof zzq) {
                        zzq = (zzq) queryLocalInterface2;
                    } else {
                        zzq = new zzs(readStrongBinder);
                    }
                }
                getCurrentScreenClass(zzq);
                break;
            case 18:
                zzw zzw;
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface2 = readStrongBinder.queryLocalInterface("com.google.android.gms.measurement.api.internal.IStringProvider");
                    if (queryLocalInterface2 instanceof zzw) {
                        zzw = (zzw) queryLocalInterface2;
                    } else {
                        zzw = new zzx(readStrongBinder);
                    }
                }
                setInstanceIdProvider(zzw);
                break;
            case 19:
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface2 = readStrongBinder.queryLocalInterface(str2);
                    if (queryLocalInterface2 instanceof zzq) {
                        zzq = (zzq) queryLocalInterface2;
                    } else {
                        zzq = new zzs(readStrongBinder);
                    }
                }
                getCachedAppInstanceId(zzq);
                break;
            case 20:
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface2 = readStrongBinder.queryLocalInterface(str2);
                    if (queryLocalInterface2 instanceof zzq) {
                        zzq = (zzq) queryLocalInterface2;
                    } else {
                        zzq = new zzs(readStrongBinder);
                    }
                }
                getAppInstanceId(zzq);
                break;
            case 21:
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface2 = readStrongBinder.queryLocalInterface(str2);
                    if (queryLocalInterface2 instanceof zzq) {
                        zzq = (zzq) queryLocalInterface2;
                    } else {
                        zzq = new zzs(readStrongBinder);
                    }
                }
                getGmpAppId(zzq);
                break;
            case 22:
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface2 = readStrongBinder.queryLocalInterface(str2);
                    if (queryLocalInterface2 instanceof zzq) {
                        zzq = (zzq) queryLocalInterface2;
                    } else {
                        zzq = new zzs(readStrongBinder);
                    }
                }
                generateEventId(zzq);
                break;
            case 23:
                beginAdUnitExposure(parcel.readString(), parcel.readLong());
                break;
            case 24:
                endAdUnitExposure(parcel.readString(), parcel.readLong());
                break;
            case 25:
                onActivityStarted(Stub.asInterface(parcel.readStrongBinder()), parcel.readLong());
                break;
            case 26:
                onActivityStopped(Stub.asInterface(parcel.readStrongBinder()), parcel.readLong());
                break;
            case 27:
                onActivityCreated(Stub.asInterface(parcel.readStrongBinder()), (Bundle) zzc.zza(parcel, Bundle.CREATOR), parcel.readLong());
                break;
            case 28:
                onActivityDestroyed(Stub.asInterface(parcel.readStrongBinder()), parcel.readLong());
                break;
            case 29:
                onActivityPaused(Stub.asInterface(parcel.readStrongBinder()), parcel.readLong());
                break;
            case 30:
                onActivityResumed(Stub.asInterface(parcel.readStrongBinder()), parcel.readLong());
                break;
            case 31:
                IObjectWrapper asInterface = Stub.asInterface(parcel.readStrongBinder());
                readStrongBinder2 = parcel.readStrongBinder();
                if (readStrongBinder2 != null) {
                    queryLocalInterface = readStrongBinder2.queryLocalInterface(str2);
                    if (queryLocalInterface instanceof zzq) {
                        zzq = (zzq) queryLocalInterface;
                    } else {
                        zzq = new zzs(readStrongBinder2);
                    }
                }
                onActivitySaveInstanceState(asInterface, zzq, parcel.readLong());
                break;
            case 32:
                Bundle bundle2 = (Bundle) zzc.zza(parcel, Bundle.CREATOR);
                readStrongBinder2 = parcel.readStrongBinder();
                if (readStrongBinder2 != null) {
                    queryLocalInterface = readStrongBinder2.queryLocalInterface(str2);
                    if (queryLocalInterface instanceof zzq) {
                        zzq = (zzq) queryLocalInterface;
                    } else {
                        zzq = new zzs(readStrongBinder2);
                    }
                }
                performAction(bundle2, zzq, parcel.readLong());
                break;
            case 33:
                logHealthData(parcel.readInt(), parcel.readString(), Stub.asInterface(parcel.readStrongBinder()), Stub.asInterface(parcel.readStrongBinder()), Stub.asInterface(parcel.readStrongBinder()));
                break;
            case 34:
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface2 = readStrongBinder.queryLocalInterface(str);
                    if (queryLocalInterface2 instanceof zzt) {
                        zzt = (zzt) queryLocalInterface2;
                    } else {
                        zzt = new zzv(readStrongBinder);
                    }
                }
                setEventInterceptor(zzt);
                break;
            case 35:
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface2 = readStrongBinder.queryLocalInterface(str);
                    if (queryLocalInterface2 instanceof zzt) {
                        zzt = (zzt) queryLocalInterface2;
                    } else {
                        zzt = new zzv(readStrongBinder);
                    }
                }
                registerOnMeasurementEventListener(zzt);
                break;
            case 36:
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface2 = readStrongBinder.queryLocalInterface(str);
                    if (queryLocalInterface2 instanceof zzt) {
                        zzt = (zzt) queryLocalInterface2;
                    } else {
                        zzt = new zzv(readStrongBinder);
                    }
                }
                unregisterOnMeasurementEventListener(zzt);
                break;
            case 37:
                initForTests(zzc.zzb(parcel));
                break;
            case 38:
                IBinder readStrongBinder4 = parcel.readStrongBinder();
                if (readStrongBinder4 != null) {
                    queryLocalInterface = readStrongBinder4.queryLocalInterface(str2);
                    if (queryLocalInterface instanceof zzq) {
                        zzq = (zzq) queryLocalInterface;
                    } else {
                        zzq = new zzs(readStrongBinder4);
                    }
                }
                getTestFlag(zzq, parcel.readInt());
                break;
            case 39:
                setDataCollectionEnabled(zzc.zza(parcel));
                break;
            case 40:
                readStrongBinder = parcel.readStrongBinder();
                if (readStrongBinder != null) {
                    queryLocalInterface2 = readStrongBinder.queryLocalInterface(str2);
                    if (queryLocalInterface2 instanceof zzq) {
                        zzq = (zzq) queryLocalInterface2;
                    } else {
                        zzq = new zzs(readStrongBinder);
                    }
                }
                isDataCollectionEnabled(zzq);
                break;
            default:
                return false;
        }
        parcel2.writeNoException();
        return true;
    }
}
