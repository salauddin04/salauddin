package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.reward.AdMetadataListener;
import javax.annotation.concurrent.GuardedBy;

public final class zzcpw extends AdMetadataListener {
    @GuardedBy("this")
    private zzzn zzgep;

    public final synchronized void zzb(zzzn zzzn) {
        this.zzgep = zzzn;
    }

    public final synchronized void onAdMetadataChanged() {
        if (this.zzgep != null) {
            try {
                this.zzgep.onAdMetadataChanged();
            } catch (Throwable e) {
                zzbae.zzd("Remote Exception at onAdMetadataChanged.", e);
            }
        }
    }
}
