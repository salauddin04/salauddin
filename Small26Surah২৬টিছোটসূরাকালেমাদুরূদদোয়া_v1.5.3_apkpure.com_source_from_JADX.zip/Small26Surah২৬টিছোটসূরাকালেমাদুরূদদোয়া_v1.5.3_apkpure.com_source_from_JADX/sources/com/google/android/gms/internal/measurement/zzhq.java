package com.google.android.gms.internal.measurement;

import java.io.IOException;

abstract class zzhq<T, B> {
    zzhq() {
    }

    abstract void zza(B b, int i, long j);

    abstract void zza(B b, int i, zzdp zzdp);

    abstract void zza(B b, int i, T t);

    abstract void zza(T t, zzil zzil) throws IOException;

    abstract boolean zza(zzgx zzgx);

    abstract void zzb(B b, int i, long j);

    abstract void zzc(B b, int i, int i2);

    abstract void zzc(T t, zzil zzil) throws IOException;

    abstract void zze(Object obj, T t);

    abstract void zzf(Object obj, B b);

    abstract T zzg(T t, T t2);

    abstract void zzi(Object obj);

    abstract B zzoq();

    abstract T zzp(B b);

    abstract int zzs(T t);

    abstract T zzw(Object obj);

    abstract B zzx(Object obj);

    abstract int zzy(T t);

    final boolean zza(B b, zzgx zzgx) throws IOException {
        int tag = zzgx.getTag();
        int i = tag >>> 3;
        tag &= 7;
        if (tag == 0) {
            zza((Object) b, i, zzgx.zzkl());
            return true;
        } else if (tag == 1) {
            zzb(b, i, zzgx.zzkn());
            return true;
        } else if (tag == 2) {
            zza((Object) b, i, zzgx.zzkr());
            return true;
        } else if (tag == 3) {
            Object zzoq = zzoq();
            int i2 = 4 | (i << 3);
            while (zzgx.zzlh() != Integer.MAX_VALUE) {
                if (!zza(zzoq, zzgx)) {
                    break;
                }
            }
            if (i2 == zzgx.getTag()) {
                zza((Object) b, i, zzp(zzoq));
                return true;
            }
            throw zzfh.zzmy();
        } else if (tag == 4) {
            return null;
        } else {
            if (tag == 5) {
                zzc(b, i, zzgx.zzko());
                return true;
            }
            throw zzfh.zzmz();
        }
    }
}
