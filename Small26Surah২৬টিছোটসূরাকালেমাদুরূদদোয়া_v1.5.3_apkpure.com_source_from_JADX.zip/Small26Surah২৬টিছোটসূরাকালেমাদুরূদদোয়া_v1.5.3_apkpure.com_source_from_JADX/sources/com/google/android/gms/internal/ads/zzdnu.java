package com.google.android.gms.internal.ads;

import java.lang.reflect.Type;

public enum zzdnu {
    DOUBLE(0, zzdnw.SCALAR, zzdol.DOUBLE),
    FLOAT(1, zzdnw.SCALAR, zzdol.FLOAT),
    INT64(2, zzdnw.SCALAR, zzdol.LONG),
    UINT64(3, zzdnw.SCALAR, zzdol.LONG),
    INT32(4, zzdnw.SCALAR, zzdol.INT),
    FIXED64(5, zzdnw.SCALAR, zzdol.LONG),
    FIXED32(6, zzdnw.SCALAR, zzdol.INT),
    BOOL(7, zzdnw.SCALAR, zzdol.BOOLEAN),
    STRING(8, zzdnw.SCALAR, zzdol.STRING),
    MESSAGE(9, zzdnw.SCALAR, zzdol.MESSAGE),
    BYTES(10, zzdnw.SCALAR, zzdol.BYTE_STRING),
    UINT32(11, zzdnw.SCALAR, zzdol.INT),
    ENUM(12, zzdnw.SCALAR, zzdol.ENUM),
    SFIXED32(13, zzdnw.SCALAR, zzdol.INT),
    SFIXED64(14, zzdnw.SCALAR, zzdol.LONG),
    SINT32(15, zzdnw.SCALAR, zzdol.INT),
    SINT64(16, zzdnw.SCALAR, zzdol.LONG),
    GROUP(17, zzdnw.SCALAR, zzdol.MESSAGE),
    DOUBLE_LIST(18, zzdnw.VECTOR, zzdol.DOUBLE),
    FLOAT_LIST(19, zzdnw.VECTOR, zzdol.FLOAT),
    INT64_LIST(20, zzdnw.VECTOR, zzdol.LONG),
    UINT64_LIST(21, zzdnw.VECTOR, zzdol.LONG),
    INT32_LIST(22, zzdnw.VECTOR, zzdol.INT),
    FIXED64_LIST(23, zzdnw.VECTOR, zzdol.LONG),
    FIXED32_LIST(24, zzdnw.VECTOR, zzdol.INT),
    BOOL_LIST(25, zzdnw.VECTOR, zzdol.BOOLEAN),
    STRING_LIST(26, zzdnw.VECTOR, zzdol.STRING),
    MESSAGE_LIST(27, zzdnw.VECTOR, zzdol.MESSAGE),
    BYTES_LIST(28, zzdnw.VECTOR, zzdol.BYTE_STRING),
    UINT32_LIST(29, zzdnw.VECTOR, zzdol.INT),
    ENUM_LIST(30, zzdnw.VECTOR, zzdol.ENUM),
    SFIXED32_LIST(31, zzdnw.VECTOR, zzdol.INT),
    SFIXED64_LIST(32, zzdnw.VECTOR, zzdol.LONG),
    SINT32_LIST(33, zzdnw.VECTOR, zzdol.INT),
    SINT64_LIST(34, zzdnw.VECTOR, zzdol.LONG),
    DOUBLE_LIST_PACKED(35, zzdnw.PACKED_VECTOR, zzdol.DOUBLE),
    FLOAT_LIST_PACKED(36, zzdnw.PACKED_VECTOR, zzdol.FLOAT),
    INT64_LIST_PACKED(37, zzdnw.PACKED_VECTOR, zzdol.LONG),
    UINT64_LIST_PACKED(38, zzdnw.PACKED_VECTOR, zzdol.LONG),
    INT32_LIST_PACKED(39, zzdnw.PACKED_VECTOR, zzdol.INT),
    FIXED64_LIST_PACKED(40, zzdnw.PACKED_VECTOR, zzdol.LONG),
    FIXED32_LIST_PACKED(41, zzdnw.PACKED_VECTOR, zzdol.INT),
    BOOL_LIST_PACKED(42, zzdnw.PACKED_VECTOR, zzdol.BOOLEAN),
    UINT32_LIST_PACKED(43, zzdnw.PACKED_VECTOR, zzdol.INT),
    ENUM_LIST_PACKED(44, zzdnw.PACKED_VECTOR, zzdol.ENUM),
    SFIXED32_LIST_PACKED(45, zzdnw.PACKED_VECTOR, zzdol.INT),
    SFIXED64_LIST_PACKED(46, zzdnw.PACKED_VECTOR, zzdol.LONG),
    SINT32_LIST_PACKED(47, zzdnw.PACKED_VECTOR, zzdol.INT),
    SINT64_LIST_PACKED(48, zzdnw.PACKED_VECTOR, zzdol.LONG),
    GROUP_LIST(49, zzdnw.VECTOR, zzdol.MESSAGE),
    MAP(50, zzdnw.MAP, zzdol.VOID);
    
    private static final zzdnu[] zzhgo = null;
    private static final Type[] zzhgp = null;
    private final int id;
    private final zzdol zzhgk;
    private final zzdnw zzhgl;
    private final Class<?> zzhgm;
    private final boolean zzhgn;

    private zzdnu(int i, zzdnw zzdnw, zzdol zzdol) {
        this.id = i;
        this.zzhgl = zzdnw;
        this.zzhgk = zzdol;
        r2 = zzdnv.zzhgr[zzdnw.ordinal()];
        if (r2 == 1) {
            this.zzhgm = zzdol.zzayl();
        } else if (r2 != 2) {
            this.zzhgm = null;
        } else {
            this.zzhgm = zzdol.zzayl();
        }
        r2 = null;
        if (zzdnw == zzdnw.SCALAR) {
            zzdnw = zzdnv.zzhgs[zzdol.ordinal()];
            if (!(zzdnw == 1 || zzdnw == 2 || zzdnw == 3)) {
                r2 = true;
            }
        }
        this.zzhgn = r2;
    }

    public final int id() {
        return this.id;
    }

    static {
        zzhgp = new Type[0];
        zzdnu[] values = values();
        zzhgo = new zzdnu[values.length];
        int length = values.length;
        int i;
        while (i < length) {
            zzdnu zzdnu = values[i];
            zzhgo[zzdnu.id] = zzdnu;
            i++;
        }
    }
}
