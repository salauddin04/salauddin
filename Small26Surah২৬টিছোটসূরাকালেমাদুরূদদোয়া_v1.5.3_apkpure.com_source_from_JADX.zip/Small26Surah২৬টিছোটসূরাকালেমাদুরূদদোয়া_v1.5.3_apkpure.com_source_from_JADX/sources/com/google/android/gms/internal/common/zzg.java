package com.google.android.gms.internal.common;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build.VERSION;
import android.support.annotation.RequiresApi;

public final class zzg {
    private static volatile boolean zziy = (zzam() ^ 1);

    public static boolean zzam() {
        return VERSION.SDK_INT >= 24;
    }

    @TargetApi(24)
    @RequiresApi(24)
    public static Context getDeviceProtectedStorageContext(Context context) {
        if (context.isDeviceProtectedStorage()) {
            return context;
        }
        return context.createDeviceProtectedStorageContext();
    }
}
