package com.google.android.gms.internal.measurement;

import java.io.IOException;

public final class zzbx extends zzip<zzbx> {
    private static volatile zzbx[] zzvt;
    public Integer zzvu;
    public zzcb[] zzvv;
    public zzby[] zzvw;
    private Boolean zzvx;
    private Boolean zzvy;

    public static zzbx[] zziz() {
        if (zzvt == null) {
            synchronized (zzit.zzanl) {
                if (zzvt == null) {
                    zzvt = new zzbx[0];
                }
            }
        }
        return zzvt;
    }

    public zzbx() {
        this.zzvu = null;
        this.zzvv = zzcb.zzjd();
        this.zzvw = zzby.zzjb();
        this.zzvx = null;
        this.zzvy = null;
        this.zzand = null;
        this.zzanm = -1;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzbx)) {
            return false;
        }
        zzbx zzbx = (zzbx) obj;
        Integer num = this.zzvu;
        if (num == null) {
            if (zzbx.zzvu != null) {
                return false;
            }
        } else if (!num.equals(zzbx.zzvu)) {
            return false;
        }
        if (!zzit.equals(this.zzvv, zzbx.zzvv) || !zzit.equals(this.zzvw, zzbx.zzvw)) {
            return false;
        }
        Boolean bool = this.zzvx;
        if (bool == null) {
            if (zzbx.zzvx != null) {
                return false;
            }
        } else if (!bool.equals(zzbx.zzvx)) {
            return false;
        }
        bool = this.zzvy;
        if (bool == null) {
            if (zzbx.zzvy != null) {
                return false;
            }
        } else if (!bool.equals(zzbx.zzvy)) {
            return false;
        }
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                return this.zzand.equals(zzbx.zzand);
            }
        }
        if (zzbx.zzand != null) {
            if (zzbx.zzand.isEmpty() == null) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int hashCode = (getClass().getName().hashCode() + 527) * 31;
        Integer num = this.zzvu;
        int i = 0;
        hashCode = (((((hashCode + (num == null ? 0 : num.hashCode())) * 31) + zzit.hashCode(this.zzvv)) * 31) + zzit.hashCode(this.zzvw)) * 31;
        Boolean bool = this.zzvx;
        hashCode = (hashCode + (bool == null ? 0 : bool.hashCode())) * 31;
        bool = this.zzvy;
        hashCode = (hashCode + (bool == null ? 0 : bool.hashCode())) * 31;
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                i = this.zzand.hashCode();
            }
        }
        return hashCode + i;
    }

    public final void zza(zzin zzin) throws IOException {
        Integer num = this.zzvu;
        if (num != null) {
            zzin.zzc(1, num.intValue());
        }
        zzcb[] zzcbArr = this.zzvv;
        int i = 0;
        if (zzcbArr != null && zzcbArr.length > 0) {
            int i2 = 0;
            while (true) {
                zzcb[] zzcbArr2 = this.zzvv;
                if (i2 >= zzcbArr2.length) {
                    break;
                }
                zziv zziv = zzcbArr2[i2];
                if (zziv != null) {
                    zzin.zza(2, zziv);
                }
                i2++;
            }
        }
        zzby[] zzbyArr = this.zzvw;
        if (zzbyArr != null && zzbyArr.length > 0) {
            while (true) {
                zzbyArr = this.zzvw;
                if (i >= zzbyArr.length) {
                    break;
                }
                zziv zziv2 = zzbyArr[i];
                if (zziv2 != null) {
                    zzin.zza(3, zziv2);
                }
                i++;
            }
        }
        Boolean bool = this.zzvx;
        if (bool != null) {
            zzin.zzb(4, bool.booleanValue());
        }
        bool = this.zzvy;
        if (bool != null) {
            zzin.zzb(5, bool.booleanValue());
        }
        super.zza(zzin);
    }

    protected final int zzja() {
        int zzja = super.zzja();
        Integer num = this.zzvu;
        if (num != null) {
            zzja += zzin.zzg(1, num.intValue());
        }
        zzcb[] zzcbArr = this.zzvv;
        int i = 0;
        if (zzcbArr != null && zzcbArr.length > 0) {
            int i2 = zzja;
            zzja = 0;
            while (true) {
                zzcb[] zzcbArr2 = this.zzvv;
                if (zzja >= zzcbArr2.length) {
                    break;
                }
                zziv zziv = zzcbArr2[zzja];
                if (zziv != null) {
                    i2 += zzin.zzb(2, zziv);
                }
                zzja++;
            }
            zzja = i2;
        }
        zzby[] zzbyArr = this.zzvw;
        if (zzbyArr != null && zzbyArr.length > 0) {
            while (true) {
                zzbyArr = this.zzvw;
                if (i >= zzbyArr.length) {
                    break;
                }
                zziv zziv2 = zzbyArr[i];
                if (zziv2 != null) {
                    zzja += zzin.zzb(3, zziv2);
                }
                i++;
            }
        }
        Boolean bool = this.zzvx;
        if (bool != null) {
            bool.booleanValue();
            zzja += zzin.zzaj(4) + 1;
        }
        bool = this.zzvy;
        if (bool == null) {
            return zzja;
        }
        bool.booleanValue();
        return zzja + (zzin.zzaj(5) + 1);
    }

    public final /* synthetic */ zziv zza(zzim zzim) throws IOException {
        while (true) {
            int zzkj = zzim.zzkj();
            if (zzkj == 0) {
                return this;
            }
            if (zzkj == 8) {
                this.zzvu = Integer.valueOf(zzim.zzlb());
            } else if (zzkj == 18) {
                zzkj = zziy.zzb(zzim, 18);
                zzcb[] zzcbArr = this.zzvv;
                r1 = zzcbArr == null ? 0 : zzcbArr.length;
                r0 = new zzcb[(zzkj + r1)];
                if (r1 != 0) {
                    System.arraycopy(this.zzvv, 0, r0, 0, r1);
                }
                while (r1 < r0.length - 1) {
                    r0[r1] = new zzcb();
                    zzim.zza(r0[r1]);
                    zzim.zzkj();
                    r1++;
                }
                r0[r1] = new zzcb();
                zzim.zza(r0[r1]);
                this.zzvv = r0;
            } else if (zzkj == 26) {
                zzkj = zziy.zzb(zzim, 26);
                zzby[] zzbyArr = this.zzvw;
                r1 = zzbyArr == null ? 0 : zzbyArr.length;
                r0 = new zzby[(zzkj + r1)];
                if (r1 != 0) {
                    System.arraycopy(this.zzvw, 0, r0, 0, r1);
                }
                while (r1 < r0.length - 1) {
                    r0[r1] = new zzby();
                    zzim.zza(r0[r1]);
                    zzim.zzkj();
                    r1++;
                }
                r0[r1] = new zzby();
                zzim.zza(r0[r1]);
                this.zzvw = r0;
            } else if (zzkj == 32) {
                this.zzvx = Boolean.valueOf(zzim.zzkp());
            } else if (zzkj == 40) {
                this.zzvy = Boolean.valueOf(zzim.zzkp());
            } else if (!super.zza(zzim, zzkj)) {
                return this;
            }
        }
    }
}
