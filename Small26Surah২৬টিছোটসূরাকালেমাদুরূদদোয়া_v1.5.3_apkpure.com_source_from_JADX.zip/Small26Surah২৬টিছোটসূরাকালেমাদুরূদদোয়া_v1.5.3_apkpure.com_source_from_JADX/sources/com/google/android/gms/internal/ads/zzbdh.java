package com.google.android.gms.internal.ads;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.zzk;
import java.util.concurrent.TimeUnit;

@zzare
public final class zzbdh {
    private final zzbaj zzdlf;
    private final String zzdlz;
    @Nullable
    private final zzadh zzebx;
    private boolean zzecb;
    @Nullable
    private final zzadf zzeeo;
    private final zzayr zzeep = new zzayu().zza("min_1", Double.MIN_VALUE, 1.0d).zza("1_5", 1.0d, 5.0d).zza("5_10", 5.0d, 10.0d).zza("10_20", 10.0d, 20.0d).zza("20_30", 20.0d, 30.0d).zza("30_max", 30.0d, Double.MAX_VALUE).zzwq();
    private final long[] zzeeq;
    private final String[] zzeer;
    private boolean zzees = false;
    private boolean zzeet = false;
    private boolean zzeeu = false;
    private boolean zzeev = false;
    private zzbcp zzeew;
    private boolean zzeex;
    private boolean zzeey;
    private long zzeez = -1;
    private final Context zzlj;

    public zzbdh(Context context, zzbaj zzbaj, String str, @Nullable zzadh zzadh, @Nullable zzadf zzadf) {
        this.zzlj = context;
        this.zzdlf = zzbaj;
        this.zzdlz = str;
        this.zzebx = zzadh;
        this.zzeeo = zzadf;
        String str2 = (String) zzyr.zzpe().zzd(zzact.zzcmc);
        if (str2 == null) {
            r1.zzeer = new String[0];
            r1.zzeeq = new long[0];
            return;
        }
        String[] split = TextUtils.split(str2, ",");
        r1.zzeer = new String[split.length];
        r1.zzeeq = new long[split.length];
        for (int i = 0; i < split.length; i++) {
            try {
                r1.zzeeq[i] = Long.parseLong(split[i]);
            } catch (Throwable e) {
                zzbae.zzd("Unable to parse frame hash target time number.", e);
                r1.zzeeq[i] = -1;
            }
        }
    }

    public final void zzb(zzbcp zzbcp) {
        zzada.zza(this.zzebx, this.zzeeo, "vpc2");
        this.zzees = true;
        zzadh zzadh = this.zzebx;
        if (zzadh != null) {
            zzadh.zzh("vpn", zzbcp.zzxg());
        }
        this.zzeew = zzbcp;
    }

    public final void zzhd() {
        if (!this.zzees) {
            return;
        }
        if (!this.zzeet) {
            zzada.zza(this.zzebx, this.zzeeo, "vfr2");
            this.zzeet = true;
        }
    }

    public final void onStop() {
        if (((Boolean) zzyr.zzpe().zzd(zzact.zzcmb)).booleanValue() && !this.zzeex) {
            String str;
            Bundle bundle = new Bundle();
            bundle.putString("type", "native-player-metrics");
            bundle.putString("request", this.zzdlz);
            bundle.putString("player", this.zzeew.zzxg());
            for (zzayt zzayt : this.zzeep.zzwp()) {
                str = "fps_c_";
                String valueOf = String.valueOf(zzayt.name);
                bundle.putString(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), Integer.toString(zzayt.count));
                str = "fps_p_";
                valueOf = String.valueOf(zzayt.name);
                bundle.putString(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), Double.toString(zzayt.zzdxf));
            }
            int i = 0;
            while (true) {
                long[] jArr = this.zzeeq;
                if (i < jArr.length) {
                    str = this.zzeer[i];
                    if (str != null) {
                        String valueOf2 = String.valueOf(Long.valueOf(jArr[i]));
                        StringBuilder stringBuilder = new StringBuilder(String.valueOf(valueOf2).length() + 3);
                        stringBuilder.append("fh_");
                        stringBuilder.append(valueOf2);
                        bundle.putString(stringBuilder.toString(), str);
                    }
                    i++;
                } else {
                    zzk.zzlg().zza(this.zzlj, this.zzdlf.zzbsy, "gmob-apps", bundle, true);
                    this.zzeex = true;
                    return;
                }
            }
        }
    }

    public final void zzc(zzbcp zzbcp) {
        if (this.zzeeu && !r0.zzeev) {
            if (zzaxa.zzvj() && !r0.zzeev) {
                zzaxa.zzds("VideoMetricsMixin first frame");
            }
            zzada.zza(r0.zzebx, r0.zzeeo, "vff2");
            r0.zzeev = true;
        }
        long nanoTime = zzk.zzln().nanoTime();
        if (r0.zzecb && r0.zzeey && r0.zzeez != -1) {
            double toNanos = (double) TimeUnit.SECONDS.toNanos(1);
            double d = (double) (nanoTime - r0.zzeez);
            Double.isNaN(toNanos);
            Double.isNaN(d);
            r0.zzeep.zza(toNanos / d);
        }
        r0.zzeey = r0.zzecb;
        r0.zzeez = nanoTime;
        nanoTime = ((Long) zzyr.zzpe().zzd(zzact.zzcmd)).longValue();
        long currentPosition = (long) zzbcp.getCurrentPosition();
        int i = 0;
        while (true) {
            String[] strArr = r0.zzeer;
            if (i < strArr.length) {
                if (strArr[i] == null && nanoTime > Math.abs(currentPosition - r0.zzeeq[i])) {
                    break;
                }
                zzbcp zzbcp2 = zzbcp;
                i++;
            } else {
                return;
            }
        }
        String[] strArr2 = r0.zzeer;
        int i2 = 8;
        Bitmap bitmap = zzbcp.getBitmap(8, 8);
        long j = 63;
        int i3 = 0;
        long j2 = 0;
        while (i3 < i2) {
            long j3 = j;
            int i4 = 0;
            while (i4 < i2) {
                int pixel = bitmap.getPixel(i4, i3);
                j2 |= ((Color.blue(pixel) + Color.red(pixel)) + Color.green(pixel) > 128 ? 1 : 0) << ((int) j3);
                i4++;
                j3--;
                i2 = 8;
            }
            i3++;
            j = j3;
            i2 = 8;
        }
        strArr2[i] = String.format("%016X", new Object[]{Long.valueOf(j2)});
    }

    public final void zzyl() {
        this.zzecb = true;
        if (this.zzeet && !this.zzeeu) {
            zzada.zza(this.zzebx, this.zzeeo, "vfp2");
            this.zzeeu = true;
        }
    }

    public final void zzym() {
        this.zzecb = false;
    }
}
