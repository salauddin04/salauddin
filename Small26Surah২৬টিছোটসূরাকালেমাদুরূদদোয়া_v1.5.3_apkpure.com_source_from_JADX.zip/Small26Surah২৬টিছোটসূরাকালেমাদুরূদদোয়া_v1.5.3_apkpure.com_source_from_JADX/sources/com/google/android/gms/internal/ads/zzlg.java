package com.google.android.gms.internal.ads;

public final class zzlg {
    public final zzlr zzary;
    public final Object zzarz;
    public final zzle zzasd;
    public final int zzatk;

    public zzlg(zzlr zzlr, Object obj, zzle zzle, int i) {
        this.zzary = zzlr;
        this.zzarz = obj;
        this.zzasd = zzle;
        this.zzatk = i;
    }
}
