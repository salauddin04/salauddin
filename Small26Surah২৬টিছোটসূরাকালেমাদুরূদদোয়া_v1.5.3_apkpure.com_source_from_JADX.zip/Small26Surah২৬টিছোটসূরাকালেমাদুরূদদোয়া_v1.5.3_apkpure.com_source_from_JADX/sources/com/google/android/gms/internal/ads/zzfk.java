package com.google.android.gms.internal.ads;

import com.google.android.gms.internal.ads.zzbp.zza.zza;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.Callable;

public abstract class zzfk implements Callable {
    private final String TAG = getClass().getSimpleName();
    private final String className;
    private final int zzaaa;
    private final int zzaab;
    protected final zzdy zzvd;
    protected final zza zzzm;
    private final String zzzu;
    protected Method zzzw;

    public zzfk(zzdy zzdy, String str, String str2, zza zza, int i, int i2) {
        this.zzvd = zzdy;
        this.className = str;
        this.zzzu = str2;
        this.zzzm = zza;
        this.zzaaa = i;
        this.zzaab = i2;
    }

    protected abstract void zzcx() throws IllegalAccessException, InvocationTargetException;

    public java.lang.Void zzcz() throws java.lang.Exception {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r8 = this;
        r0 = 0;
        r1 = java.lang.System.nanoTime();	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r3 = r8.zzvd;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r4 = r8.className;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r5 = r8.zzzu;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r3 = r3.zzc(r4, r5);	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r8.zzzw = r3;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r3 = r8.zzzw;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        if (r3 != 0) goto L_0x0016;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
    L_0x0015:
        return r0;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
    L_0x0016:
        r8.zzcx();	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r3 = r8.zzvd;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r3 = r3.zzcm();	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        if (r3 == 0) goto L_0x0036;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
    L_0x0021:
        r4 = r8.zzaaa;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r5 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        if (r4 == r5) goto L_0x0036;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
    L_0x0027:
        r4 = r8.zzaab;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r5 = r8.zzaaa;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r6 = java.lang.System.nanoTime();	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r6 = r6 - r1;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r1 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r6 = r6 / r1;	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
        r3.zza(r4, r5, r6);	 Catch:{ IllegalAccessException -> 0x0036, IllegalAccessException -> 0x0036 }
    L_0x0036:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzfk.zzcz():java.lang.Void");
    }

    public /* synthetic */ Object call() throws Exception {
        return zzcz();
    }
}
