package com.google.android.gms.internal.ads;

import com.google.android.gms.internal.ads.zzbp.zza.zzc;

final class zzbt implements zzdoe<zzc> {
    zzbt() {
    }
}
