package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.internal.zzk;
import org.json.JSONObject;

public final class zzbyi implements zzdth<zztw> {
    private final zzdtt<zzbaj> zzfgo;
    private final zzdtt<String> zzfgp;

    public zzbyi(zzdtt<zzbaj> zzdtt, zzdtt<String> zzdtt2) {
        this.zzfgo = zzdtt;
        this.zzfgp = zzdtt2;
    }

    public final /* synthetic */ Object get() {
        zzbaj zzbaj = (zzbaj) this.zzfgo.get();
        String str = (String) this.zzfgp.get();
        zzk.zzlg();
        return (zztw) zzdtn.zza((Object) new zztw(zzaxj.zzwb(), zzbaj, str, new JSONObject(), false, true), "Cannot return null from a non-@Nullable @Provides method");
    }
}
