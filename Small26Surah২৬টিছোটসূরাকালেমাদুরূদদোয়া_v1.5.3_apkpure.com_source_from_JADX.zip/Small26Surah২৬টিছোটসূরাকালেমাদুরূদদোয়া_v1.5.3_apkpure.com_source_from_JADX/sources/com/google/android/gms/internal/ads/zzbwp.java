package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.internal.overlay.zzo;

public final class zzbwp implements zzo {
    private final zzbsu zzflp;
    private final zzbuu zzflq;

    public zzbwp(zzbsu zzbsu, zzbuu zzbuu) {
        this.zzflp = zzbsu;
        this.zzflq = zzbuu;
    }

    public final void zzsz() {
        this.zzflp.zzsz();
        this.zzflq.onHide();
    }

    public final void onPause() {
        this.zzflp.onPause();
    }

    public final void onResume() {
        this.zzflp.onResume();
    }

    public final void zzta() {
        this.zzflp.zzta();
        this.zzflq.zzagw();
    }
}
