package com.google.android.gms.internal.measurement;

enum zzii extends zzif {
    zzii(String str, int i, zzik zzik, int i2) {
        super(str, 10, zzik, 2);
    }
}
