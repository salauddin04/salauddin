package com.google.android.gms.internal.ads;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.IObjectWrapper.Stub;

public abstract class zzaox extends zzfn implements zzaow {
    public zzaox() {
        super("com.google.android.gms.ads.internal.mediation.client.rtb.IRtbAdapter");
    }

    public static zzaow zzab(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.IRtbAdapter");
        if (queryLocalInterface instanceof zzaow) {
            return (zzaow) queryLocalInterface;
        }
        return new zzaoy(iBinder);
    }

    protected final boolean dispatchTransaction(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
        zzaox zzaox = this;
        int i3 = i;
        Parcel parcel3 = parcel;
        Parcel parcel4 = parcel2;
        zzaok zzaok = null;
        String readString;
        IBinder readStrongBinder;
        if (i3 == 1) {
            zzaok zzaok2;
            IObjectWrapper asInterface = Stub.asInterface(parcel.readStrongBinder());
            readString = parcel.readString();
            Bundle bundle = (Bundle) zzfo.zza(parcel, Bundle.CREATOR);
            Bundle bundle2 = (Bundle) zzfo.zza(parcel, Bundle.CREATOR);
            zzyb zzyb = (zzyb) zzfo.zza(parcel, zzyb.CREATOR);
            readStrongBinder = parcel.readStrongBinder();
            if (readStrongBinder == null) {
                zzaok2 = null;
            } else {
                zzaoz zzaoz;
                IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.ISignalsCallback");
                if (queryLocalInterface instanceof zzaoz) {
                    zzaoz = (zzaoz) queryLocalInterface;
                } else {
                    zzaoz = new zzapb(readStrongBinder);
                }
                zzaok2 = zzaoz;
            }
            zza(asInterface, readString, bundle, bundle2, zzyb, (zzaoz) zzaok2);
            parcel2.writeNoException();
        } else if (i3 == 2) {
            r0 = zzsx();
            parcel2.writeNoException();
            zzfo.zzb(parcel4, r0);
        } else if (i3 == 3) {
            r0 = zzsy();
            parcel2.writeNoException();
            zzfo.zzb(parcel4, r0);
        } else if (i3 == 5) {
            IInterface videoController = getVideoController();
            parcel2.writeNoException();
            zzfo.zza(parcel4, videoController);
        } else if (i3 == 10) {
            zzx(Stub.asInterface(parcel.readStrongBinder()));
            parcel2.writeNoException();
        } else if (i3 != 11) {
            String readString2;
            zzxx zzxx;
            IObjectWrapper asInterface2;
            IInterface queryLocalInterface2;
            zzaok zzaok3;
            boolean zzy;
            switch (i3) {
                case 13:
                    readString2 = parcel.readString();
                    readString = parcel.readString();
                    zzxx = (zzxx) zzfo.zza(parcel, zzxx.CREATOR);
                    asInterface2 = Stub.asInterface(parcel.readStrongBinder());
                    readStrongBinder = parcel.readStrongBinder();
                    if (readStrongBinder != null) {
                        queryLocalInterface2 = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.IBannerCallback");
                        if (queryLocalInterface2 instanceof zzaok) {
                            zzaok = (zzaok) queryLocalInterface2;
                        } else {
                            zzaok = new zzaom(readStrongBinder);
                        }
                    }
                    zzaok3 = zzaok;
                    zza(readString2, readString, zzxx, asInterface2, zzaok3, zzamx.zzz(parcel.readStrongBinder()), (zzyb) zzfo.zza(parcel, zzyb.CREATOR));
                    parcel2.writeNoException();
                    break;
                case 14:
                    readString2 = parcel.readString();
                    readString = parcel.readString();
                    zzxx = (zzxx) zzfo.zza(parcel, zzxx.CREATOR);
                    asInterface2 = Stub.asInterface(parcel.readStrongBinder());
                    readStrongBinder = parcel.readStrongBinder();
                    if (readStrongBinder != null) {
                        queryLocalInterface2 = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.IInterstitialCallback");
                        if (queryLocalInterface2 instanceof zzaon) {
                            zzaon zzaon = (zzaon) queryLocalInterface2;
                        } else {
                            zzaok = new zzaop(readStrongBinder);
                        }
                    }
                    zzaok3 = zzaok;
                    zza(readString2, readString, zzxx, asInterface2, (zzaon) zzaok3, zzamx.zzz(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    break;
                case 15:
                    zzy = zzy(Stub.asInterface(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    zzfo.writeBoolean(parcel4, zzy);
                    break;
                case 16:
                    readString2 = parcel.readString();
                    readString = parcel.readString();
                    zzxx = (zzxx) zzfo.zza(parcel, zzxx.CREATOR);
                    asInterface2 = Stub.asInterface(parcel.readStrongBinder());
                    readStrongBinder = parcel.readStrongBinder();
                    if (readStrongBinder != null) {
                        queryLocalInterface2 = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.IRewardedCallback");
                        if (queryLocalInterface2 instanceof zzaot) {
                            zzaot zzaot = (zzaot) queryLocalInterface2;
                        } else {
                            zzaok = new zzaov(readStrongBinder);
                        }
                    }
                    zzaok3 = zzaok;
                    zza(readString2, readString, zzxx, asInterface2, (zzaot) zzaok3, zzamx.zzz(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    break;
                case 17:
                    zzy = zzz(Stub.asInterface(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    zzfo.writeBoolean(parcel4, zzy);
                    break;
                case 18:
                    readString2 = parcel.readString();
                    readString = parcel.readString();
                    zzxx = (zzxx) zzfo.zza(parcel, zzxx.CREATOR);
                    asInterface2 = Stub.asInterface(parcel.readStrongBinder());
                    readStrongBinder = parcel.readStrongBinder();
                    if (readStrongBinder != null) {
                        queryLocalInterface2 = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.INativeCallback");
                        if (queryLocalInterface2 instanceof zzaoq) {
                            zzaoq zzaoq = (zzaoq) queryLocalInterface2;
                        } else {
                            zzaok = new zzaos(readStrongBinder);
                        }
                    }
                    zzaok3 = zzaok;
                    zza(readString2, readString, zzxx, asInterface2, (zzaoq) zzaok3, zzamx.zzz(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    break;
                default:
                    return false;
            }
        } else {
            zza(parcel.createStringArray(), (Bundle[]) parcel.createTypedArray(Bundle.CREATOR));
            parcel2.writeNoException();
        }
        return true;
    }
}
