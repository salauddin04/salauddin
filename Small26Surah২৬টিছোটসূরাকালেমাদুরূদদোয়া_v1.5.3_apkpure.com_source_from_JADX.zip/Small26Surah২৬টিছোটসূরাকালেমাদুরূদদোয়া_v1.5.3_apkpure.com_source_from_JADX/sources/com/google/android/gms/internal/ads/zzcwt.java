package com.google.android.gms.internal.ads;

import android.content.Context;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class zzcwt implements zzcuz<zzcws> {
    private ScheduledExecutorService zzfiw;
    private zzaqn zzgjn;
    private Context zzlj;

    public zzcwt(zzaqn zzaqn, ScheduledExecutorService scheduledExecutorService, Context context) {
        this.zzgjn = zzaqn;
        this.zzfiw = scheduledExecutorService;
        this.zzlj = context;
    }

    public final zzbbi<zzcws> zzalm() {
        return zzbas.zza(zzbas.zza(this.zzgjn.zzn(this.zzlj), ((Long) zzyr.zzpe().zzd(zzact.zzcth)).longValue(), TimeUnit.MILLISECONDS, this.zzfiw), zzcwu.zzdrp, zzaxh.zzdvr);
    }
}
