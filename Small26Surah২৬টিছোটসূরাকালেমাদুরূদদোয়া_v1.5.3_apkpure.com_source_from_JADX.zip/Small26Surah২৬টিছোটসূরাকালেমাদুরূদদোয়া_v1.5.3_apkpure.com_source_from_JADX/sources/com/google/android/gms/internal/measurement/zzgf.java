package com.google.android.gms.internal.measurement;

interface zzgf {
    int zzns();

    boolean zznt();

    zzgh zznu();
}
