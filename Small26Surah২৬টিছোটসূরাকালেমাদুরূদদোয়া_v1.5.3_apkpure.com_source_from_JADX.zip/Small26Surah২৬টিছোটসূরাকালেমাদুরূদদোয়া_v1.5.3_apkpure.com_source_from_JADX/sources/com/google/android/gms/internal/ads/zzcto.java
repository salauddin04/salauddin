package com.google.android.gms.internal.ads;

import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.support.v4.os.EnvironmentCompat;
import android.text.TextUtils;
import java.util.ArrayList;
import javax.annotation.Nullable;

public final class zzcto implements zzcuz<zzctn> {
    private final PackageInfo zzdlo;
    private final zzaxc zzdum;
    private final zzcxu zzfjp;
    private final zzbbm zzfqw;

    public zzcto(zzbbm zzbbm, zzcxu zzcxu, @Nullable PackageInfo packageInfo, zzaxc zzaxc) {
        this.zzfqw = zzbbm;
        this.zzfjp = zzcxu;
        this.zzdlo = packageInfo;
        this.zzdum = zzaxc;
    }

    public final zzbbi<zzctn> zzalm() {
        return this.zzfqw.zza(new zzctp(this));
    }

    final /* synthetic */ void zza(ArrayList arrayList, Bundle bundle) {
        int i;
        bundle.putInt("native_version", 3);
        bundle.putStringArrayList("native_templates", arrayList);
        bundle.putStringArrayList("native_custom_templates", this.zzfjp.zzgld);
        arrayList = ((Boolean) zzyr.zzpe().zzd(zzact.zzcsh)).booleanValue();
        String str = "landscape";
        String str2 = "portrait";
        String str3 = "any";
        String str4 = EnvironmentCompat.MEDIA_UNKNOWN;
        if (arrayList != null && this.zzfjp.zzdgu.versionCode > 3) {
            bundle.putBoolean("enable_native_media_orientation", true);
            arrayList = this.zzfjp.zzdgu.zzbqd;
            arrayList = arrayList != 1 ? arrayList != 2 ? arrayList != 3 ? arrayList != 4 ? str4 : "square" : str2 : str : str3;
            if (!str4.equals(arrayList)) {
                bundle.putString("native_media_orientation", arrayList);
            }
        }
        arrayList = this.zzfjp.zzdgu.zzbqc;
        if (arrayList == null) {
            str = str3;
        } else if (arrayList == 1) {
            str = str2;
        } else if (arrayList != 2) {
            str = str4;
        }
        if (str4.equals(str) == null) {
            bundle.putString("native_image_orientation", str);
        }
        bundle.putBoolean("native_multiple_images", this.zzfjp.zzdgu.zzbqe);
        bundle.putBoolean("use_custom_mute", this.zzfjp.zzdgu.zzbqh);
        arrayList = this.zzdlo;
        if (arrayList == null) {
            arrayList = null;
        } else {
            arrayList = arrayList.versionCode;
        }
        if (arrayList > this.zzdum.zzvq()) {
            this.zzdum.zzvw();
            this.zzdum.zzct(arrayList);
        }
        arrayList = this.zzdum.zzvv();
        if (arrayList != null) {
            arrayList = arrayList.optJSONArray(this.zzfjp.zzglb);
            if (arrayList != null) {
                arrayList = arrayList.toString();
                if (!TextUtils.isEmpty(arrayList)) {
                    bundle.putString("native_advanced_settings", arrayList);
                }
                if (this.zzfjp.zzglg > 1) {
                    bundle.putInt("max_num_ads", this.zzfjp.zzglg);
                }
                if (this.zzfjp.zzdng != null) {
                    arrayList = this.zzfjp.zzdng;
                    i = arrayList.zzdbg;
                    str = "l";
                    if (i != 1) {
                        if (i == 2) {
                            arrayList = arrayList.zzdbg;
                            StringBuilder stringBuilder = new StringBuilder(52);
                            stringBuilder.append("Instream ad video aspect ratio ");
                            stringBuilder.append(arrayList);
                            stringBuilder.append(" is wrong.");
                            zzbae.zzen(stringBuilder.toString());
                        } else {
                            str = "p";
                        }
                    }
                    bundle.putString("ia_var", str);
                    bundle.putBoolean("instr", true);
                }
                if (this.zzfjp.zzamn() != null) {
                    bundle.putBoolean("has_delayed_banner_listener", true);
                }
            }
        }
        arrayList = null;
        if (TextUtils.isEmpty(arrayList)) {
            bundle.putString("native_advanced_settings", arrayList);
        }
        if (this.zzfjp.zzglg > 1) {
            bundle.putInt("max_num_ads", this.zzfjp.zzglg);
        }
        if (this.zzfjp.zzdng != null) {
            arrayList = this.zzfjp.zzdng;
            i = arrayList.zzdbg;
            str = "l";
            if (i != 1) {
                if (i == 2) {
                    str = "p";
                } else {
                    arrayList = arrayList.zzdbg;
                    StringBuilder stringBuilder2 = new StringBuilder(52);
                    stringBuilder2.append("Instream ad video aspect ratio ");
                    stringBuilder2.append(arrayList);
                    stringBuilder2.append(" is wrong.");
                    zzbae.zzen(stringBuilder2.toString());
                }
            }
            bundle.putString("ia_var", str);
            bundle.putBoolean("instr", true);
        }
        if (this.zzfjp.zzamn() != null) {
            bundle.putBoolean("has_delayed_banner_listener", true);
        }
    }

    final /* synthetic */ zzctn zzalt() throws Exception {
        ArrayList arrayList = this.zzfjp.zzglc;
        if (arrayList == null) {
            return zzctq.zzghl;
        }
        if (arrayList.isEmpty()) {
            return zzctr.zzghl;
        }
        return new zzcts(this, arrayList);
    }
}
