package com.google.android.gms.internal.ads;

import android.support.annotation.Nullable;

public final class zzbwn implements zzdth<zzbha> {
    private final zzbvy zzflo;

    private zzbwn(zzbvy zzbvy) {
        this.zzflo = zzbvy;
    }

    public static zzbwn zzc(zzbvy zzbvy) {
        return new zzbwn(zzbvy);
    }

    @Nullable
    public final /* synthetic */ Object get() {
        return this.zzflo.zzafn();
    }
}
