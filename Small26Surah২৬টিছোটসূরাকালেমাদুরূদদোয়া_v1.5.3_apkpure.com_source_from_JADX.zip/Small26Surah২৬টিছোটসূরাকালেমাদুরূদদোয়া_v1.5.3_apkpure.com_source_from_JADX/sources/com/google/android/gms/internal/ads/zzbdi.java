package com.google.android.gms.internal.ads;

@zzare
final class zzbdi implements Runnable {
    private boolean zzbuu = false;
    private zzbcr zzecs;

    zzbdi(zzbcr zzbcr) {
        this.zzecs = zzbcr;
    }

    public final void run() {
        if (!this.zzbuu) {
            this.zzecs.zzxt();
            zzyn();
        }
    }

    public final void pause() {
        this.zzbuu = true;
        this.zzecs.zzxt();
    }

    public final void resume() {
        this.zzbuu = false;
        zzyn();
    }

    private final void zzyn() {
        zzaxj.zzdvx.removeCallbacks(this);
        zzaxj.zzdvx.postDelayed(this, 250);
    }
}
