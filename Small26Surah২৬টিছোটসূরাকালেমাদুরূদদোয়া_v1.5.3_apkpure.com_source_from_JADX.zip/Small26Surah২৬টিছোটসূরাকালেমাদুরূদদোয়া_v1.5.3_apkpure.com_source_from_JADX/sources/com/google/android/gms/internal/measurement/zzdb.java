package com.google.android.gms.internal.measurement;

final class zzdb extends zzcw<String> {
    zzdb(zzdc zzdc, String str, String str2) {
        super(zzdc, str, str2);
    }

    final /* synthetic */ Object zzc(Object obj) {
        return obj instanceof String ? (String) obj : null;
    }
}
