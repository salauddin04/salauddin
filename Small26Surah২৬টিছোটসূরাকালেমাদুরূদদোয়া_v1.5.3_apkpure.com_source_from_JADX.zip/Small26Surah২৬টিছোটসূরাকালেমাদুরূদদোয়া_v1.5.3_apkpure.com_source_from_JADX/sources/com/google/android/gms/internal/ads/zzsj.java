package com.google.android.gms.internal.ads;

public interface zzsj<S> {
    void zza(S s, zzry zzry);

    void zzc(S s, int i);

    void zze(S s);
}
