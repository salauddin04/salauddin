package com.google.android.gms.internal.measurement;

final /* synthetic */ class zzct implements zzcr {
    private final zzcs zzzr;
    private final String zzzs;

    zzct(zzcs zzcs, String str) {
        this.zzzr = zzcs;
        this.zzzs = str;
    }

    public final Object zzjn() {
        return this.zzzr.zzcc(this.zzzs);
    }
}
