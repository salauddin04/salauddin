package com.google.android.gms.internal.measurement;

import java.util.Arrays;
import java.util.Collection;
import java.util.RandomAccess;

final class zzej extends zzdj<Double> implements zzfg<Double>, zzgt, RandomAccess {
    private static final zzej zzadg;
    private int size;
    private double[] zzadh;

    zzej() {
        this(new double[10], 0);
    }

    private zzej(double[] dArr, int i) {
        this.zzadh = dArr;
        this.size = i;
    }

    protected final void removeRange(int i, int i2) {
        zzka();
        if (i2 >= i) {
            Object obj = this.zzadh;
            System.arraycopy(obj, i2, obj, i, this.size - i2);
            this.size -= i2 - i;
            this.modCount++;
            return;
        }
        throw new IndexOutOfBoundsException("toIndex < fromIndex");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzej)) {
            return super.equals(obj);
        }
        zzej zzej = (zzej) obj;
        if (this.size != zzej.size) {
            return false;
        }
        obj = zzej.zzadh;
        for (int i = 0; i < this.size; i++) {
            if (Double.doubleToLongBits(this.zzadh[i]) != Double.doubleToLongBits(obj[i])) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int i = 1;
        for (int i2 = 0; i2 < this.size; i2++) {
            i = (i * 31) + zzfb.zzba(Double.doubleToLongBits(this.zzadh[i2]));
        }
        return i;
    }

    public final int size() {
        return this.size;
    }

    public final void zzf(double d) {
        zzc(this.size, d);
    }

    private final void zzc(int i, double d) {
        zzka();
        if (i >= 0) {
            int i2 = this.size;
            if (i <= i2) {
                Object obj = this.zzadh;
                if (i2 < obj.length) {
                    System.arraycopy(obj, i, obj, i + 1, i2 - i);
                } else {
                    Object obj2 = new double[(((i2 * 3) / 2) + 1)];
                    System.arraycopy(obj, 0, obj2, 0, i);
                    System.arraycopy(this.zzadh, i, obj2, i + 1, this.size - i);
                    this.zzadh = obj2;
                }
                this.zzadh[i] = d;
                this.size++;
                this.modCount++;
                return;
            }
        }
        throw new IndexOutOfBoundsException(zzp(i));
    }

    public final boolean addAll(Collection<? extends Double> collection) {
        zzka();
        zzfb.checkNotNull(collection);
        if (!(collection instanceof zzej)) {
            return super.addAll(collection);
        }
        zzej zzej = (zzej) collection;
        int i = zzej.size;
        if (i == 0) {
            return false;
        }
        int i2 = this.size;
        if (Integer.MAX_VALUE - i2 >= i) {
            i2 += i;
            double[] dArr = this.zzadh;
            if (i2 > dArr.length) {
                this.zzadh = Arrays.copyOf(dArr, i2);
            }
            System.arraycopy(zzej.zzadh, 0, this.zzadh, this.size, zzej.size);
            this.size = i2;
            this.modCount += 1;
            return true;
        }
        throw new OutOfMemoryError();
    }

    public final boolean remove(Object obj) {
        zzka();
        for (int i = 0; i < this.size; i++) {
            if (obj.equals(Double.valueOf(this.zzadh[i]))) {
                obj = this.zzadh;
                System.arraycopy(obj, i + 1, obj, i, (this.size - i) - 1);
                this.size -= 1;
                this.modCount += 1;
                return true;
            }
        }
        return false;
    }

    private final void zzo(int i) {
        if (i < 0 || i >= this.size) {
            throw new IndexOutOfBoundsException(zzp(i));
        }
    }

    private final String zzp(int i) {
        int i2 = this.size;
        StringBuilder stringBuilder = new StringBuilder(35);
        stringBuilder.append("Index:");
        stringBuilder.append(i);
        stringBuilder.append(", Size:");
        stringBuilder.append(i2);
        return stringBuilder.toString();
    }

    public final /* synthetic */ Object set(int i, Object obj) {
        double doubleValue = ((Double) obj).doubleValue();
        zzka();
        zzo(i);
        obj = this.zzadh;
        double d = obj[i];
        obj[i] = doubleValue;
        return Double.valueOf(d);
    }

    public final /* synthetic */ Object remove(int i) {
        zzka();
        zzo(i);
        Object obj = this.zzadh;
        double d = obj[i];
        int i2 = this.size;
        if (i < i2 - 1) {
            System.arraycopy(obj, i + 1, obj, i, (i2 - i) - 1);
        }
        this.size--;
        this.modCount++;
        return Double.valueOf(d);
    }

    public final /* synthetic */ void add(int i, Object obj) {
        zzc(i, ((Double) obj).doubleValue());
    }

    public final /* synthetic */ zzfg zzq(int i) {
        if (i >= this.size) {
            return new zzej(Arrays.copyOf(this.zzadh, i), this.size);
        }
        throw new IllegalArgumentException();
    }

    public final /* synthetic */ Object get(int i) {
        zzo(i);
        return Double.valueOf(this.zzadh[i]);
    }

    static {
        zzdj zzej = new zzej(new double[0], 0);
        zzadg = zzej;
        zzej.zzjz();
    }
}
