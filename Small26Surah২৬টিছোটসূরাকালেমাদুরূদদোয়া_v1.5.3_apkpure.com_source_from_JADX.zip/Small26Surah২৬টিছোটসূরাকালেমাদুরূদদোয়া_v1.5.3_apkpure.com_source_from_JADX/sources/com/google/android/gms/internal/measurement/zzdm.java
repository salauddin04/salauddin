package com.google.android.gms.internal.measurement;

final class zzdm {
    public int zzabs;
    public long zzabt;
    public Object zzabu;
    public final zzem zzabv;

    zzdm() {
        this.zzabv = zzem.zzls();
    }

    zzdm(zzem zzem) {
        if (zzem != null) {
            this.zzabv = zzem;
            return;
        }
        throw new NullPointerException();
    }
}
