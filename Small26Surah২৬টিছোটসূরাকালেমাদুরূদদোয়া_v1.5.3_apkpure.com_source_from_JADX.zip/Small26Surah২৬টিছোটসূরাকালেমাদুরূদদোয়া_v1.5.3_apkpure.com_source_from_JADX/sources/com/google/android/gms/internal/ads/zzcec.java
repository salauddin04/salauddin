package com.google.android.gms.internal.ads;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.PopupWindow;
import com.google.android.gms.common.util.PlatformVersion;
import javax.annotation.Nullable;

@TargetApi(19)
public final class zzcec {
    @Nullable
    private PopupWindow zzftr;
    @Nullable
    private Context zzlj;

    public final void zza(Context context, View view) {
        if (!PlatformVersion.isAtLeastKitKat()) {
            return;
        }
        if (!PlatformVersion.isAtLeastLollipop()) {
            this.zzftr = zzb(context, view);
            if (this.zzftr == null) {
                context = null;
            }
            this.zzlj = context;
        }
    }

    public final void zzajo() {
        Context context = this.zzlj;
        if (context != null) {
            if (this.zzftr != null) {
                if ((context instanceof Activity) && ((Activity) context).isDestroyed()) {
                    this.zzlj = null;
                    this.zzftr = null;
                    return;
                }
                if (this.zzftr.isShowing()) {
                    this.zzftr.dismiss();
                }
                this.zzlj = null;
                this.zzftr = null;
            }
        }
    }

    private static android.widget.PopupWindow zzb(android.content.Context r5, android.view.View r6) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = r5 instanceof android.app.Activity;
        r1 = 0;
        if (r0 == 0) goto L_0x000d;
    L_0x0005:
        r0 = r5;
        r0 = (android.app.Activity) r0;
        r0 = r0.getWindow();
        goto L_0x000e;
    L_0x000d:
        r0 = r1;
    L_0x000e:
        if (r0 == 0) goto L_0x004c;
    L_0x0010:
        r2 = r0.getDecorView();
        if (r2 != 0) goto L_0x0017;
    L_0x0016:
        goto L_0x004c;
    L_0x0017:
        r2 = r5;
        r2 = (android.app.Activity) r2;
        r2 = r2.isDestroyed();
        if (r2 == 0) goto L_0x0021;
    L_0x0020:
        return r1;
    L_0x0021:
        r2 = new android.widget.FrameLayout;
        r2.<init>(r5);
        r5 = new android.view.ViewGroup$LayoutParams;
        r3 = -1;
        r5.<init>(r3, r3);
        r2.setLayoutParams(r5);
        r2.addView(r6, r3, r3);
        r5 = new android.widget.PopupWindow;
        r6 = 0;
        r4 = 1;
        r5.<init>(r2, r4, r4, r6);
        r5.setOutsideTouchable(r4);
        r5.setClippingEnabled(r6);
        r2 = "Displaying the 1x1 popup off the screen.";
        com.google.android.gms.internal.ads.zzbae.zzdp(r2);
        r0 = r0.getDecorView();	 Catch:{ Exception -> 0x004c }
        r5.showAtLocation(r0, r6, r3, r3);	 Catch:{ Exception -> 0x004c }
        return r5;
    L_0x004c:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzcec.zzb(android.content.Context, android.view.View):android.widget.PopupWindow");
    }
}
