package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzez.zze;
import java.io.IOException;
import java.util.Arrays;

public final class zzhr {
    private static final zzhr zzakp = new zzhr(0, new int[0], new Object[0], false);
    private int count;
    private boolean zzabp;
    private int zzago;
    private Object[] zzajb;
    private int[] zzakq;

    public static zzhr zzor() {
        return zzakp;
    }

    static zzhr zzos() {
        return new zzhr();
    }

    static zzhr zza(zzhr zzhr, zzhr zzhr2) {
        int i = zzhr.count + zzhr2.count;
        Object copyOf = Arrays.copyOf(zzhr.zzakq, i);
        System.arraycopy(zzhr2.zzakq, 0, copyOf, zzhr.count, zzhr2.count);
        Object copyOf2 = Arrays.copyOf(zzhr.zzajb, i);
        System.arraycopy(zzhr2.zzajb, 0, copyOf2, zzhr.count, zzhr2.count);
        return new zzhr(i, copyOf, copyOf2, true);
    }

    private zzhr() {
        this(0, new int[8], new Object[8], true);
    }

    private zzhr(int i, int[] iArr, Object[] objArr, boolean z) {
        this.zzago = -1;
        this.count = i;
        this.zzakq = iArr;
        this.zzajb = objArr;
        this.zzabp = z;
    }

    public final void zzjz() {
        this.zzabp = false;
    }

    final void zza(zzil zzil) throws IOException {
        int i;
        if (zzil.zzln() == zze.zzahg) {
            for (i = this.count - 1; i >= 0; i--) {
                zzil.zza(this.zzakq[i] >>> 3, this.zzajb[i]);
            }
            return;
        }
        for (i = 0; i < this.count; i++) {
            zzil.zza(this.zzakq[i] >>> 3, this.zzajb[i]);
        }
    }

    public final void zzb(zzil zzil) throws IOException {
        if (this.count != 0) {
            int i;
            if (zzil.zzln() == zze.zzahf) {
                for (i = 0; i < this.count; i++) {
                    zzb(this.zzakq[i], this.zzajb[i], zzil);
                }
                return;
            }
            for (i = this.count - 1; i >= 0; i--) {
                zzb(this.zzakq[i], this.zzajb[i], zzil);
            }
        }
    }

    private static void zzb(int i, Object obj, zzil zzil) throws IOException {
        int i2 = i >>> 3;
        i &= 7;
        if (i == 0) {
            zzil.zzi(i2, ((Long) obj).longValue());
        } else if (i == 1) {
            zzil.zzc(i2, ((Long) obj).longValue());
        } else if (i == 2) {
            zzil.zza(i2, (zzdp) obj);
        } else if (i != 3) {
            if (i == 5) {
                zzil.zzf(i2, ((Integer) obj).intValue());
                return;
            }
            throw new RuntimeException(zzfh.zzmz());
        } else if (zzil.zzln() == zze.zzahf) {
            zzil.zzas(i2);
            ((zzhr) obj).zzb(zzil);
            zzil.zzat(i2);
        } else {
            zzil.zzat(i2);
            ((zzhr) obj).zzb(zzil);
            zzil.zzas(i2);
        }
    }

    public final int zzot() {
        int i = this.zzago;
        if (i != -1) {
            return i;
        }
        int i2 = 0;
        for (i = 0; i < this.count; i++) {
            i2 += zzeg.zzd(this.zzakq[i] >>> 3, (zzdp) this.zzajb[i]);
        }
        this.zzago = i2;
        return i2;
    }

    public final int zzly() {
        int i = this.zzago;
        if (i != -1) {
            return i;
        }
        int i2 = 0;
        for (i = 0; i < this.count; i++) {
            int i3 = this.zzakq[i];
            int i4 = i3 >>> 3;
            i3 &= 7;
            if (i3 == 0) {
                i3 = zzeg.zze(i4, ((Long) this.zzajb[i]).longValue());
            } else if (i3 == 1) {
                i3 = zzeg.zzg(i4, ((Long) this.zzajb[i]).longValue());
            } else if (i3 == 2) {
                i3 = zzeg.zzc(i4, (zzdp) this.zzajb[i]);
            } else if (i3 == 3) {
                i3 = (zzeg.zzaj(i4) << 1) + ((zzhr) this.zzajb[i]).zzly();
            } else if (i3 == 5) {
                i3 = zzeg.zzj(i4, ((Integer) this.zzajb[i]).intValue());
            } else {
                throw new IllegalStateException(zzfh.zzmz());
            }
            i2 += i3;
        }
        this.zzago = i2;
        return i2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof zzhr)) {
            return false;
        }
        zzhr zzhr = (zzhr) obj;
        int i = this.count;
        if (i == zzhr.count) {
            Object obj2;
            int[] iArr = this.zzakq;
            int[] iArr2 = zzhr.zzakq;
            for (int i2 = 0; i2 < i; i2++) {
                if (iArr[i2] != iArr2[i2]) {
                    obj2 = null;
                    break;
                }
            }
            obj2 = 1;
            if (obj2 != null) {
                Object[] objArr = this.zzajb;
                obj = zzhr.zzajb;
                int i3 = this.count;
                for (int i4 = 0; i4 < i3; i4++) {
                    if (!objArr[i4].equals(obj[i4])) {
                        obj = null;
                        break;
                    }
                }
                obj = true;
                if (obj != null) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        int i = this.count;
        int i2 = (i + 527) * 31;
        int[] iArr = this.zzakq;
        int i3 = 17;
        int i4 = 17;
        for (int i5 = 0; i5 < i; i5++) {
            i4 = (i4 * 31) + iArr[i5];
        }
        i2 = (i2 + i4) * 31;
        Object[] objArr = this.zzajb;
        for (int i6 = 0; i6 < this.count; i6++) {
            i3 = (i3 * 31) + objArr[i6].hashCode();
        }
        return i2 + i3;
    }

    final void zzb(StringBuilder stringBuilder, int i) {
        for (int i2 = 0; i2 < this.count; i2++) {
            zzgk.zzb(stringBuilder, i, String.valueOf(this.zzakq[i2] >>> 3), this.zzajb[i2]);
        }
    }

    final void zzb(int i, Object obj) {
        if (this.zzabp) {
            int i2;
            int i3 = this.count;
            if (i3 == this.zzakq.length) {
                i2 = this.count + (i3 < 4 ? 8 : i3 >> 1);
                this.zzakq = Arrays.copyOf(this.zzakq, i2);
                this.zzajb = Arrays.copyOf(this.zzajb, i2);
            }
            int[] iArr = this.zzakq;
            i2 = this.count;
            iArr[i2] = i;
            this.zzajb[i2] = obj;
            this.count = i2 + 1;
            return;
        }
        throw new UnsupportedOperationException();
    }
}
