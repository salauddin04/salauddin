package com.google.android.gms.internal.ads;

import java.util.Map;

final class zzahh implements zzahn<zzbha> {
    zzahh() {
    }

    public final /* synthetic */ void zza(Object obj, Map map) {
        obj = ((zzbha) obj).zzaat();
        if (obj != null) {
            obj.zzrg();
        }
    }
}
