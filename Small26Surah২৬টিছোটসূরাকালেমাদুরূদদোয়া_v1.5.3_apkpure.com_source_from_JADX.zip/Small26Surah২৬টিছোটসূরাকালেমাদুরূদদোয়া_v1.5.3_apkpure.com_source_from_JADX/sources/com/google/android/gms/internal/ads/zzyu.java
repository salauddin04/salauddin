package com.google.android.gms.internal.ads;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzyu extends IInterface {
    void onAdClicked() throws RemoteException;
}
