package com.google.android.gms.internal.ads;

import java.io.IOException;

final class zzoh {
    private final zzst zzbac = new zzst(8);
    private int zzbch;

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean zza(com.google.android.gms.internal.ads.zzno r18) throws java.io.IOException, java.lang.InterruptedException {
        /*
        r17 = this;
        r0 = r17;
        r1 = r18;
        r2 = r18.getLength();
        r4 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;
        r6 = -1;
        r8 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1));
        if (r8 == 0) goto L_0x0016;
    L_0x0010:
        r8 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1));
        if (r8 <= 0) goto L_0x0015;
    L_0x0014:
        goto L_0x0016;
    L_0x0015:
        r4 = r2;
    L_0x0016:
        r5 = (int) r4;
        r4 = r0.zzbac;
        r4 = r4.data;
        r8 = 4;
        r9 = 0;
        r1.zzc(r4, r9, r8);
        r4 = r0.zzbac;
        r10 = r4.zzge();
        r0.zzbch = r8;
    L_0x0028:
        r12 = 440786851; // 0x1a45dfa3 float:4.0919297E-23 double:2.1777764E-315;
        r4 = 1;
        r8 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1));
        if (r8 == 0) goto L_0x0050;
    L_0x0030:
        r8 = r0.zzbch;
        r8 = r8 + r4;
        r0.zzbch = r8;
        if (r8 != r5) goto L_0x0038;
    L_0x0037:
        return r9;
    L_0x0038:
        r8 = r0.zzbac;
        r8 = r8.data;
        r1.zzc(r8, r9, r4);
        r4 = 8;
        r10 = r10 << r4;
        r12 = -256; // 0xffffffffffffff00 float:NaN double:NaN;
        r10 = r10 & r12;
        r4 = r0.zzbac;
        r4 = r4.data;
        r4 = r4[r9];
        r4 = r4 & 255;
        r12 = (long) r4;
        r10 = r10 | r12;
        goto L_0x0028;
    L_0x0050:
        r10 = r17.zzc(r18);
        r5 = r0.zzbch;
        r12 = (long) r5;
        r14 = -9223372036854775808;
        r5 = (r10 > r14 ? 1 : (r10 == r14 ? 0 : -1));
        if (r5 == 0) goto L_0x00a3;
    L_0x005d:
        r5 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1));
        if (r5 == 0) goto L_0x0068;
    L_0x0061:
        r5 = r12 + r10;
        r7 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1));
        if (r7 < 0) goto L_0x0068;
    L_0x0067:
        goto L_0x00a3;
    L_0x0068:
        r2 = r0.zzbch;
        r5 = (long) r2;
        r7 = r12 + r10;
        r3 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1));
        if (r3 >= 0) goto L_0x009d;
    L_0x0071:
        r2 = r17.zzc(r18);
        r5 = (r2 > r14 ? 1 : (r2 == r14 ? 0 : -1));
        if (r5 != 0) goto L_0x007a;
    L_0x0079:
        return r9;
    L_0x007a:
        r2 = r17.zzc(r18);
        r5 = 0;
        r7 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1));
        if (r7 < 0) goto L_0x009c;
    L_0x0084:
        r7 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        r16 = (r2 > r7 ? 1 : (r2 == r7 ? 0 : -1));
        if (r16 <= 0) goto L_0x008c;
    L_0x008b:
        goto L_0x009c;
    L_0x008c:
        r7 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1));
        if (r7 == 0) goto L_0x0068;
    L_0x0090:
        r5 = (int) r2;
        r1.zzar(r5);
        r5 = r0.zzbch;
        r5 = (long) r5;
        r5 = r5 + r2;
        r2 = (int) r5;
        r0.zzbch = r2;
        goto L_0x0068;
    L_0x009c:
        return r9;
    L_0x009d:
        r1 = (long) r2;
        r3 = (r1 > r7 ? 1 : (r1 == r7 ? 0 : -1));
        if (r3 != 0) goto L_0x00a3;
    L_0x00a2:
        return r4;
    L_0x00a3:
        return r9;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzoh.zza(com.google.android.gms.internal.ads.zzno):boolean");
    }

    private final long zzc(zzno zzno) throws IOException, InterruptedException {
        int i = 0;
        zzno.zzc(this.zzbac.data, 0, 1);
        int i2 = this.zzbac.data[0] & 255;
        if (i2 == 0) {
            return Long.MIN_VALUE;
        }
        int i3 = 128;
        int i4 = 0;
        while ((i2 & i3) == 0) {
            i3 >>= 1;
            i4++;
        }
        i2 &= i3 ^ -1;
        zzno.zzc(this.zzbac.data, 1, i4);
        while (i < i4) {
            i++;
            i2 = (this.zzbac.data[i] & 255) + (i2 << 8);
        }
        this.zzbch += i4 + 1;
        return (long) i2;
    }
}
