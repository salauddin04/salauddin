package com.google.android.gms.internal.measurement;

import android.content.Context;
import android.support.annotation.GuardedBy;
import android.support.v4.content.PermissionChecker;
import android.util.Log;

final class zzcs implements zzcp {
    @GuardedBy("GservicesLoader.class")
    static zzcs zzzq;
    private final Context zzno;

    static zzcs zzp(Context context) {
        synchronized (zzcs.class) {
            if (zzzq == null) {
                zzzq = (PermissionChecker.checkSelfPermission(context, "com.google.android.providers.gsf.permission.READ_GSERVICES") == 0 ? 1 : null) != null ? new zzcs(context) : new zzcs();
            }
            context = zzzq;
        }
        return context;
    }

    private zzcs(Context context) {
        this.zzno = context;
        this.zzno.getContentResolver().registerContentObserver(zzci.CONTENT_URI, true, new zzcu(this, null));
    }

    private zzcs() {
        this.zzno = null;
    }

    private final String zzcb(String str) {
        if (this.zzno == null) {
            return null;
        }
        try {
            return (String) zzcq.zza(new zzct(this, str));
        } catch (Throwable e) {
            String str2 = "Unable to read GServices for: ";
            str = String.valueOf(str);
            Log.e("GservicesLoader", str.length() != 0 ? str2.concat(str) : new String(str2), e);
            return null;
        }
    }

    public final /* synthetic */ Object zzca(String str) {
        return zzcb(str);
    }

    final /* synthetic */ String zzcc(String str) {
        return zzci.zza(this.zzno.getContentResolver(), str, null);
    }
}
