package com.google.android.gms.internal.measurement;

import java.io.IOException;

public abstract class zzip<M extends zzip<M>> extends zziv {
    protected zzir zzand;

    protected int zzja() {
        if (this.zzand == null) {
            return 0;
        }
        int i = 0;
        for (int i2 = 0; i2 < this.zzand.size(); i2++) {
            i += this.zzand.zzbn(i2).zzja();
        }
        return i;
    }

    public void zza(zzin zzin) throws IOException {
        if (this.zzand != null) {
            for (int i = 0; i < this.zzand.size(); i++) {
                this.zzand.zzbn(i).zza(zzin);
            }
        }
    }

    protected final boolean zza(zzim zzim, int i) throws IOException {
        int position = zzim.getPosition();
        if (!zzim.zzv(i)) {
            return null;
        }
        int i2 = i >>> 3;
        zzix zzix = new zzix(i, zzim.zzt(position, zzim.getPosition() - position));
        zzim = null;
        i = this.zzand;
        if (i == 0) {
            this.zzand = new zzir();
        } else {
            zzim = i.zzbm(i2);
        }
        if (zzim == null) {
            zzim = new zzis();
            this.zzand.zza(i2, zzim);
        }
        zzim.zza(zzix);
        return true;
    }

    public final /* synthetic */ zziv zzpe() throws CloneNotSupportedException {
        return (zzip) clone();
    }

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        zzip zzip = (zzip) super.zzpe();
        zzit.zza(this, zzip);
        return zzip;
    }
}
