package com.google.android.gms.internal.ads;

import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;

public interface zzzl extends IInterface {
    IBinder zza(IObjectWrapper iObjectWrapper, zzyb zzyb, String str, zzamq zzamq, int i, int i2) throws RemoteException;
}
