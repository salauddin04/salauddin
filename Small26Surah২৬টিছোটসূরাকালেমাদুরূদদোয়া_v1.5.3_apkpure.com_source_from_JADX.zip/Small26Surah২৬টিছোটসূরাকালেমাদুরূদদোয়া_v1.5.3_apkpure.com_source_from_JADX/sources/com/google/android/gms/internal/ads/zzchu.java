package com.google.android.gms.internal.ads;

import android.content.Context;
import android.support.annotation.NonNull;
import com.google.android.gms.ads.internal.zzk;
import com.google.android.gms.common.ConnectionResult;
import java.io.InputStream;

public final class zzchu extends zzchw {
    public zzchu(Context context) {
        this.zzfxi = new zzarg(context, zzk.zzlu().zzwr(), this, this);
    }

    public final zzbbi<InputStream> zzf(zzary zzary) {
        synchronized (this.mLock) {
            if (this.zzfxf) {
                zzary = this.zzddx;
                return zzary;
            }
            this.zzfxf = true;
            this.zzfxh = zzary;
            this.zzfxi.checkAvailabilityAndConnect();
            this.zzddx.zza(new zzchv(this), zzbbn.zzeah);
            zzary = this.zzddx;
            return zzary;
        }
    }

    public final void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        zzbae.zzdp("Cannot connect to remote service, fallback to local instance.");
        this.zzddx.setException(new zzcid(0));
    }

    public final void onConnected(android.os.Bundle r5) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r4 = this;
        r5 = r4.mLock;
        monitor-enter(r5);
        r0 = r4.zzfxg;	 Catch:{ all -> 0x003d }
        if (r0 != 0) goto L_0x003b;	 Catch:{ all -> 0x003d }
    L_0x0007:
        r0 = 1;	 Catch:{ all -> 0x003d }
        r4.zzfxg = r0;	 Catch:{ all -> 0x003d }
        r0 = 0;
        r1 = r4.zzfxi;	 Catch:{ RemoteException -> 0x0031, RemoteException -> 0x0031, Throwable -> 0x001c }
        r1 = r1.zztr();	 Catch:{ RemoteException -> 0x0031, RemoteException -> 0x0031, Throwable -> 0x001c }
        r2 = r4.zzfxh;	 Catch:{ RemoteException -> 0x0031, RemoteException -> 0x0031, Throwable -> 0x001c }
        r3 = new com.google.android.gms.internal.ads.zzchx;	 Catch:{ RemoteException -> 0x0031, RemoteException -> 0x0031, Throwable -> 0x001c }
        r3.<init>(r4);	 Catch:{ RemoteException -> 0x0031, RemoteException -> 0x0031, Throwable -> 0x001c }
        r1.zza(r2, r3);	 Catch:{ RemoteException -> 0x0031, RemoteException -> 0x0031, Throwable -> 0x001c }
        goto L_0x003b;
    L_0x001c:
        r1 = move-exception;
        r2 = com.google.android.gms.ads.internal.zzk.zzlk();	 Catch:{ all -> 0x003d }
        r3 = "RemoteAdRequestClientTask.onConnected";	 Catch:{ all -> 0x003d }
        r2.zza(r1, r3);	 Catch:{ all -> 0x003d }
        r1 = r4.zzddx;	 Catch:{ all -> 0x003d }
        r2 = new com.google.android.gms.internal.ads.zzcid;	 Catch:{ all -> 0x003d }
        r2.<init>(r0);	 Catch:{ all -> 0x003d }
        r1.setException(r2);	 Catch:{ all -> 0x003d }
        goto L_0x003b;	 Catch:{ all -> 0x003d }
    L_0x0031:
        r1 = r4.zzddx;	 Catch:{ all -> 0x003d }
        r2 = new com.google.android.gms.internal.ads.zzcid;	 Catch:{ all -> 0x003d }
        r2.<init>(r0);	 Catch:{ all -> 0x003d }
        r1.setException(r2);	 Catch:{ all -> 0x003d }
    L_0x003b:
        monitor-exit(r5);	 Catch:{ all -> 0x003d }
        return;	 Catch:{ all -> 0x003d }
    L_0x003d:
        r0 = move-exception;	 Catch:{ all -> 0x003d }
        monitor-exit(r5);	 Catch:{ all -> 0x003d }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzchu.onConnected(android.os.Bundle):void");
    }
}
