package com.google.android.gms.internal.ads;

import android.content.Context;

public final class zzcsu implements zzcuz<zzcst> {
    private final zzbbm zzfqw;
    private final Context zzlj;

    public zzcsu(Context context, zzbbm zzbbm) {
        this.zzlj = context;
        this.zzfqw = zzbbm;
    }

    public final zzbbi<zzcst> zzalm() {
        return this.zzfqw.zza(new zzcsv(this));
    }
}
