package com.google.android.gms.internal.measurement;

final class zzfx implements zzgg {
    zzfx() {
    }

    public final boolean zzb(Class<?> cls) {
        return false;
    }

    public final zzgf zzc(Class<?> cls) {
        throw new IllegalStateException("This should never be called.");
    }
}
