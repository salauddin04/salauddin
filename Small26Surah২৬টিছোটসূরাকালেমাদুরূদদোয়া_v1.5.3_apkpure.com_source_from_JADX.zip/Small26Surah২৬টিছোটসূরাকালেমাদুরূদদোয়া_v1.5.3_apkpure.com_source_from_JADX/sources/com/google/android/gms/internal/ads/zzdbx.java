package com.google.android.gms.internal.ads;

import java.security.GeneralSecurityException;

public interface zzdbx {
    byte[] zzk(byte[] bArr) throws GeneralSecurityException;
}
