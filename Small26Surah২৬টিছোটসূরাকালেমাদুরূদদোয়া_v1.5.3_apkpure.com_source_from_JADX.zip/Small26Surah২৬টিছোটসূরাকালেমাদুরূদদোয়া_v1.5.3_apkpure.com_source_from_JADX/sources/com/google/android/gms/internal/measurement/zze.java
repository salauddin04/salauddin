package com.google.android.gms.internal.measurement;

import android.os.Bundle;
import android.os.IInterface;
import android.os.RemoteException;

public interface zze extends IInterface {
    Bundle zza(Bundle bundle) throws RemoteException;
}
