package com.google.android.gms.internal.ads;

import android.os.Bundle;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract class zzagg extends zzfn implements zzagf {
    public zzagg() {
        super("com.google.android.gms.ads.internal.formats.client.IUnifiedNativeAd");
    }

    protected final boolean dispatchTransaction(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
        IInterface zzri;
        switch (i) {
            case 2:
                i = getHeadline();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 3:
                i = getImages();
                parcel2.writeNoException();
                parcel2.writeList(i);
                break;
            case 4:
                i = getBody();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 5:
                zzri = zzri();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzri);
                break;
            case 6:
                i = getCallToAction();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 7:
                i = getAdvertiser();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 8:
                i = getStarRating();
                parcel2.writeNoException();
                parcel2.writeDouble(i);
                break;
            case 9:
                i = getStore();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 10:
                i = getPrice();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 11:
                zzri = getVideoController();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzri);
                break;
            case 12:
                i = getMediationAdapterClassName();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 13:
                destroy();
                parcel2.writeNoException();
                break;
            case 14:
                zzri = zzrj();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzri);
                break;
            case 15:
                performClick((Bundle) zzfo.zza(parcel, Bundle.CREATOR));
                parcel2.writeNoException();
                break;
            case 16:
                i = recordImpression((Bundle) zzfo.zza(parcel, Bundle.CREATOR));
                parcel2.writeNoException();
                zzfo.writeBoolean(parcel2, i);
                break;
            case 17:
                reportTouchEvent((Bundle) zzfo.zza(parcel, Bundle.CREATOR));
                parcel2.writeNoException();
                break;
            case 18:
                zzri = zzrh();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzri);
                break;
            case 19:
                zzri = zzrk();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzri);
                break;
            case 20:
                i = getExtras();
                parcel2.writeNoException();
                zzfo.zzb(parcel2, i);
                break;
            case 21:
                i = parcel.readStrongBinder();
                if (i == 0) {
                    i = 0;
                } else {
                    parcel = i.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IUnconfirmedClickListener");
                    if ((parcel instanceof zzagc) != 0) {
                        i = (zzagc) parcel;
                    } else {
                        i = new zzage(i);
                    }
                }
                zza((zzagc) i);
                parcel2.writeNoException();
                break;
            case 22:
                cancelUnconfirmedClick();
                parcel2.writeNoException();
                break;
            case 23:
                i = getMuteThisAdReasons();
                parcel2.writeNoException();
                parcel2.writeList(i);
                break;
            case 24:
                i = isCustomMuteThisAdEnabled();
                parcel2.writeNoException();
                zzfo.writeBoolean(parcel2, i);
                break;
            case 25:
                zza((zzaai) zzaaj.zzf(parcel.readStrongBinder()));
                parcel2.writeNoException();
                break;
            case 26:
                zza((zzaae) zzaaf.zze(parcel.readStrongBinder()));
                parcel2.writeNoException();
                break;
            case 27:
                zzro();
                parcel2.writeNoException();
                break;
            case 28:
                recordCustomClickGesture();
                parcel2.writeNoException();
                break;
            case 29:
                zzri = zzrp();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzri);
                break;
            default:
                return false;
        }
        return true;
    }
}
