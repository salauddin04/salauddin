package com.google.android.gms.internal.measurement;

final class zzga<K, V> {
    public final zzif zzais;
    public final K zzait;
    public final zzif zzaiu;
    public final V zzzw;
}
