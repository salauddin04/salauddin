package com.google.android.gms.internal.ads;

import android.view.View;
import android.view.View.OnAttachStateChangeListener;

final class zzbis implements OnAttachStateChangeListener {
    private final /* synthetic */ zzavc zzeju;
    private final /* synthetic */ zzbip zzemo;

    zzbis(zzbip zzbip, zzavc zzavc) {
        this.zzemo = zzbip;
        this.zzeju = zzavc;
    }

    public final void onViewDetachedFromWindow(View view) {
    }

    public final void onViewAttachedToWindow(View view) {
        this.zzemo.zza(view, this.zzeju, 10);
    }
}
