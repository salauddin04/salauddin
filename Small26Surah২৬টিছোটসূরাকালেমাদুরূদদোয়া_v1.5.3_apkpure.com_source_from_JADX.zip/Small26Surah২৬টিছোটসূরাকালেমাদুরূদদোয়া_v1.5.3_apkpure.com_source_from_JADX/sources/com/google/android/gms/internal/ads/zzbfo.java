package com.google.android.gms.internal.ads;

@zzare
final class zzbfo extends zzay {
    static final zzbfo zzehq = new zzbfo();

    zzbfo() {
    }

    public final zzbd zza(String str, byte[] bArr, String str2) {
        if ("moov".equals(str) != null) {
            return new zzbf();
        }
        if ("mvhd".equals(str) != null) {
            return new zzbg();
        }
        return new zzbh(str);
    }
}
