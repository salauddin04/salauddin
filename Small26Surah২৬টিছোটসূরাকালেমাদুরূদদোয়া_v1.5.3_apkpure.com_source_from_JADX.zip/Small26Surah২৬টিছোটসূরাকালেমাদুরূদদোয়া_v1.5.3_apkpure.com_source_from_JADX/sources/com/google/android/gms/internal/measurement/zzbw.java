package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzbt.zze.zzb;

final class zzbw implements zzfe {
    static final zzfe zzty = new zzbw();

    private zzbw() {
    }

    public final boolean zzf(int i) {
        return zzb.zzk(i) != 0;
    }
}
