package com.google.android.gms.internal.ads;

public final class zzccz implements zzdth<zzccy> {
    private final zzdtt<zzbsd> zzexh;
    private final zzdtt<zzcxl> zzffi;

    public zzccz(zzdtt<zzbsd> zzdtt, zzdtt<zzcxl> zzdtt2) {
        this.zzexh = zzdtt;
        this.zzffi = zzdtt2;
    }

    public final /* synthetic */ Object get() {
        return new zzccy((zzbsd) this.zzexh.get(), (zzcxl) this.zzffi.get());
    }
}
