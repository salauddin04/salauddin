package com.google.android.gms.internal.ads;

import java.util.Map;

final class zzcco implements zzbao<zzbha> {
    private final /* synthetic */ String zzfso;
    private final /* synthetic */ Map zzfsp;

    zzcco(zzcci zzcci, String str, Map map) {
        this.zzfso = str;
        this.zzfsp = map;
    }

    public final void zzb(Throwable th) {
    }

    public final /* synthetic */ void zzk(Object obj) {
        ((zzbha) obj).zza(this.zzfso, this.zzfsp);
    }
}
