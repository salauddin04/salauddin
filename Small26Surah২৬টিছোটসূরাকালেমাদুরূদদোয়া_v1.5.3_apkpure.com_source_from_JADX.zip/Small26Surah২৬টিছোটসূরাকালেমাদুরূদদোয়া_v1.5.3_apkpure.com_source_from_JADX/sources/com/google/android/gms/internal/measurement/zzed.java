package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.util.Arrays;

final class zzed extends zzeb {
    private final byte[] buffer;
    private int limit;
    private int pos;
    private final boolean zzacm;
    private int zzacn;
    private int zzaco;
    private int zzacp;
    private int zzacq;

    private zzed(byte[] bArr, int i, int i2, boolean z) {
        super();
        this.zzacq = Integer.MAX_VALUE;
        this.buffer = bArr;
        this.limit = i2 + i;
        this.pos = i;
        this.zzaco = this.pos;
        this.zzacm = z;
    }

    final long zzky() throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:9:0x001d in {5, 6, 8} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r6 = this;
        r0 = 0;
        r2 = 0;
    L_0x0003:
        r3 = 64;
        if (r2 >= r3) goto L_0x0018;
    L_0x0007:
        r3 = r6.zzlg();
        r4 = r3 & 127;
        r4 = (long) r4;
        r4 = r4 << r2;
        r0 = r0 | r4;
        r3 = r3 & 128;
        if (r3 != 0) goto L_0x0015;
    L_0x0014:
        return r0;
    L_0x0015:
        r2 = r2 + 7;
        goto L_0x0003;
    L_0x0018:
        r0 = com.google.android.gms.internal.measurement.zzfh.zzmw();
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzed.zzky():long");
    }

    public final boolean zzv(int r6) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:40:0x006f in {11, 13, 14, 18, 20, 22, 24, 30, 32, 36, 37, 39} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r5 = this;
        r0 = r6 & 7;
        r1 = 0;
        r2 = 1;
        if (r0 == 0) goto L_0x003f;
    L_0x0006:
        if (r0 == r2) goto L_0x0039;
    L_0x0008:
        r3 = 2;
        if (r0 == r3) goto L_0x0031;
    L_0x000b:
        r3 = 4;
        r4 = 3;
        if (r0 == r4) goto L_0x001e;
    L_0x000f:
        if (r0 == r3) goto L_0x001d;
    L_0x0011:
        r6 = 5;
        if (r0 != r6) goto L_0x0018;
    L_0x0014:
        r5.zzz(r3);
        return r2;
    L_0x0018:
        r6 = com.google.android.gms.internal.measurement.zzfh.zzmz();
        throw r6;
    L_0x001d:
        return r1;
    L_0x001e:
        r0 = r5.zzkj();
        if (r0 == 0) goto L_0x002a;
    L_0x0024:
        r0 = r5.zzv(r0);
        if (r0 != 0) goto L_0x001e;
    L_0x002a:
        r6 = r6 >>> r4;
        r6 = r6 << r4;
        r6 = r6 | r3;
        r5.zzu(r6);
        return r2;
    L_0x0031:
        r6 = r5.zzlb();
        r5.zzz(r6);
        return r2;
    L_0x0039:
        r6 = 8;
        r5.zzz(r6);
        return r2;
    L_0x003f:
        r6 = r5.limit;
        r0 = r5.pos;
        r6 = r6 - r0;
        r0 = 10;
        if (r6 < r0) goto L_0x005e;
    L_0x0048:
        if (r1 >= r0) goto L_0x0059;
    L_0x004a:
        r6 = r5.buffer;
        r3 = r5.pos;
        r4 = r3 + 1;
        r5.pos = r4;
        r6 = r6[r3];
        if (r6 >= 0) goto L_0x0069;
    L_0x0056:
        r1 = r1 + 1;
        goto L_0x0048;
    L_0x0059:
        r6 = com.google.android.gms.internal.measurement.zzfh.zzmw();
        throw r6;
    L_0x005e:
        if (r1 >= r0) goto L_0x006a;
    L_0x0060:
        r6 = r5.zzlg();
        if (r6 >= 0) goto L_0x0069;
    L_0x0066:
        r1 = r1 + 1;
        goto L_0x005e;
    L_0x0069:
        return r2;
    L_0x006a:
        r6 = com.google.android.gms.internal.measurement.zzfh.zzmw();
        throw r6;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzed.zzv(int):boolean");
    }

    public final int zzkj() throws IOException {
        if (zzkz()) {
            this.zzacp = 0;
            return 0;
        }
        this.zzacp = zzlb();
        int i = this.zzacp;
        if ((i >>> 3) != 0) {
            return i;
        }
        throw zzfh.zzmx();
    }

    public final void zzu(int i) throws zzfh {
        if (this.zzacp != i) {
            throw zzfh.zzmy();
        }
    }

    public final double readDouble() throws IOException {
        return Double.longBitsToDouble(zzle());
    }

    public final float readFloat() throws IOException {
        return Float.intBitsToFloat(zzld());
    }

    public final long zzkk() throws IOException {
        return zzlc();
    }

    public final long zzkl() throws IOException {
        return zzlc();
    }

    public final int zzkm() throws IOException {
        return zzlb();
    }

    public final long zzkn() throws IOException {
        return zzle();
    }

    public final int zzko() throws IOException {
        return zzld();
    }

    public final boolean zzkp() throws IOException {
        return zzlc() != 0;
    }

    public final String readString() throws IOException {
        int zzlb = zzlb();
        if (zzlb > 0) {
            int i = this.limit;
            int i2 = this.pos;
            if (zzlb <= i - i2) {
                String str = new String(this.buffer, i2, zzlb, zzfb.UTF_8);
                this.pos += zzlb;
                return str;
            }
        }
        if (zzlb == 0) {
            return "";
        }
        if (zzlb < 0) {
            throw zzfh.zzmv();
        }
        throw zzfh.zzmu();
    }

    public final String zzkq() throws IOException {
        int zzlb = zzlb();
        if (zzlb > 0) {
            int i = this.limit;
            int i2 = this.pos;
            if (zzlb <= i - i2) {
                String zzh = zzhy.zzh(this.buffer, i2, zzlb);
                this.pos += zzlb;
                return zzh;
            }
        }
        if (zzlb == 0) {
            return "";
        }
        if (zzlb <= 0) {
            throw zzfh.zzmv();
        }
        throw zzfh.zzmu();
    }

    public final <T extends zzgh> T zza(zzgs<T> zzgs, zzem zzem) throws IOException {
        int zzlb = zzlb();
        if (this.zzach < this.zzaci) {
            zzlb = zzx(zzlb);
            this.zzach++;
            zzgh zzgh = (zzgh) zzgs.zza(this, zzem);
            zzu(null);
            this.zzach--;
            zzy(zzlb);
            return zzgh;
        }
        throw zzfh.zzna();
    }

    public final zzdp zzkr() throws IOException {
        int i;
        int i2;
        int zzlb = zzlb();
        if (zzlb > 0) {
            i = this.limit;
            i2 = this.pos;
            if (zzlb <= i - i2) {
                zzdp zzb = zzdp.zzb(this.buffer, i2, zzlb);
                this.pos += zzlb;
                return zzb;
            }
        }
        if (zzlb == 0) {
            return zzdp.zzaby;
        }
        if (zzlb > 0) {
            i = this.limit;
            i2 = this.pos;
            if (zzlb <= i - i2) {
                this.pos = zzlb + i2;
                byte[] copyOfRange = Arrays.copyOfRange(this.buffer, i2, this.pos);
                return zzdp.zzg(copyOfRange);
            }
        }
        if (zzlb > 0) {
            throw zzfh.zzmu();
        } else if (zzlb == 0) {
            copyOfRange = zzfb.zzahk;
            return zzdp.zzg(copyOfRange);
        } else {
            throw zzfh.zzmv();
        }
    }

    public final int zzks() throws IOException {
        return zzlb();
    }

    public final int zzkt() throws IOException {
        return zzlb();
    }

    public final int zzku() throws IOException {
        return zzld();
    }

    public final long zzkv() throws IOException {
        return zzle();
    }

    public final int zzkw() throws IOException {
        return zzeb.zzaa(zzlb());
    }

    public final long zzkx() throws IOException {
        return zzeb.zzap(zzlc());
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final int zzlb() throws java.io.IOException {
        /*
        r5 = this;
        r0 = r5.pos;
        r1 = r5.limit;
        if (r1 == r0) goto L_0x006b;
    L_0x0006:
        r2 = r5.buffer;
        r3 = r0 + 1;
        r0 = r2[r0];
        if (r0 < 0) goto L_0x0011;
    L_0x000e:
        r5.pos = r3;
        return r0;
    L_0x0011:
        r1 = r1 - r3;
        r4 = 9;
        if (r1 < r4) goto L_0x006b;
    L_0x0016:
        r1 = r3 + 1;
        r3 = r2[r3];
        r3 = r3 << 7;
        r0 = r0 ^ r3;
        if (r0 >= 0) goto L_0x0022;
    L_0x001f:
        r0 = r0 ^ -128;
        goto L_0x0068;
    L_0x0022:
        r3 = r1 + 1;
        r1 = r2[r1];
        r1 = r1 << 14;
        r0 = r0 ^ r1;
        if (r0 < 0) goto L_0x002f;
    L_0x002b:
        r0 = r0 ^ 16256;
    L_0x002d:
        r1 = r3;
        goto L_0x0068;
    L_0x002f:
        r1 = r3 + 1;
        r3 = r2[r3];
        r3 = r3 << 21;
        r0 = r0 ^ r3;
        if (r0 >= 0) goto L_0x003d;
    L_0x0038:
        r2 = -2080896; // 0xffffffffffe03f80 float:NaN double:NaN;
        r0 = r0 ^ r2;
        goto L_0x0068;
    L_0x003d:
        r3 = r1 + 1;
        r1 = r2[r1];
        r4 = r1 << 28;
        r0 = r0 ^ r4;
        r4 = 266354560; // 0xfe03f80 float:2.2112565E-29 double:1.315966377E-315;
        r0 = r0 ^ r4;
        if (r1 >= 0) goto L_0x002d;
    L_0x004a:
        r1 = r3 + 1;
        r3 = r2[r3];
        if (r3 >= 0) goto L_0x0068;
    L_0x0050:
        r3 = r1 + 1;
        r1 = r2[r1];
        if (r1 >= 0) goto L_0x002d;
    L_0x0056:
        r1 = r3 + 1;
        r3 = r2[r3];
        if (r3 >= 0) goto L_0x0068;
    L_0x005c:
        r3 = r1 + 1;
        r1 = r2[r1];
        if (r1 >= 0) goto L_0x002d;
    L_0x0062:
        r1 = r3 + 1;
        r2 = r2[r3];
        if (r2 < 0) goto L_0x006b;
    L_0x0068:
        r5.pos = r1;
        return r0;
    L_0x006b:
        r0 = r5.zzky();
        r1 = (int) r0;
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzed.zzlb():int");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final long zzlc() throws java.io.IOException {
        /*
        r11 = this;
        r0 = r11.pos;
        r1 = r11.limit;
        if (r1 == r0) goto L_0x00b5;
    L_0x0006:
        r2 = r11.buffer;
        r3 = r0 + 1;
        r0 = r2[r0];
        if (r0 < 0) goto L_0x0012;
    L_0x000e:
        r11.pos = r3;
        r0 = (long) r0;
        return r0;
    L_0x0012:
        r1 = r1 - r3;
        r4 = 9;
        if (r1 < r4) goto L_0x00b5;
    L_0x0017:
        r1 = r3 + 1;
        r3 = r2[r3];
        r3 = r3 << 7;
        r0 = r0 ^ r3;
        if (r0 >= 0) goto L_0x0026;
    L_0x0020:
        r0 = r0 ^ -128;
    L_0x0022:
        r2 = (long) r0;
        r3 = r2;
        goto L_0x00b2;
    L_0x0026:
        r3 = r1 + 1;
        r1 = r2[r1];
        r1 = r1 << 14;
        r0 = r0 ^ r1;
        if (r0 < 0) goto L_0x0037;
    L_0x002f:
        r0 = r0 ^ 16256;
        r0 = (long) r0;
        r9 = r0;
        r1 = r3;
        r3 = r9;
        goto L_0x00b2;
    L_0x0037:
        r1 = r3 + 1;
        r3 = r2[r3];
        r3 = r3 << 21;
        r0 = r0 ^ r3;
        if (r0 >= 0) goto L_0x0045;
    L_0x0040:
        r2 = -2080896; // 0xffffffffffe03f80 float:NaN double:NaN;
        r0 = r0 ^ r2;
        goto L_0x0022;
    L_0x0045:
        r3 = (long) r0;
        r0 = r1 + 1;
        r1 = r2[r1];
        r5 = (long) r1;
        r1 = 28;
        r5 = r5 << r1;
        r3 = r3 ^ r5;
        r5 = 0;
        r1 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1));
        if (r1 < 0) goto L_0x005c;
    L_0x0055:
        r1 = 266354560; // 0xfe03f80 float:2.2112565E-29 double:1.315966377E-315;
    L_0x0058:
        r1 = r1 ^ r3;
        r3 = r1;
    L_0x005a:
        r1 = r0;
        goto L_0x00b2;
    L_0x005c:
        r1 = r0 + 1;
        r0 = r2[r0];
        r7 = (long) r0;
        r0 = 35;
        r7 = r7 << r0;
        r3 = r3 ^ r7;
        r0 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1));
        if (r0 >= 0) goto L_0x0070;
    L_0x0069:
        r5 = -34093383808; // 0xfffffff80fe03f80 float:2.2112565E-29 double:NaN;
    L_0x006e:
        r3 = r3 ^ r5;
        goto L_0x00b2;
    L_0x0070:
        r0 = r1 + 1;
        r1 = r2[r1];
        r7 = (long) r1;
        r1 = 42;
        r7 = r7 << r1;
        r3 = r3 ^ r7;
        r1 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1));
        if (r1 < 0) goto L_0x0083;
    L_0x007d:
        r1 = 4363953127296; // 0x3f80fe03f80 float:2.2112565E-29 double:2.1560793202584E-311;
        goto L_0x0058;
    L_0x0083:
        r1 = r0 + 1;
        r0 = r2[r0];
        r7 = (long) r0;
        r0 = 49;
        r7 = r7 << r0;
        r3 = r3 ^ r7;
        r0 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1));
        if (r0 >= 0) goto L_0x0096;
    L_0x0090:
        r5 = -558586000294016; // 0xfffe03f80fe03f80 float:2.2112565E-29 double:NaN;
        goto L_0x006e;
    L_0x0096:
        r0 = r1 + 1;
        r1 = r2[r1];
        r7 = (long) r1;
        r1 = 56;
        r7 = r7 << r1;
        r3 = r3 ^ r7;
        r7 = 71499008037633920; // 0xfe03f80fe03f80 float:2.2112565E-29 double:6.838959413692434E-304;
        r3 = r3 ^ r7;
        r1 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1));
        if (r1 >= 0) goto L_0x005a;
    L_0x00a9:
        r1 = r0 + 1;
        r0 = r2[r0];
        r7 = (long) r0;
        r0 = (r7 > r5 ? 1 : (r7 == r5 ? 0 : -1));
        if (r0 < 0) goto L_0x00b5;
    L_0x00b2:
        r11.pos = r1;
        return r3;
    L_0x00b5:
        r0 = r11.zzky();
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzed.zzlc():long");
    }

    private final int zzld() throws IOException {
        int i = this.pos;
        if (this.limit - i >= 4) {
            byte[] bArr = this.buffer;
            this.pos = i + 4;
            return ((bArr[i + 3] & 255) << 24) | (((bArr[i] & 255) | ((bArr[i + 1] & 255) << 8)) | ((bArr[i + 2] & 255) << 16));
        }
        throw zzfh.zzmu();
    }

    private final long zzle() throws IOException {
        int i = this.pos;
        if (this.limit - i >= 8) {
            byte[] bArr = this.buffer;
            this.pos = i + 8;
            return ((((long) bArr[i + 7]) & 255) << 56) | (((((((((long) bArr[i]) & 255) | ((((long) bArr[i + 1]) & 255) << 8)) | ((((long) bArr[i + 2]) & 255) << 16)) | ((((long) bArr[i + 3]) & 255) << 24)) | ((((long) bArr[i + 4]) & 255) << 32)) | ((((long) bArr[i + 5]) & 255) << 40)) | ((((long) bArr[i + 6]) & 255) << 48));
        }
        throw zzfh.zzmu();
    }

    public final int zzx(int i) throws zzfh {
        if (i >= 0) {
            i += zzla();
            int i2 = this.zzacq;
            if (i <= i2) {
                this.zzacq = i;
                zzlf();
                return i2;
            }
            throw zzfh.zzmu();
        }
        throw zzfh.zzmv();
    }

    private final void zzlf() {
        this.limit += this.zzacn;
        int i = this.limit;
        int i2 = i - this.zzaco;
        int i3 = this.zzacq;
        if (i2 > i3) {
            this.zzacn = i2 - i3;
            this.limit = i - this.zzacn;
            return;
        }
        this.zzacn = 0;
    }

    public final void zzy(int i) {
        this.zzacq = i;
        zzlf();
    }

    public final boolean zzkz() throws IOException {
        return this.pos == this.limit;
    }

    public final int zzla() {
        return this.pos - this.zzaco;
    }

    private final byte zzlg() throws IOException {
        int i = this.pos;
        if (i != this.limit) {
            byte[] bArr = this.buffer;
            this.pos = i + 1;
            return bArr[i];
        }
        throw zzfh.zzmu();
    }

    public final void zzz(int i) throws IOException {
        if (i >= 0) {
            int i2 = this.limit;
            int i3 = this.pos;
            if (i <= i2 - i3) {
                this.pos = i3 + i;
                return;
            }
        }
        if (i < 0) {
            throw zzfh.zzmv();
        }
        throw zzfh.zzmu();
    }
}
