package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class zzez<MessageType extends zzez<MessageType, BuilderType>, BuilderType extends zza<MessageType, BuilderType>> extends zzdg<MessageType, BuilderType> {
    private static Map<Object, zzez<?, ?>> zzagp = new ConcurrentHashMap();
    protected zzhr zzagn = zzhr.zzor();
    private int zzago = -1;

    public enum zze {
        public static final int zzagu = 1;
        public static final int zzagv = 2;
        public static final int zzagw = 3;
        public static final int zzagx = 4;
        public static final int zzagy = 5;
        public static final int zzagz = 6;
        public static final int zzaha = 7;
        private static final /* synthetic */ int[] zzahb = new int[]{zzagu, zzagv, zzagw, zzagx, zzagy, zzagz, zzaha};
        public static final int zzahc = 1;
        public static final int zzahd = 2;
        private static final /* synthetic */ int[] zzahe = new int[]{zzahc, zzahd};
        public static final int zzahf = 1;
        public static final int zzahg = 2;
        private static final /* synthetic */ int[] zzahh = new int[]{zzahf, zzahg};

        public static int[] zzmt() {
            return (int[]) zzahb.clone();
        }
    }

    public static class zzd<ContainingType extends zzgh, Type> extends zzek<ContainingType, Type> {
    }

    public static class zzb<T extends zzez<T, ?>> extends zzdi<T> {
        private final T zzagq;

        public zzb(T t) {
            this.zzagq = t;
        }

        public final /* synthetic */ Object zza(zzeb zzeb, zzem zzem) throws zzfh {
            return zzez.zza(this.zzagq, zzeb, zzem);
        }
    }

    public static abstract class zza<MessageType extends zzez<MessageType, BuilderType>, BuilderType extends zza<MessageType, BuilderType>> extends zzdh<MessageType, BuilderType> {
        private final MessageType zzagq;
        protected MessageType zzagr;
        private boolean zzags = null;

        protected zza(MessageType messageType) {
            this.zzagq = messageType;
            this.zzagr = (zzez) messageType.zza(zze.zzagx, null, null);
        }

        protected final void zzmn() {
            if (this.zzags) {
                zzez zzez = (zzez) this.zzagr.zza(zze.zzagx, null, null);
                zza(zzez, this.zzagr);
                this.zzagr = zzez;
                this.zzags = false;
            }
        }

        public final boolean isInitialized() {
            return zzez.zza(this.zzagr, false);
        }

        public MessageType zzmo() {
            if (this.zzags) {
                return this.zzagr;
            }
            this.zzagr.zzjz();
            this.zzags = true;
            return this.zzagr;
        }

        public final MessageType zzmp() {
            zzez zzez = (zzez) zzmq();
            if (zzez.isInitialized()) {
                return zzez;
            }
            throw new zzhp(zzez);
        }

        public final BuilderType zza(MessageType messageType) {
            zzmn();
            zza(this.zzagr, messageType);
            return this;
        }

        private static void zza(MessageType messageType, MessageType messageType2) {
            zzgu.zznz().zzv(messageType).zzc(messageType, messageType2);
        }

        protected final /* synthetic */ zzdh zza(zzdg zzdg) {
            return zza((zzez) zzdg);
        }

        public final /* synthetic */ zzdh zzjx() {
            return (zza) clone();
        }

        public /* synthetic */ zzgh zzmq() {
            return zzmo();
        }

        public /* synthetic */ zzgh zzmr() {
            return zzmp();
        }

        public final /* synthetic */ zzgh zzmm() {
            return this.zzagq;
        }

        public /* synthetic */ Object clone() throws CloneNotSupportedException {
            zza zza = (zza) this.zzagq.zza(zze.zzagy, null, null);
            zza.zza((zzez) zzmq());
            return zza;
        }
    }

    public static abstract class zzc<MessageType extends zzc<MessageType, BuilderType>, BuilderType> extends zzez<MessageType, BuilderType> implements zzgj {
        protected zzeq<Object> zzagt = zzeq.zzlx();

        final zzeq<Object> zzms() {
            if (this.zzagt.isImmutable()) {
                this.zzagt = (zzeq) this.zzagt.clone();
            }
            return this.zzagt;
        }
    }

    protected abstract Object zza(int i, Object obj, Object obj2);

    public String toString() {
        return zzgk.zza(this, super.toString());
    }

    public int hashCode() {
        if (this.zzabm != 0) {
            return this.zzabm;
        }
        this.zzabm = zzgu.zznz().zzv(this).hashCode(this);
        return this.zzabm;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (((zzez) zza(zze.zzagz, null, null)).getClass().isInstance(obj)) {
            return zzgu.zznz().zzv(this).equals(this, (zzez) obj);
        }
        return null;
    }

    protected final void zzjz() {
        zzgu.zznz().zzv(this).zzi(this);
    }

    protected final <MessageType extends zzez<MessageType, BuilderType>, BuilderType extends zza<MessageType, BuilderType>> BuilderType zzmg() {
        return (zza) zza(zze.zzagy, null, null);
    }

    public final boolean isInitialized() {
        return zza(this, Boolean.TRUE.booleanValue());
    }

    public final BuilderType zzmh() {
        zza zza = (zza) zza(zze.zzagy, null, null);
        zza.zza(this);
        return zza;
    }

    final int zzjw() {
        return this.zzago;
    }

    final void zzn(int i) {
        this.zzago = i;
    }

    public final void zzb(zzeg zzeg) throws IOException {
        zzgu.zznz().zzf(getClass()).zza(this, zzei.zza(zzeg));
    }

    public final int zzly() {
        if (this.zzago == -1) {
            this.zzago = zzgu.zznz().zzv(this).zzs(this);
        }
        return this.zzago;
    }

    static <T extends zzez<?, ?>> T zzd(Class<T> cls) {
        T t = (zzez) zzagp.get(cls);
        if (t == null) {
            try {
                Class.forName(cls.getName(), true, cls.getClassLoader());
                t = (zzez) zzagp.get(cls);
            } catch (Class<T> cls2) {
                throw new IllegalStateException("Class initialization cannot fail.", cls2);
            }
        }
        if (t == null) {
            t = (zzez) ((zzez) zzhw.zzh(cls2)).zza(zze.zzagz, null, null);
            if (t != null) {
                zzagp.put(cls2, t);
            } else {
                throw new IllegalStateException();
            }
        }
        return t;
    }

    protected static <T extends zzez<?, ?>> void zza(Class<T> cls, T t) {
        zzagp.put(cls, t);
    }

    protected static Object zza(zzgh zzgh, String str, Object[] objArr) {
        return new zzgw(zzgh, str, objArr);
    }

    static Object zza(Method method, Object obj, Object... objArr) {
        try {
            return method.invoke(obj, objArr);
        } catch (Method method2) {
            throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", method2);
        } catch (Method method22) {
            method22 = method22.getCause();
            if ((method22 instanceof RuntimeException) != null) {
                throw ((RuntimeException) method22);
            } else if ((method22 instanceof Error) != null) {
                throw ((Error) method22);
            } else {
                throw new RuntimeException("Unexpected exception thrown by generated accessor method.", method22);
            }
        }
    }

    protected static final <T extends zzez<T, ?>> boolean zza(T t, boolean z) {
        byte byteValue = ((Byte) t.zza(zze.zzagu, null, null)).byteValue();
        if (byteValue == (byte) 1) {
            return true;
        }
        if (byteValue == (byte) 0) {
            return null;
        }
        boolean zzu = zzgu.zznz().zzv(t).zzu(t);
        if (z) {
            t.zza(zze.zzagv, zzu ? t : null, null);
        }
        return zzu;
    }

    protected static zzff zzmi() {
        return zzfv.zznk();
    }

    protected static zzff zza(zzff zzff) {
        int size = zzff.size();
        return zzff.zzav(size == 0 ? 10 : size << 1);
    }

    protected static <E> zzfg<E> zzmj() {
        return zzgv.zzoa();
    }

    protected static <E> zzfg<E> zza(zzfg<E> zzfg) {
        int size = zzfg.size();
        return zzfg.zzq(size == 0 ? 10 : size << 1);
    }

    static <T extends zzez<T, ?>> T zza(T t, zzeb zzeb, zzem zzem) throws zzfh {
        zzez zzez = (zzez) t.zza(zze.zzagx, null, null);
        try {
            zzgu.zznz().zzv(zzez).zza(zzez, zzee.zza(zzeb), zzem);
            zzez.zzjz();
            return zzez;
        } catch (zzeb zzeb2) {
            if ((zzeb2.getCause() instanceof zzfh) != null) {
                throw ((zzfh) zzeb2.getCause());
            }
            throw new zzfh(zzeb2.getMessage()).zzg(zzez);
        } catch (T t2) {
            if ((t2.getCause() instanceof zzfh) != null) {
                throw ((zzfh) t2.getCause());
            }
            throw t2;
        }
    }

    private static <T extends com.google.android.gms.internal.measurement.zzez<T, ?>> T zza(T r6, byte[] r7, int r8, int r9, com.google.android.gms.internal.measurement.zzem r10) throws com.google.android.gms.internal.measurement.zzfh {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r8 = com.google.android.gms.internal.measurement.zzez.zze.zzagx;
        r0 = 0;
        r6 = r6.zza(r8, r0, r0);
        r6 = (com.google.android.gms.internal.measurement.zzez) r6;
        r8 = com.google.android.gms.internal.measurement.zzgu.zznz();	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        r0 = r8.zzv(r6);	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        r3 = 0;	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        r5 = new com.google.android.gms.internal.measurement.zzdm;	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        r5.<init>(r10);	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        r1 = r6;	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        r2 = r7;	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        r4 = r9;	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        r0.zza(r1, r2, r3, r4, r5);	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        r6.zzjz();	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        r7 = r6.zzabm;	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        if (r7 != 0) goto L_0x0025;	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
    L_0x0024:
        return r6;	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
    L_0x0025:
        r7 = new java.lang.RuntimeException;	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        r7.<init>();	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
        throw r7;	 Catch:{ IOException -> 0x0034, IndexOutOfBoundsException -> 0x002b }
    L_0x002b:
        r7 = com.google.android.gms.internal.measurement.zzfh.zzmu();
        r6 = r7.zzg(r6);
        throw r6;
    L_0x0034:
        r7 = move-exception;
        r8 = r7.getCause();
        r8 = r8 instanceof com.google.android.gms.internal.measurement.zzfh;
        if (r8 == 0) goto L_0x0044;
    L_0x003d:
        r6 = r7.getCause();
        r6 = (com.google.android.gms.internal.measurement.zzfh) r6;
        throw r6;
    L_0x0044:
        r8 = new com.google.android.gms.internal.measurement.zzfh;
        r7 = r7.getMessage();
        r8.<init>(r7);
        r6 = r8.zzg(r6);
        throw r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzez.zza(com.google.android.gms.internal.measurement.zzez, byte[], int, int, com.google.android.gms.internal.measurement.zzem):T");
    }

    protected static <T extends zzez<T, ?>> T zza(T t, byte[] bArr, zzem zzem) throws zzfh {
        t = zza(t, bArr, 0, bArr.length, zzem);
        if (t != null) {
            if (t.isInitialized() == null) {
                throw new zzfh(new zzhp(t).getMessage()).zzg(t);
            }
        }
        return t;
    }

    public final /* synthetic */ zzgi zzmk() {
        zza zza = (zza) zza(zze.zzagy, null, null);
        zza.zza(this);
        return zza;
    }

    public final /* synthetic */ zzgi zzml() {
        return (zza) zza(zze.zzagy, null, null);
    }

    public final /* synthetic */ zzgh zzmm() {
        return (zzez) zza(zze.zzagz, null, null);
    }
}
