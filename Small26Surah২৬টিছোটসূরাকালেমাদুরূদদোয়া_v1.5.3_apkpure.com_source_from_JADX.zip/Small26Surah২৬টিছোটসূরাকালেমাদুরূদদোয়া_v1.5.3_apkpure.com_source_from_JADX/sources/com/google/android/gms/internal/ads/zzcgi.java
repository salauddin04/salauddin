package com.google.android.gms.internal.ads;

final /* synthetic */ class zzcgi implements Runnable {
    private final zzcga zzfvf;

    zzcgi(zzcga zzcga) {
        this.zzfvf = zzcga;
    }

    public final void run() {
        this.zzfvf.zzakd();
    }
}
