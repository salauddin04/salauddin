package com.google.android.gms.internal.ads;

public final class zzard implements zzarc {
    public final void zza(Throwable th, String str) {
    }

    public final void zza(Throwable th, String str, float f) {
    }
}
