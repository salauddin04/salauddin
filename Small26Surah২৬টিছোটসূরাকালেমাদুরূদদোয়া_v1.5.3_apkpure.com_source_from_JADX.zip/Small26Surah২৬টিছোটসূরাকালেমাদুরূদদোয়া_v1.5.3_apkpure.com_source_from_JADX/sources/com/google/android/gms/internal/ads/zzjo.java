package com.google.android.gms.internal.ads;

import java.io.IOException;

public final class zzjo implements zzjp {
    private final byte[] data;
    private int zzape;
    private int zzapf;

    public zzjo(byte[] bArr) {
        zzkh.checkNotNull(bArr);
        zzkh.checkArgument(bArr.length > 0);
        this.data = bArr;
    }

    public final void close() throws IOException {
    }

    public final long zza(zzjq zzjq) throws IOException {
        this.zzape = (int) zzjq.zzahv;
        this.zzapf = (int) (zzjq.zzcd == -1 ? ((long) this.data.length) - zzjq.zzahv : zzjq.zzcd);
        int i = this.zzapf;
        if (i > 0 && this.zzape + i <= this.data.length) {
            return (long) i;
        }
        int i2 = this.zzape;
        long j = zzjq.zzcd;
        zzjq = this.data.length;
        StringBuilder stringBuilder = new StringBuilder(77);
        stringBuilder.append("Unsatisfiable range: [");
        stringBuilder.append(i2);
        stringBuilder.append(", ");
        stringBuilder.append(j);
        stringBuilder.append("], length: ");
        stringBuilder.append(zzjq);
        throw new IOException(stringBuilder.toString());
    }

    public final int read(byte[] bArr, int i, int i2) throws IOException {
        int i3 = this.zzapf;
        if (i3 == 0) {
            return -1;
        }
        i2 = Math.min(i2, i3);
        System.arraycopy(this.data, this.zzape, bArr, i, i2);
        this.zzape += i2;
        this.zzapf -= i2;
        return i2;
    }
}
