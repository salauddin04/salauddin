package com.google.android.gms.internal.ads;

public interface zzbge {
    zzbfu zza(zzbdg zzbdg, int i, String str, zzbdf zzbdf);
}
