package com.google.android.gms.internal.ads;

import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.IObjectWrapper.Stub;

public abstract class zzzu extends zzfn implements zzzt {
    public zzzu() {
        super("com.google.android.gms.ads.internal.client.IClientApi");
    }

    protected final boolean dispatchTransaction(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
        IInterface zza;
        switch (i) {
            case 1:
                zza = zza(Stub.asInterface(parcel.readStrongBinder()), (zzyb) zzfo.zza(parcel, zzyb.CREATOR), parcel.readString(), zzamr.zzy(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            case 2:
                zza = zzb(Stub.asInterface(parcel.readStrongBinder()), (zzyb) zzfo.zza(parcel, zzyb.CREATOR), parcel.readString(), zzamr.zzy(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            case 3:
                zza = zza((IObjectWrapper) Stub.asInterface(parcel.readStrongBinder()), (String) parcel.readString(), zzamr.zzy(parcel.readStrongBinder()), (int) parcel.readInt());
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            case 4:
                zza = zzg(Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            case 5:
                zza = zzc(Stub.asInterface(parcel.readStrongBinder()), Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            case 6:
                zza = zza((IObjectWrapper) Stub.asInterface(parcel.readStrongBinder()), (zzamq) zzamr.zzy(parcel.readStrongBinder()), (int) parcel.readInt());
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            case 7:
                zza = zzh(Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            case 8:
                zza = zzf(Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            case 9:
                zza = zza(Stub.asInterface(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            case 10:
                zza = zza((IObjectWrapper) Stub.asInterface(parcel.readStrongBinder()), (zzyb) zzfo.zza(parcel, zzyb.CREATOR), parcel.readString(), (int) parcel.readInt());
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            case 11:
                zza = zza((IObjectWrapper) Stub.asInterface(parcel.readStrongBinder()), (IObjectWrapper) Stub.asInterface(parcel.readStrongBinder()), (IObjectWrapper) Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            case 12:
                zza = zzb(Stub.asInterface(parcel.readStrongBinder()), parcel.readString(), zzamr.zzy(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                zzfo.zza(parcel2, zza);
                break;
            default:
                return false;
        }
        return true;
    }
}
