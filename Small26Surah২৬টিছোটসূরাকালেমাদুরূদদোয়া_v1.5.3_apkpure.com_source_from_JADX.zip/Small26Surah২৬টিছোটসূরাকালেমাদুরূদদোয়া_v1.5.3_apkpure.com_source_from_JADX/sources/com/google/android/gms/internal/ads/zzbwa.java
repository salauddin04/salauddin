package com.google.android.gms.internal.ads;

final /* synthetic */ class zzbwa implements zzbtn {
    private final zzbvy zzfln;

    zzbwa(zzbvy zzbvy) {
        this.zzfln = zzbvy;
    }

    public final void zzafq() {
        this.zzfln.zzahc();
    }
}
