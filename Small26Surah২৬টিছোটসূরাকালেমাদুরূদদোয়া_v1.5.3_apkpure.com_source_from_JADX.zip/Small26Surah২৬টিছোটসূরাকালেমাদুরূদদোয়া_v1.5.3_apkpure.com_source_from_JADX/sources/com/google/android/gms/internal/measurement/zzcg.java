package com.google.android.gms.internal.measurement;

import java.io.IOException;

public final class zzcg extends zzip<zzcg> {
    public zzch[] zzxl;

    public zzcg() {
        this.zzxl = zzch.zzjg();
        this.zzand = null;
        this.zzanm = -1;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzcg)) {
            return false;
        }
        zzcg zzcg = (zzcg) obj;
        if (!zzit.equals(this.zzxl, zzcg.zzxl)) {
            return false;
        }
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                return this.zzand.equals(zzcg.zzand);
            }
        }
        if (zzcg.zzand != null) {
            if (zzcg.zzand.isEmpty() == null) {
                return false;
            }
        }
        return true;
    }

    public final int hashCode() {
        int hashCode;
        int hashCode2 = (((getClass().getName().hashCode() + 527) * 31) + zzit.hashCode(this.zzxl)) * 31;
        if (this.zzand != null) {
            if (!this.zzand.isEmpty()) {
                hashCode = this.zzand.hashCode();
                return hashCode2 + hashCode;
            }
        }
        hashCode = 0;
        return hashCode2 + hashCode;
    }

    public final void zza(zzin zzin) throws IOException {
        zzch[] zzchArr = this.zzxl;
        if (zzchArr != null && zzchArr.length > 0) {
            int i = 0;
            while (true) {
                zzch[] zzchArr2 = this.zzxl;
                if (i >= zzchArr2.length) {
                    break;
                }
                zziv zziv = zzchArr2[i];
                if (zziv != null) {
                    zzin.zza(1, zziv);
                }
                i++;
            }
        }
        super.zza(zzin);
    }

    protected final int zzja() {
        int zzja = super.zzja();
        zzch[] zzchArr = this.zzxl;
        if (zzchArr != null && zzchArr.length > 0) {
            int i = 0;
            while (true) {
                zzch[] zzchArr2 = this.zzxl;
                if (i >= zzchArr2.length) {
                    break;
                }
                zziv zziv = zzchArr2[i];
                if (zziv != null) {
                    zzja += zzin.zzb(1, zziv);
                }
                i++;
            }
        }
        return zzja;
    }

    public final /* synthetic */ zziv zza(zzim zzim) throws IOException {
        while (true) {
            int zzkj = zzim.zzkj();
            if (zzkj == 0) {
                return this;
            }
            if (zzkj == 10) {
                zzkj = zziy.zzb(zzim, 10);
                zzch[] zzchArr = this.zzxl;
                int length = zzchArr == null ? 0 : zzchArr.length;
                Object obj = new zzch[(zzkj + length)];
                if (length != 0) {
                    System.arraycopy(this.zzxl, 0, obj, 0, length);
                }
                while (length < obj.length - 1) {
                    obj[length] = new zzch();
                    zzim.zza(obj[length]);
                    zzim.zzkj();
                    length++;
                }
                obj[length] = new zzch();
                zzim.zza(obj[length]);
                this.zzxl = obj;
            } else if (!super.zza(zzim, zzkj)) {
                return this;
            }
        }
    }
}
