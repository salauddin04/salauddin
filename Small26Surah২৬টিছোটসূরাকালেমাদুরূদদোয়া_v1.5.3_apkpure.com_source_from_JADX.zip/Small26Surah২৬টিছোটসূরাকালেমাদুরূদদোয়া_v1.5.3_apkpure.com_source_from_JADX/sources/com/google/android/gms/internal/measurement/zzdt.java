package com.google.android.gms.internal.measurement;

import java.util.Arrays;

final class zzdt implements zzdv {
    private zzdt() {
    }

    public final byte[] zzc(byte[] bArr, int i, int i2) {
        return Arrays.copyOfRange(bArr, i, i2 + i);
    }
}
