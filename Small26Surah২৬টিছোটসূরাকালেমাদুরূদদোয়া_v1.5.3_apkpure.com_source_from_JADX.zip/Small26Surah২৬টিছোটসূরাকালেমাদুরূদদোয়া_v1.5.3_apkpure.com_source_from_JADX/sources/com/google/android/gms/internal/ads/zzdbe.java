package com.google.android.gms.internal.ads;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzdbe extends IInterface {
    zzdbc zza(zzdba zzdba) throws RemoteException;

    void zza(zzdax zzdax) throws RemoteException;
}
