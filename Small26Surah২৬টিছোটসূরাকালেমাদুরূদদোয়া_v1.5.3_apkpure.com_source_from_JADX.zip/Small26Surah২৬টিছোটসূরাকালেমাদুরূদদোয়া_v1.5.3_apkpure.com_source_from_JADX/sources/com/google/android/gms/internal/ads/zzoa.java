package com.google.android.gms.internal.ads;

final class zzoa {
    private final int zzank;
    private final long zzanm;

    private zzoa(int i, long j) {
        this.zzank = i;
        this.zzanm = j;
    }
}
