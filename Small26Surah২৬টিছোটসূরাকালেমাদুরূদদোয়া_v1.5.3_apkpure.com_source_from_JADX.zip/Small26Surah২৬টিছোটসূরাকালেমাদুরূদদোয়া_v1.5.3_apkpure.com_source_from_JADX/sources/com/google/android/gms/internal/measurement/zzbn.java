package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzbl.zza.zzb;

final class zzbn implements zzfd<zzb> {
    zzbn() {
    }
}
