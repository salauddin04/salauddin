package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class zzin {
    private final ByteBuffer zzada;
    private zzeg zzanb;
    private int zzanc;

    private zzin(byte[] bArr, int i, int i2) {
        this(ByteBuffer.wrap(bArr, i, i2));
    }

    private static int zza(java.lang.CharSequence r8) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:30:0x008f in {4, 9, 14, 21, 23, 24, 25, 27, 29} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = r8.length();
        r1 = 0;
        r2 = 0;
    L_0x0006:
        if (r2 >= r0) goto L_0x0013;
    L_0x0008:
        r3 = r8.charAt(r2);
        r4 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        if (r3 >= r4) goto L_0x0013;
    L_0x0010:
        r2 = r2 + 1;
        goto L_0x0006;
    L_0x0013:
        r3 = r0;
    L_0x0014:
        if (r2 >= r0) goto L_0x006c;
    L_0x0016:
        r4 = r8.charAt(r2);
        r5 = 2048; // 0x800 float:2.87E-42 double:1.0118E-320;
        if (r4 >= r5) goto L_0x0026;
    L_0x001e:
        r4 = 127 - r4;
        r4 = r4 >>> 31;
        r3 = r3 + r4;
        r2 = r2 + 1;
        goto L_0x0014;
    L_0x0026:
        r4 = r8.length();
    L_0x002a:
        if (r2 >= r4) goto L_0x006b;
    L_0x002c:
        r6 = r8.charAt(r2);
        if (r6 >= r5) goto L_0x0038;
    L_0x0032:
        r6 = 127 - r6;
        r6 = r6 >>> 31;
        r1 = r1 + r6;
        goto L_0x0068;
    L_0x0038:
        r1 = r1 + 2;
        r7 = 55296; // 0xd800 float:7.7486E-41 double:2.732E-319;
        if (r7 > r6) goto L_0x0068;
    L_0x003f:
        r7 = 57343; // 0xdfff float:8.0355E-41 double:2.8331E-319;
        if (r6 > r7) goto L_0x0068;
    L_0x0044:
        r6 = java.lang.Character.codePointAt(r8, r2);
        r7 = 65536; // 0x10000 float:9.18355E-41 double:3.2379E-319;
        if (r6 < r7) goto L_0x004f;
    L_0x004c:
        r2 = r2 + 1;
        goto L_0x0068;
    L_0x004f:
        r8 = new java.lang.IllegalArgumentException;
        r0 = 39;
        r1 = new java.lang.StringBuilder;
        r1.<init>(r0);
        r0 = "Unpaired surrogate at index ";
        r1.append(r0);
        r1.append(r2);
        r0 = r1.toString();
        r8.<init>(r0);
        throw r8;
    L_0x0068:
        r2 = r2 + 1;
        goto L_0x002a;
    L_0x006b:
        r3 = r3 + r1;
    L_0x006c:
        if (r3 < r0) goto L_0x006f;
    L_0x006e:
        return r3;
    L_0x006f:
        r8 = new java.lang.IllegalArgumentException;
        r0 = (long) r3;
        r2 = 4294967296; // 0x100000000 float:0.0 double:2.121995791E-314;
        r0 = r0 + r2;
        r2 = 54;
        r3 = new java.lang.StringBuilder;
        r3.<init>(r2);
        r2 = "UTF-8 length does not fit in int: ";
        r3.append(r2);
        r3.append(r0);
        r0 = r3.toString();
        r8.<init>(r0);
        throw r8;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzin.zza(java.lang.CharSequence):int");
    }

    public static int zzar(int i) {
        return (i & -128) == 0 ? 1 : (i & -16384) == 0 ? 2 : (-2097152 & i) == 0 ? 3 : (i & -268435456) == 0 ? 4 : 5;
    }

    private static void zzd(java.lang.CharSequence r14, java.nio.ByteBuffer r15) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:71:0x01c4 in {11, 13, 19, 20, 24, 26, 29, 36, 37, 38, 40, 42, 44, 47, 52, 54, 57, 62, 63, 65, 66, 67, 68, 70} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = r15.isReadOnly();
        if (r0 != 0) goto L_0x01be;
    L_0x0006:
        r0 = r15.hasArray();
        r1 = "Unpaired surrogate at index ";
        r2 = 39;
        r3 = 57343; // 0xdfff float:8.0355E-41 double:2.8331E-319;
        r4 = 55296; // 0xd800 float:7.7486E-41 double:2.732E-319;
        r5 = 2048; // 0x800 float:2.87E-42 double:1.0118E-320;
        r6 = 0;
        r7 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        if (r0 == 0) goto L_0x0127;
    L_0x001b:
        r0 = r15.array();	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r8 = r15.arrayOffset();	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r9 = r15.position();	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r8 = r8 + r9;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r9 = r15.remaining();	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r10 = r14.length();	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r9 = r9 + r8;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0031:
        if (r6 >= r10) goto L_0x0043;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0033:
        r11 = r6 + r8;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        if (r11 >= r9) goto L_0x0043;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0037:
        r12 = r14.charAt(r6);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        if (r12 >= r7) goto L_0x0043;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x003d:
        r12 = (byte) r12;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0[r11] = r12;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r6 = r6 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        goto L_0x0031;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0043:
        if (r6 != r10) goto L_0x0048;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0045:
        r8 = r8 + r10;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        goto L_0x0114;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0048:
        r8 = r8 + r6;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0049:
        if (r6 >= r10) goto L_0x0114;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x004b:
        r11 = r14.charAt(r6);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        if (r11 >= r7) goto L_0x005b;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0051:
        if (r8 >= r9) goto L_0x005b;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0053:
        r12 = r8 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r11 = (byte) r11;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0[r8] = r11;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0058:
        r8 = r12;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        goto L_0x00d7;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x005b:
        if (r11 >= r5) goto L_0x0073;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x005d:
        r12 = r9 + -2;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        if (r8 > r12) goto L_0x0073;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0061:
        r12 = r8 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r11 >>> 6;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r13 | 960;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = (byte) r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0[r8] = r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r8 = r12 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r11 = r11 & 63;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r11 = r11 | r7;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r11 = (byte) r11;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0[r12] = r11;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        goto L_0x00d7;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0073:
        if (r11 < r4) goto L_0x0077;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0075:
        if (r3 >= r11) goto L_0x0097;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0077:
        r12 = r9 + -3;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        if (r8 > r12) goto L_0x0097;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x007b:
        r12 = r8 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r11 >>> 12;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r13 | 480;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = (byte) r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0[r8] = r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r8 = r12 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r11 >>> 6;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r13 & 63;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r13 | r7;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = (byte) r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0[r12] = r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r12 = r8 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r11 = r11 & 63;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r11 = r11 | r7;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r11 = (byte) r11;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0[r8] = r11;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        goto L_0x0058;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0097:
        r12 = r9 + -4;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        if (r8 > r12) goto L_0x00f3;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x009b:
        r12 = r6 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r14.length();	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        if (r12 == r13) goto L_0x00dc;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x00a3:
        r6 = r14.charAt(r12);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = java.lang.Character.isSurrogatePair(r11, r6);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        if (r13 == 0) goto L_0x00db;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x00ad:
        r6 = java.lang.Character.toCodePoint(r11, r6);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r11 = r8 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r6 >>> 18;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r13 | 240;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = (byte) r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0[r8] = r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r8 = r11 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r6 >>> 12;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r13 & 63;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r13 | r7;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = (byte) r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0[r11] = r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r11 = r8 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r6 >>> 6;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r13 & 63;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = r13 | r7;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r13 = (byte) r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0[r8] = r13;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r8 = r11 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r6 = r6 & 63;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r6 = r6 | r7;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r6 = (byte) r6;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0[r11] = r6;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r6 = r12;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x00d7:
        r6 = r6 + 1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        goto L_0x0049;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x00db:
        r6 = r12;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x00dc:
        r14 = new java.lang.IllegalArgumentException;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r6 = r6 + -1;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r15 = new java.lang.StringBuilder;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r15.<init>(r2);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r15.append(r1);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r15.append(r6);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r15 = r15.toString();	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r14.<init>(r15);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        throw r14;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x00f3:
        r14 = new java.lang.ArrayIndexOutOfBoundsException;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r15 = 37;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0 = new java.lang.StringBuilder;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0.<init>(r15);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r15 = "Failed writing ";	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0.append(r15);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0.append(r11);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r15 = " at index ";	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0.append(r15);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r0.append(r8);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r15 = r0.toString();	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r14.<init>(r15);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        throw r14;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
    L_0x0114:
        r14 = r15.arrayOffset();	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r8 = r8 - r14;	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        r15.position(r8);	 Catch:{ ArrayIndexOutOfBoundsException -> 0x011d }
        return;
    L_0x011d:
        r14 = move-exception;
        r15 = new java.nio.BufferOverflowException;
        r15.<init>();
        r15.initCause(r14);
        throw r15;
    L_0x0127:
        r0 = r14.length();
    L_0x012b:
        if (r6 >= r0) goto L_0x01bd;
    L_0x012d:
        r8 = r14.charAt(r6);
        if (r8 >= r7) goto L_0x0139;
    L_0x0133:
        r8 = (byte) r8;
        r15.put(r8);
        goto L_0x01b9;
    L_0x0139:
        if (r8 >= r5) goto L_0x014b;
    L_0x013b:
        r9 = r8 >>> 6;
        r9 = r9 | 960;
        r9 = (byte) r9;
        r15.put(r9);
        r8 = r8 & 63;
        r8 = r8 | r7;
        r8 = (byte) r8;
        r15.put(r8);
        goto L_0x01b9;
    L_0x014b:
        if (r8 < r4) goto L_0x01a1;
    L_0x014d:
        if (r3 >= r8) goto L_0x0150;
    L_0x014f:
        goto L_0x01a1;
    L_0x0150:
        r9 = r6 + 1;
        r10 = r14.length();
        if (r9 == r10) goto L_0x018a;
    L_0x0158:
        r6 = r14.charAt(r9);
        r10 = java.lang.Character.isSurrogatePair(r8, r6);
        if (r10 == 0) goto L_0x0189;
    L_0x0162:
        r6 = java.lang.Character.toCodePoint(r8, r6);
        r8 = r6 >>> 18;
        r8 = r8 | 240;
        r8 = (byte) r8;
        r15.put(r8);
        r8 = r6 >>> 12;
        r8 = r8 & 63;
        r8 = r8 | r7;
        r8 = (byte) r8;
        r15.put(r8);
        r8 = r6 >>> 6;
        r8 = r8 & 63;
        r8 = r8 | r7;
        r8 = (byte) r8;
        r15.put(r8);
        r6 = r6 & 63;
        r6 = r6 | r7;
        r6 = (byte) r6;
        r15.put(r6);
        r6 = r9;
        goto L_0x01b9;
    L_0x0189:
        r6 = r9;
    L_0x018a:
        r14 = new java.lang.IllegalArgumentException;
        r6 = r6 + -1;
        r15 = new java.lang.StringBuilder;
        r15.<init>(r2);
        r15.append(r1);
        r15.append(r6);
        r15 = r15.toString();
        r14.<init>(r15);
        throw r14;
    L_0x01a1:
        r9 = r8 >>> 12;
        r9 = r9 | 480;
        r9 = (byte) r9;
        r15.put(r9);
        r9 = r8 >>> 6;
        r9 = r9 & 63;
        r9 = r9 | r7;
        r9 = (byte) r9;
        r15.put(r9);
        r8 = r8 & 63;
        r8 = r8 | r7;
        r8 = (byte) r8;
        r15.put(r8);
    L_0x01b9:
        r6 = r6 + 1;
        goto L_0x012b;
    L_0x01bd:
        return;
    L_0x01be:
        r14 = new java.nio.ReadOnlyBufferException;
        r14.<init>();
        throw r14;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzin.zzd(java.lang.CharSequence, java.nio.ByteBuffer):void");
    }

    private zzin(ByteBuffer byteBuffer) {
        this.zzada = byteBuffer;
        this.zzada.order(ByteOrder.LITTLE_ENDIAN);
    }

    public static zzin zzl(byte[] bArr) {
        return zzk(bArr, 0, bArr.length);
    }

    public static zzin zzk(byte[] bArr, int i, int i2) {
        return new zzin(bArr, 0, i2);
    }

    public final void zzi(int i, long j) throws IOException {
        zzb(i, 0);
        zzbc(j);
    }

    public final void zzc(int i, int i2) throws IOException {
        zzb(i, 0);
        if (i2 >= 0) {
            zzbl(i2);
        } else {
            zzbc((long) i2);
        }
    }

    public final void zzb(int i, boolean z) throws IOException {
        zzb(i, 0);
        i = (byte) z;
        if (this.zzada.hasRemaining()) {
            this.zzada.put(i);
            return;
        }
        throw new zzio(this.zzada.position(), this.zzada.limit());
    }

    public final void zzb(int i, String str) throws IOException {
        zzb(i, 2);
        try {
            i = zzar(str.length());
            if (i == zzar(str.length() * 3)) {
                int position = this.zzada.position();
                if (this.zzada.remaining() >= i) {
                    this.zzada.position(position + i);
                    zzd((CharSequence) str, this.zzada);
                    str = this.zzada.position();
                    this.zzada.position(position);
                    zzbl((str - position) - i);
                    this.zzada.position(str);
                    return;
                }
                throw new zzio(position + i, this.zzada.limit());
            }
            zzbl(zza(str));
            zzd((CharSequence) str, this.zzada);
        } catch (int i2) {
            str = new zzio(this.zzada.position(), this.zzada.limit());
            str.initCause(i2);
            throw str;
        }
    }

    public final void zza(int i, zziv zziv) throws IOException {
        zzb(i, 2);
        if (zziv.zzanm < 0) {
            zziv.zzly();
        }
        zzbl(zziv.zzanm);
        zziv.zza(this);
    }

    public final void zze(int i, zzgh zzgh) throws IOException {
        if (this.zzanb == null) {
            this.zzanb = zzeg.zza(this.zzada);
            this.zzanc = this.zzada.position();
        } else if (this.zzanc != this.zzada.position()) {
            this.zzanb.write(this.zzada.array(), this.zzanc, this.zzada.position() - this.zzanc);
            this.zzanc = this.zzada.position();
        }
        zzeg zzeg = this.zzanb;
        zzeg.zza(i, zzgh);
        zzeg.flush();
        this.zzanc = this.zzada.position();
    }

    public static int zzd(int i, long j) {
        i = zzaj(i);
        j = (-128 & j) == 0 ? 1 : (-16384 & j) == 0 ? 2 : (-2097152 & j) == 0 ? 3 : (-268435456 & j) == 0 ? 4 : (-34359738368L & j) == 0 ? 5 : (-4398046511104L & j) == 0 ? 6 : (-562949953421312L & j) == 0 ? 7 : (-72057594037927936L & j) == 0 ? 8 : (j & Long.MIN_VALUE) == 0 ? 9 : 10;
        return i + j;
    }

    public static int zzg(int i, int i2) {
        return zzaj(i) + zzak(i2);
    }

    public static int zzc(int i, String str) {
        return zzaj(i) + zzcp(str);
    }

    public static int zzb(int i, zziv zziv) {
        i = zzaj(i);
        zziv = zziv.zzly();
        return i + (zzar(zziv) + zziv);
    }

    public static int zzak(int i) {
        return i >= 0 ? zzar(i) : 10;
    }

    public static int zzcp(String str) {
        str = zza(str);
        return zzar(str) + str;
    }

    public final void zzlk() {
        if (this.zzada.remaining() != 0) {
            throw new IllegalStateException(String.format("Did not write as much data as expected, %s bytes remaining.", new Object[]{Integer.valueOf(this.zzada.remaining())}));
        }
    }

    private final void zzbk(int i) throws IOException {
        i = (byte) i;
        if (this.zzada.hasRemaining()) {
            this.zzada.put(i);
            return;
        }
        throw new zzio(this.zzada.position(), this.zzada.limit());
    }

    public final void zzm(byte[] bArr) throws IOException {
        int length = bArr.length;
        if (this.zzada.remaining() >= length) {
            this.zzada.put(bArr, 0, length);
            return;
        }
        throw new zzio(this.zzada.position(), this.zzada.limit());
    }

    public final void zzb(int i, int i2) throws IOException {
        zzbl((i << 3) | i2);
    }

    public static int zzaj(int i) {
        return zzar(i << 3);
    }

    public final void zzbl(int i) throws IOException {
        while ((i & -128) != 0) {
            zzbk((i & 127) | 128);
            i >>>= 7;
        }
        zzbk(i);
    }

    private final void zzbc(long j) throws IOException {
        while ((-128 & j) != 0) {
            zzbk((((int) j) & 127) | 128);
            j >>>= 7;
        }
        zzbk((int) j);
    }
}
