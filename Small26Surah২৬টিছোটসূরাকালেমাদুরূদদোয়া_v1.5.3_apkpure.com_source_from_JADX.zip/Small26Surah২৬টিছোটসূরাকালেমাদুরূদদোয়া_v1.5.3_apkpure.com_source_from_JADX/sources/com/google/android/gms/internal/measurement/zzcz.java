package com.google.android.gms.internal.measurement;

import android.util.Log;

final class zzcz extends zzcw<Boolean> {
    zzcz(zzdc zzdc, String str, Boolean bool) {
        super(zzdc, str, bool);
    }

    final /* synthetic */ Object zzc(Object obj) {
        if (obj instanceof Boolean) {
            return (Boolean) obj;
        }
        String str;
        if (obj instanceof String) {
            str = (String) obj;
            if (zzci.zzyv.matcher(str).matches()) {
                return Boolean.valueOf(true);
            }
            if (zzci.zzyw.matcher(str).matches()) {
                return Boolean.valueOf(null);
            }
        }
        str = super.zzjq();
        obj = String.valueOf(obj);
        StringBuilder stringBuilder = new StringBuilder((String.valueOf(str).length() + 28) + String.valueOf(obj).length());
        stringBuilder.append("Invalid boolean value for ");
        stringBuilder.append(str);
        stringBuilder.append(": ");
        stringBuilder.append(obj);
        Log.e("PhenotypeFlag", stringBuilder.toString());
        return null;
    }
}
