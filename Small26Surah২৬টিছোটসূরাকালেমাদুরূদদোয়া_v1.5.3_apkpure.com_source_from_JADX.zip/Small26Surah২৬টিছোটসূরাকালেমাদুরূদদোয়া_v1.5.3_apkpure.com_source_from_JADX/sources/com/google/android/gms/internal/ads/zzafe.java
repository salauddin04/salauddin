package com.google.android.gms.internal.ads;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper.Stub;

public abstract class zzafe extends zzfn implements zzafd {
    public zzafe() {
        super("com.google.android.gms.ads.internal.formats.client.INativeCustomTemplateAd");
    }

    public static zzafd zzn(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.INativeCustomTemplateAd");
        if (queryLocalInterface instanceof zzafd) {
            return (zzafd) queryLocalInterface;
        }
        return new zzaff(iBinder);
    }

    protected final boolean dispatchTransaction(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
        IInterface zzck;
        switch (i) {
            case 1:
                i = zzcj(parcel.readString());
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 2:
                zzck = zzck(parcel.readString());
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzck);
                break;
            case 3:
                i = getAvailableAssetNames();
                parcel2.writeNoException();
                parcel2.writeStringList(i);
                break;
            case 4:
                i = getCustomTemplateId();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 5:
                performClick(parcel.readString());
                parcel2.writeNoException();
                break;
            case 6:
                recordImpression();
                parcel2.writeNoException();
                break;
            case 7:
                zzck = getVideoController();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzck);
                break;
            case 8:
                destroy();
                parcel2.writeNoException();
                break;
            case 9:
                zzck = zzrm();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzck);
                break;
            case 10:
                i = zzp(Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                zzfo.writeBoolean(parcel2, i);
                break;
            case 11:
                zzck = zzrh();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzck);
                break;
            default:
                return false;
        }
        return true;
    }
}
