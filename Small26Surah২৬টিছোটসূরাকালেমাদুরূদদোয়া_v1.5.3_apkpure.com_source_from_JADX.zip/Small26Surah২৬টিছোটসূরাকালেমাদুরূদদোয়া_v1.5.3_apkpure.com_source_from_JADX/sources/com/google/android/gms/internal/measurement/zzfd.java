package com.google.android.gms.internal.measurement;

public interface zzfd<T extends zzfc> {
}
