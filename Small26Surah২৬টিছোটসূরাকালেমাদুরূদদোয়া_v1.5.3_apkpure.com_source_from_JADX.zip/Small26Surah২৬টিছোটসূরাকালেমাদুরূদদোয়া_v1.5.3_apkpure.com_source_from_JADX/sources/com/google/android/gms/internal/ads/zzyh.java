package com.google.android.gms.internal.ads;

import android.app.Activity;
import android.os.RemoteException;
import com.google.android.gms.dynamic.ObjectWrapper;

final class zzyh extends zzyq<zzaqh> {
    private final /* synthetic */ Activity val$activity;
    private final /* synthetic */ zzyf zzchx;

    zzyh(zzyf zzyf, Activity activity) {
        this.zzchx = zzyf;
        this.val$activity = activity;
    }

    protected final /* synthetic */ Object zzov() {
        zzyf.zza(this.val$activity, "ad_overlay");
        return null;
    }

    public final /* synthetic */ Object zzow() throws RemoteException {
        return this.zzchx.zzchs.zzc(this.val$activity);
    }

    public final /* synthetic */ Object zza(zzzt zzzt) throws RemoteException {
        return zzzt.zzf(ObjectWrapper.wrap(this.val$activity));
    }
}
