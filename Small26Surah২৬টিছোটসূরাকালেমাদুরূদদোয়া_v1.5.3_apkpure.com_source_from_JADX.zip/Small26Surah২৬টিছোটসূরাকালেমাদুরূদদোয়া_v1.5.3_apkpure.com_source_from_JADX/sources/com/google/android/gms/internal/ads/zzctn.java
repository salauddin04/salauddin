package com.google.android.gms.internal.ads;

import android.os.Bundle;

public interface zzctn extends zzcuy<Bundle> {
}
