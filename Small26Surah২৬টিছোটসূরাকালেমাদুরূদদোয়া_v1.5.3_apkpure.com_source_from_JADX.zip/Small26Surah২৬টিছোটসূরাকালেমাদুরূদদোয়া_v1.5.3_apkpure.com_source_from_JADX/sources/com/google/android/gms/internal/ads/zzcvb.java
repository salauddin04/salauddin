package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.internal.zzk;

final /* synthetic */ class zzcvb implements Runnable {
    private final zzcuz zzgii;
    private final long zzgij;

    zzcvb(zzcuz zzcuz, long j) {
        this.zzgii = zzcuz;
        this.zzgij = j;
    }

    public final void run() {
        zzcuz zzcuz = this.zzgii;
        long j = this.zzgij;
        String canonicalName = zzcuz.getClass().getCanonicalName();
        long elapsedRealtime = zzk.zzln().elapsedRealtime() - j;
        StringBuilder stringBuilder = new StringBuilder(String.valueOf(canonicalName).length() + 40);
        stringBuilder.append("Signal runtime : ");
        stringBuilder.append(canonicalName);
        stringBuilder.append(" = ");
        stringBuilder.append(elapsedRealtime);
        zzaxa.zzds(stringBuilder.toString());
    }
}
