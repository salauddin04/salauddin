package com.google.android.gms.internal.ads;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.concurrent.GuardedBy;

public final class zzcnj implements zzcjy<zzamt, zzcla> {
    private final zzclb zzfvd;
    @GuardedBy("this")
    private final Map<String, zzcjx<zzamt, zzcla>> zzgbu = new HashMap();

    public zzcnj(zzclb zzclb) {
        this.zzfvd = zzclb;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final com.google.android.gms.internal.ads.zzcjx<com.google.android.gms.internal.ads.zzamt, com.google.android.gms.internal.ads.zzcla> zzd(java.lang.String r3, org.json.JSONObject r4) throws java.lang.Throwable {
        /*
        r2 = this;
        monitor-enter(r2);
        r0 = r2.zzgbu;	 Catch:{ all -> 0x0027 }
        r0 = r0.get(r3);	 Catch:{ all -> 0x0027 }
        r0 = (com.google.android.gms.internal.ads.zzcjx) r0;	 Catch:{ all -> 0x0027 }
        if (r0 != 0) goto L_0x0025;
    L_0x000b:
        r0 = r2.zzfvd;	 Catch:{ all -> 0x0027 }
        r4 = r0.zze(r3, r4);	 Catch:{ all -> 0x0027 }
        if (r4 != 0) goto L_0x0016;
    L_0x0013:
        r3 = 0;
        monitor-exit(r2);	 Catch:{ all -> 0x0027 }
        return r3;
    L_0x0016:
        r0 = new com.google.android.gms.internal.ads.zzcjx;	 Catch:{ all -> 0x0027 }
        r1 = new com.google.android.gms.internal.ads.zzcla;	 Catch:{ all -> 0x0027 }
        r1.<init>();	 Catch:{ all -> 0x0027 }
        r0.<init>(r4, r1, r3);	 Catch:{ all -> 0x0027 }
        r4 = r2.zzgbu;	 Catch:{ all -> 0x0027 }
        r4.put(r3, r0);	 Catch:{ all -> 0x0027 }
    L_0x0025:
        monitor-exit(r2);	 Catch:{ all -> 0x0027 }
        return r0;
    L_0x0027:
        r3 = move-exception;
        monitor-exit(r2);	 Catch:{ all -> 0x0027 }
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzcnj.zzd(java.lang.String, org.json.JSONObject):com.google.android.gms.internal.ads.zzcjx<com.google.android.gms.internal.ads.zzamt, com.google.android.gms.internal.ads.zzcla>");
    }
}
