package com.google.android.gms.internal.measurement;

import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.support.annotation.WorkerThread;
import android.util.Log;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.common.util.Clock;
import com.google.android.gms.common.util.DefaultClock;
import com.google.android.gms.common.util.VisibleForTesting;
import com.google.android.gms.dynamite.DynamiteModule;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.measurement.dynamite.ModuleDescriptor;
import com.google.android.gms.measurement.api.AppMeasurementSdk;
import com.google.android.gms.measurement.internal.zzda;
import com.google.android.gms.measurement.internal.zzdb;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nonnull;

public class zzaa {
    private static Boolean zzaf = null;
    private static Boolean zzag = null;
    @VisibleForTesting
    private static String zzah = "use_dynamite_api";
    @VisibleForTesting
    private static String zzai = "allow_remote_dynamite";
    private static boolean zzaj = false;
    private static boolean zzak = false;
    private static volatile zzaa zzz;
    protected final Clock zzaa;
    private final ExecutorService zzab;
    private final AppMeasurementSdk zzac;
    private Map<zzdb, zzc> zzad;
    private int zzae;
    private boolean zzal;
    private String zzam;
    private zzn zzan;
    private final String zzw;

    abstract class zza implements Runnable {
        final long timestamp;
        private final /* synthetic */ zzaa zzar;
        final long zzbs;
        private final boolean zzbt;

        zza(zzaa zzaa) {
            this(zzaa, true);
        }

        abstract void zzl() throws RemoteException;

        protected void zzm() {
        }

        zza(zzaa zzaa, boolean z) {
            this.zzar = zzaa;
            this.timestamp = zzaa.zzaa.currentTimeMillis();
            this.zzbs = zzaa.zzaa.elapsedRealtime();
            this.zzbt = z;
        }

        public void run() {
            if (this.zzar.zzal) {
                zzm();
                return;
            }
            try {
                zzl();
            } catch (Exception e) {
                this.zzar.zza(e, false, this.zzbt);
                zzm();
            }
        }
    }

    class zzd implements ActivityLifecycleCallbacks {
        final /* synthetic */ zzaa zzar;

        zzd(zzaa zzaa) {
            this.zzar = zzaa;
        }

        public final void onActivityCreated(Activity activity, Bundle bundle) {
            this.zzar.zza(new zzbe(this, activity, bundle));
        }

        public final void onActivityStarted(Activity activity) {
            this.zzar.zza(new zzbf(this, activity));
        }

        public final void onActivityResumed(Activity activity) {
            this.zzar.zza(new zzbg(this, activity));
        }

        public final void onActivityPaused(Activity activity) {
            this.zzar.zza(new zzbh(this, activity));
        }

        public final void onActivityStopped(Activity activity) {
            this.zzar.zza(new zzbi(this, activity));
        }

        public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
            zzm zzm = new zzm();
            this.zzar.zza(new zzbj(this, activity, zzm));
            activity = zzm.zzb(50);
            if (activity != null) {
                bundle.putAll(activity);
            }
        }

        public final void onActivityDestroyed(Activity activity) {
            this.zzar.zza(new zzbk(this, activity));
        }
    }

    static class zzb extends zzu {
        private final zzda zzbu;

        zzb(zzda zzda) {
            this.zzbu = zzda;
        }

        public final void onEvent(String str, String str2, Bundle bundle, long j) {
            this.zzbu.interceptEvent(str, str2, bundle, j);
        }

        public final int id() {
            return this.zzbu.hashCode();
        }
    }

    static class zzc extends zzu {
        private final zzdb zzbv;

        zzc(zzdb zzdb) {
            this.zzbv = zzdb;
        }

        public final void onEvent(String str, String str2, Bundle bundle, long j) {
            this.zzbv.onEvent(str, str2, bundle, j);
        }

        public final int id() {
            return this.zzbv.hashCode();
        }
    }

    public static zzaa zza(@Nonnull Context context) {
        return zza(context, null, null, null, null);
    }

    public static zzaa zza(Context context, String str, String str2, String str3, Bundle bundle) {
        Preconditions.checkNotNull(context);
        if (zzz == null) {
            synchronized (zzaa.class) {
                if (zzz == null) {
                    zzz = new zzaa(context, str, str2, str3, bundle);
                }
            }
        }
        return zzz;
    }

    public final AppMeasurementSdk zzh() {
        return this.zzac;
    }

    private zzaa(Context context, String str, String str2, String str3, Bundle bundle) {
        int i;
        Application application;
        if (str != null) {
            if (zza(str2, str3)) {
                this.zzw = str;
                this.zzaa = DefaultClock.getInstance();
                this.zzab = new ThreadPoolExecutor(0, 1, 30, TimeUnit.SECONDS, new LinkedBlockingQueue());
                this.zzac = new AppMeasurementSdk(this);
                i = 0;
                if (zzb(context) != null) {
                    if (zzi() != null) {
                        str = null;
                        if (str != null) {
                            this.zzam = null;
                            this.zzal = true;
                            Log.w(this.zzw, "Disabling data collection. Found google_app_id in strings.xml but Google Analytics for Firebase is missing. Remove this value or add Google Analytics for Firebase to resume data collection.");
                        }
                        if (zza(str2, str3) != null) {
                            this.zzam = "fa";
                            if (str2 != null || str3 == null) {
                                str = str2 != null ? true : null;
                                if (str3 == null) {
                                    i = 1;
                                }
                                if ((str ^ i) != null) {
                                    Log.w(this.zzw, "Specified origin or custom app id is null. Both parameters will be ignored.");
                                }
                            } else {
                                Log.v(this.zzw, "Deferring to Google Analytics for Firebase for event data collection. https://goo.gl/J1sWQy");
                                this.zzal = true;
                                return;
                            }
                        }
                        this.zzam = str2;
                        zza(new zzab(this, str2, str3, context, bundle));
                        application = (Application) context.getApplicationContext();
                        if (application != null) {
                            Log.w(this.zzw, "Unable to register lifecycle notifications. Application null.");
                            return;
                        } else {
                            application.registerActivityLifecycleCallbacks(new zzd(this));
                            return;
                        }
                    }
                }
                str = true;
                if (str != null) {
                    if (zza(str2, str3) != null) {
                        this.zzam = str2;
                    } else {
                        this.zzam = "fa";
                        if (str2 != null) {
                        }
                        if (str2 != null) {
                        }
                        if (str3 == null) {
                            i = 1;
                        }
                        if ((str ^ i) != null) {
                            Log.w(this.zzw, "Specified origin or custom app id is null. Both parameters will be ignored.");
                        }
                    }
                    zza(new zzab(this, str2, str3, context, bundle));
                    application = (Application) context.getApplicationContext();
                    if (application != null) {
                        application.registerActivityLifecycleCallbacks(new zzd(this));
                        return;
                    } else {
                        Log.w(this.zzw, "Unable to register lifecycle notifications. Application null.");
                        return;
                    }
                }
                this.zzam = null;
                this.zzal = true;
                Log.w(this.zzw, "Disabling data collection. Found google_app_id in strings.xml but Google Analytics for Firebase is missing. Remove this value or add Google Analytics for Firebase to resume data collection.");
            }
        }
        this.zzw = "FA";
        this.zzaa = DefaultClock.getInstance();
        this.zzab = new ThreadPoolExecutor(0, 1, 30, TimeUnit.SECONDS, new LinkedBlockingQueue());
        this.zzac = new AppMeasurementSdk(this);
        i = 0;
        if (zzb(context) != null) {
            if (zzi() != null) {
                str = null;
                if (str != null) {
                    this.zzam = null;
                    this.zzal = true;
                    Log.w(this.zzw, "Disabling data collection. Found google_app_id in strings.xml but Google Analytics for Firebase is missing. Remove this value or add Google Analytics for Firebase to resume data collection.");
                }
                if (zza(str2, str3) != null) {
                    this.zzam = "fa";
                    if (str2 != null) {
                    }
                    if (str2 != null) {
                    }
                    if (str3 == null) {
                        i = 1;
                    }
                    if ((str ^ i) != null) {
                        Log.w(this.zzw, "Specified origin or custom app id is null. Both parameters will be ignored.");
                    }
                } else {
                    this.zzam = str2;
                }
                zza(new zzab(this, str2, str3, context, bundle));
                application = (Application) context.getApplicationContext();
                if (application != null) {
                    Log.w(this.zzw, "Unable to register lifecycle notifications. Application null.");
                    return;
                } else {
                    application.registerActivityLifecycleCallbacks(new zzd(this));
                    return;
                }
            }
        }
        str = true;
        if (str != null) {
            if (zza(str2, str3) != null) {
                this.zzam = str2;
            } else {
                this.zzam = "fa";
                if (str2 != null) {
                }
                if (str2 != null) {
                }
                if (str3 == null) {
                    i = 1;
                }
                if ((str ^ i) != null) {
                    Log.w(this.zzw, "Specified origin or custom app id is null. Both parameters will be ignored.");
                }
            }
            zza(new zzab(this, str2, str3, context, bundle));
            application = (Application) context.getApplicationContext();
            if (application != null) {
                application.registerActivityLifecycleCallbacks(new zzd(this));
                return;
            } else {
                Log.w(this.zzw, "Unable to register lifecycle notifications. Application null.");
                return;
            }
        }
        this.zzam = null;
        this.zzal = true;
        Log.w(this.zzw, "Disabling data collection. Found google_app_id in strings.xml but Google Analytics for Firebase is missing. Remove this value or add Google Analytics for Firebase to resume data collection.");
    }

    private static boolean zzb(android.content.Context r1) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = 0;
        com.google.android.gms.common.api.internal.GoogleServices.initialize(r1);	 Catch:{ IllegalStateException -> 0x000c }
        r1 = com.google.android.gms.common.api.internal.GoogleServices.getGoogleAppId();	 Catch:{ IllegalStateException -> 0x000c }
        if (r1 == 0) goto L_0x000c;
    L_0x000a:
        r1 = 1;
        return r1;
    L_0x000c:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzaa.zzb(android.content.Context):boolean");
    }

    private static boolean zza(String str, String str2) {
        return (str2 == null || str == null || zzi() != null) ? null : true;
    }

    private final void zza(zza zza) {
        this.zzab.execute(zza);
    }

    protected final zzn zza(Context context, boolean z) {
        if (z) {
            try {
                z = DynamiteModule.PREFER_HIGHEST_OR_REMOTE_VERSION;
            } catch (Exception e) {
                zza(e, true, false);
                return null;
            }
        }
        z = DynamiteModule.PREFER_LOCAL;
        return zzo.asInterface(DynamiteModule.load(context, z, ModuleDescriptor.MODULE_ID).instantiate("com.google.android.gms.measurement.internal.AppMeasurementDynamiteService"));
    }

    private static int zzc(Context context) {
        return DynamiteModule.getRemoteVersion(context, ModuleDescriptor.MODULE_ID);
    }

    private static int zzd(Context context) {
        return DynamiteModule.getLocalVersion(context, ModuleDescriptor.MODULE_ID);
    }

    private final void zza(Exception exception, boolean z, boolean z2) {
        this.zzal |= z;
        if (z) {
            Log.w(this.zzw, "Data collection startup failed. No data will be collected.", exception);
            return;
        }
        z = "Error with data collection. Data lost.";
        if (z2) {
            zza(5, (String) z, (Object) exception, null, null);
        }
        Log.w(this.zzw, z, exception);
    }

    private static boolean zzi() {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r0 = "com.google.firebase.analytics.FirebaseAnalytics";	 Catch:{ ClassNotFoundException -> 0x0007 }
        java.lang.Class.forName(r0);	 Catch:{ ClassNotFoundException -> 0x0007 }
        r0 = 1;
        return r0;
    L_0x0007:
        r0 = 0;
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzaa.zzi():boolean");
    }

    public final void zza(zzda zzda) {
        zza(new zzam(this, zzda));
    }

    public final void zza(zzdb zzdb) {
        zza(new zzax(this, zzdb));
    }

    public final void zzb(zzdb zzdb) {
        zza(new zzba(this, zzdb));
    }

    public final void logEvent(@Nonnull String str, Bundle bundle) {
        zza(null, str, bundle, false, true, null);
    }

    public final void logEventInternal(String str, String str2, Bundle bundle) {
        zza(str, str2, bundle, true, true, null);
    }

    public final void logEventInternalNoInterceptor(String str, String str2, Bundle bundle, long j) {
        zza(str, str2, bundle, true, false, Long.valueOf(j));
    }

    private final void zza(String str, String str2, Bundle bundle, boolean z, boolean z2, Long l) {
        zza(new zzbb(this, l, str, str2, bundle, z, z2));
    }

    public final void setUserProperty(String str, String str2) {
        zza(null, str, (Object) str2, false);
    }

    public final void setUserPropertyInternal(String str, String str2, Object obj) {
        zza(str, str2, obj, true);
    }

    private final void zza(String str, String str2, Object obj, boolean z) {
        zza(new zzbc(this, str, str2, obj, z));
    }

    public final void setConditionalUserProperty(Bundle bundle) {
        zza(new zzbd(this, bundle));
    }

    public final void clearConditionalUserProperty(String str, String str2, Bundle bundle) {
        zza(new zzac(this, str, str2, bundle));
    }

    public final List<Bundle> getConditionalUserProperties(String str, String str2) {
        zzm zzm = new zzm();
        zza(new zzad(this, str, str2, zzm));
        List list = (List) zzm.zza(zzm.zzb((long) 5000), List.class);
        return list == null ? Collections.emptyList() : list;
    }

    public final void setUserId(String str) {
        zza(new zzae(this, str));
    }

    public final void setCurrentScreen(Activity activity, String str, String str2) {
        zza(new zzaf(this, activity, str, str2));
    }

    public final void setMeasurementEnabled(boolean z) {
        zza(new zzag(this, z));
    }

    public final void resetAnalyticsData() {
        zza(new zzah(this));
    }

    public final void setMinimumSessionDuration(long j) {
        zza(new zzai(this, j));
    }

    public final void setSessionTimeoutDuration(long j) {
        zza(new zzaj(this, j));
    }

    public final void beginAdUnitExposure(String str) {
        zza(new zzak(this, str));
    }

    public final void endAdUnitExposure(String str) {
        zza(new zzal(this, str));
    }

    public final String getGmpAppId() {
        zzm zzm = new zzm();
        zza(new zzan(this, zzm));
        return zzm.zza(500);
    }

    public final String zzj() {
        zzm zzm = new zzm();
        zza(new zzao(this, zzm));
        return zzm.zza(50);
    }

    public final long generateEventId() {
        zzm zzm = new zzm();
        zza(new zzap(this, zzm));
        Long l = (Long) zzm.zza(zzm.zzb(500), Long.class);
        if (l != null) {
            return l.longValue();
        }
        long nextLong = new Random(System.nanoTime() ^ this.zzaa.currentTimeMillis()).nextLong();
        int i = this.zzae + 1;
        this.zzae = i;
        return nextLong + ((long) i);
    }

    public final String getCurrentScreenName() {
        zzm zzm = new zzm();
        zza(new zzaq(this, zzm));
        return zzm.zza(500);
    }

    public final String getCurrentScreenClass() {
        zzm zzm = new zzm();
        zza(new zzar(this, zzm));
        return zzm.zza(500);
    }

    public final Map<String, Object> getUserProperties(String str, String str2, boolean z) {
        zzm zzm = new zzm();
        zza(new zzas(this, str, str2, z, zzm));
        str = zzm.zzb((long) 5000);
        if (str != null) {
            if (str.size() != null) {
                str2 = new HashMap(str.size());
                for (String str3 : str.keySet()) {
                    Object obj = str.get(str3);
                    if ((obj instanceof Double) || (obj instanceof Long) || (obj instanceof String)) {
                        str2.put(str3, obj);
                    }
                }
                return str2;
            }
        }
        return Collections.emptyMap();
    }

    public final void zza(int i, String str, Object obj, Object obj2, Object obj3) {
        zza(new zzat(this, false, 5, str, obj, null, null));
    }

    public final Bundle zza(Bundle bundle, boolean z) {
        zzm zzm = new zzm();
        zza(new zzau(this, bundle, zzm));
        return z ? zzm.zzb((long) 5000) : null;
    }

    public final int getMaxUserProperties(String str) {
        zzm zzm = new zzm();
        zza(new zzav(this, str, zzm));
        Integer num = (Integer) zzm.zza(zzm.zzb(10000), Integer.class);
        if (num == null) {
            return 25;
        }
        return num.intValue();
    }

    @WorkerThread
    public final String getAppInstanceId() {
        zzm zzm = new zzm();
        zza(new zzaw(this, zzm));
        return zzm.zza(120000);
    }

    public final String getAppIdOrigin() {
        return this.zzam;
    }

    public final Object zzb(int i) {
        zzm zzm = new zzm();
        zza(new zzay(this, zzm, i));
        return zzm.zza(zzm.zzb(15000), Object.class);
    }

    public final void setDataCollectionEnabled(boolean z) {
        zza(new zzaz(this, z));
    }

    private static void zze(Context context) {
        synchronized (zzaa.class) {
            try {
                if (zzaf != null && zzag != null) {
                } else if (zza(context, "app_measurement_internal_disable_startup_flags")) {
                    zzaf = Boolean.valueOf(false);
                    zzag = Boolean.valueOf(false);
                } else {
                    context = context.getSharedPreferences("com.google.android.gms.measurement.prefs", 0);
                    zzaf = Boolean.valueOf(context.getBoolean(zzah, false));
                    zzag = Boolean.valueOf(context.getBoolean(zzai, false));
                    context = context.edit();
                    context.remove(zzah);
                    context.remove(zzai);
                    context.apply();
                }
            } catch (NullPointerException e) {
                context = e;
                Log.e("FA", "Exception reading flag from SharedPreferences.", context);
                zzaf = Boolean.valueOf(false);
                zzag = Boolean.valueOf(false);
            } catch (ClassCastException e2) {
                context = e2;
                Log.e("FA", "Exception reading flag from SharedPreferences.", context);
                zzaf = Boolean.valueOf(false);
                zzag = Boolean.valueOf(false);
            } catch (IllegalStateException e3) {
                context = e3;
                Log.e("FA", "Exception reading flag from SharedPreferences.", context);
                zzaf = Boolean.valueOf(false);
                zzag = Boolean.valueOf(false);
            }
        }
    }

    public static boolean zzf(Context context) {
        zze(context);
        return zzaf.booleanValue();
    }

    private static boolean zza(android.content.Context r3, @android.support.annotation.Size(min = 1) java.lang.String r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        com.google.android.gms.common.internal.Preconditions.checkNotEmpty(r4);
        r0 = 0;
        r1 = com.google.android.gms.common.wrappers.Wrappers.packageManager(r3);	 Catch:{ NameNotFoundException -> 0x0020 }
        r3 = r3.getPackageName();	 Catch:{ NameNotFoundException -> 0x0020 }
        r2 = 128; // 0x80 float:1.794E-43 double:6.32E-322;	 Catch:{ NameNotFoundException -> 0x0020 }
        r3 = r1.getApplicationInfo(r3, r2);	 Catch:{ NameNotFoundException -> 0x0020 }
        if (r3 == 0) goto L_0x0020;	 Catch:{ NameNotFoundException -> 0x0020 }
    L_0x0014:
        r1 = r3.metaData;	 Catch:{ NameNotFoundException -> 0x0020 }
        if (r1 != 0) goto L_0x0019;	 Catch:{ NameNotFoundException -> 0x0020 }
    L_0x0018:
        goto L_0x0020;	 Catch:{ NameNotFoundException -> 0x0020 }
    L_0x0019:
        r3 = r3.metaData;	 Catch:{ NameNotFoundException -> 0x0020 }
        r3 = r3.getBoolean(r4);	 Catch:{ NameNotFoundException -> 0x0020 }
        return r3;
    L_0x0020:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzaa.zza(android.content.Context, java.lang.String):boolean");
    }
}
