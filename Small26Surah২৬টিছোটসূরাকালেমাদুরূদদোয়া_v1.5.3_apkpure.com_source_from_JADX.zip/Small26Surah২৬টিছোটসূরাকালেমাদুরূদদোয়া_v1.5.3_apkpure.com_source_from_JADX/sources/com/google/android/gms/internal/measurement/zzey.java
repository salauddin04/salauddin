package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzez.zze;

final class zzey implements zzgg {
    private static final zzey zzagm = new zzey();

    private zzey() {
    }

    public static zzey zzmf() {
        return zzagm;
    }

    public final boolean zzb(Class<?> cls) {
        return zzez.class.isAssignableFrom(cls);
    }

    public final zzgf zzc(Class<?> cls) {
        if (zzez.class.isAssignableFrom(cls)) {
            try {
                return (zzgf) zzez.zzd(cls.asSubclass(zzez.class)).zza(zze.zzagw, null, null);
            } catch (Throwable e) {
                String str = "Unable to get message info for ";
                cls = String.valueOf(cls.getName());
                throw new RuntimeException(cls.length() != 0 ? str.concat(cls) : new String(str), e);
            }
        }
        String str2 = "Unsupported message type: ";
        cls = String.valueOf(cls.getName());
        throw new IllegalArgumentException(cls.length() != 0 ? str2.concat(cls) : new String(str2));
    }
}
