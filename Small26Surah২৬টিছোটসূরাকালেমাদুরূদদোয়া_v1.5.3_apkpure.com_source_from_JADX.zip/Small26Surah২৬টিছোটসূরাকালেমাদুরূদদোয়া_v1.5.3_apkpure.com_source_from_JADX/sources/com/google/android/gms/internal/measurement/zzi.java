package com.google.android.gms.internal.measurement;

final /* synthetic */ class zzi implements zzj {
    static final zzj zzi = new zzi();

    private zzi() {
    }

    public final boolean zze() {
        return false;
    }
}
