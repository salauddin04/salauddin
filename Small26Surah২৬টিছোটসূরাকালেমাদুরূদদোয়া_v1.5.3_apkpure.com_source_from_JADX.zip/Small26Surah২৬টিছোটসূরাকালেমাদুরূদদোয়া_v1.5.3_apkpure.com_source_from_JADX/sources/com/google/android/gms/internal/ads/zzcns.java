package com.google.android.gms.internal.ads;

final /* synthetic */ class zzcns implements Runnable {
    private final zzbha zzemh;

    zzcns(zzbha zzbha) {
        this.zzemh = zzbha;
    }

    public final void run() {
        this.zzemh.zzaac();
    }
}
