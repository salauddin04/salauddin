package com.google.android.gms.internal.measurement;

enum zzih extends zzif {
    zzih(String str, int i, zzik zzik, int i2) {
        super(str, 9, zzik, 3);
    }
}
