package com.google.android.gms.internal.ads;

final class zzgs implements Runnable {
    private final /* synthetic */ zzgv zzaei;
    private final /* synthetic */ zzgr zzaej;

    zzgs(zzgr zzgr, zzgv zzgv) {
        this.zzaej = zzgr;
        this.zzaei = zzgv;
    }

    public final void run() {
        this.zzaej.zzadn.zzb(this.zzaei);
    }
}
