package com.google.android.gms.internal.measurement;

public interface zzcr<V> {
    V zzjn();
}
