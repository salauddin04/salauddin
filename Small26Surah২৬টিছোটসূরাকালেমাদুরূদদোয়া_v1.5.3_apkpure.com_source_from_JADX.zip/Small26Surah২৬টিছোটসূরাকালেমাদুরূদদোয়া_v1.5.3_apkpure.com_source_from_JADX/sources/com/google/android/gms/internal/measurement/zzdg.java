package com.google.android.gms.internal.measurement;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public abstract class zzdg<MessageType extends zzdg<MessageType, BuilderType>, BuilderType extends zzdh<MessageType, BuilderType>> implements zzgh {
    private static boolean zzabn = false;
    protected int zzabm = 0;

    public final zzdp zzjv() {
        try {
            zzdx zzt = zzdp.zzt(zzly());
            zzb(zzt.zzki());
            return zzt.zzkh();
        } catch (Throwable e) {
            String str = "ByteString";
            String name = getClass().getName();
            StringBuilder stringBuilder = new StringBuilder((String.valueOf(name).length() + 62) + str.length());
            stringBuilder.append("Serializing ");
            stringBuilder.append(name);
            stringBuilder.append(" to a ");
            stringBuilder.append(str);
            stringBuilder.append(" threw an IOException (should never happen).");
            throw new RuntimeException(stringBuilder.toString(), e);
        }
    }

    public final byte[] toByteArray() {
        try {
            byte[] bArr = new byte[zzly()];
            zzeg zzh = zzeg.zzh(bArr);
            zzb(zzh);
            zzh.zzlk();
            return bArr;
        } catch (Throwable e) {
            String str = "byte array";
            String name = getClass().getName();
            StringBuilder stringBuilder = new StringBuilder((String.valueOf(name).length() + 62) + str.length());
            stringBuilder.append("Serializing ");
            stringBuilder.append(name);
            stringBuilder.append(" to a ");
            stringBuilder.append(str);
            stringBuilder.append(" threw an IOException (should never happen).");
            throw new RuntimeException(stringBuilder.toString(), e);
        }
    }

    int zzjw() {
        throw new UnsupportedOperationException();
    }

    void zzn(int i) {
        throw new UnsupportedOperationException();
    }

    protected static <T> void zza(Iterable<T> iterable, List<? super T> list) {
        zzfb.checkNotNull(iterable);
        String str = " is null.";
        String str2 = "Element at index ";
        StringBuilder stringBuilder;
        int size;
        if (iterable instanceof zzfq) {
            iterable = ((zzfq) iterable).zzng();
            zzfq zzfq = (zzfq) list;
            list = list.size();
            for (Object next : iterable) {
                if (next == null) {
                    iterable = zzfq.size() - list;
                    stringBuilder = new StringBuilder(37);
                    stringBuilder.append(str2);
                    stringBuilder.append(iterable);
                    stringBuilder.append(str);
                    iterable = stringBuilder.toString();
                    for (size = zzfq.size() - 1; size >= list; size--) {
                        zzfq.remove(size);
                    }
                    throw new NullPointerException(iterable);
                } else if (next instanceof zzdp) {
                    zzfq.zzc((zzdp) next);
                } else {
                    zzfq.add((String) next);
                }
            }
        } else if (iterable instanceof zzgt) {
            list.addAll((Collection) iterable);
        } else {
            if ((list instanceof ArrayList) && (iterable instanceof Collection)) {
                ((ArrayList) list).ensureCapacity(list.size() + ((Collection) iterable).size());
            }
            int size2 = list.size();
            for (Object next2 : iterable) {
                if (next2 == null) {
                    iterable = list.size() - size2;
                    stringBuilder = new StringBuilder(37);
                    stringBuilder.append(str2);
                    stringBuilder.append(iterable);
                    stringBuilder.append(str);
                    iterable = stringBuilder.toString();
                    for (size = list.size() - 1; size >= size2; size--) {
                        list.remove(size);
                    }
                    throw new NullPointerException(iterable);
                }
                list.add(next2);
            }
        }
    }
}
