package com.google.android.gms.internal.ads;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.common.util.GmsVersion;
import com.google.android.gms.dynamic.ObjectWrapper;

public final class zzclm implements zzcjz<zzbvw, zzamt, zzckz> {
    private final zzbaj zzbrd;
    private final zzbwr zzfzy;
    private final Context zzlj;

    public zzclm(Context context, zzbaj zzbaj, zzbwr zzbwr) {
        this.zzlj = context;
        this.zzbrd = zzbaj;
        this.zzfzy = zzbwr;
    }

    public final void zza(zzcxt zzcxt, zzcxl zzcxl, zzcjx<zzamt, zzckz> zzcjx) throws RemoteException {
        if (this.zzbrd.zzdzf < GmsVersion.VERSION_HALLOUMI) {
            ((zzamt) zzcjx.zzdge).zza(ObjectWrapper.wrap(this.zzlj), zzcxt.zzgkx.zzfjp.zzghg, zzcxl.zzgkh.toString(), (zzamw) zzcjx.zzfzn);
        } else {
            ((zzamt) zzcjx.zzdge).zza(ObjectWrapper.wrap(this.zzlj), zzcxt.zzgkx.zzfjp.zzghg, zzcxl.zzgkh.toString(), zzazd.zza(zzcxl.zzgke), (zzamw) zzcjx.zzfzn);
        }
    }

    public final /* synthetic */ Object zzb(zzcxt zzcxt, zzcxl zzcxl, zzcjx zzcjx) throws RemoteException, zzcmv {
        zzcxt = this.zzfzy.zza(new zzbpq(zzcxt, zzcxl, zzcjx.zzfir), new zzbvy(new zzcln(zzcjx)));
        ((zzckz) zzcjx.zzfzn).zza(zzcxt.zzadi());
        return zzcxt.zzaee();
    }
}
