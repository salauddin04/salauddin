package com.google.android.gms.internal.measurement;

import java.util.Iterator;

final class zzhf {
    private static final Iterator<Object> zzakj = new zzhg();
    private static final Iterable<Object> zzakk = new zzhh();

    static <T> Iterable<T> zzoo() {
        return zzakk;
    }
}
