package com.google.android.gms.internal.ads;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelWriter;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Class;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Constructor;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Field;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Param;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable.Reserved;

@Class(creator = "IconAdOptionsParcelCreator")
@Reserved({1})
@zzare
public final class zzaav extends AbstractSafeParcelable {
    public static final Creator<zzaav> CREATOR = new zzaaw();
    @Field(id = 2)
    private final int zzcis;

    @Constructor
    public zzaav(@Param(id = 2) int i) {
        this.zzcis = i;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        i = SafeParcelWriter.beginObjectHeader(parcel);
        SafeParcelWriter.writeInt(parcel, 2, this.zzcis);
        SafeParcelWriter.finishObjectHeader(parcel, i);
    }
}
