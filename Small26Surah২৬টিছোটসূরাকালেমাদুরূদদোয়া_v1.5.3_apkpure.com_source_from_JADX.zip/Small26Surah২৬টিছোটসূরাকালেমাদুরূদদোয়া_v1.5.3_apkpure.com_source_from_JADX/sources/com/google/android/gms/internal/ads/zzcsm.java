package com.google.android.gms.internal.ads;

import com.google.android.gms.common.util.Clock;

public final class zzcsm implements zzdth<zzcsj<zzcve>> {
    private final zzdtt<zzcvf> zzepj;
    private final zzdtt<Clock> zzfgi;

    public zzcsm(zzdtt<zzcvf> zzdtt, zzdtt<Clock> zzdtt2) {
        this.zzepj = zzdtt;
        this.zzfgi = zzdtt2;
    }

    public final /* synthetic */ Object get() {
        return (zzcsj) zzdtn.zza(new zzcsj((zzcvf) this.zzepj.get(), ((Long) zzyr.zzpe().zzd(zzact.zzcqn)).longValue(), (Clock) this.zzfgi.get()), "Cannot return null from a non-@Nullable @Provides method");
    }
}
