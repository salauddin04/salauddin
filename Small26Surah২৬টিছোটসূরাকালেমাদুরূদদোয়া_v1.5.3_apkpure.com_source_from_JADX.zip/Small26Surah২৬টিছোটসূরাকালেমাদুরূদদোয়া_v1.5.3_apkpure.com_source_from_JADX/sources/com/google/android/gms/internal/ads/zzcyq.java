package com.google.android.gms.internal.ads;

import android.content.Context;

public final class zzcyq implements zzdth<Context> {
    private final zzcyn zzglu;
    private final zzdtt<zzcyl> zzglv;

    private zzcyq(zzcyn zzcyn, zzdtt<zzcyl> zzdtt) {
        this.zzglu = zzcyn;
        this.zzglv = zzdtt;
    }

    public static zzcyq zzb(zzcyn zzcyn, zzdtt<zzcyl> zzdtt) {
        return new zzcyq(zzcyn, zzdtt);
    }

    public final /* synthetic */ Object get() {
        return (Context) zzdtn.zza(((zzcyl) this.zzglv.get()).zzys, "Cannot return null from a non-@Nullable @Provides method");
    }
}
