package com.google.android.gms.internal.ads;

final /* synthetic */ class zzbzl implements Runnable {
    private final zzbzk zzfpt;
    private final zzcaa zzfpu;

    zzbzl(zzbzk zzbzk, zzcaa zzcaa) {
        this.zzfpt = zzbzk;
        this.zzfpu = zzcaa;
    }

    public final void run() {
        this.zzfpt.zze(this.zzfpu);
    }
}
