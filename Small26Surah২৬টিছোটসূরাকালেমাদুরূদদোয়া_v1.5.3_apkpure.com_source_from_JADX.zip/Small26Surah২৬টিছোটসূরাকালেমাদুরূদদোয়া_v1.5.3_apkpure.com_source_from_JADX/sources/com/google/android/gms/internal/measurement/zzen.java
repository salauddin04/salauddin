package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.util.Map.Entry;

abstract class zzen<T extends zzes<T>> {
    zzen() {
    }

    abstract int zza(Entry<?, ?> entry);

    abstract Object zza(zzem zzem, zzgh zzgh, int i);

    abstract <UT, UB> UB zza(zzgx zzgx, Object obj, zzem zzem, zzeq<T> zzeq, UB ub, zzhq<UT, UB> zzhq) throws IOException;

    abstract void zza(zzdp zzdp, Object obj, zzem zzem, zzeq<T> zzeq) throws IOException;

    abstract void zza(zzgx zzgx, Object obj, zzem zzem, zzeq<T> zzeq) throws IOException;

    abstract void zza(zzil zzil, Entry<?, ?> entry) throws IOException;

    abstract boolean zze(zzgh zzgh);

    abstract zzeq<T> zzg(Object obj);

    abstract zzeq<T> zzh(Object obj);

    abstract void zzi(Object obj);
}
