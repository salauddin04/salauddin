package com.google.android.gms.internal.measurement;

import com.google.android.gms.internal.measurement.zzbl.zza.zzb;

final class zzbo implements zzfe {
    static final zzfe zzty = new zzbo();

    private zzbo() {
    }

    public final boolean zzf(int i) {
        return zzb.zze(i) != 0;
    }
}
