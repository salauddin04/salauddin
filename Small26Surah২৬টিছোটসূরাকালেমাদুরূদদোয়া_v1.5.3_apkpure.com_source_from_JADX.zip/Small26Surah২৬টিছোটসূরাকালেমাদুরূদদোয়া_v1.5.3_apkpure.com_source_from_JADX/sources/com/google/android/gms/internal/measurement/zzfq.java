package com.google.android.gms.internal.measurement;

import java.util.List;

public interface zzfq extends List {
    Object zzaw(int i);

    void zzc(zzdp zzdp);

    List<?> zzng();

    zzfq zznh();
}
