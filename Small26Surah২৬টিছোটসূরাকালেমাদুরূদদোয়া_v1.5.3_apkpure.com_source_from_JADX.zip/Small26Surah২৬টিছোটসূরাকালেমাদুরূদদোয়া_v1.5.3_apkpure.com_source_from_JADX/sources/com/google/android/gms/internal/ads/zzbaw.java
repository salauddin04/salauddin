package com.google.android.gms.internal.ads;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

final /* synthetic */ class zzbaw implements Runnable {
    private final Iterable zzdzo;
    private final zzbbs zzdzp;

    zzbaw(Iterable iterable, zzbbs zzbbs) {
        this.zzdzo = iterable;
        this.zzdzp = zzbbs;
    }

    public final void run() {
        Throwable e;
        Iterable<zzbbi> iterable = this.zzdzo;
        zzbbs zzbbs = this.zzdzp;
        List arrayList = new ArrayList();
        for (zzbbi zzbbi : iterable) {
            try {
                arrayList.add(zzbbi.get());
            } catch (ExecutionException e2) {
                zzbbs.setException(e2.getCause());
            } catch (InterruptedException e3) {
                e = e3;
                zzbbs.setException(e);
            } catch (Exception e4) {
                e = e4;
                zzbbs.setException(e);
            }
        }
        zzbbs.set(arrayList);
    }
}
