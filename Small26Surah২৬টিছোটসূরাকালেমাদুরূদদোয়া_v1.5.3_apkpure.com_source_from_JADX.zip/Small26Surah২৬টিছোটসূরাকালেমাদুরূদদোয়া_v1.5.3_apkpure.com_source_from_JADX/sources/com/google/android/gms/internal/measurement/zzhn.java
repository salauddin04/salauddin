package com.google.android.gms.internal.measurement;

final class zzhn implements zzho {
    private final /* synthetic */ zzdp zzakn;

    zzhn(zzdp zzdp) {
        this.zzakn = zzdp;
    }

    public final int size() {
        return this.zzakn.size();
    }

    public final byte zzr(int i) {
        return this.zzakn.zzr(i);
    }
}
