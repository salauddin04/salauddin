package com.google.android.gms.internal.ads;

import android.content.Context;

public final class zzbmb implements zzdth<zzbma> {
    private final zzdtt<Context> zzeol;

    private zzbmb(zzdtt<Context> zzdtt) {
        this.zzeol = zzdtt;
    }

    public static zzbmb zzf(zzdtt<Context> zzdtt) {
        return new zzbmb(zzdtt);
    }

    public final /* synthetic */ Object get() {
        return new zzbma((Context) this.zzeol.get());
    }
}
