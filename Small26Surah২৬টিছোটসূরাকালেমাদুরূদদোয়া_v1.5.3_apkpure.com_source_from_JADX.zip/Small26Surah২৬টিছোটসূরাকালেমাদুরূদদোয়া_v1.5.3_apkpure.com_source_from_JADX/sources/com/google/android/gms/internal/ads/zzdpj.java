package com.google.android.gms.internal.ads;

import java.io.IOException;

public interface zzdpj extends zzdpl {
    byte[] toByteArray();

    zzdmq zzavf();

    int zzaxj();

    zzdpk zzaxt();

    zzdpk zzaxu();

    void zzb(zzdnh zzdnh) throws IOException;
}
