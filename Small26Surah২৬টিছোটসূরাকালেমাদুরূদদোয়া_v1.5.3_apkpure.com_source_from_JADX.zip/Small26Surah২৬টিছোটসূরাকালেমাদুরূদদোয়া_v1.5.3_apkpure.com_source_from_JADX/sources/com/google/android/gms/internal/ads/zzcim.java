package com.google.android.gms.internal.ads;

final /* synthetic */ class zzcim implements Runnable {
    private final zzcif zzfxp;

    zzcim(zzcif zzcif) {
        this.zzfxp = zzcif;
    }

    public final void run() {
        this.zzfxp.zzaki();
    }
}
