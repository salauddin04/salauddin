package com.google.android.gms.internal.measurement;

public interface zzgi extends zzgj, Cloneable {
    zzgi zza(zzgh zzgh);

    zzgh zzmq();

    zzgh zzmr();
}
