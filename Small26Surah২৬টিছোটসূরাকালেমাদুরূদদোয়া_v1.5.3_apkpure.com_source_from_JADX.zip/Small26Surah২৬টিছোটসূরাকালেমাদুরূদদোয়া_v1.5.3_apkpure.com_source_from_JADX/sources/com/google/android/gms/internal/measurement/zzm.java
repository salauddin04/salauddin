package com.google.android.gms.internal.measurement;

import android.os.Bundle;
import android.util.Log;
import java.util.concurrent.atomic.AtomicReference;

public final class zzm extends zzr {
    private final AtomicReference<Bundle> zzr = new AtomicReference();
    private boolean zzs;

    public final void zzb(Bundle bundle) {
        synchronized (this.zzr) {
            try {
                this.zzr.set(bundle);
                this.zzs = true;
                this.zzr.notify();
            } catch (Throwable th) {
                this.zzr.notify();
            }
        }
    }

    final String zza(long j) {
        return (String) zza(zzb(j), String.class);
    }

    final android.os.Bundle zzb(long r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r2 = this;
        r0 = r2.zzr;
        monitor-enter(r0);
        r1 = r2.zzs;	 Catch:{ all -> 0x001a }
        if (r1 != 0) goto L_0x0010;
    L_0x0007:
        r1 = r2.zzr;	 Catch:{ InterruptedException -> 0x000d }
        r1.wait(r3);	 Catch:{ InterruptedException -> 0x000d }
        goto L_0x0010;
    L_0x000d:
        r3 = 0;
        monitor-exit(r0);	 Catch:{ all -> 0x001a }
        return r3;	 Catch:{ all -> 0x001a }
    L_0x0010:
        r3 = r2.zzr;	 Catch:{ all -> 0x001a }
        r3 = r3.get();	 Catch:{ all -> 0x001a }
        r3 = (android.os.Bundle) r3;	 Catch:{ all -> 0x001a }
        monitor-exit(r0);	 Catch:{ all -> 0x001a }
        return r3;	 Catch:{ all -> 0x001a }
    L_0x001a:
        r3 = move-exception;	 Catch:{ all -> 0x001a }
        monitor-exit(r0);	 Catch:{ all -> 0x001a }
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzm.zzb(long):android.os.Bundle");
    }

    static <T> T zza(Bundle bundle, Class<T> cls) {
        if (bundle != null) {
            bundle = bundle.get("r");
            if (bundle != null) {
                try {
                    bundle = cls.cast(bundle);
                    return bundle;
                } catch (Throwable e) {
                    cls = cls.getCanonicalName();
                    bundle = bundle.getClass().getCanonicalName();
                    Object[] objArr = new Object[]{cls, bundle};
                    cls = "AM";
                    Log.w(cls, String.format("Unexpected object type. Expected, Received".concat(": %s, %s"), objArr), e);
                    throw e;
                }
            }
        }
        return null;
    }
}
