package com.google.android.gms.internal.ads;

public final class zzctm implements zzdth<zzctk> {
    private final zzdtt<zzcxj> zzffa;
    private final zzdtt<zzbbm> zzfgg;

    private zzctm(zzdtt<zzbbm> zzdtt, zzdtt<zzcxj> zzdtt2) {
        this.zzfgg = zzdtt;
        this.zzffa = zzdtt2;
    }

    public static zzctm zzap(zzdtt<zzbbm> zzdtt, zzdtt<zzcxj> zzdtt2) {
        return new zzctm(zzdtt, zzdtt2);
    }

    public final /* synthetic */ Object get() {
        return new zzctk((zzbbm) this.zzfgg.get(), (zzcxj) this.zzffa.get());
    }
}
