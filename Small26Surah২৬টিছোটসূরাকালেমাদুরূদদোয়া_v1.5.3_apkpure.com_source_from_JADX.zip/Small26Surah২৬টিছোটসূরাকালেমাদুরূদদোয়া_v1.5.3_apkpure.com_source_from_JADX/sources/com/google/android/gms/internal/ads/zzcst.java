package com.google.android.gms.internal.ads;

import android.os.Bundle;

public final class zzcst implements zzcuy<Bundle> {
    private final Bundle zzghd;

    public zzcst(Bundle bundle) {
        this.zzghd = bundle;
    }

    public final /* synthetic */ void zzt(Object obj) {
        ((Bundle) obj).putBundle("content_info", this.zzghd);
    }
}
