package com.google.android.gms.internal.measurement;

public interface zzff extends zzfg<Long> {
    long getLong(int i);

    zzff zzav(int i);

    void zzbb(long j);
}
