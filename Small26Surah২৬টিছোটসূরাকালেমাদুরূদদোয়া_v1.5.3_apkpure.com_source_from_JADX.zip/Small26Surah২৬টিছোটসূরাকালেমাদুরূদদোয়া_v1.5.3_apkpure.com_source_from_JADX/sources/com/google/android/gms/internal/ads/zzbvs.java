package com.google.android.gms.internal.ads;

import com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks;

final /* synthetic */ class zzbvs implements zzbtt {
    static final zzbtt zzfka = new zzbvs();

    private zzbvs() {
    }

    public final void zzr(Object obj) {
        ((VideoLifecycleCallbacks) obj).onVideoStart();
    }
}
