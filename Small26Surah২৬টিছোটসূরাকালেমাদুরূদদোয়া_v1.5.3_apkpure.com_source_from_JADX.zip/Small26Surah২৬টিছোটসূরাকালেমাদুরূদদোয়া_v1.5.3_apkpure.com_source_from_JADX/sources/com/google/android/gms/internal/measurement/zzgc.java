package com.google.android.gms.internal.measurement;

import java.util.Map;

interface zzgc {
    int zzb(int i, Object obj, Object obj2);

    Object zzb(Object obj, Object obj2);

    Map<?, ?> zzm(Object obj);

    Map<?, ?> zzn(Object obj);

    boolean zzo(Object obj);

    Object zzp(Object obj);

    Object zzq(Object obj);

    zzga<?, ?> zzr(Object obj);
}
