package com.google.android.gms.internal.ads;

final class zziu {
    public final zziy[] zzamd;
    public zzhj zzame;
    public int zzamf = -1;

    public zziu(int i) {
        this.zzamd = new zziy[i];
    }
}
