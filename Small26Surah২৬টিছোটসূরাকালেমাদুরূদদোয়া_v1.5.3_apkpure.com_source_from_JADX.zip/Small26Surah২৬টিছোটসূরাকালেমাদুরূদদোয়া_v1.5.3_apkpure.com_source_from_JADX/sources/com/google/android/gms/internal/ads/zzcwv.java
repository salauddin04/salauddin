package com.google.android.gms.internal.ads;

import android.content.Context;
import java.util.concurrent.ScheduledExecutorService;

public final class zzcwv implements zzdth<zzcwt> {
    private final zzdtt<Context> zzeol;
    private final zzdtt<ScheduledExecutorService> zzfjc;
    private final zzdtt<zzaqn> zzgit;

    public zzcwv(zzdtt<zzaqn> zzdtt, zzdtt<ScheduledExecutorService> zzdtt2, zzdtt<Context> zzdtt3) {
        this.zzgit = zzdtt;
        this.zzfjc = zzdtt2;
        this.zzeol = zzdtt3;
    }

    public final /* synthetic */ Object get() {
        return new zzcwt((zzaqn) this.zzgit.get(), (ScheduledExecutorService) this.zzfjc.get(), (Context) this.zzeol.get());
    }
}
