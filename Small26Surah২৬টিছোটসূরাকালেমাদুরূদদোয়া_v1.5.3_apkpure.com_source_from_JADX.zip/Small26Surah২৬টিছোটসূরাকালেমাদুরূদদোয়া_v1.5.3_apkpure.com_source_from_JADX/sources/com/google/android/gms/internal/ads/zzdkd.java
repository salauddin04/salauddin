package com.google.android.gms.internal.ads;

import java.security.interfaces.ECPublicKey;

public final class zzdkd {
    private ECPublicKey zzgyv;

    public zzdkd(ECPublicKey eCPublicKey) {
        this.zzgyv = eCPublicKey;
    }

    public final com.google.android.gms.internal.ads.zzdke zza(java.lang.String r11, byte[] r12, byte[] r13, int r14, com.google.android.gms.internal.ads.zzdku r15) throws java.security.GeneralSecurityException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:54:0x01ad in {17, 18, 19, 21, 24, 27, 28, 29, 35, 36, 37, 41, 43, 45, 48, 50, 51, 53} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r10 = this;
        r0 = r10.zzgyv;
        r0 = r0.getParams();
        r0 = com.google.android.gms.internal.ads.zzdkq.zza(r0);
        r1 = r0.getPublic();
        r1 = (java.security.interfaces.ECPublicKey) r1;
        r0 = r0.getPrivate();
        r0 = (java.security.interfaces.ECPrivateKey) r0;
        r2 = r10.zzgyv;
        r3 = r2.getParams();	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        r4 = r0.getParams();	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        r5 = r3.getCurve();	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        r6 = r4.getCurve();	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        r5 = r5.equals(r6);	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        if (r5 == 0) goto L_0x0198;	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
    L_0x002e:
        r5 = r3.getGenerator();	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        r6 = r4.getGenerator();	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        r5 = r5.equals(r6);	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        if (r5 == 0) goto L_0x0198;	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
    L_0x003c:
        r5 = r3.getOrder();	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        r6 = r4.getOrder();	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        r5 = r5.equals(r6);	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        if (r5 == 0) goto L_0x0198;	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
    L_0x004a:
        r3 = r3.getCofactor();	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        r4 = r4.getCofactor();	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        if (r3 != r4) goto L_0x0198;
    L_0x0054:
        r2 = r2.getW();
        r0 = com.google.android.gms.internal.ads.zzdkq.zza(r0, r2);
        r2 = r1.getParams();
        r2 = r2.getCurve();
        r1 = r1.getW();
        com.google.android.gms.internal.ads.zzdkq.zza(r1, r2);
        r2 = com.google.android.gms.internal.ads.zzdkq.zzb(r2);
        r3 = com.google.android.gms.internal.ads.zzdkr.zzgzy;
        r4 = r15.ordinal();
        r3 = r3[r4];
        r4 = 2;
        r5 = 1;
        r6 = 0;
        if (r3 == r5) goto L_0x00fe;
    L_0x007c:
        if (r3 == r4) goto L_0x00c9;
    L_0x007e:
        r7 = 3;
        if (r3 != r7) goto L_0x00a4;
    L_0x0081:
        r2 = r2 + r5;
        r15 = new byte[r2];
        r3 = r1.getAffineX();
        r3 = r3.toByteArray();
        r8 = r3.length;
        r2 = r2 - r8;
        r8 = r3.length;
        java.lang.System.arraycopy(r3, r6, r15, r2, r8);
        r1 = r1.getAffineY();
        r1 = r1.testBit(r6);
        if (r1 == 0) goto L_0x009d;
    L_0x009c:
        goto L_0x009e;
    L_0x009d:
        r7 = 2;
    L_0x009e:
        r1 = (byte) r7;
        r15[r6] = r1;
        r3 = r15;
        goto L_0x0123;
    L_0x00a4:
        r11 = new java.security.GeneralSecurityException;
        r12 = java.lang.String.valueOf(r15);
        r13 = java.lang.String.valueOf(r12);
        r13 = r13.length();
        r13 = r13 + 15;
        r14 = new java.lang.StringBuilder;
        r14.<init>(r13);
        r13 = "invalid format:";
        r14.append(r13);
        r14.append(r12);
        r12 = r14.toString();
        r11.<init>(r12);
        throw r11;
    L_0x00c9:
        r15 = r2 * 2;
        r3 = new byte[r15];
        r7 = r1.getAffineX();
        r7 = r7.toByteArray();
        r8 = r7.length;
        if (r8 <= r2) goto L_0x00df;
    L_0x00d8:
        r8 = r7.length;
        r8 = r8 - r2;
        r9 = r7.length;
        r7 = java.util.Arrays.copyOfRange(r7, r8, r9);
    L_0x00df:
        r1 = r1.getAffineY();
        r1 = r1.toByteArray();
        r8 = r1.length;
        if (r8 <= r2) goto L_0x00f1;
    L_0x00ea:
        r8 = r1.length;
        r8 = r8 - r2;
        r9 = r1.length;
        r1 = java.util.Arrays.copyOfRange(r1, r8, r9);
    L_0x00f1:
        r8 = r1.length;
        r15 = r15 - r8;
        r8 = r1.length;
        java.lang.System.arraycopy(r1, r6, r3, r15, r8);
        r15 = r7.length;
        r2 = r2 - r15;
        r15 = r7.length;
        java.lang.System.arraycopy(r7, r6, r3, r2, r15);
        goto L_0x0123;
    L_0x00fe:
        r15 = r2 * 2;
        r15 = r15 + r5;
        r3 = new byte[r15];
        r7 = r1.getAffineX();
        r7 = r7.toByteArray();
        r1 = r1.getAffineY();
        r1 = r1.toByteArray();
        r8 = r1.length;
        r15 = r15 - r8;
        r8 = r1.length;
        java.lang.System.arraycopy(r1, r6, r3, r15, r8);
        r2 = r2 + r5;
        r15 = r7.length;
        r2 = r2 - r15;
        r15 = r7.length;
        java.lang.System.arraycopy(r7, r6, r3, r2, r15);
        r15 = 4;
        r3[r6] = r15;
    L_0x0123:
        r15 = new byte[r4][];
        r15[r6] = r3;
        r15[r5] = r0;
        r15 = com.google.android.gms.internal.ads.zzdjr.zza(r15);
        r0 = com.google.android.gms.internal.ads.zzdkw.zzhaq;
        r0 = r0.zzgt(r11);
        r0 = (javax.crypto.Mac) r0;
        r1 = r0.getMacLength();
        r1 = r1 * 255;
        if (r14 > r1) goto L_0x0190;
    L_0x013d:
        if (r12 == 0) goto L_0x014c;
    L_0x013f:
        r1 = r12.length;
        if (r1 != 0) goto L_0x0143;
    L_0x0142:
        goto L_0x014c;
    L_0x0143:
        r1 = new javax.crypto.spec.SecretKeySpec;
        r1.<init>(r12, r11);
        r0.init(r1);
        goto L_0x015a;
    L_0x014c:
        r12 = new javax.crypto.spec.SecretKeySpec;
        r1 = r0.getMacLength();
        r1 = new byte[r1];
        r12.<init>(r1, r11);
        r0.init(r12);
    L_0x015a:
        r12 = r0.doFinal(r15);
        r15 = new byte[r14];
        r1 = new javax.crypto.spec.SecretKeySpec;
        r1.<init>(r12, r11);
        r0.init(r1);
        r11 = new byte[r6];
        r12 = 0;
    L_0x016b:
        r0.update(r11);
        r0.update(r13);
        r11 = (byte) r5;
        r0.update(r11);
        r11 = r0.doFinal();
        r1 = r11.length;
        r1 = r1 + r12;
        if (r1 >= r14) goto L_0x0186;
    L_0x017d:
        r1 = r11.length;
        java.lang.System.arraycopy(r11, r6, r15, r12, r1);
        r1 = r11.length;
        r12 = r12 + r1;
        r5 = r5 + 1;
        goto L_0x016b;
    L_0x0186:
        r14 = r14 - r12;
        java.lang.System.arraycopy(r11, r6, r15, r12, r14);
        r11 = new com.google.android.gms.internal.ads.zzdke;
        r11.<init>(r3, r15);
        return r11;
    L_0x0190:
        r11 = new java.security.GeneralSecurityException;
        r12 = "size too large";
        r11.<init>(r12);
        throw r11;
    L_0x0198:
        r11 = new java.security.GeneralSecurityException;	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        r12 = "invalid public key spec";	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        r11.<init>(r12);	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
        throw r11;	 Catch:{ IllegalArgumentException -> 0x01a2, NullPointerException -> 0x01a0 }
    L_0x01a0:
        r11 = move-exception;
        goto L_0x01a3;
    L_0x01a2:
        r11 = move-exception;
    L_0x01a3:
        r12 = new java.security.GeneralSecurityException;
        r11 = r11.toString();
        r12.<init>(r11);
        throw r12;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzdkd.zza(java.lang.String, byte[], byte[], int, com.google.android.gms.internal.ads.zzdku):com.google.android.gms.internal.ads.zzdke");
    }
}
