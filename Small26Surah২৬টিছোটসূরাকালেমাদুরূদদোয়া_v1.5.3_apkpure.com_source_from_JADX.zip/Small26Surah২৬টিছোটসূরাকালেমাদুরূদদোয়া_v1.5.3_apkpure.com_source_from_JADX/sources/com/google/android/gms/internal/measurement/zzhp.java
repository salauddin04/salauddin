package com.google.android.gms.internal.measurement;

import java.util.List;

public final class zzhp extends RuntimeException {
    private final List<String> zzako = null;

    public zzhp(zzgh zzgh) {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }
}
