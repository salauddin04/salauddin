package com.google.android.gms.internal.measurement;

import java.util.Iterator;

public interface zzdw extends Iterator<Byte> {
    byte nextByte();
}
