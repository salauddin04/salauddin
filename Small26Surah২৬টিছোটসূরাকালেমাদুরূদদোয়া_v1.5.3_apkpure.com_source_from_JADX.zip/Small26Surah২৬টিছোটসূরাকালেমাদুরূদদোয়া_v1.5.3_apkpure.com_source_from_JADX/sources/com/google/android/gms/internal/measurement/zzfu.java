package com.google.android.gms.internal.measurement;

import java.util.List;

final class zzfu extends zzfr {
    private zzfu() {
        super();
    }

    final <L> List<L> zza(Object obj, long j) {
        List<L> zzd = zzd(obj, j);
        if (zzd.zzjy()) {
            return zzd;
        }
        int size = zzd.size();
        Object zzq = zzd.zzq(size == 0 ? 10 : size << 1);
        zzhw.zza(obj, j, zzq);
        return zzq;
    }

    final void zzb(Object obj, long j) {
        zzd(obj, j).zzjz();
    }

    final <E> void zza(Object obj, Object obj2, long j) {
        zzfg zzd = zzd(obj, j);
        obj2 = zzd(obj2, j);
        int size = zzd.size();
        int size2 = obj2.size();
        if (size > 0 && size2 > 0) {
            if (!zzd.zzjy()) {
                zzd = zzd.zzq(size2 + size);
            }
            zzd.addAll(obj2);
        }
        if (size > 0) {
            obj2 = zzd;
        }
        zzhw.zza(obj, j, obj2);
    }

    private static <E> zzfg<E> zzd(Object obj, long j) {
        return (zzfg) zzhw.zzp(obj, j);
    }
}
