package com.google.android.gms.internal.ads;

import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper.Stub;

public abstract class zzanf extends zzfn implements zzane {
    public zzanf() {
        super("com.google.android.gms.ads.internal.mediation.client.INativeContentAdMapper");
    }

    protected final boolean dispatchTransaction(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
        IInterface zzrl;
        switch (i) {
            case 2:
                i = getHeadline();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 3:
                i = getImages();
                parcel2.writeNoException();
                parcel2.writeList(i);
                break;
            case 4:
                i = getBody();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 5:
                zzrl = zzrl();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzrl);
                break;
            case 6:
                i = getCallToAction();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 7:
                i = getAdvertiser();
                parcel2.writeNoException();
                parcel2.writeString(i);
                break;
            case 8:
                recordImpression();
                parcel2.writeNoException();
                break;
            case 9:
                zzt(Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                break;
            case 10:
                zzu(Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                break;
            case 11:
                i = getOverrideImpressionRecording();
                parcel2.writeNoException();
                zzfo.writeBoolean(parcel2, i);
                break;
            case 12:
                i = getOverrideClickHandling();
                parcel2.writeNoException();
                zzfo.writeBoolean(parcel2, i);
                break;
            case 13:
                i = getExtras();
                parcel2.writeNoException();
                zzfo.zzb(parcel2, i);
                break;
            case 14:
                zzv(Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                break;
            case 15:
                zzrl = zzso();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzrl);
                break;
            case 16:
                zzrl = getVideoController();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzrl);
                break;
            case 19:
                zzrl = zzrj();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzrl);
                break;
            case 20:
                zzrl = zzsp();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzrl);
                break;
            case 21:
                zzrl = zzrk();
                parcel2.writeNoException();
                zzfo.zza(parcel2, zzrl);
                break;
            case 22:
                zzc(Stub.asInterface(parcel.readStrongBinder()), Stub.asInterface(parcel.readStrongBinder()), Stub.asInterface(parcel.readStrongBinder()));
                parcel2.writeNoException();
                break;
            default:
                return false;
        }
        return true;
    }
}
