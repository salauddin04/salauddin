package com.google.android.gms.internal.ads;

final class zzqr {
    private int length;
    private int[] zzahp;
    private long[] zzahq;
    private long[] zzahs;
    private int zzajq = 1000;
    private int[] zzajr;
    private int[] zzbjs;
    private zznx[] zzbjt;
    private zzlh[] zzbju;
    private int zzbjv;
    private int zzbjw;
    private int zzbjx;
    private long zzbjy;
    private long zzbjz;
    private boolean zzbka;
    private boolean zzbkb;
    private zzlh zzbkc;

    public zzqr() {
        int i = this.zzajq;
        this.zzbjs = new int[i];
        this.zzahq = new long[i];
        this.zzahs = new long[i];
        this.zzajr = new int[i];
        this.zzahp = new int[i];
        this.zzbjt = new zznx[i];
        this.zzbju = new zzlh[i];
        this.zzbjy = Long.MIN_VALUE;
        this.zzbjz = Long.MIN_VALUE;
        this.zzbkb = true;
        this.zzbka = true;
    }

    public final synchronized long zzg(long r9, boolean r11) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:37:0x0064 in {6, 12, 22, 24, 27, 31, 33, 36} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r8 = this;
        monitor-enter(r8);
        r0 = r8.zzjk();	 Catch:{ all -> 0x0061 }
        r1 = -1;	 Catch:{ all -> 0x0061 }
        if (r0 == 0) goto L_0x005f;	 Catch:{ all -> 0x0061 }
    L_0x0009:
        r0 = r8.zzahs;	 Catch:{ all -> 0x0061 }
        r3 = r8.zzbjw;	 Catch:{ all -> 0x0061 }
        r3 = r0[r3];	 Catch:{ all -> 0x0061 }
        r0 = (r9 > r3 ? 1 : (r9 == r3 ? 0 : -1));	 Catch:{ all -> 0x0061 }
        if (r0 >= 0) goto L_0x0014;	 Catch:{ all -> 0x0061 }
    L_0x0013:
        goto L_0x005f;	 Catch:{ all -> 0x0061 }
    L_0x0014:
        r3 = r8.zzbjz;	 Catch:{ all -> 0x0061 }
        r0 = (r9 > r3 ? 1 : (r9 == r3 ? 0 : -1));
        if (r0 <= 0) goto L_0x001e;
    L_0x001a:
        if (r11 != 0) goto L_0x001e;
    L_0x001c:
        monitor-exit(r8);
        return r1;
    L_0x001e:
        r11 = 0;
        r0 = r8.zzbjw;	 Catch:{ all -> 0x0061 }
        r3 = -1;	 Catch:{ all -> 0x0061 }
        r11 = -1;	 Catch:{ all -> 0x0061 }
        r4 = 0;	 Catch:{ all -> 0x0061 }
    L_0x0024:
        r5 = r8.zzbjx;	 Catch:{ all -> 0x0061 }
        if (r0 == r5) goto L_0x0041;	 Catch:{ all -> 0x0061 }
    L_0x0028:
        r5 = r8.zzahs;	 Catch:{ all -> 0x0061 }
        r6 = r5[r0];	 Catch:{ all -> 0x0061 }
        r5 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1));	 Catch:{ all -> 0x0061 }
        if (r5 > 0) goto L_0x0041;	 Catch:{ all -> 0x0061 }
    L_0x0030:
        r5 = r8.zzajr;	 Catch:{ all -> 0x0061 }
        r5 = r5[r0];	 Catch:{ all -> 0x0061 }
        r5 = r5 & 1;	 Catch:{ all -> 0x0061 }
        if (r5 == 0) goto L_0x0039;	 Catch:{ all -> 0x0061 }
    L_0x0038:
        r11 = r4;	 Catch:{ all -> 0x0061 }
    L_0x0039:
        r0 = r0 + 1;	 Catch:{ all -> 0x0061 }
        r5 = r8.zzajq;	 Catch:{ all -> 0x0061 }
        r0 = r0 % r5;	 Catch:{ all -> 0x0061 }
        r4 = r4 + 1;
        goto L_0x0024;
    L_0x0041:
        if (r11 != r3) goto L_0x0045;
    L_0x0043:
        monitor-exit(r8);
        return r1;
    L_0x0045:
        r9 = r8.zzbjw;	 Catch:{ all -> 0x0061 }
        r9 = r9 + r11;	 Catch:{ all -> 0x0061 }
        r10 = r8.zzajq;	 Catch:{ all -> 0x0061 }
        r9 = r9 % r10;	 Catch:{ all -> 0x0061 }
        r8.zzbjw = r9;	 Catch:{ all -> 0x0061 }
        r9 = r8.zzbjv;	 Catch:{ all -> 0x0061 }
        r9 = r9 + r11;	 Catch:{ all -> 0x0061 }
        r8.zzbjv = r9;	 Catch:{ all -> 0x0061 }
        r9 = r8.length;	 Catch:{ all -> 0x0061 }
        r9 = r9 - r11;	 Catch:{ all -> 0x0061 }
        r8.length = r9;	 Catch:{ all -> 0x0061 }
        r9 = r8.zzahq;	 Catch:{ all -> 0x0061 }
        r10 = r8.zzbjw;	 Catch:{ all -> 0x0061 }
        r10 = r9[r10];	 Catch:{ all -> 0x0061 }
        monitor-exit(r8);
        return r10;
    L_0x005f:
        monitor-exit(r8);
        return r1;
    L_0x0061:
        r9 = move-exception;
        monitor-exit(r8);
        throw r9;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzqr.zzg(long, boolean):long");
    }

    public final synchronized boolean zzjk() {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:11:0x000d in {4, 6, 7, 10} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r1 = this;
        monitor-enter(r1);
        r0 = r1.length;	 Catch:{ all -> 0x000a }
        if (r0 == 0) goto L_0x0008;
    L_0x0005:
        r0 = 1;
    L_0x0006:
        monitor-exit(r1);
        return r0;
    L_0x0008:
        r0 = 0;
        goto L_0x0006;
    L_0x000a:
        r0 = move-exception;
        monitor-exit(r1);
        throw r0;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzqr.zzjk():boolean");
    }

    public final void zzjh() {
        this.zzbjv = 0;
        this.zzbjw = 0;
        this.zzbjx = 0;
        this.length = 0;
        this.zzbka = true;
    }

    public final void zzji() {
        this.zzbjy = Long.MIN_VALUE;
        this.zzbjz = Long.MIN_VALUE;
    }

    public final int zzjj() {
        return this.zzbjv + this.length;
    }

    public final synchronized zzlh zzjl() {
        if (this.zzbkb) {
            return null;
        }
        return this.zzbkc;
    }

    public final synchronized long zzje() {
        return Math.max(this.zzbjy, this.zzbjz);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized int zza(com.google.android.gms.internal.ads.zzlj r5, com.google.android.gms.internal.ads.zznd r6, boolean r7, boolean r8, com.google.android.gms.internal.ads.zzlh r9, com.google.android.gms.internal.ads.zzqs r10) {
        /*
        r4 = this;
        monitor-enter(r4);
        r0 = r4.zzjk();	 Catch:{ all -> 0x00a6 }
        r1 = -5;
        r2 = -3;
        r3 = -4;
        if (r0 != 0) goto L_0x0024;
    L_0x000a:
        if (r8 == 0) goto L_0x0012;
    L_0x000c:
        r5 = 4;
        r6.setFlags(r5);	 Catch:{ all -> 0x00a6 }
        monitor-exit(r4);
        return r3;
    L_0x0012:
        r6 = r4.zzbkc;	 Catch:{ all -> 0x00a6 }
        if (r6 == 0) goto L_0x0022;
    L_0x0016:
        if (r7 != 0) goto L_0x001c;
    L_0x0018:
        r6 = r4.zzbkc;	 Catch:{ all -> 0x00a6 }
        if (r6 == r9) goto L_0x0022;
    L_0x001c:
        r6 = r4.zzbkc;	 Catch:{ all -> 0x00a6 }
        r5.zzaue = r6;	 Catch:{ all -> 0x00a6 }
        monitor-exit(r4);
        return r1;
    L_0x0022:
        monitor-exit(r4);
        return r2;
    L_0x0024:
        if (r7 != 0) goto L_0x009c;
    L_0x0026:
        r7 = r4.zzbju;	 Catch:{ all -> 0x00a6 }
        r8 = r4.zzbjw;	 Catch:{ all -> 0x00a6 }
        r7 = r7[r8];	 Catch:{ all -> 0x00a6 }
        if (r7 == r9) goto L_0x002f;
    L_0x002e:
        goto L_0x009c;
    L_0x002f:
        r5 = r6.zzde;	 Catch:{ all -> 0x00a6 }
        r7 = 0;
        r8 = 1;
        if (r5 != 0) goto L_0x0037;
    L_0x0035:
        r5 = 1;
        goto L_0x0038;
    L_0x0037:
        r5 = 0;
    L_0x0038:
        if (r5 == 0) goto L_0x003c;
    L_0x003a:
        monitor-exit(r4);
        return r2;
    L_0x003c:
        r5 = r4.zzahs;	 Catch:{ all -> 0x00a6 }
        r9 = r4.zzbjw;	 Catch:{ all -> 0x00a6 }
        r0 = r5[r9];	 Catch:{ all -> 0x00a6 }
        r6.zzaga = r0;	 Catch:{ all -> 0x00a6 }
        r5 = r4.zzajr;	 Catch:{ all -> 0x00a6 }
        r9 = r4.zzbjw;	 Catch:{ all -> 0x00a6 }
        r5 = r5[r9];	 Catch:{ all -> 0x00a6 }
        r6.setFlags(r5);	 Catch:{ all -> 0x00a6 }
        r5 = r4.zzahp;	 Catch:{ all -> 0x00a6 }
        r9 = r4.zzbjw;	 Catch:{ all -> 0x00a6 }
        r5 = r5[r9];	 Catch:{ all -> 0x00a6 }
        r10.size = r5;	 Catch:{ all -> 0x00a6 }
        r5 = r4.zzahq;	 Catch:{ all -> 0x00a6 }
        r9 = r4.zzbjw;	 Catch:{ all -> 0x00a6 }
        r0 = r5[r9];	 Catch:{ all -> 0x00a6 }
        r10.zzajx = r0;	 Catch:{ all -> 0x00a6 }
        r5 = r4.zzbjt;	 Catch:{ all -> 0x00a6 }
        r9 = r4.zzbjw;	 Catch:{ all -> 0x00a6 }
        r5 = r5[r9];	 Catch:{ all -> 0x00a6 }
        r10.zzbbj = r5;	 Catch:{ all -> 0x00a6 }
        r0 = r4.zzbjy;	 Catch:{ all -> 0x00a6 }
        r5 = r6.zzaga;	 Catch:{ all -> 0x00a6 }
        r5 = java.lang.Math.max(r0, r5);	 Catch:{ all -> 0x00a6 }
        r4.zzbjy = r5;	 Catch:{ all -> 0x00a6 }
        r5 = r4.length;	 Catch:{ all -> 0x00a6 }
        r5 = r5 - r8;
        r4.length = r5;	 Catch:{ all -> 0x00a6 }
        r5 = r4.zzbjw;	 Catch:{ all -> 0x00a6 }
        r5 = r5 + r8;
        r4.zzbjw = r5;	 Catch:{ all -> 0x00a6 }
        r5 = r4.zzbjv;	 Catch:{ all -> 0x00a6 }
        r5 = r5 + r8;
        r4.zzbjv = r5;	 Catch:{ all -> 0x00a6 }
        r5 = r4.zzbjw;	 Catch:{ all -> 0x00a6 }
        r6 = r4.zzajq;	 Catch:{ all -> 0x00a6 }
        if (r5 != r6) goto L_0x0086;
    L_0x0084:
        r4.zzbjw = r7;	 Catch:{ all -> 0x00a6 }
    L_0x0086:
        r5 = r4.length;	 Catch:{ all -> 0x00a6 }
        if (r5 <= 0) goto L_0x0092;
    L_0x008a:
        r5 = r4.zzahq;	 Catch:{ all -> 0x00a6 }
        r6 = r4.zzbjw;	 Catch:{ all -> 0x00a6 }
        r6 = r5[r6];	 Catch:{ all -> 0x00a6 }
        r5 = r6;
        goto L_0x0098;
    L_0x0092:
        r5 = r10.zzajx;	 Catch:{ all -> 0x00a6 }
        r7 = r10.size;	 Catch:{ all -> 0x00a6 }
        r7 = (long) r7;	 Catch:{ all -> 0x00a6 }
        r5 = r5 + r7;
    L_0x0098:
        r10.zzbkd = r5;	 Catch:{ all -> 0x00a6 }
        monitor-exit(r4);
        return r3;
    L_0x009c:
        r6 = r4.zzbju;	 Catch:{ all -> 0x00a6 }
        r7 = r4.zzbjw;	 Catch:{ all -> 0x00a6 }
        r6 = r6[r7];	 Catch:{ all -> 0x00a6 }
        r5.zzaue = r6;	 Catch:{ all -> 0x00a6 }
        monitor-exit(r4);
        return r1;
    L_0x00a6:
        r5 = move-exception;
        monitor-exit(r4);
        throw r5;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzqr.zza(com.google.android.gms.internal.ads.zzlj, com.google.android.gms.internal.ads.zznd, boolean, boolean, com.google.android.gms.internal.ads.zzlh, com.google.android.gms.internal.ads.zzqs):int");
    }

    public final synchronized long zzjm() {
        if (!zzjk()) {
            return -1;
        }
        int i = ((this.zzbjw + this.length) - 1) % this.zzajq;
        this.zzbjw = (this.zzbjw + this.length) % this.zzajq;
        this.zzbjv += this.length;
        this.length = 0;
        return this.zzahq[i] + ((long) this.zzahp[i]);
    }

    public final synchronized boolean zzg(zzlh zzlh) {
        if (zzlh == null) {
            this.zzbkb = true;
            return false;
        }
        this.zzbkb = false;
        if (zzsy.zza(zzlh, this.zzbkc)) {
            return false;
        }
        this.zzbkc = zzlh;
        return true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized void zza(long r6, int r8, long r9, int r11, com.google.android.gms.internal.ads.zznx r12) {
        /*
        r5 = this;
        monitor-enter(r5);
        r0 = r5.zzbka;	 Catch:{ all -> 0x00eb }
        r1 = 0;
        if (r0 == 0) goto L_0x000e;
    L_0x0006:
        r0 = r8 & 1;
        if (r0 != 0) goto L_0x000c;
    L_0x000a:
        monitor-exit(r5);
        return;
    L_0x000c:
        r5.zzbka = r1;	 Catch:{ all -> 0x00eb }
    L_0x000e:
        r0 = r5.zzbkb;	 Catch:{ all -> 0x00eb }
        r2 = 1;
        if (r0 != 0) goto L_0x0015;
    L_0x0013:
        r0 = 1;
        goto L_0x0016;
    L_0x0015:
        r0 = 0;
    L_0x0016:
        com.google.android.gms.internal.ads.zzsk.checkState(r0);	 Catch:{ all -> 0x00eb }
        r5.zzep(r6);	 Catch:{ all -> 0x00eb }
        r0 = r5.zzahs;	 Catch:{ all -> 0x00eb }
        r3 = r5.zzbjx;	 Catch:{ all -> 0x00eb }
        r0[r3] = r6;	 Catch:{ all -> 0x00eb }
        r6 = r5.zzahq;	 Catch:{ all -> 0x00eb }
        r7 = r5.zzbjx;	 Catch:{ all -> 0x00eb }
        r6[r7] = r9;	 Catch:{ all -> 0x00eb }
        r6 = r5.zzahp;	 Catch:{ all -> 0x00eb }
        r7 = r5.zzbjx;	 Catch:{ all -> 0x00eb }
        r6[r7] = r11;	 Catch:{ all -> 0x00eb }
        r6 = r5.zzajr;	 Catch:{ all -> 0x00eb }
        r7 = r5.zzbjx;	 Catch:{ all -> 0x00eb }
        r6[r7] = r8;	 Catch:{ all -> 0x00eb }
        r6 = r5.zzbjt;	 Catch:{ all -> 0x00eb }
        r7 = r5.zzbjx;	 Catch:{ all -> 0x00eb }
        r6[r7] = r12;	 Catch:{ all -> 0x00eb }
        r6 = r5.zzbju;	 Catch:{ all -> 0x00eb }
        r7 = r5.zzbjx;	 Catch:{ all -> 0x00eb }
        r8 = r5.zzbkc;	 Catch:{ all -> 0x00eb }
        r6[r7] = r8;	 Catch:{ all -> 0x00eb }
        r6 = r5.zzbjs;	 Catch:{ all -> 0x00eb }
        r7 = r5.zzbjx;	 Catch:{ all -> 0x00eb }
        r6[r7] = r1;	 Catch:{ all -> 0x00eb }
        r6 = r5.length;	 Catch:{ all -> 0x00eb }
        r6 = r6 + r2;
        r5.length = r6;	 Catch:{ all -> 0x00eb }
        r6 = r5.length;	 Catch:{ all -> 0x00eb }
        r7 = r5.zzajq;	 Catch:{ all -> 0x00eb }
        if (r6 != r7) goto L_0x00dc;
    L_0x0053:
        r6 = r5.zzajq;	 Catch:{ all -> 0x00eb }
        r6 = r6 + 1000;
        r7 = new int[r6];	 Catch:{ all -> 0x00eb }
        r8 = new long[r6];	 Catch:{ all -> 0x00eb }
        r9 = new long[r6];	 Catch:{ all -> 0x00eb }
        r10 = new int[r6];	 Catch:{ all -> 0x00eb }
        r11 = new int[r6];	 Catch:{ all -> 0x00eb }
        r12 = new com.google.android.gms.internal.ads.zznx[r6];	 Catch:{ all -> 0x00eb }
        r0 = new com.google.android.gms.internal.ads.zzlh[r6];	 Catch:{ all -> 0x00eb }
        r2 = r5.zzajq;	 Catch:{ all -> 0x00eb }
        r3 = r5.zzbjw;	 Catch:{ all -> 0x00eb }
        r2 = r2 - r3;
        r3 = r5.zzahq;	 Catch:{ all -> 0x00eb }
        r4 = r5.zzbjw;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r3, r4, r8, r1, r2);	 Catch:{ all -> 0x00eb }
        r3 = r5.zzahs;	 Catch:{ all -> 0x00eb }
        r4 = r5.zzbjw;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r3, r4, r9, r1, r2);	 Catch:{ all -> 0x00eb }
        r3 = r5.zzajr;	 Catch:{ all -> 0x00eb }
        r4 = r5.zzbjw;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r3, r4, r10, r1, r2);	 Catch:{ all -> 0x00eb }
        r3 = r5.zzahp;	 Catch:{ all -> 0x00eb }
        r4 = r5.zzbjw;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r3, r4, r11, r1, r2);	 Catch:{ all -> 0x00eb }
        r3 = r5.zzbjt;	 Catch:{ all -> 0x00eb }
        r4 = r5.zzbjw;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r3, r4, r12, r1, r2);	 Catch:{ all -> 0x00eb }
        r3 = r5.zzbju;	 Catch:{ all -> 0x00eb }
        r4 = r5.zzbjw;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r3, r4, r0, r1, r2);	 Catch:{ all -> 0x00eb }
        r3 = r5.zzbjs;	 Catch:{ all -> 0x00eb }
        r4 = r5.zzbjw;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r3, r4, r7, r1, r2);	 Catch:{ all -> 0x00eb }
        r3 = r5.zzbjw;	 Catch:{ all -> 0x00eb }
        r4 = r5.zzahq;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r4, r1, r8, r2, r3);	 Catch:{ all -> 0x00eb }
        r4 = r5.zzahs;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r4, r1, r9, r2, r3);	 Catch:{ all -> 0x00eb }
        r4 = r5.zzajr;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r4, r1, r10, r2, r3);	 Catch:{ all -> 0x00eb }
        r4 = r5.zzahp;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r4, r1, r11, r2, r3);	 Catch:{ all -> 0x00eb }
        r4 = r5.zzbjt;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r4, r1, r12, r2, r3);	 Catch:{ all -> 0x00eb }
        r4 = r5.zzbju;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r4, r1, r0, r2, r3);	 Catch:{ all -> 0x00eb }
        r4 = r5.zzbjs;	 Catch:{ all -> 0x00eb }
        java.lang.System.arraycopy(r4, r1, r7, r2, r3);	 Catch:{ all -> 0x00eb }
        r5.zzahq = r8;	 Catch:{ all -> 0x00eb }
        r5.zzahs = r9;	 Catch:{ all -> 0x00eb }
        r5.zzajr = r10;	 Catch:{ all -> 0x00eb }
        r5.zzahp = r11;	 Catch:{ all -> 0x00eb }
        r5.zzbjt = r12;	 Catch:{ all -> 0x00eb }
        r5.zzbju = r0;	 Catch:{ all -> 0x00eb }
        r5.zzbjs = r7;	 Catch:{ all -> 0x00eb }
        r5.zzbjw = r1;	 Catch:{ all -> 0x00eb }
        r7 = r5.zzajq;	 Catch:{ all -> 0x00eb }
        r5.zzbjx = r7;	 Catch:{ all -> 0x00eb }
        r7 = r5.zzajq;	 Catch:{ all -> 0x00eb }
        r5.length = r7;	 Catch:{ all -> 0x00eb }
        r5.zzajq = r6;	 Catch:{ all -> 0x00eb }
        monitor-exit(r5);
        return;
    L_0x00dc:
        r6 = r5.zzbjx;	 Catch:{ all -> 0x00eb }
        r6 = r6 + r2;
        r5.zzbjx = r6;	 Catch:{ all -> 0x00eb }
        r6 = r5.zzbjx;	 Catch:{ all -> 0x00eb }
        r7 = r5.zzajq;	 Catch:{ all -> 0x00eb }
        if (r6 != r7) goto L_0x00e9;
    L_0x00e7:
        r5.zzbjx = r1;	 Catch:{ all -> 0x00eb }
    L_0x00e9:
        monitor-exit(r5);
        return;
    L_0x00eb:
        r6 = move-exception;
        monitor-exit(r5);
        throw r6;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ads.zzqr.zza(long, int, long, int, com.google.android.gms.internal.ads.zznx):void");
    }

    public final synchronized void zzep(long j) {
        this.zzbjz = Math.max(this.zzbjz, j);
    }
}
