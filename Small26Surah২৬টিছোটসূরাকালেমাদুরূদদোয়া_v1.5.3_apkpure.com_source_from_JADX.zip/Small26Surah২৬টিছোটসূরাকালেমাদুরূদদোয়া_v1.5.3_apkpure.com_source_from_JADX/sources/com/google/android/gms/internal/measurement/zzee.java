package com.google.android.gms.internal.measurement;

import java.io.IOException;
import java.util.List;

final class zzee implements zzgx {
    private int tag;
    private final zzeb zzacr;
    private int zzacs;
    private int zzact = 0;

    public static zzee zza(zzeb zzeb) {
        if (zzeb.zzack != null) {
            return zzeb.zzack;
        }
        return new zzee(zzeb);
    }

    private final void zza(java.util.List<java.lang.String> r3, boolean r4) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:25:0x0056 in {8, 12, 14, 15, 18, 22, 24} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r2 = this;
        r0 = r2.tag;
        r0 = r0 & 7;
        r1 = 2;
        if (r0 != r1) goto L_0x0051;
    L_0x0007:
        r0 = r3 instanceof com.google.android.gms.internal.measurement.zzfq;
        if (r0 == 0) goto L_0x002d;
    L_0x000b:
        if (r4 != 0) goto L_0x002d;
    L_0x000d:
        r0 = r3;
        r0 = (com.google.android.gms.internal.measurement.zzfq) r0;
    L_0x0010:
        r3 = r2.zzkr();
        r0.zzc(r3);
        r3 = r2.zzacr;
        r3 = r3.zzkz();
        if (r3 == 0) goto L_0x0020;
    L_0x001f:
        return;
    L_0x0020:
        r3 = r2.zzacr;
        r3 = r3.zzkj();
        r4 = r2.tag;
        if (r3 == r4) goto L_0x0010;
    L_0x002a:
        r2.zzact = r3;
        return;
    L_0x002d:
        if (r4 == 0) goto L_0x0034;
    L_0x002f:
        r0 = r2.zzkq();
        goto L_0x0038;
    L_0x0034:
        r0 = r2.readString();
    L_0x0038:
        r3.add(r0);
        r0 = r2.zzacr;
        r0 = r0.zzkz();
        if (r0 == 0) goto L_0x0044;
    L_0x0043:
        return;
    L_0x0044:
        r0 = r2.zzacr;
        r0 = r0.zzkj();
        r1 = r2.tag;
        if (r0 == r1) goto L_0x002d;
    L_0x004e:
        r2.zzact = r0;
        return;
    L_0x0051:
        r3 = com.google.android.gms.internal.measurement.zzfh.zzmz();
        throw r3;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzee.zza(java.util.List, boolean):void");
    }

    public final <T> void zza(java.util.List<T> r4, com.google.android.gms.internal.measurement.zzgy<T> r5, com.google.android.gms.internal.measurement.zzem r6) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:13:0x002b in {6, 9, 10, 12} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r3 = this;
        r0 = r3.tag;
        r1 = r0 & 7;
        r2 = 2;
        if (r1 != r2) goto L_0x0026;
    L_0x0007:
        r1 = r3.zzc(r5, r6);
        r4.add(r1);
        r1 = r3.zzacr;
        r1 = r1.zzkz();
        if (r1 != 0) goto L_0x0025;
    L_0x0016:
        r1 = r3.zzact;
        if (r1 == 0) goto L_0x001b;
    L_0x001a:
        goto L_0x0025;
    L_0x001b:
        r1 = r3.zzacr;
        r1 = r1.zzkj();
        if (r1 == r0) goto L_0x0007;
    L_0x0023:
        r3.zzact = r1;
    L_0x0025:
        return;
    L_0x0026:
        r4 = com.google.android.gms.internal.measurement.zzfh.zzmz();
        throw r4;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzee.zza(java.util.List, com.google.android.gms.internal.measurement.zzgy, com.google.android.gms.internal.measurement.zzem):void");
    }

    public final <K, V> void zza(java.util.Map<K, V> r8, com.google.android.gms.internal.measurement.zzga<K, V> r9, com.google.android.gms.internal.measurement.zzem r10) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:30:0x006b in {12, 14, 15, 17, 21, 23, 26, 29} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r7 = this;
        r0 = 2;
        r7.zzab(r0);
        r1 = r7.zzacr;
        r1 = r1.zzks();
        r2 = r7.zzacr;
        r1 = r2.zzx(r1);
        r2 = r9.zzait;
        r3 = r9.zzzw;
    L_0x0014:
        r4 = r7.zzlh();	 Catch:{ all -> 0x0064 }
        r5 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;	 Catch:{ all -> 0x0064 }
        if (r4 == r5) goto L_0x005b;	 Catch:{ all -> 0x0064 }
    L_0x001d:
        r5 = r7.zzacr;	 Catch:{ all -> 0x0064 }
        r5 = r5.zzkz();	 Catch:{ all -> 0x0064 }
        if (r5 != 0) goto L_0x005b;
    L_0x0025:
        r5 = 1;
        r6 = "Unable to parse map entry.";
        if (r4 == r5) goto L_0x0046;
    L_0x002a:
        if (r4 == r0) goto L_0x0039;
    L_0x002c:
        r4 = r7.zzli();	 Catch:{ zzfi -> 0x004e }
        if (r4 == 0) goto L_0x0033;	 Catch:{ zzfi -> 0x004e }
    L_0x0032:
        goto L_0x0014;	 Catch:{ zzfi -> 0x004e }
    L_0x0033:
        r4 = new com.google.android.gms.internal.measurement.zzfh;	 Catch:{ zzfi -> 0x004e }
        r4.<init>(r6);	 Catch:{ zzfi -> 0x004e }
        throw r4;	 Catch:{ zzfi -> 0x004e }
    L_0x0039:
        r4 = r9.zzaiu;	 Catch:{ zzfi -> 0x004e }
        r5 = r9.zzzw;	 Catch:{ zzfi -> 0x004e }
        r5 = r5.getClass();	 Catch:{ zzfi -> 0x004e }
        r3 = r7.zza(r4, r5, r10);	 Catch:{ zzfi -> 0x004e }
        goto L_0x0014;	 Catch:{ zzfi -> 0x004e }
    L_0x0046:
        r4 = r9.zzais;	 Catch:{ zzfi -> 0x004e }
        r5 = 0;	 Catch:{ zzfi -> 0x004e }
        r2 = r7.zza(r4, r5, r5);	 Catch:{ zzfi -> 0x004e }
        goto L_0x0014;
    L_0x004e:
        r4 = r7.zzli();	 Catch:{ all -> 0x0064 }
        if (r4 == 0) goto L_0x0055;	 Catch:{ all -> 0x0064 }
    L_0x0054:
        goto L_0x0014;	 Catch:{ all -> 0x0064 }
    L_0x0055:
        r8 = new com.google.android.gms.internal.measurement.zzfh;	 Catch:{ all -> 0x0064 }
        r8.<init>(r6);	 Catch:{ all -> 0x0064 }
        throw r8;	 Catch:{ all -> 0x0064 }
    L_0x005b:
        r8.put(r2, r3);	 Catch:{ all -> 0x0064 }
        r8 = r7.zzacr;
        r8.zzy(r1);
        return;
    L_0x0064:
        r8 = move-exception;
        r9 = r7.zzacr;
        r9.zzy(r1);
        throw r8;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzee.zza(java.util.Map, com.google.android.gms.internal.measurement.zzga, com.google.android.gms.internal.measurement.zzem):void");
    }

    public final <T> void zzb(java.util.List<T> r4, com.google.android.gms.internal.measurement.zzgy<T> r5, com.google.android.gms.internal.measurement.zzem r6) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:13:0x002b in {6, 9, 10, 12} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r3 = this;
        r0 = r3.tag;
        r1 = r0 & 7;
        r2 = 3;
        if (r1 != r2) goto L_0x0026;
    L_0x0007:
        r1 = r3.zzd(r5, r6);
        r4.add(r1);
        r1 = r3.zzacr;
        r1 = r1.zzkz();
        if (r1 != 0) goto L_0x0025;
    L_0x0016:
        r1 = r3.zzact;
        if (r1 == 0) goto L_0x001b;
    L_0x001a:
        goto L_0x0025;
    L_0x001b:
        r1 = r3.zzacr;
        r1 = r1.zzkj();
        if (r1 == r0) goto L_0x0007;
    L_0x0023:
        r3.zzact = r1;
    L_0x0025:
        return;
    L_0x0026:
        r4 = com.google.android.gms.internal.measurement.zzfh.zzmz();
        throw r4;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzee.zzb(java.util.List, com.google.android.gms.internal.measurement.zzgy, com.google.android.gms.internal.measurement.zzem):void");
    }

    public final void zzm(java.util.List<com.google.android.gms.internal.measurement.zzdp> r3) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:11:0x0029 in {4, 8, 10} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.visit(BlockProcessor.java:38)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:56)
	at jadx.core.ProcessClass.process(ProcessClass.java:39)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:282)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler.lambda$appendSourcesSave$0(JadxDecompiler.java:200)
	at jadx.api.JadxDecompiler$$Lambda$8/1484171695.run(Unknown Source)
*/
        /*
        r2 = this;
        r0 = r2.tag;
        r0 = r0 & 7;
        r1 = 2;
        if (r0 != r1) goto L_0x0024;
    L_0x0007:
        r0 = r2.zzkr();
        r3.add(r0);
        r0 = r2.zzacr;
        r0 = r0.zzkz();
        if (r0 == 0) goto L_0x0017;
    L_0x0016:
        return;
    L_0x0017:
        r0 = r2.zzacr;
        r0 = r0.zzkj();
        r1 = r2.tag;
        if (r0 == r1) goto L_0x0007;
    L_0x0021:
        r2.zzact = r0;
        return;
    L_0x0024:
        r3 = com.google.android.gms.internal.measurement.zzfh.zzmz();
        throw r3;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.measurement.zzee.zzm(java.util.List):void");
    }

    private zzee(zzeb zzeb) {
        this.zzacr = (zzeb) zzfb.zza((Object) zzeb, "input");
        this.zzacr.zzack = this;
    }

    public final int zzlh() throws IOException {
        int i = this.zzact;
        if (i != 0) {
            this.tag = i;
            this.zzact = 0;
        } else {
            this.tag = this.zzacr.zzkj();
        }
        i = this.tag;
        if (i != 0) {
            if (i != this.zzacs) {
                return i >>> 3;
            }
        }
        return Integer.MAX_VALUE;
    }

    public final int getTag() {
        return this.tag;
    }

    public final boolean zzli() throws IOException {
        if (!this.zzacr.zzkz()) {
            int i = this.tag;
            if (i != this.zzacs) {
                return this.zzacr.zzv(i);
            }
        }
        return false;
    }

    private final void zzab(int i) throws IOException {
        if ((this.tag & 7) != i) {
            throw zzfh.zzmz();
        }
    }

    public final double readDouble() throws IOException {
        zzab(1);
        return this.zzacr.readDouble();
    }

    public final float readFloat() throws IOException {
        zzab(5);
        return this.zzacr.readFloat();
    }

    public final long zzkk() throws IOException {
        zzab(0);
        return this.zzacr.zzkk();
    }

    public final long zzkl() throws IOException {
        zzab(0);
        return this.zzacr.zzkl();
    }

    public final int zzkm() throws IOException {
        zzab(0);
        return this.zzacr.zzkm();
    }

    public final long zzkn() throws IOException {
        zzab(1);
        return this.zzacr.zzkn();
    }

    public final int zzko() throws IOException {
        zzab(5);
        return this.zzacr.zzko();
    }

    public final boolean zzkp() throws IOException {
        zzab(0);
        return this.zzacr.zzkp();
    }

    public final String readString() throws IOException {
        zzab(2);
        return this.zzacr.readString();
    }

    public final String zzkq() throws IOException {
        zzab(2);
        return this.zzacr.zzkq();
    }

    public final <T> T zza(zzgy<T> zzgy, zzem zzem) throws IOException {
        zzab(2);
        return zzc(zzgy, zzem);
    }

    public final <T> T zzb(zzgy<T> zzgy, zzem zzem) throws IOException {
        zzab(3);
        return zzd(zzgy, zzem);
    }

    private final <T> T zzc(zzgy<T> zzgy, zzem zzem) throws IOException {
        int zzks = this.zzacr.zzks();
        if (this.zzacr.zzach < this.zzacr.zzaci) {
            zzks = this.zzacr.zzx(zzks);
            T newInstance = zzgy.newInstance();
            zzeb zzeb = this.zzacr;
            zzeb.zzach++;
            zzgy.zza(newInstance, this, zzem);
            zzgy.zzi(newInstance);
            this.zzacr.zzu(null);
            zzgy = this.zzacr;
            zzgy.zzach--;
            this.zzacr.zzy(zzks);
            return newInstance;
        }
        throw zzfh.zzna();
    }

    private final <T> T zzd(zzgy<T> zzgy, zzem zzem) throws IOException {
        int i = this.zzacs;
        T t = ((this.tag >>> 3) << 3) | 4;
        this.zzacs = t;
        try {
            t = zzgy.newInstance();
            zzgy.zza(t, this, zzem);
            zzgy.zzi(t);
            if (this.tag == this.zzacs) {
                return t;
            }
            throw zzfh.zznb();
        } finally {
            this.zzacs = i;
        }
    }

    public final zzdp zzkr() throws IOException {
        zzab(2);
        return this.zzacr.zzkr();
    }

    public final int zzks() throws IOException {
        zzab(0);
        return this.zzacr.zzks();
    }

    public final int zzkt() throws IOException {
        zzab(0);
        return this.zzacr.zzkt();
    }

    public final int zzku() throws IOException {
        zzab(5);
        return this.zzacr.zzku();
    }

    public final long zzkv() throws IOException {
        zzab(1);
        return this.zzacr.zzkv();
    }

    public final int zzkw() throws IOException {
        zzab(0);
        return this.zzacr.zzkw();
    }

    public final long zzkx() throws IOException {
        zzab(0);
        return this.zzacr.zzkx();
    }

    public final void zzd(List<Double> list) throws IOException {
        int zzla;
        if (list instanceof zzej) {
            zzej zzej = (zzej) list;
            list = this.tag & 7;
            if (list == 1) {
                do {
                    zzej.zzf(this.zzacr.readDouble());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else if (list == 2) {
                list = this.zzacr.zzks();
                zzac(list);
                zzla = this.zzacr.zzla() + list;
                do {
                    zzej.zzf(this.zzacr.readDouble());
                } while (this.zzacr.zzla() < zzla);
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 1) {
            do {
                list.add(Double.valueOf(this.zzacr.readDouble()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else if (i == 2) {
            i = this.zzacr.zzks();
            zzac(i);
            zzla = this.zzacr.zzla() + i;
            do {
                list.add(Double.valueOf(this.zzacr.readDouble()));
            } while (this.zzacr.zzla() < zzla);
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zze(List<Float> list) throws IOException {
        if (list instanceof zzew) {
            zzew zzew = (zzew) list;
            list = this.tag & 7;
            if (list == 2) {
                list = this.zzacr.zzks();
                zzad(list);
                int zzla = this.zzacr.zzla() + list;
                do {
                    zzew.zzc(this.zzacr.readFloat());
                } while (this.zzacr.zzla() < zzla);
                return;
            } else if (list == 5) {
                do {
                    zzew.zzc(this.zzacr.readFloat());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 2) {
            i = this.zzacr.zzks();
            zzad(i);
            int zzla2 = this.zzacr.zzla() + i;
            do {
                list.add(Float.valueOf(this.zzacr.readFloat()));
            } while (this.zzacr.zzla() < zzla2);
        } else if (i == 5) {
            do {
                list.add(Float.valueOf(this.zzacr.readFloat()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zzf(List<Long> list) throws IOException {
        int zzla;
        if (list instanceof zzfv) {
            zzfv zzfv = (zzfv) list;
            list = this.tag & 7;
            if (list == null) {
                do {
                    zzfv.zzbb(this.zzacr.zzkk());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else if (list == 2) {
                zzla = this.zzacr.zzla() + this.zzacr.zzks();
                do {
                    zzfv.zzbb(this.zzacr.zzkk());
                } while (this.zzacr.zzla() < zzla);
                zzae(zzla);
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 0) {
            do {
                list.add(Long.valueOf(this.zzacr.zzkk()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else if (i == 2) {
            zzla = this.zzacr.zzla() + this.zzacr.zzks();
            do {
                list.add(Long.valueOf(this.zzacr.zzkk()));
            } while (this.zzacr.zzla() < zzla);
            zzae(zzla);
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zzg(List<Long> list) throws IOException {
        int zzla;
        if (list instanceof zzfv) {
            zzfv zzfv = (zzfv) list;
            list = this.tag & 7;
            if (list == null) {
                do {
                    zzfv.zzbb(this.zzacr.zzkl());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else if (list == 2) {
                zzla = this.zzacr.zzla() + this.zzacr.zzks();
                do {
                    zzfv.zzbb(this.zzacr.zzkl());
                } while (this.zzacr.zzla() < zzla);
                zzae(zzla);
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 0) {
            do {
                list.add(Long.valueOf(this.zzacr.zzkl()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else if (i == 2) {
            zzla = this.zzacr.zzla() + this.zzacr.zzks();
            do {
                list.add(Long.valueOf(this.zzacr.zzkl()));
            } while (this.zzacr.zzla() < zzla);
            zzae(zzla);
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zzh(List<Integer> list) throws IOException {
        if (list instanceof zzfa) {
            zzfa zzfa = (zzfa) list;
            list = this.tag & 7;
            if (list == null) {
                do {
                    zzfa.zzau(this.zzacr.zzkm());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else if (list == 2) {
                int zzla;
                zzla = this.zzacr.zzla() + this.zzacr.zzks();
                do {
                    zzfa.zzau(this.zzacr.zzkm());
                } while (this.zzacr.zzla() < zzla);
                zzae(zzla);
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 0) {
            do {
                list.add(Integer.valueOf(this.zzacr.zzkm()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else if (i == 2) {
            zzla = this.zzacr.zzla() + this.zzacr.zzks();
            do {
                list.add(Integer.valueOf(this.zzacr.zzkm()));
            } while (this.zzacr.zzla() < zzla);
            zzae(zzla);
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zzi(List<Long> list) throws IOException {
        int zzla;
        if (list instanceof zzfv) {
            zzfv zzfv = (zzfv) list;
            list = this.tag & 7;
            if (list == 1) {
                do {
                    zzfv.zzbb(this.zzacr.zzkn());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else if (list == 2) {
                list = this.zzacr.zzks();
                zzac(list);
                zzla = this.zzacr.zzla() + list;
                do {
                    zzfv.zzbb(this.zzacr.zzkn());
                } while (this.zzacr.zzla() < zzla);
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 1) {
            do {
                list.add(Long.valueOf(this.zzacr.zzkn()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else if (i == 2) {
            i = this.zzacr.zzks();
            zzac(i);
            zzla = this.zzacr.zzla() + i;
            do {
                list.add(Long.valueOf(this.zzacr.zzkn()));
            } while (this.zzacr.zzla() < zzla);
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zzj(List<Integer> list) throws IOException {
        if (list instanceof zzfa) {
            zzfa zzfa = (zzfa) list;
            list = this.tag & 7;
            if (list == 2) {
                list = this.zzacr.zzks();
                zzad(list);
                int zzla = this.zzacr.zzla() + list;
                do {
                    zzfa.zzau(this.zzacr.zzko());
                } while (this.zzacr.zzla() < zzla);
                return;
            } else if (list == 5) {
                do {
                    zzfa.zzau(this.zzacr.zzko());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 2) {
            i = this.zzacr.zzks();
            zzad(i);
            int zzla2 = this.zzacr.zzla() + i;
            do {
                list.add(Integer.valueOf(this.zzacr.zzko()));
            } while (this.zzacr.zzla() < zzla2);
        } else if (i == 5) {
            do {
                list.add(Integer.valueOf(this.zzacr.zzko()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zzk(List<Boolean> list) throws IOException {
        int zzla;
        if (list instanceof zzdn) {
            zzdn zzdn = (zzdn) list;
            list = this.tag & 7;
            if (list == null) {
                do {
                    zzdn.addBoolean(this.zzacr.zzkp());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else if (list == 2) {
                zzla = this.zzacr.zzla() + this.zzacr.zzks();
                do {
                    zzdn.addBoolean(this.zzacr.zzkp());
                } while (this.zzacr.zzla() < zzla);
                zzae(zzla);
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 0) {
            do {
                list.add(Boolean.valueOf(this.zzacr.zzkp()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else if (i == 2) {
            zzla = this.zzacr.zzla() + this.zzacr.zzks();
            do {
                list.add(Boolean.valueOf(this.zzacr.zzkp()));
            } while (this.zzacr.zzla() < zzla);
            zzae(zzla);
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void readStringList(List<String> list) throws IOException {
        zza((List) list, false);
    }

    public final void zzl(List<String> list) throws IOException {
        zza((List) list, true);
    }

    public final void zzn(List<Integer> list) throws IOException {
        if (list instanceof zzfa) {
            zzfa zzfa = (zzfa) list;
            list = this.tag & 7;
            if (list == null) {
                do {
                    zzfa.zzau(this.zzacr.zzks());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else if (list == 2) {
                int zzla;
                zzla = this.zzacr.zzla() + this.zzacr.zzks();
                do {
                    zzfa.zzau(this.zzacr.zzks());
                } while (this.zzacr.zzla() < zzla);
                zzae(zzla);
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 0) {
            do {
                list.add(Integer.valueOf(this.zzacr.zzks()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else if (i == 2) {
            zzla = this.zzacr.zzla() + this.zzacr.zzks();
            do {
                list.add(Integer.valueOf(this.zzacr.zzks()));
            } while (this.zzacr.zzla() < zzla);
            zzae(zzla);
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zzo(List<Integer> list) throws IOException {
        if (list instanceof zzfa) {
            zzfa zzfa = (zzfa) list;
            list = this.tag & 7;
            if (list == null) {
                do {
                    zzfa.zzau(this.zzacr.zzkt());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else if (list == 2) {
                int zzla;
                zzla = this.zzacr.zzla() + this.zzacr.zzks();
                do {
                    zzfa.zzau(this.zzacr.zzkt());
                } while (this.zzacr.zzla() < zzla);
                zzae(zzla);
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 0) {
            do {
                list.add(Integer.valueOf(this.zzacr.zzkt()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else if (i == 2) {
            zzla = this.zzacr.zzla() + this.zzacr.zzks();
            do {
                list.add(Integer.valueOf(this.zzacr.zzkt()));
            } while (this.zzacr.zzla() < zzla);
            zzae(zzla);
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zzp(List<Integer> list) throws IOException {
        if (list instanceof zzfa) {
            zzfa zzfa = (zzfa) list;
            list = this.tag & 7;
            if (list == 2) {
                list = this.zzacr.zzks();
                zzad(list);
                int zzla = this.zzacr.zzla() + list;
                do {
                    zzfa.zzau(this.zzacr.zzku());
                } while (this.zzacr.zzla() < zzla);
                return;
            } else if (list == 5) {
                do {
                    zzfa.zzau(this.zzacr.zzku());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 2) {
            i = this.zzacr.zzks();
            zzad(i);
            int zzla2 = this.zzacr.zzla() + i;
            do {
                list.add(Integer.valueOf(this.zzacr.zzku()));
            } while (this.zzacr.zzla() < zzla2);
        } else if (i == 5) {
            do {
                list.add(Integer.valueOf(this.zzacr.zzku()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zzq(List<Long> list) throws IOException {
        int zzla;
        if (list instanceof zzfv) {
            zzfv zzfv = (zzfv) list;
            list = this.tag & 7;
            if (list == 1) {
                do {
                    zzfv.zzbb(this.zzacr.zzkv());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else if (list == 2) {
                list = this.zzacr.zzks();
                zzac(list);
                zzla = this.zzacr.zzla() + list;
                do {
                    zzfv.zzbb(this.zzacr.zzkv());
                } while (this.zzacr.zzla() < zzla);
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 1) {
            do {
                list.add(Long.valueOf(this.zzacr.zzkv()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else if (i == 2) {
            i = this.zzacr.zzks();
            zzac(i);
            zzla = this.zzacr.zzla() + i;
            do {
                list.add(Long.valueOf(this.zzacr.zzkv()));
            } while (this.zzacr.zzla() < zzla);
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zzr(List<Integer> list) throws IOException {
        int zzla;
        if (list instanceof zzfa) {
            zzfa zzfa = (zzfa) list;
            list = this.tag & 7;
            if (list == null) {
                do {
                    zzfa.zzau(this.zzacr.zzkw());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else if (list == 2) {
                zzla = this.zzacr.zzla() + this.zzacr.zzks();
                do {
                    zzfa.zzau(this.zzacr.zzkw());
                } while (this.zzacr.zzla() < zzla);
                zzae(zzla);
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 0) {
            do {
                list.add(Integer.valueOf(this.zzacr.zzkw()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else if (i == 2) {
            zzla = this.zzacr.zzla() + this.zzacr.zzks();
            do {
                list.add(Integer.valueOf(this.zzacr.zzkw()));
            } while (this.zzacr.zzla() < zzla);
            zzae(zzla);
        } else {
            throw zzfh.zzmz();
        }
    }

    public final void zzs(List<Long> list) throws IOException {
        if (list instanceof zzfv) {
            zzfv zzfv = (zzfv) list;
            list = this.tag & 7;
            if (list == null) {
                do {
                    zzfv.zzbb(this.zzacr.zzkx());
                    if (this.zzacr.zzkz() == null) {
                        list = this.zzacr.zzkj();
                    } else {
                        return;
                    }
                } while (list == this.tag);
                this.zzact = list;
                return;
            } else if (list == 2) {
                int zzla;
                zzla = this.zzacr.zzla() + this.zzacr.zzks();
                do {
                    zzfv.zzbb(this.zzacr.zzkx());
                } while (this.zzacr.zzla() < zzla);
                zzae(zzla);
                return;
            } else {
                throw zzfh.zzmz();
            }
        }
        int i = this.tag & 7;
        if (i == 0) {
            do {
                list.add(Long.valueOf(this.zzacr.zzkx()));
                if (!this.zzacr.zzkz()) {
                    i = this.zzacr.zzkj();
                } else {
                    return;
                }
            } while (i == this.tag);
            this.zzact = i;
        } else if (i == 2) {
            zzla = this.zzacr.zzla() + this.zzacr.zzks();
            do {
                list.add(Long.valueOf(this.zzacr.zzkx()));
            } while (this.zzacr.zzla() < zzla);
            zzae(zzla);
        } else {
            throw zzfh.zzmz();
        }
    }

    private static void zzac(int i) throws IOException {
        if ((i & 7) != 0) {
            throw zzfh.zznb();
        }
    }

    private final Object zza(zzif zzif, Class<?> cls, zzem zzem) throws IOException {
        switch (zzef.zzacu[zzif.ordinal()]) {
            case 1:
                return Boolean.valueOf(zzkp());
            case 2:
                return zzkr();
            case 3:
                return Double.valueOf(readDouble());
            case 4:
                return Integer.valueOf(zzkt());
            case 5:
                return Integer.valueOf(zzko());
            case 6:
                return Long.valueOf(zzkn());
            case 7:
                return Float.valueOf(readFloat());
            case 8:
                return Integer.valueOf(zzkm());
            case 9:
                return Long.valueOf(zzkl());
            case 10:
                zzab(2);
                return zzc(zzgu.zznz().zzf(cls), zzem);
            case 11:
                return Integer.valueOf(zzku());
            case 12:
                return Long.valueOf(zzkv());
            case 13:
                return Integer.valueOf(zzkw());
            case 14:
                return Long.valueOf(zzkx());
            case 15:
                return zzkq();
            case 16:
                return Integer.valueOf(zzks());
            case 17:
                return Long.valueOf(zzkk());
            default:
                throw new RuntimeException("unsupported field type.");
        }
    }

    private static void zzad(int i) throws IOException {
        if ((i & 3) != 0) {
            throw zzfh.zznb();
        }
    }

    private final void zzae(int i) throws IOException {
        if (this.zzacr.zzla() != i) {
            throw zzfh.zzmu();
        }
    }
}
