package com.google.android.gms.internal.measurement;

final /* synthetic */ class zzcm implements zzcr {
    private final zzcl zzzo;

    zzcm(zzcl zzcl) {
        this.zzzo = zzcl;
    }

    public final Object zzjn() {
        return this.zzzo.zzjm();
    }
}
