package com.google.android.gms.internal.ads;

public interface zzbej {
    void zzd(boolean z, long j);
}
