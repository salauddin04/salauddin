package com.google.android.gms.internal.ads;

public final class zzcxq {
    public final zzcxu zzfjp;

    public zzcxq(zzcxu zzcxu) {
        this.zzfjp = zzcxu;
    }
}
